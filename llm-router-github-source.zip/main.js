const { app, BrowserWindow, ipcMain, shell, clipboard, dialog, Tray, Menu, nativeImage } = require('electron');
const path = require('path');
const fs = require('fs');
const { ConfigManager } = require('./src/config');
const { Router } = require('./src/router');

// M4 修复：remote:migrate 高敏感操作全局限流/审计状态（模块级，不是实例状态）
// { calls: [...timestamps], failures: N, lockedUntil: ms }
const MIGRATE_RATE_LIMIT = { calls: [], failures: 0, lockedUntil: 0 };
const { HealthChecker } = require('./src/healthcheck');
const { ProxyServer } = require('./src/proxy');
const { ModelMemory } = require('./src/model-memory');
const { LocalEngine } = require('./src/local-engine');
const { ToolRegistry } = require('./src/tools');
const { BrainEngine } = require('./src/brain');
const { RemoteManager } = require('./src/remote');

let mainWindow;
let config;
let router;
let healthChecker;
let proxyServer;
let modelMemory;
let localEngine;
let toolRegistry;
let brain;
let remoteManager;
let isQuitting = false;
let keepAliveTimer = null;

// 系统托盘
let tray = null;

// 清理所有后台资源
function cleanupAndQuit() {
  if (isQuitting) return;
  isQuitting = true;
  if (keepAliveTimer) { clearInterval(keepAliveTimer); keepAliveTimer = null; }
  try { if (healthChecker) healthChecker.stop(); } catch (e) {}
  try { if (proxyServer) proxyServer.stop(); } catch (e) {}
  // H5 修复：退出前强制 flush 配额/统计数据（debounce 可能还差几秒才写盘）
  try { if (config && typeof config.flushNow === 'function') config.flushNow(); } catch (e) {}
  if (tray) { try { tray.destroy(); } catch (e) {} tray = null; }
  // 强制退出，防止 Express / 定时器残留进程
  setTimeout(() => app.exit(0), 200);
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 860,
    minWidth: 960,
    minHeight: 640,
    frame: false,
    transparent: false,
    backgroundColor: '#87CEEB',
    titleBarStyle: 'hidden',
    icon: path.join(__dirname, 'build/icon.png'),
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'));

  // 就绪后显示，避免白屏闪烁
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  // 打开外部链接
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  // 最小化到托盘（可配置）
  mainWindow.on('minimize', (e) => {
    if (config.get('trayMinimize') !== false && tray) {
      e.preventDefault();
      mainWindow.hide();
    }
  });

  // 托盘双击恢复
  mainWindow.on('restore', () => {
    mainWindow.show();
  });

  // 关闭：先清理后台进程，再退出
  mainWindow.on('close', (e) => {
    if (!isQuitting) {
      e.preventDefault();
      cleanupAndQuit();
    }
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

function showMainWindow() {
  if (!mainWindow || mainWindow.isDestroyed()) {
    createWindow();
    return;
  }
  if (mainWindow.isMinimized()) mainWindow.restore();
  mainWindow.show();
  mainWindow.focus();
}

/**
 * 加载应用图标（兼容 asar 内路径：优先 createFromPath，失败时读 buffer）
 */
function loadAppIcon() {
  const iconPath = path.join(__dirname, 'build/icon.png');
  let icon = nativeImage.createFromPath(iconPath);
  if (!icon.isEmpty()) return icon;
  try {
    const buf = fs.readFileSync(iconPath);
    icon = nativeImage.createFromBuffer(buf);
    if (!icon.isEmpty()) return icon;
  } catch (e) {}
  // 兜底：生成 16x16 简单图标
  return nativeImage.createFromDataURL(
    'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAaUlEQVR4nGNgGAWjYBSMgkEFGBgY/mOABTQzYIC1oX4UA0YBFQ3A1BBGo3AUjIJRMApGwSgYBaNgFIyCUTAKRsEoGAWjYBSMglEwCkbBKBgFo2AUjIJRMApGwSgYBaNgFIyCUTAKhs4AAOOKEY4ZSWcUAAAAAElFTkSuQmCC'
  );
}

/**
 * 创建系统托盘
 */
function createTray() {
  const icon = loadAppIcon();
  tray = new Tray(icon);
  tray.setToolTip('子沐智能中转路由 v3.0.2');

  const contextMenu = Menu.buildFromTemplate([
    { label: '显示主窗口', click: showMainWindow },
    { label: '重启代理', click: async () => { try { await proxyServer.restart(config.get('proxyPort')); } catch (e) {} } },
    { type: 'separator' },
    { label: '退出', click: () => cleanupAndQuit() }
  ]);
  tray.setContextMenu(contextMenu);

  // 双击托盘恢复窗口
  tray.on('double-click', showMainWindow);
  tray.on('click', showMainWindow);
}

/**
 * 强制保活：每 30 秒检查窗口和代理服务器状态
 */
function startKeepAlive() {
  if (keepAliveTimer) clearInterval(keepAliveTimer);
  keepAliveTimer = setInterval(() => {
    // 检查代理服务器
    if (proxyServer && !proxyServer.getStatus().running && !isQuitting) {
      console.log('[保活] 代理服务器已停止，尝试重启...');
      proxyServer.start(config.get('proxyPort') || 3456).catch(err => {
        console.error('[保活] 代理重启失败:', err.message);
      });
    }
    // 检查主窗口（被意外销毁时重建）
    if (!isQuitting && (!mainWindow || mainWindow.isDestroyed())) {
      console.log('[保活] 主窗口已销毁，重建...');
      createWindow();
    }
  }, 30000);
  console.log('强制保活已启动（每 30 秒检查窗口与代理状态）');
}

// ==================== IPC 处理器 ====================

// --- 配置 ---
ipcMain.handle('config:get', () => config.getAll());
ipcMain.handle('config:save', (_, data) => {
  config.save(data);
  modelMemory?.trackFeature('config_change');
  return true;
});
ipcMain.handle('config:reset', () => {
  config.reset();
  modelMemory?.trackFeature('config_change', { detail: '重置配置' });
  return true;
});

// --- 服务商 ---
ipcMain.handle('provider:add', (_, provider) => {
  const p = config.addProvider(provider);
  modelMemory?.trackFeature('provider_manage', { detail: '新增 ' + (provider.name || '') });
  return p;
});
ipcMain.handle('provider:update', (_, id, data) => {
  const p = config.updateProvider(id, data);
  modelMemory?.trackFeature('provider_manage', { detail: '修改 ' + (data.name || id) });
  return p;
});
ipcMain.handle('provider:remove', (_, id) => {
  modelMemory?.trackFeature('provider_manage', { ok: false, detail: '删除 ' + id });
  return config.removeProvider(id);
});

// --- 模型 ---
ipcMain.handle('models:fetch', async (_, providerId) => {
  return await router.fetchModels(providerId);
});

ipcMain.handle('models:fetchAll', async () => {
  return await router.fetchAllModels();
});

// --- 健康检测 ---
ipcMain.handle('health:status', () => healthChecker.getStatus());
ipcMain.handle('health:check', async () => {
  await healthChecker.checkAll();
  return healthChecker.getStatus();
});
ipcMain.handle('health:checkProvider', async (_, providerId) => {
  return await healthChecker.checkProviderById(providerId);
});

ipcMain.handle('health:restart', () => {
  if (healthChecker) {
    healthChecker.stop();
    healthChecker.start();
    return true;
  }
  return false;
});

// --- 路由测试 ---
ipcMain.handle('route:test', async (_, { model, messages, stream }) => {
  const result = await router.routeWithFallback({ model, messages, stream });
  // 非流式时附带 meta（实际模型/服务商/切换标记），供测试页展示
  if (stream && result.data?.stream) {
    return { data: result.data, meta: result.meta };
  }
  return { data: result.data, meta: result.meta };
});

// --- 代理服务器 ---
ipcMain.handle('proxy:status', () => {
  if (!proxyServer) return { running: false, port: null };
  return proxyServer.getStatus();
});

ipcMain.handle('proxy:setPort', (_, port) => {
  config.set('proxyPort', port);
  return proxyServer.restart(port);
});

ipcMain.handle('proxy:restart', () => {
  return proxyServer.restart(config.get('proxyPort'));
});

// --- 统计 ---
ipcMain.handle('stats:get', () => router.getStats());
ipcMain.handle('stats:reset', () => {
  modelMemory?.trackFeature('stats_reset');
  return router.resetStats();
});

// --- 预设渠道商（v3.0.2） ---
ipcMain.handle('presets:get', () => {
  const { PROVIDER_PRESETS } = require('./src/config');
  return PROVIDER_PRESETS;
});

// --- Trace 调用日志（v3.0.2） ---
ipcMain.handle('logs:recent', (_, filter = {}) => router.tracer.recent(filter.limit || 200, filter));
ipcMain.handle('logs:export', () => {
  modelMemory?.trackFeature('logs_export');
  return router.tracer.exportAll();
});
ipcMain.handle('logs:clear', () => {
  modelMemory?.trackFeature('logs_export', { detail: '清空' });
  router.tracer.clear();
  return true;
});
// M5 修复：trace 状态端点（暴露写盘失败次数、最后一次错误）
ipcMain.handle('logs:status', () => router.tracer?.status?.() || null);

// --- 智能模块（v3.0.2）：质量评分/护栏/语义缓存/SLO/驻留/影子/体检 ---
ipcMain.handle('smart:get', () => ({
  quality: config.get('quality') || {},
  guard: config.get('guard') || {},
  semanticCache: config.get('semanticCache') || {},
  slo: config.get('slo') || {},
  residency: config.get('residency') || {},
  shadow: config.get('shadow') || {},
  logging: config.get('logging') || {},
  stats: router.getStats(),
  healthcheck: router.getHealthCheck()
}));
ipcMain.handle('smart:set', (_, section, data) => {
  const current = config.get(section) || {};
  config.set(section, { ...current, ...(data || {}) });
  return config.get(section);
});

// --- 内置记忆系统（v3.0.2） ---
ipcMain.handle('memory:get', () => modelMemory?.getReport() || null);
ipcMain.handle('memory:probe', async () => {
  if (!modelMemory) return null;
  modelMemory.trackFeature('memory_probe');
  const results = await modelMemory.probeAll();
  return { results, report: modelMemory.getReport() };
});
ipcMain.handle('memory:sync', () => {
  if (!modelMemory) return null;
  const added = modelMemory.syncModelsToProviders();
  modelMemory.trackFeature('memory_sync');
  return { added, report: modelMemory.getReport() };
});
ipcMain.handle('memory:clear', () => {
  modelMemory?.clear();
  return modelMemory?.getReport() || null;
});
ipcMain.handle('memory:set', (_, data) => {
  const current = config.get('memory') || {};
  config.set('memory', { ...current, ...(data || {}) });
  return config.get('memory');
});
ipcMain.handle('memory:track', (_, id, opts) => {
  modelMemory?.trackFeature(id, opts);
  return true;
});

// --- 本地模型（v3.0.2）：引擎管理 + 工具面板 ---
ipcMain.handle('local:status', () => localEngine?.status() || null);
ipcMain.handle('local:downloadEngine', async () => {
  modelMemory?.trackFeature('local_engine_download');
  return localEngine?.downloadEngine() || { ok: false, error: '引擎未初始化' };
});
ipcMain.handle('local:downloadModel', async () => {
  modelMemory?.trackFeature('local_model_download');
  return localEngine?.downloadModel() || { ok: false, error: '引擎未初始化' };
});
ipcMain.handle('local:start', async () => {
  modelMemory?.trackFeature('local_start');
  return localEngine?.start() || { ok: false, error: '引擎未初始化' };
});
ipcMain.handle('local:stop', async () => localEngine?.stop() || { ok: true });
ipcMain.handle('local:set', (_, data) => {
  const cur = config.get('local') || {};
  config.set('local', { ...cur, ...(data || {}) });
  return config.get('local');
});
ipcMain.handle('local:tools', () => {
  if (!toolRegistry) return { tools: [] };
  return { tools: toolRegistry.toolsPayload() };
});
ipcMain.handle('local:toolRun', async (_, name, argsText) => {
  if (!toolRegistry) return { ok: false, error: '工具集未初始化' };
  const r = await toolRegistry.execute(name, argsText);
  modelMemory?.trackFeature('local_tool', { detail: name, ok: !!r.ok });
  return r;
});

// --- 远程访问与迁移（v3.0.2） ---
ipcMain.handle('remote:get', () => {
  const rc = config.get('remote') || {};
  return {
    ...rc,
    hasPassword: !!rc.passwordHash,
    hasApiKey: !!rc.apiKey,
    listening: !!remoteManager?._remoteServer,
    localProxyPort: config.get('proxyPort') || 3456
  };
});
ipcMain.handle('remote:regenerateKey', () => {
  const key = remoteManager.regenerateApiKey();
  modelMemory?.trackFeature('remote_key');
  return { ok: true, apiKey: key };
});
ipcMain.handle('remote:set', (_, data) => {
  const rc = { ...(config.get('remote') || {}) };
  if (data.username !== undefined) rc.username = data.username;
  if (data.port !== undefined) rc.port = parseInt(data.port, 10) || 3457;
  if (data.allowMigrate !== undefined) rc.allowMigrate = !!data.allowMigrate;
  if (data.enabled !== undefined) rc.enabled = !!data.enabled;
  config.set('remote', rc);
  syncRemote();
  return { ...rc, hasPassword: !!rc.passwordHash, listening: !!remoteManager?._remoteServer };
});
ipcMain.handle('remote:setPassword', (_, password) => {
  const rc = { ...(config.get('remote') || {}) };
  if (!password || String(password).length < 6) return { ok: false, error: '密码至少 6 位' };
  remoteManager.setCredentials(rc.username || 'admin', String(password));
  syncRemote();
  return { ok: true };
});
ipcMain.handle('remote:nginx', (_, domain) => {
  const rc = config.get('remote') || {};
  const r = remoteManager.genNginxConf(domain || 'router.example.com', rc.port || 3457);
  modelMemory?.trackFeature('remote_nginx');
  return r;
});
ipcMain.handle('remote:test', async (_, { host, port, username, password, apiKey }) => {
  // 测试远程连接（B 电脑用）：远程 Key 直连或账号密码登录（v3.0.2）
  try {
    // URL 解析（v3.0.2）：host 可携带协议与端口，如 http://1.2.3.4:3457
    let base = host;
    if (!/^https?:\/\//.test(base)) base = 'http://' + base;
    try {
      const u = new URL(base);
      if (u.port) port = u.port;
      base = u.origin;
    } catch (e) { /* 保留原样 */ }
    const endpoint = `${base}:${port || 3457}`;
    const headers = {};
    if (apiKey) {
      headers['X-Router-Remote-Key'] = apiKey;
    } else {
      const loginRes = await fetch(`${endpoint}/remote/login`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }), signal: AbortSignal.timeout(8000)
      });
      const lj = await loginRes.json();
      if (!lj.ok) return { ok: false, error: lj.error || ('登录失败 HTTP ' + loginRes.status) };
      headers['Authorization'] = 'Bearer ' + lj.token;
    }
    const stRes = await fetch(`${endpoint}/remote/status`, { headers, signal: AbortSignal.timeout(8000) });
    const st = await stRes.json();
    if (!st.ok) return { ok: false, error: st.error || '认证失败' };
    return { ok: true, remote: st };
  } catch (e) { return { ok: false, error: '连接失败: ' + e.message }; }
});
ipcMain.handle('remote:migrate', async (_, { host, port, username, password, apiKey }) => {
  // B 电脑一键迁移：Key 直连或登录 → 导出 → 备份本地 → 应用配置与记忆 → 返回结果
  // M4 修复：migrate 会传输全部 API Key + 记忆画像 → 高敏感操作
  //   1) 限流：5 分钟内最多 3 次，防止误触/恶意拖库
  //   2) 审计：每次调用记 trace，含来源标识（无用户上下文则记 'unknown'）
  //   3) 失败计数：连续失败 5 次锁 15 分钟
  const now = Date.now();
  if (MIGRATE_RATE_LIMIT.lockedUntil > now) {
    const remain = Math.ceil((MIGRATE_RATE_LIMIT.lockedUntil - now) / 60000);
    modelMemory?.trackFeature?.('remote_migrate_blocked', { detail: `locked ${remain}min` });
    return { ok: false, error: `Migrate 已被临时锁定（${remain} 分钟后解锁）` };
  }
  // 滑动窗口：清理 5 分钟前记录
  MIGRATE_RATE_LIMIT.calls = MIGRATE_RATE_LIMIT.calls.filter(t => now - t < 5 * 60 * 1000);
  if (MIGRATE_RATE_LIMIT.calls.length >= 3) {
    MIGRATE_RATE_LIMIT.lockedUntil = now + 15 * 60 * 1000;
    modelMemory?.trackFeature?.('remote_migrate_locked', { detail: '3次/5分钟触发锁定' });
    return { ok: false, error: 'Migrate 5 分钟内超过 3 次，已锁定 15 分钟' };
  }
  MIGRATE_RATE_LIMIT.calls.push(now);
  modelMemory?.trackFeature?.('remote_migrate_audit', { detail: `${host}:${port} user=${username || 'apikey'}` });
  try {
    let base = host;
    if (!/^https?:\/\//.test(base)) base = 'http://' + base;
    try {
      const u = new URL(base);
      if (u.port) port = u.port;
      base = u.origin;
    } catch (e) { /* 保留原样 */ }
    const endpoint = `${base}:${port || 3457}`;
    const headers = {};
    if (apiKey) {
      headers['X-Router-Remote-Key'] = apiKey;
    } else {
      const loginRes = await fetch(`${endpoint}/remote/login`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }), signal: AbortSignal.timeout(10000)
      });
      const lj = await loginRes.json();
      if (!lj.ok) return { ok: false, error: lj.error || '登录失败' };
      headers['Authorization'] = 'Bearer ' + lj.token;
    }
    const exRes = await fetch(`${endpoint}/remote/export`, {
      method: 'POST', headers, signal: AbortSignal.timeout(30000)
    });
    const ex = await exRes.json();
    if (!ex.ok) return { ok: false, error: ex.error || '导出失败' };
    // 备份本地配置
    const fsx = require('fs');
    const pathx = require('path');
    const cf = pathx.join(app.getPath('userData'), 'config.json');
    if (fsx.existsSync(cf)) {
      fsx.copyFileSync(cf, cf + '.pre-migrate.bak');
    }
    // 应用远程配置（保留本地 远程/本地引擎 相关配置）
    const remoteCfg = ex.config || {};
    const localCfg = config.getAll();
    remoteCfg.remote = localCfg.remote;
    remoteCfg.local = localCfg.local;
    remoteCfg.proxyPort = localCfg.proxyPort;
    config.save(remoteCfg);
    // 应用记忆
    if (ex.memory && modelMemory) {
      try { modelMemory.data = { ...modelMemory.defaultData(), ...ex.memory }; modelMemory.save(); } catch (e) {}
    }
    return {
      ok: true,
      version: ex.version,
      providers: (remoteCfg.providers || []).length,
      models: (remoteCfg.providers || []).reduce((s, p) => s + (p.models || []).length, 0),
      note: '配置已迁移（渠道/Key/价格/路由），本地引擎与远程设置保留；重启后生效'
    };
  } catch (e) {
    // M4 修复：累计失败计数；连续 5 次失败锁 15 分钟（防止被用于探测/拖库）
    MIGRATE_RATE_LIMIT.failures = (MIGRATE_RATE_LIMIT.failures || 0) + 1;
    if (MIGRATE_RATE_LIMIT.failures >= 5) {
      MIGRATE_RATE_LIMIT.lockedUntil = Date.now() + 15 * 60 * 1000;
      modelMemory?.trackFeature?.('remote_migrate_locked', { detail: `5次失败 locked` });
    }
    return { ok: false, error: '迁移失败: ' + e.message };
  }
});

// --- 路由大脑（v3.0.2） ---
ipcMain.handle('brain:status', () => brain?.status() || null);
ipcMain.handle('brain:run', async (_, reason) => {
  const r = await brain?.run(reason || '手动触发', { force: true });
  return r || { ok: false, error: '大脑未初始化' };
});
ipcMain.handle('brain:set', (_, data) => {
  const cur = config.get('local') || {};
  config.set('local', { ...cur, ...(data || {}) });
  // 即时生效：启停定时巡检
  if (data?.brainEnabled !== undefined || data?.brainAutoStart !== undefined || data?.brainIntervalMin !== undefined) {
    if (localEngine.running && config.get('local').brainEnabled !== false && config.get('local').brainAutoStart !== false) {
      brain?.stopAuto(); brain?.startAuto();
    } else {
      brain?.stopAuto();
    }
  }
  return config.get('local');
});
// C2 修复：Brain 撤销栈 IPC
ipcMain.handle('brain:pending', () => brain?.tools?.getPendingWrite?.() || null);
ipcMain.handle('brain:undo-stack', () => brain?.tools?.getUndoStack?.() || []);
ipcMain.handle('brain:undo', () => brain?.tools?.undoLast?.() || { ok: false, error: '工具未就绪' });
ipcMain.handle('brain:cancel', () => {
  if (!brain?.tools?._pendingWrite) return { ok: true, note: '无挂起操作' };
  const cancelled = brain.tools._pendingWrite;
  brain.tools._pendingWrite = null;
  return { ok: true, cancelled, note: '已取消挂起的写操作' };
});

// 远程访问与迁移（v3.0.2）：注入认证/迁移 API + 按需监听 0.0.0.0（模块级函数，供 IPC 与启动调用）
function syncRemote() {
  if (!remoteManager || !proxyServer) return;
  const rc = config.get('remote') || {};
  if (rc.enabled && rc.passwordHash && !remoteManager._remoteServer) {
    // 启用时自动生成远程 API Key（v3.0.2）
    remoteManager.ensureApiKey();
    try {
      remoteManager._remoteServer = proxyServer.app.listen(rc.port || 3457, '0.0.0.0', () =>
        console.log(`[远程] 远程访问已开启: http://0.0.0.0:${rc.port || 3457}（需账号密码，迁移接口 /remote/export）`));
    } catch (e) { console.error('[远程] 启动失败:', e.message); }
  } else if ((!rc.enabled || !rc.passwordHash) && remoteManager._remoteServer) {
    try { remoteManager._remoteServer.close(); } catch (e) {}
    remoteManager._remoteServer = null;
    console.log('[远程] 远程访问已关闭');
  }
}

// 启动自清理（v3.0.2）：避免长期运行积累无用的临时文件
function cleanupJunkFiles() {
  try {
    const base = app.getPath('userData');
    // 1. 清理 Electron blob_storage 中的空目录/孤立 blob
    const blob = path.join(base, 'blob_storage');
    if (fs.existsSync(blob)) {
      for (const en of fs.readdirSync(blob, { withFileTypes: true })) {
        const full = path.join(blob, en.name);
        if (en.isDirectory()) {
          try {
            const items = fs.readdirSync(full);
            if (items.length === 0) fs.rmdirSync(full);
          } catch (e) {}
        }
      }
    }
    // 2. 下载日志截断（>2MB 保留最后 100 行）
    const dl = path.join(base, 'local', 'download.log');
    if (fs.existsSync(dl)) {
      const st = fs.statSync(dl);
      if (st.size > 2 * 1024 * 1024) {
        const lines = fs.readFileSync(dl, 'utf8').split('\n').slice(-100);
        fs.writeFileSync(dl, lines.join('\n'), 'utf8');
      }
    }
    // 3. Trace 日志：执行一次轮转（按 logging.days 清理过期）
    try { router?.tracer?.rotate?.(); } catch (e) {}
  } catch (e) {
    console.error('启动自清理失败:', e.message);
  }
}

// 数据占用统计（设置页「数据与日志」卡）
function dirSize(dir) {
  let total = 0;
  try {
    const walk = (d) => {
      for (const en of fs.readdirSync(d, { withFileTypes: true })) {
        const full = path.join(d, en.name);
        if (en.isDirectory()) walk(full);
        else total += fs.statSync(full).size;
      }
    };
    walk(dir);
  } catch (e) {}
  return total;
}

ipcMain.handle('data:usage', () => {
  const base = app.getPath('userData');
  const logs = path.join(base, 'logs');
  const local = path.join(base, 'local');
  const cache = path.join(base, 'Cache');
  const blob = path.join(base, 'blob_storage');
  const memFile = path.join(base, 'model-memory.json');
  return {
    logs: dirSize(logs),
    local: dirSize(local),
    cache: dirSize(cache),
    blob: dirSize(blob),
    memory: fs.existsSync(memFile) ? fs.statSync(memFile).size : 0,
    config: fs.existsSync(path.join(base, 'config.json')) ? fs.statSync(path.join(base, 'config.json')).size : 0
  };
});
ipcMain.handle('data:cleanup', () => {
  cleanupJunkFiles();
  modelMemory?.trackFeature('cache_manage', { detail: '数据清理' });
  return { ok: true };
});

// --- 内存命中缓存（v2.0.2） ---
ipcMain.handle('cache:get', () => ({
  config: config.get('cache') || {},
  stats: router.getCacheStats()
}));
ipcMain.handle('cache:set', (_, data) => {
  const cache = { ...(config.get('cache') || {}), ...(data || {}) };
  // 限幅：16MB ~ 8GB
  if (cache.maxBytes != null) {
    const raw = Number(cache.maxBytes);
    cache.maxBytes = Math.max(16 * 1024 * 1024, Math.min(8 * 1024 * 1024 * 1024, Number.isFinite(raw) && raw > 0 ? raw : 1024 * 1024 * 1024));
  }
  config.set('cache', cache);
  return { config: config.get('cache'), stats: router.getCacheStats() };
});
ipcMain.handle('cache:clear', () => {
  modelMemory?.trackFeature('cache_manage', { detail: '清空缓存' });
  return router.clearCache();
});

// --- 价格管理 ---
ipcMain.handle('price:get', () => ({
  currency: config.get('currency') || 'USD',
  models: config.get('prices.models') || {}
}));
ipcMain.handle('price:set', (_, modelId, input, output) => router.setPrice(modelId, input, output));
ipcMain.handle('price:remove', (_, modelId) => router.removePrice(modelId));
ipcMain.handle('price:sync', () => {
  const synced = router.syncPrices();
  return { synced, models: config.get('prices.models') || {} };
});
ipcMain.handle('price:setCurrency', (_, currency) => {
  config.set('currency', currency);
  return config.get('currency');
});

// --- 应用设置 ---
ipcMain.handle('app:setAutoStart', (_, enabled) => {
  config.set('autoStart', !!enabled);
  app.setLoginItemSettings({ openAtLogin: !!enabled });
  return config.get('autoStart');
});
ipcMain.handle('app:getAutoStart', () => {
  const current = app.getLoginItemSettings().openAtLogin;
  config.set('autoStart', current);
  return current;
});
ipcMain.handle('app:setTrayMinimize', (_, enabled) => {
  config.set('trayMinimize', enabled !== false);
  return config.get('trayMinimize');
});

// --- 窗口控制 ---
ipcMain.handle('window:minimize', () => {
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.minimize();
});

ipcMain.handle('window:close', () => {
  cleanupAndQuit();
});

ipcMain.handle('window:maximize', () => {
  if (mainWindow && !mainWindow.isDestroyed()) {
    if (mainWindow.isMaximized()) {
      mainWindow.unmaximize();
    } else {
      mainWindow.maximize();
    }
    return mainWindow.isMaximized();
  }
  return false;
});

// --- 健康更新事件转发 ---
function forwardHealthUpdate() {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('health:update', healthChecker.getStatus());
  }
}

// --- 统计更新事件转发 ---
function forwardStatsUpdate() {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('stats:update', router.getStats());
  }
}

// --- 剪贴板 ---
ipcMain.handle('clipboard:copy', (_, text) => {
  clipboard.writeText(text);
  return true;
});

// --- 背景图管理 ---
function getBgImagePath() {
  const userDataPath = app.getPath('userData');
  return path.join(userDataPath, 'custom-bg.png');
}

ipcMain.handle('bg:save', (_, dataUrl) => {
  try {
    const base64Data = dataUrl.replace(/^data:image\/\w+;base64,/, '');
    const buf = Buffer.from(base64Data, 'base64');
    const bgPath = getBgImagePath();
    fs.writeFileSync(bgPath, buf);
    return { success: true, path: bgPath };
  } catch (e) {
    return { success: false, error: e.message };
  }
});

ipcMain.handle('bg:load', () => {
  try {
    const bgPath = getBgImagePath();
    if (fs.existsSync(bgPath)) {
      const buf = fs.readFileSync(bgPath);
      return 'data:image/png;base64,' + buf.toString('base64');
    }
    return null;
  } catch (e) {
    return null;
  }
});

ipcMain.handle('bg:reset', () => {
  try {
    const bgPath = getBgImagePath();
    if (fs.existsSync(bgPath)) {
      fs.unlinkSync(bgPath);
    }
    return true;
  } catch (e) {
    return false;
  }
});

// ==================== 应用生命周期 ====================

app.whenReady().then(async () => {
  config = new ConfigManager();
  router = new Router(config, app.getPath('userData'));
  healthChecker = new HealthChecker(config, router);

  // 内置记忆系统：注入路由 + 启动时异步探测渠道模型
  modelMemory = new ModelMemory(config, app.getPath('userData'));
  router.setModelMemory(modelMemory);
  router.slo.onEvent = (ev) => modelMemory?.trackFeature(ev.type === 'degrade' ? 'slo_degrade' : 'slo_recover');
  healthChecker.setMemory(modelMemory);
  if ((config.get('memory') || {}).enabled !== false) {
    modelMemory.syncModelsToProviders();
    setTimeout(() => { modelMemory.probeAll().catch(e => console.error('启动探测失败:', e.message)); }, 3000);
  }

  // 本地模型引擎 + 内置工具集（v3.0.2）：接入路由（本地渠道 kind='local' 自动走引擎）
  localEngine = new LocalEngine(config, app.getPath('userData'));
  toolRegistry = new ToolRegistry({ config, router, memory: modelMemory, tracer: router.tracer });
  router.setLocalEngine(localEngine, toolRegistry);
  // 本地模型引擎后端 = 云端渠道模型时：把推理委托给所选渠道的模型（走正常路由，含熔断/重试/统计）
  localEngine.cloudCaller = async ({ provider, model, messages, stream, tools, temperature, max_tokens, timeout }) => {
    const key = router.getActiveKey(provider);
    if (!key) throw new Error('云端渠道无可用 Key：' + (provider?.name || '未知渠道'));
    const body = {
      messages,
      stream: !!stream,
      temperature: temperature ?? 0.7,
      max_tokens: max_tokens ?? 2048
    };
    if (tools && tools.length) body.tools = tools;
    return await router.callProvider(provider, key, model, body, timeout || 300000);
  };
  global.__healthChecker__ = healthChecker;   // 工具 probe_providers 使用
  localEngine.onEvent = (ev) => {
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('local:event', ev);
    }
  };

  // 路由大脑（v3.0.2）：本地模型作为路由器大脑，观察路由状态并自主调用工具优化
  brain = new BrainEngine({ config, router, localEngine, toolRegistry, memory: modelMemory, tracer: router.tracer });
  router.setBrain(brain);
  brain.onEvent = (ev) => {
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('brain:event', ev);
    }
  };
  const syncBrainAuto = () => {
    const lc = config.get('local') || {};
    if (localEngine.running && lc.brainEnabled !== false && lc.brainAutoStart !== false) {
      brain.startAuto();
    } else {
      brain.stopAuto();
    }
  };
  const origEmit = localEngine.onEvent;
  localEngine.onEvent = (ev) => {
    origEmit(ev);
    if (ev.type === 'state') syncBrainAuto();
  };

  // 大脑自动休眠/唤醒（v3.0.2）：空闲 15 分钟自动停引擎释放内存，路由有请求自动唤醒
  router.autoWakeHook = () => {
    if (!localEngine || localEngine.running || localEngine.waking) return;
    // 后端=云端渠道模型：无本地进程可唤醒（启用状态由用户在界面上控制），跳过
    if ((config.get('local') || {}).backend === 'cloud') return;
    console.log('[本地模型] 路由活动，自动唤醒引擎...');
    modelMemory?.trackFeature('local_wake');
    localEngine.start().catch(e => console.error('自动唤醒失败:', e.message));
  };
  // H6 修复：把 autoWakeHook 同步注入到 localEngine，让 chat() 入口也能触发唤醒
  router.installAutoWakeOnEngine();
  const idleTimer = setInterval(() => {
    try {
      if (router.isEngineIdle()) {
        console.log('[本地模型] 空闲 ' + (config.get('local')?.idleSleepMinutes || 15) + ' 分钟无请求，自动休眠引擎（有请求进来自动唤醒）');
        modelMemory?.trackFeature('brain_sleep');
        localEngine.stop();
      }
    } catch (e) {}
  }, 30000);
  // 本地渠道健康状态联动（healthcheck 读取 engine.running）

  // 启动自清理：避免长期运行积累临时文件
  cleanupJunkFiles();

  // 开机自启
  try {
    const autoStart = app.getLoginItemSettings().openAtLogin;
    config.set('autoStart', autoStart);
  } catch (e) {}

  // 启动代理服务器
  const port = config.get('proxyPort') || 3456;
  proxyServer = new ProxyServer(config, router);
  try {
    await proxyServer.start(port);
    console.log(`代理服务器已启动，端口: ${port}`);
  } catch (err) {
    console.error('代理服务器启动失败:', err.message);
  }

  // 远程访问与迁移（v3.0.2）：注入认证/迁移 API + 按需监听 0.0.0.0（必须在 proxyServer 创建后）
  remoteManager = new RemoteManager(config);
  proxyServer.attachRemote(remoteManager, {
    version: app.getVersion(),
    exportAll: () => ({
      config: config.getAll(),
      memory: (() => { try { return modelMemory ? modelMemory.data : null; } catch (e) { return null; } })(),
      version: app.getVersion()
    })
  });
  syncRemote();

  // 设置事件回调
  healthChecker.onUpdate = forwardHealthUpdate;
  router.onStatsUpdate = forwardStatsUpdate;

  createWindow();
  createTray();
  healthChecker.start();
  startKeepAlive();
});

app.on('window-all-closed', () => {
  // 有托盘时保持后台运行，不退出
  if (tray) return;
  cleanupAndQuit();
});

app.on('before-quit', (e) => {
  if (!isQuitting) {
    e.preventDefault();
    cleanupAndQuit();
  }
});

// 防止进程残留：收到 SIGTERM/SIGINT 时也清理（修复重复注册）
process.on('SIGTERM', cleanupAndQuit);
process.on('SIGINT', cleanupAndQuit);
