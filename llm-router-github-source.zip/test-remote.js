/**
 * 远程访问与迁移测试（v3.0.0）
 * 运行: node test-remote.js
 */
const assert = require('assert');
const os = require('os');
const fs = require('fs');
const path = require('path');

const Module = require('module');
const origLoad = Module._load;
const userDataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'llm-remote-'));
Module._load = function (request, parent, isMain) {
  if (request === 'electron') return { app: { getPath: () => userDataDir, getVersion: () => '3.0.0-test' }, ipcMain: { handle: () => {} } };
  return origLoad.apply(this, arguments);
};

const { RemoteManager } = require('./src/remote');
const express = require('express');

let passed = 0, failed = 0;
function ok(name) { passed++; console.log(`  ok ${name}`); }
function fail(name, detail) { failed++; console.log(`  FAIL ${name}: ${detail || ''}`); }

function mockConfig() {
  const state = { providers: [], remote: { enabled: false, port: 3457, username: 'admin', passwordHash: null, salt: null, tokenHours: 24, allowMigrate: true } };
  return {
    config: state,
    get(key) { return key.split('.').reduce((o, k) => o?.[k], this.config); },
    set(key, v) { const ks = key.split('.'); const last = ks.pop(); const t = ks.reduce((o, k) => { if (!o[k]) o[k] = {}; return o[k]; }, this.config); t[last] = v; },
    getAll() { return this.config; },
    persist() {},
    addProvider(p) { const prov = { id: 'p1', name: p.name, baseUrl: p.baseUrl, keys: p.keys, models: p.models, enabled: true, priority: 1 }; this.config.providers.push(prov); return prov; },
    getProviders() { return this.config.providers; },
    getEnabledProviders() { return this.config.providers.filter(p => p.enabled); }
  };
}

(async () => {
  // ============ 账号密码与登录 ============
  {
    try {
      const config = mockConfig();
      const rm = new RemoteManager(config);
      rm.setCredentials('admin', 'secret123');
      const c = config.get('remote');
      assert.ok(c.passwordHash && c.salt, '应存哈希与盐');
      assert.ok(!c.passwordHash.includes('secret123'), '不得存明文密码');
      assert.ok(rm.verifyPassword('secret123'), '正确密码验证通过');
      assert.ok(!rm.verifyPassword('wrong'), '错误密码验证失败');
      // 未启用时登录失败
      const r1 = rm.login('admin', 'secret123');
      assert.ok(!r1.ok && r1.error.includes('未启用'));
      // 启用后登录
      config.set('remote', { ...config.get('remote'), enabled: true });
      const r2 = rm.login('admin', 'secret123');
      assert.ok(r2.ok && r2.token, '登录应返回 token');
      assert.ok(rm.isTokenValid(r2.token), 'token 有效');
      assert.ok(!rm.isTokenValid('bad-token'), '无效 token 拒绝');
      assert.ok(!rm.login('admin', 'wrong').ok, '错密码拒绝');
      ok('账号密码哈希存储 + 登录签发 token + 校验');
    } catch (e) { fail('账号密码/登录', e.message); }
  }

  // ============ 认证中间件 + 迁移 API ============
  {
    try {
      const config = mockConfig();
      config.set('remote', { ...config.get('remote'), enabled: true });
      const rm = new RemoteManager(config);
      rm.setCredentials('admin', 'secret123');
      const mw = rm.authMiddleware();
      const fakeRes = () => {
        const r = { statusCode: 200, body: null };
        r.status = (s) => { r.statusCode = s; return r; };
        r.json = (b) => { r.body = b; return r; };
        return r;
      };
      const mkReq = (ip, auth) => ({ socket: { remoteAddress: ip }, headers: { authorization: auth || '' }, path: '/v1/chat/completions' });
      // 非本机无认证 → 401
      let nexted = false;
      let res = fakeRes();
      mw(mkReq('1.2.3.4'), res, () => { nexted = true; });
      assert.strictEqual(res.statusCode, 401, '非本机无认证应 401');
      assert.ok(!nexted);
      // 本机放行
      nexted = false; res = fakeRes();
      mw(mkReq('127.0.0.1'), res, () => { nexted = true; });
      assert.ok(nexted, '本机请求应放行');
      // 非本机 + 有效 token → 放行
      const lg = rm.login('admin', 'secret123');
      nexted = false; res = fakeRes();
      mw(mkReq('1.2.3.4', 'Bearer ' + lg.token), res, () => { nexted = true; });
      assert.ok(nexted, '有效 token 应放行');
      // 非本机 + Basic 账号密码 → 放行
      const basic = Buffer.from('admin:secret123').toString('base64');
      nexted = false; res = fakeRes();
      mw(mkReq('1.2.3.4', 'Basic ' + basic), res, () => { nexted = true; });
      assert.ok(nexted, 'Basic 认证应放行');
      // 迁移 API：认证后导出（模拟非本机 + token）
      const app = express();
      app.use(express.json());
      rm.attach(app, { version: '3.0.0-test', exportAll: () => ({ config: { providers: [{ name: '商汤', keys: ['sk-test'] }] }, memory: { totalCalls: 5 }, version: '3.0.0-test' }) });
      const server = app.listen(0, '127.0.0.1', async () => {
        const base = `http://127.0.0.1:${server.address().port}`;
        const ex = await fetch(base + '/remote/export', { method: 'POST', headers: { 'Authorization': 'Bearer ' + lg.token } });
        const b = await ex.json();
        assert.ok(b.ok && b.config.providers[0].name === '商汤' && b.config.providers[0].keys[0] === 'sk-test', '认证后导出含渠道与 Key');
        ok('认证中间件（本机放行/非本机 401/token/Basic）+ 迁移导出');
        server.close();
      });
    } catch (e) { fail('认证/迁移 API', e.message); }
  }

  // ============ Nginx 反代配置生成 ============
  {
    try {
      const config = mockConfig();
      const rm = new RemoteManager(config);
      const r = rm.genNginxConf('router.example.com', 3457);
      assert.ok(r.nginxConf.includes('server_name router.example.com'), '含域名');
      assert.ok(r.nginxConf.includes('proxy_pass http://127.0.0.1:3457'), '反代到远程端口');
      assert.ok(r.nginxConf.includes('certbot'), '含证书命令');
      assert.ok(r.nginxConf.includes('ssl_certificate'), '含 SSL 证书路径');
      assert.ok(r.renewCmd.includes('certbot renew'), '含自动续期命令');
      assert.ok(r.tips.length >= 2, '含使用提示');
      ok('Nginx 配置：域名/反代/SSL 证书/自动续期');
    } catch (e) { fail('Nginx 配置', e.message); }
  }

  // ============ 远程 API Key（v3.0.1） ============
  {
    try {
      const config = mockConfig();
      config.set('remote', { ...config.get('remote'), enabled: true });
      const rm = new RemoteManager(config);
      rm.setCredentials('admin', 'secret123');
      // 自动生成
      const k1 = rm.ensureApiKey();
      assert.ok(k1.startsWith('zr_') && k1.length > 20, 'Key 应自动生成且带前缀');
      assert.strictEqual(rm.ensureApiKey(), k1, '已存在不重复生成');
      assert.ok(rm.verifyApiKey(k1), 'Key 校验通过');
      assert.ok(!rm.verifyApiKey('wrong-key'), '错误 Key 拒绝');
      // 重新生成 → 旧 Key 失效
      const k2 = rm.regenerateApiKey();
      assert.notStrictEqual(k2, k1, '新 Key 不同');
      assert.ok(rm.verifyApiKey(k2), '新 Key 有效');
      assert.ok(!rm.verifyApiKey(k1), '旧 Key 立即失效');
      // 认证中间件：Key 头 / Bearer Key / 账号密码 token
      const mw = rm.authMiddleware();
      const fakeRes = () => { const r = { statusCode: 200 }; r.status = (s) => { r.statusCode = s; return r; }; r.json = () => r; return r; };
      const mkReq = (ip, headers) => ({ socket: { remoteAddress: ip }, headers: headers || {}, path: '/v1/chat/completions' });
      let nexted = false;
      mw(mkReq('1.2.3.4', { 'x-router-remote-key': k2 }), fakeRes(), () => { nexted = true; });
      assert.ok(nexted, 'X-Router-Remote-Key 头应放行');
      nexted = false;
      mw(mkReq('1.2.3.4', { authorization: 'Bearer ' + k2 }), fakeRes(), () => { nexted = true; });
      assert.ok(nexted, 'Bearer 带远程 Key 应放行');
      nexted = false;
      mw(mkReq('1.2.3.4', {}), fakeRes(), () => { nexted = true; });
      assert.ok(!nexted, '无凭据应拒绝');
      ok('远程 API Key：生成/重置/校验/头与 Bearer 认证');
    } catch (e) { fail('远程 API Key', e.message); }
  }

  console.log(`\n通过 ${passed} 项, 失败 ${failed} 项`);
  process.exit(failed > 0 ? 1 : 0);
})().catch(e => { console.error('测试崩溃:', e); process.exit(1); });
