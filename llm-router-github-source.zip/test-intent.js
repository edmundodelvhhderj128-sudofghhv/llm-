/**
 * 请求级意图/复杂度识别测试（v2.10.0）
 * 运行: node test-intent.js
 */
const assert = require('assert');
const os = require('os');
const fs = require('fs');
const path = require('path');

const Module = require('module');
const origLoad = Module._load;
const userDataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'llm-intent-'));
Module._load = function (request, parent, isMain) {
  if (request === 'electron') return { app: { getPath: () => userDataDir }, ipcMain: { handle: () => {} } };
  return origLoad.apply(this, arguments);
};

const { classifyIntent, complexityScore, modelStrength, taskFitness, analyzeRequest } = require('./src/intent');
const { Router } = require('./src/router');

let passed = 0, failed = 0;
function ok(name) { passed++; console.log(`  ok ${name}`); }
function fail(name, detail) { failed++; console.log(`  FAIL ${name}: ${detail || ''}`); }

function mockConfig() {
  const state = {
    providers: [], routing: { strategy: 'priority', failover: true, maxRetries: 3, timeout: 60000, fallbackTimeoutMs: 20000, circuitBreaker: { enabled: true, threshold: 5, cooldownMs: 60000 }, intentRouting: true, lkgp: true, promptCacheAffinity: true },
    guard: {}, quality: {}, compression: {}, semanticCache: {}, slo: {}, residency: {}, shadow: {},
    cache: { enabled: false }, logging: { enabled: true }, local: {}, prices: { models: {} }, memory: {}
  };
  return {
    config: state,
    get(key) { return key.split('.').reduce((o, k) => o?.[k], this.config); },
    set(key, v) { const ks = key.split('.'); const last = ks.pop(); const t = ks.reduce((o, k) => { if (!o[k]) o[k] = {}; return o[k]; }, this.config); t[last] = v; },
    getAll() { return this.config; },
    persist() {},
    addProvider(p) {
      const prov = { id: p.id || 'p' + this.config.providers.length, name: p.name, baseUrl: p.baseUrl || 'https://x.example.com', keys: p.keys || ['k1'], models: p.models || [], enabled: true, priority: p.priority || 1, keyIndex: 0, keyStats: {}, region: 'any', pathStyle: 'v1', kind: 'remote', billing: {}, weights: { latencyMs: null, successRate: 1, requests: 0 }, circuit: { failures: 0, open: false, openedAt: null }, quotaUsed: {} };
      prov.keys.forEach((_, i) => { prov.keyStats[i] = { disabled: false }; });
      this.config.providers.push(prov); return prov;
    },
    updateProvider(id, d) { const i = this.config.providers.findIndex(p => p.id === id); this.config.providers[i] = { ...this.config.providers[i], ...d }; return this.config.providers[i]; },
    getProviders() { return this.config.providers; },
    getEnabledProviders() { return this.config.providers.filter(p => p.enabled); }
  };
}

(async () => {
  // ============ 意图分类 ============
  {
    try {
      assert.strictEqual(classifyIntent([{ role: 'user', content: '帮我写一个 Python 函数计算斐波那契数列，然后解释一下' }]).intent, 'code');
      assert.strictEqual(classifyIntent([{ role: 'user', content: '把这段话翻译成英文' }]).intent, 'translate');
      assert.strictEqual(classifyIntent([{ role: 'user', content: '计算 23 × 45 + 12 等于多少' }]).intent, 'math');
      assert.strictEqual(classifyIntent([{ role: 'user', content: '请总结一下这篇文章的要点' }]).intent, 'summary');
      assert.strictEqual(classifyIntent([{ role: 'user', content: '写一首关于秋天的诗' }]).intent, 'creative');
      assert.strictEqual(classifyIntent([{ role: 'user', content: '你好，今天天气怎么样' }]).intent, 'chat');
      ok('意图分类：code/translate/math/summary/creative/chat');
    } catch (e) { fail('意图分类', e.message); }
  }

  // ============ 复杂度评估 ============
  {
    try {
      const s1 = complexityScore([{ role: 'user', content: '你好' }]);
      assert.strictEqual(s1.level, 'simple');
      const long = 'x'.repeat(3000);
      const s2 = complexityScore([{ role: 'user', content: long }]);
      assert.ok(['medium', 'complex'].includes(s2.level), '长文本应为 medium/complex: ' + s2.level);
      const s3 = complexityScore([{ role: 'user', content: '帮我写一个完整的 REST API 服务，包含认证、数据库、错误处理，这是超长的需求描述' + 'y'.repeat(9000) }]);
      assert.strictEqual(s3.level, 'complex', '代码+超长应 complex');
      ok('复杂度评估：simple/medium/complex 分档');
    } catch (e) { fail('复杂度评估', e.message); }
  }

  // ============ 模型强度与任务匹配 ============
  {
    try {
      assert.strictEqual(modelStrength('glm-5.2'), 'strong');
      assert.strictEqual(modelStrength('deepseek-v4-flash'), 'fast');
      assert.strictEqual(modelStrength('agnes-2.5-flash'), 'fast');
      assert.strictEqual(modelStrength('gpt-4o'), 'strong');
      assert.strictEqual(modelStrength('sensenova-6.8-flash-lite'), 'fast');
      // 覆盖配置
      assert.strictEqual(modelStrength('custom-x', { strong: ['custom-x'] }), 'strong');
      // fitness：复杂代码任务 → 强模型更高；简单闲聊 → 快模型更高
      const fCodeStrong = taskFitness('glm-5.2', 'code', 'complex');
      const fCodeFast = taskFitness('deepseek-v4-flash', 'code', 'complex');
      assert.ok(fCodeStrong > fCodeFast, `复杂代码应偏好强模型 (${fCodeStrong} vs ${fCodeFast})`);
      const fChatFast = taskFitness('deepseek-v4-flash', 'chat', 'simple');
      const fChatStrong = taskFitness('glm-5.2', 'chat', 'simple');
      assert.ok(fChatFast > fChatStrong, `简单闲聊应偏好快模型 (${fChatFast} vs ${fChatStrong})`);
      ok('模型强度 + 任务匹配（强模型利于复杂/快模型利于闲聊）');
    } catch (e) { fail('模型强度/匹配', e.message); }
  }

  // ============ 路由集成：auto 选模型 + 回退排序 + trace 记录 ============
  {
    try {
      const config = mockConfig();
      config.addProvider({ id: 'p1', name: '商汤', keys: ['k'], models: ['glm-5.2', 'deepseek-v4-flash', 'sensenova-6.8-flash-lite'], priority: 1 });
      config.addProvider({ id: 'p2', name: 'Agnes', keys: ['k'], models: ['agnes-2.5-flash', 'agnes-2.5-pro'], priority: 2 });
      const router = new Router(config, os.tmpdir());
      const origFetch = global.fetch;
      global.fetch = async () => ({ ok: true, status: 200, json: async () => ({ choices: [{ message: { content: 'ok' } }], usage: null }), text: async () => '' });
      try {
        // auto 选模型：复杂代码 → 应选强模型
        const r1 = await router.routeWithFallback({ model: 'auto', messages: [{ role: 'user', content: '帮我写一个完整的分布式系统代码，包含负载均衡和容错，这是很长的需求' + 'z'.repeat(2000) }] });
        assert.ok(r1.success, 'auto 应成功');
        assert.ok(r1.meta.model, '应选出模型');
        assert.ok(/glm-5\.2|agnes-2\.5-pro/.test(r1.meta.model), '复杂任务应选强模型: ' + r1.meta.model);
        // 简单闲聊 → 快模型
        const r2 = await router.routeWithFallback({ model: 'auto', messages: [{ role: 'user', content: '你好' }] });
        assert.ok(/flash|fast/.test(r2.meta.model), '简单闲聊应选快模型: ' + r2.meta.model);
        // 显式指定模型不受影响
        const r3 = await router.routeWithFallback({ model: 'glm-5.2', messages: [{ role: 'user', content: '你好' }] });
        assert.strictEqual(r3.meta.model, 'glm-5.2');
        // intent 统计
        const stats = router.getStats();
        assert.ok(stats.routing.intentStats, '应有意图统计');
        assert.ok(Object.keys(stats.routing.intentStats).length >= 1);
      } finally { global.fetch = origFetch; }
      ok('路由集成：auto 智能选模型/显式模型不受影响/意图统计');
    } catch (e) { fail('路由集成', e.message); }
  }

  console.log(`\n通过 ${passed} 项, 失败 ${failed} 项`);
  process.exit(failed > 0 ? 1 : 0);
})().catch(e => { console.error('测试崩溃:', e); process.exit(1); });
