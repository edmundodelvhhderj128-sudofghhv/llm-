// v2.2.6：内联深色背景盒改浅色（黑字可读）
const fs = require('fs');

const file = 'renderer/app.js';
let src = fs.readFileSync(file, 'utf8');
src = src.split('background: rgba(0,0,0,0.18); padding: 12px 14px; border-radius: 8px; font-size: 12px;')
  .join('background: rgba(15,23,42,0.05); padding: 12px 14px; border-radius: 8px; font-size: 12px; border: 1px solid rgba(15,23,42,0.15);');
src = src.split('background: rgba(0,0,0,0.15); border-radius: 8px; padding: 8px;')
  .join('background: rgba(15,23,42,0.04); border-radius: 8px; padding: 8px; border: 1px solid rgba(15,23,42,0.15);');
src = src.split('background: rgba(0,0,0,0.2); padding: 16px; border-radius: 8px; font-family: monospace; font-size: 12px;')
  .join('background: rgba(15,23,42,0.05); padding: 16px; border-radius: 8px; font-family: monospace; font-size: 13px; border: 1px solid rgba(15,23,42,0.15);');
fs.writeFileSync(file, src, 'utf8');
console.log('dark boxes -> light. 剩余深色背景内联:', (src.match(/background: rgba\(0,\s*0,\s*0/g) || []).length, '处');
