/**
 * 加固测试（第四轮）——浸泡/内存上限、代理并发、流式边界、半开循环、注入、配置容错
 * 运行: node test-hardening.js
 */
const assert = require('assert');
const os = require('os');
const http = require('http');
const fs = require('fs');
const path = require('path');

const Module = require('module');
const origLoad = Module._load;
let userDataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'llm-harden-'));
Module._load = function (request, parent, isMain) {
  if (request === 'electron') return { app: { getPath: () => userDataDir }, ipcMain: { handle: () => {} } };
  return origLoad.apply(this, arguments);
};

const { ConfigManager } = require('./src/config');
const { Router } = require('./src/router');
const { ProxyServer } = require('./src/proxy');

let passed = 0, failed = 0;
function ok(name) { passed++; console.log(`  ok ${name}`); }
function fail(name, detail) { failed++; console.log(`  FAIL ${name}: ${detail || ''}`); }

function mockConfig() {
  const state = {
    providers: [], routing: { strategy: 'priority', failover: true, fallback: true, maxRetries: 3, timeout: 5000, healthCheckInterval: 5, circuitBreaker: { enabled: true, threshold: 2, cooldownMs: 60000 }, quota: { enabled: false, period: 'day', limits: {} }, costOptimization: { enabled: false, preferCheapest: true }, abTest: { enabled: false, groups: [] } },
    prices: { currency: 'USD', models: {} }, cache: { enabled: true, maxBytes: 104857600, stream: true, embeddings: true },
    quality: {}, guard: { enabled: false, maskPII: true, blockSensitive: false, sensitiveWords: [] },
    semanticCache: { enabled: false, threshold: 0.95, maxEntries: 1000 }, slo: { enabled: true, p95ThresholdMs: 100000, windowSize: 50 },
    residency: { enabled: false, allowedRegions: [] }, shadow: { enabled: true }, compression: { enabled: false }, logging: { enabled: true }
  };
  return {
    config: state,
    get(key) { return key.split('.').reduce((o, k) => o?.[k], this.config); },
    set(key, v) { const ks = key.split('.'); const last = ks.pop(); const t = ks.reduce((o, k) => { if (!o[k]) o[k] = {}; return o[k]; }, this.config); t[last] = v; },
    getAll() { return this.config; },
    persist() {},
    addProvider(p) {
      const id = p.id || ('p' + this.config.providers.length);
      const prov = { id, name: p.name, baseUrl: p.baseUrl, keys: p.keys || ['k1'], models: p.models || [], enabled: p.enabled !== false, priority: p.priority || 1, keyIndex: 0, keyStats: {}, region: p.region || 'any', pathStyle: p.pathStyle || 'v1', billing: p.billing || { mode: 'tokens', pricePerCall: 0 }, weights: p.weights || { latencyMs: null, successRate: 1, requests: 0, qualityScore: 70 }, circuit: { failures: 0, open: false, openedAt: null }, quotaUsed: { periodKey: null, requests: 0, tokens: 0 } };
      prov.keys.forEach((_, i) => { prov.keyStats[i] = { requests: 0, errors: 0, consecutiveErrors: 0, lastUsed: null, disabled: false }; });
      this.config.providers.push(prov); return prov;
    },
    updateProvider(id, d) { const i = this.config.providers.findIndex(p => p.id === id); this.config.providers[i] = { ...this.config.providers[i], ...d }; return this.config.providers[i]; },
    getProviders() { return this.config.providers; },
    getEnabledProviders() { return this.config.providers.filter(p => p.enabled); }
  };
}

// 简易 mock 上游：支持分片流式 / 无 DONE 中断 / 计数
function startUpstream(options = {}) {
  const server = http.createServer((req, res) => {
    server._count = (server._count || 0) + 1;
    let body = '';
    req.on('data', c => body += c);
    req.on('end', () => {
      if (req.url === '/v1/chat/completions') {
        const parsed = JSON.parse(body || '{}');
        if (parsed.stream) {
          res.setHeader('Content-Type', 'text/event-stream');
          const full = '这是流式内容' + (server._count || 0);
          if (options.fragmented) {
            // 逐字符写入（模拟网络分片）
            const text = JSON.stringify({ id: 's', object: 'chat.completion.chunk', created: 0, model: parsed.model, choices: [{ index: 0, delta: { content: full }, finish_reason: 'stop' }], usage: { total_tokens: 5 } });
            let i = 0;
            const timer = setInterval(() => {
              if (i >= text.length) { res.write('\n\ndata: [DONE]\n\n'); res.end(); clearInterval(timer); return; }
              res.write(text[i]); i++;
            }, 1);
          } else if (options.noDone) {
            res.write(`data: ${JSON.stringify({ id: 's', choices: [{ delta: { content: '部分内容' } }] })}\n\n`);
            setTimeout(() => res.destroy(), 30); // 中断，无 [DONE]
          } else {
            res.write(`data: ${JSON.stringify({ id: 's', choices: [{ delta: { content: full } }] })}\n\n`);
            res.write('data: [DONE]\n\n');
            res.end();
          }
        } else {
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ id: 'x', choices: [{ message: { content: 'ok:' + (server._count || 0) } }], usage: { total_tokens: 5 } }));
        }
      } else if (req.url === '/v1/embeddings') {
        res.setHeader('Content-Type', 'application/json');
        res.end(JSON.stringify({ data: [{ embedding: [0.1, 0.2] }] }));
      } else if (req.url === '/v1/images/generations') {
        res.setHeader('Content-Type', 'application/json');
        res.end(JSON.stringify({ created: 1, data: [{ url: 'http://cdn/img.png' }] }));
      } else { res.statusCode = 404; res.end('{}'); }
    });
  });
  return new Promise(r => server.listen(0, '127.0.0.1', () => r({ port: server.address().port, server, count: () => server._count || 0 })));
}

(async () => {
  // ============ A. 代理级并发（50 请求：25 唯一 + 25 同键） ============
  {
    const up = await startUpstream();
    const config = mockConfig();
    config.addProvider({ name: '上游', baseUrl: `http://127.0.0.1:${up.port}`, keys: ['k1'], models: ['gpt-4'] });
    const router = new Router(config, os.tmpdir());
    const proxy = new ProxyServer(config, router);
    await proxy.start(0);
    const port = proxy.port;

    const post = (content) => new Promise((resolve) => {
      const body = JSON.stringify({ model: 'gpt-4', messages: [{ role: 'user', content }] });
      const data = Buffer.from(body, 'utf8');
      const req = http.request({ host: '127.0.0.1', port, path: '/v1/chat/completions', method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': data.length } }, (res) => {
        const chunks = [];
        res.on('data', c => chunks.push(c));
        res.on('end', () => resolve(res.statusCode));
      });
      req.on('error', () => resolve(0));
      req.write(data); req.end();
    });

    const before = up.count();
    const tasks = [];
    for (let i = 0; i < 25; i++) tasks.push(post('唯一内容' + i));
    for (let i = 0; i < 25; i++) tasks.push(post('相同内容X'));
    const statuses = await Promise.all(tasks);
    const all200 = statuses.every(s => s === 200);
    const upCalls = up.count() - before;
    const stats = router.getStats();
    assert.strictEqual(all200, true, '50 个并发请求应全部 200');
    assert.strictEqual(upCalls, 26, `上游应调用 26 次（25 唯一 + 1 去重），实际 ${upCalls}`);
    assert.strictEqual(stats.totalRequests, 50, '统计应准确');
    assert.ok(stats.recentRequests.length <= 50, 'recentRequests 应封顶 50');
    ok(`代理级并发 50 请求（上游 ${upCalls} 次，去重生效）`);
    proxy.stop(); up.server.close();
  }

  // ============ B. 流式分片与中断 ============
  {
    const up = await startUpstream({ fragmented: true });
    const config = mockConfig();
    config.addProvider({ name: '上游', baseUrl: `http://127.0.0.1:${up.port}`, keys: ['k1'], models: ['gpt-4'] });
    const router = new Router(config, os.tmpdir());
    const proxy = new ProxyServer(config, router);
    await proxy.start(0);
    const port = proxy.port;

    const streamReq = (body) => new Promise((resolve) => {
      const data = Buffer.from(JSON.stringify(body), 'utf8');
      const req = http.request({ host: '127.0.0.1', port, path: '/v1/chat/completions', method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': data.length } }, (res) => {
        const chunks = [];
        res.on('data', c => chunks.push(c));
        res.on('end', () => resolve({ status: res.statusCode, text: Buffer.concat(chunks).toString('utf8') }));
      });
      req.on('error', () => resolve({ status: 0, text: '' }));
      req.write(data); req.end();
    });
    // 逐字符分片
    const r1 = await streamReq({ model: 'gpt-4', messages: [{ role: 'user', content: 'hi' }], stream: true });
    assert.strictEqual(r1.status, 200);
    assert.ok(r1.text.includes('流式内容'), '分片流式应完整转发: ' + r1.text.slice(0, 80));
    assert.ok(r1.text.includes('[DONE]'));
    ok('流式逐字符分片完整转发');

    proxy.stop(); up.server.close();
  }

  {
    const up = await startUpstream({ noDone: true });
    const config = mockConfig();
    config.addProvider({ name: '上游', baseUrl: `http://127.0.0.1:${up.port}`, keys: ['k1'], models: ['gpt-4'] });
    const router = new Router(config, os.tmpdir());
    const proxy = new ProxyServer(config, router);
    await proxy.start(0);
    const port = proxy.port;
    const streamReq = (body) => new Promise((resolve) => {
      const data = Buffer.from(JSON.stringify(body), 'utf8');
      const req = http.request({ host: '127.0.0.1', port, path: '/v1/chat/completions', method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': data.length } }, (res) => {
        const chunks = [];
        res.on('data', c => chunks.push(c));
        res.on('end', () => resolve({ status: res.statusCode, text: Buffer.concat(chunks).toString('utf8') }));
      });
      req.on('error', () => resolve({ status: 0, text: '' }));
      req.write(data); req.end();
    });
    const r = await streamReq({ model: 'gpt-4', messages: [{ role: 'user', content: 'hi' }], stream: true });
    assert.strictEqual(r.status, 200, '上游中断后客户端不应挂死');
    ok('上游中断（无 DONE）代理正常收尾');
    proxy.stop(); up.server.close();
  }

  // ============ C. 熔断半开循环 ============
  {
    const config = mockConfig();
    const p = config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4'] });
    const router = new Router(config, os.tmpdir());
    // 触发熔断
    for (let i = 0; i < 2; i++) router.recordFailure(p, 0, 'gpt-4', Object.assign(new Error('x'), { status: 500 }));
    assert.strictEqual(p.circuit.open, true);
    // 冷却期：不可用
    assert.strictEqual(router.selectProviders('gpt-4').length, 0);
    // 冷却结束（cooldownMs=60000，模拟时间流逝）
    p.circuit.openedAt = Date.now() - 120000;
    assert.strictEqual(router.selectProviders('gpt-4').length, 1, '冷却后应半开放行');
    // 探测失败 → 重新熔断
    router.recordFailure(p, 0, 'gpt-4', Object.assign(new Error('y'), { status: 500 }));
    assert.strictEqual(p.circuit.open, true, '探测失败应重新熔断');
    ok('熔断-半开-失败-重熔断 完整循环');
  }

  // ============ D. Key 轮询轮换 ============
  {
    const config = mockConfig();
    config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1', 'k2', 'k3'], models: ['gpt-4'] });
    config.set('routing.strategy', 'round-robin');
    const router = new Router(config, os.tmpdir());
    const seq = [];
    for (let i = 0; i < 5; i++) {
      seq.push(router.selectKey(config.getProviders()[0]).key);
    }
    assert.deepStrictEqual(seq, ['k1', 'k2', 'k3', 'k1', 'k2'], 'Key 应轮询轮换');
    ok('Key 轮询轮换正确');
  }

  // ============ E. 换行头注入（服务商名含 CRLF） ============
  {
    const up = await startUpstream();
    const config = mockConfig();
    config.addProvider({ name: '恶意\r\nX-Injected: 1', baseUrl: `http://127.0.0.1:${up.port}`, keys: ['k1'], models: ['gpt-4'] });
    const router = new Router(config, os.tmpdir());
    const proxy = new ProxyServer(config, router);
    await proxy.start(0);
    const port = proxy.port;
    const r = await new Promise((resolve) => {
      const data = Buffer.from(JSON.stringify({ model: 'gpt-4', messages: [{ role: 'user', content: 'hi' }] }), 'utf8');
      const req = http.request({ host: '127.0.0.1', port, path: '/v1/chat/completions', method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': data.length } }, (res) => {
        const chunks = [];
        res.on('data', c => chunks.push(c));
        res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, text: Buffer.concat(chunks).toString('utf8') }));
      });
      req.on('error', () => resolve({ status: 0, headers: {}, text: '' }));
      req.write(data); req.end();
    });
    assert.strictEqual(r.status, 200, '含 CRLF 的服务商名不应导致崩溃');
    const providerHeader = r.headers['x-router-provider'] || '';
    assert.ok(!providerHeader.includes('\r') && !providerHeader.includes('\n'), '响应头不应含原始换行');
    assert.ok(!r.headers['x-injected'], '不应存在注入头');
    ok('换行头注入被安全编码');
    proxy.stop(); up.server.close();
  }

  // ============ F. 损坏配置文件容错 ============
  {
    const cfgPath = path.join(userDataDir, 'config.json');
    fs.writeFileSync(cfgPath, '{损坏的json!!!', 'utf8');
    const cfg = new ConfigManager();
    assert.ok(cfg.getAll() && cfg.getAll().proxyPort === 3456, '损坏配置应回退默认值');
    ok('损坏配置文件自动回退默认');
  }

  // ============ G. 内存上限（浸泡） ============
  {
    const config = mockConfig();
    config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4'] });
    const router = new Router(config, os.tmpdir());
    // 写入 3000 条日志（超出内存缓存 2000）
    for (let i = 0; i < 3000; i++) {
      router.tracer.write({ traceId: 't' + i, model: 'gpt-4', provider: 'A', status: 'success', latency: 1 });
    }
    assert.ok(router.tracer.entries.length <= 2000, `tracer 内存应封顶 2000，实际 ${router.tracer.entries.length}`);
    // recentRequests 封顶 50
    const origFetch = global.fetch;
    global.fetch = async () => ({ ok: true, status: 200, headers: {}, body: null, json: async () => ({ id: 'x', choices: [{ message: { content: 'ok' } }], usage: null }) });
    try {
      for (let i = 0; i < 100; i++) {
        await router.routeWithFallback({ model: 'gpt-4', messages: [{ role: 'user', content: '浸泡' + i }] });
      }
    } finally { global.fetch = origFetch; }
    assert.ok(router.getStats().recentRequests.length <= 50, 'recentRequests 应封顶 50');
    // SLO 样本封顶
    for (let i = 0; i < 300; i++) router.slo.sample(100);
    assert.ok(router.slo.samples.length <= 50, `SLO 样本应封顶 50，实际 ${router.slo.samples.length}`);
    ok('浸泡：tracer/recentRequests/SLO 内存全部封顶');
  }

  // ============ H. 图片 url 透传 + 嵌入数组输入 ============
  {
    const up = await startUpstream();
    const config = mockConfig();
    config.addProvider({ name: '上游', baseUrl: `http://127.0.0.1:${up.port}`, keys: ['k1'], models: ['gpt-4'] });
    const router = new Router(config, os.tmpdir());
    const proxy = new ProxyServer(config, router);
    await proxy.start(0);
    const port = proxy.port;
    const post = (path, body) => new Promise((resolve) => {
      const data = Buffer.from(JSON.stringify(body), 'utf8');
      const req = http.request({ host: '127.0.0.1', port, path, method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': data.length } }, (res) => {
        const chunks = [];
        res.on('data', c => chunks.push(c));
        res.on('end', () => resolve({ status: res.statusCode, text: Buffer.concat(chunks).toString('utf8') }));
      });
      req.on('error', () => resolve({ status: 0, text: '' }));
      req.write(data); req.end();
    });
    const img = await post('/v1/images/generations', { model: 'gpt-4', prompt: '一只猫' });
    assert.strictEqual(img.status, 200, img.text);
    assert.ok(JSON.parse(img.text).data[0].url, 'url 应透传');
    const emb = await post('/v1/embeddings', { model: 'gpt-4', input: ['句子一', '句子二'] });
    assert.strictEqual(emb.status, 200, emb.text);
    ok('图片 url 透传 + 嵌入数组输入');
    proxy.stop(); up.server.close();
  }

  // ============ I. AB 权重确定性 ============
  {
    const config = mockConfig();
    const router = new Router(config, os.tmpdir());
    config.set('routing.abTest', { enabled: true, groups: [{ name: 'a', model: 'm1', weight: 30 }, { name: 'b', model: 'm2', weight: 70 }] });
    const origRandom = Math.random;
    const picks = [];
    Math.random = () => 0.2;  // r=20 → 落在 a(30) 内
    picks.push(router.weightedPick(config.get('routing.abTest.groups')).name);
    Math.random = () => 0.8;  // r=80 → 落在 b
    picks.push(router.weightedPick(config.get('routing.abTest.groups')).name);
    Math.random = origRandom;
    assert.deepStrictEqual(picks, ['a', 'b'], '权重 30/70 应确定性命中');
    ok('AB 权重边界确定性（30/70）');
  }

  console.log(`\n通过 ${passed} 项, 失败 ${failed} 项`);
  process.exit(failed > 0 ? 1 : 0);
})().catch(e => { console.error('测试崩溃:', e); process.exit(1); });
