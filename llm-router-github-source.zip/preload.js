const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  // 配置
  getConfig: () => ipcRenderer.invoke('config:get'),
  saveConfig: (config) => ipcRenderer.invoke('config:save', config),
  resetConfig: () => ipcRenderer.invoke('config:reset'),

  // 服务商
  addProvider: (provider) => ipcRenderer.invoke('provider:add', provider),
  updateProvider: (id, data) => ipcRenderer.invoke('provider:update', id, data),
  removeProvider: (id) => ipcRenderer.invoke('provider:remove', id),

  // 预设渠道商
  getPresets: () => ipcRenderer.invoke('presets:get'),

  // 模型
  fetchModels: (providerId) => ipcRenderer.invoke('models:fetch', providerId),
  fetchAllModels: () => ipcRenderer.invoke('models:fetchAll'),

  // 健康检测
  getHealthStatus: () => ipcRenderer.invoke('health:status'),
  runHealthCheck: () => ipcRenderer.invoke('health:check'),
  checkProvider: (providerId) => ipcRenderer.invoke('health:checkProvider', providerId),
  restartHealthChecker: () => ipcRenderer.invoke('health:restart'),

  // 路由测试（返回 { data, meta }，meta 含实际模型/服务商/切换标记）
  testRoute: (model, messages, stream) => ipcRenderer.invoke('route:test', { model, messages, stream }),

  // 代理
  getProxyStatus: () => ipcRenderer.invoke('proxy:status'),
  setProxyPort: (port) => ipcRenderer.invoke('proxy:setPort', port),
  restartProxy: () => ipcRenderer.invoke('proxy:restart'),

  // 统计
  getStats: () => ipcRenderer.invoke('stats:get'),
  resetStats: () => ipcRenderer.invoke('stats:reset'),

  // 价格管理
  getPrices: () => ipcRenderer.invoke('price:get'),
  setPrice: (modelId, input, output) => ipcRenderer.invoke('price:set', modelId, input, output),
  removePrice: (modelId) => ipcRenderer.invoke('price:remove', modelId),
  syncPrices: () => ipcRenderer.invoke('price:sync'),
  setCurrency: (currency) => ipcRenderer.invoke('price:setCurrency', currency),

  // 内存缓存
  getCache: () => ipcRenderer.invoke('cache:get'),
  setCache: (data) => ipcRenderer.invoke('cache:set', data),
  clearCache: () => ipcRenderer.invoke('cache:clear'),

  // Trace 日志
  getLogs: (filter) => ipcRenderer.invoke('logs:recent', filter),
  exportLogs: () => ipcRenderer.invoke('logs:export'),
  clearLogs: () => ipcRenderer.invoke('logs:clear'),

  // 智能模块（质量/护栏/语义缓存/SLO/驻留/影子/体检）
  getSmart: () => ipcRenderer.invoke('smart:get'),
  setSmart: (section, data) => ipcRenderer.invoke('smart:set', section, data),

  // 内置记忆系统
  getMemory: () => ipcRenderer.invoke('memory:get'),
  probeMemory: () => ipcRenderer.invoke('memory:probe'),
  syncMemoryModels: () => ipcRenderer.invoke('memory:sync'),
  clearMemory: () => ipcRenderer.invoke('memory:clear'),
  setMemoryConfig: (data) => ipcRenderer.invoke('memory:set', data),
  trackFeature: (id, opts) => ipcRenderer.invoke('memory:track', id, opts),

  // 本地模型（v2.4.0）
  getLocalStatus: () => ipcRenderer.invoke('local:status'),
  downloadLocalEngine: () => ipcRenderer.invoke('local:downloadEngine'),
  downloadLocalModel: () => ipcRenderer.invoke('local:downloadModel'),
  startLocal: () => ipcRenderer.invoke('local:start'),
  stopLocal: () => ipcRenderer.invoke('local:stop'),
  setLocalConfig: (data) => ipcRenderer.invoke('local:set', data),
  getLocalTools: () => ipcRenderer.invoke('local:tools'),
  runLocalTool: (name, argsText) => ipcRenderer.invoke('local:toolRun', name, argsText),
  onLocalEvent: (cb) => { ipcRenderer.on('local:event', (_e, ev) => cb(ev)); },
  getDataUsage: () => ipcRenderer.invoke('data:usage'),
  cleanupData: () => ipcRenderer.invoke('data:cleanup'),
  // 远程访问与迁移（v3.0.0）
  getRemote: () => ipcRenderer.invoke('remote:get'),
  setRemote: (data) => ipcRenderer.invoke('remote:set', data),
  setRemotePassword: (pwd) => ipcRenderer.invoke('remote:setPassword', pwd),
  regenerateRemoteKey: () => ipcRenderer.invoke('remote:regenerateKey'),
  genRemoteNginx: (domain) => ipcRenderer.invoke('remote:nginx', domain),
  testRemote: (opts) => ipcRenderer.invoke('remote:test', opts),
  migrateRemote: (opts) => ipcRenderer.invoke('remote:migrate', opts),

  // 路由大脑（v2.5.0） + C2 撤销栈 IPC
  getBrainStatus: () => ipcRenderer.invoke('brain:status'),
  runBrain: (reason) => ipcRenderer.invoke('brain:run', reason),
  setBrainConfig: (data) => ipcRenderer.invoke('brain:set', data),
  getBrainPending: () => ipcRenderer.invoke('brain:pending'),
  getBrainUndoStack: () => ipcRenderer.invoke('brain:undo-stack'),
  undoBrain: () => ipcRenderer.invoke('brain:undo'),
  cancelBrain: () => ipcRenderer.invoke('brain:cancel'),
  onBrainEvent: (cb) => { ipcRenderer.on('brain:event', (_e, ev) => cb(ev)); },

  // 应用设置
  getAutoStart: () => ipcRenderer.invoke('app:getAutoStart'),
  setAutoStart: (enabled) => ipcRenderer.invoke('app:setAutoStart', enabled),
  setTrayMinimize: (enabled) => ipcRenderer.invoke('app:setTrayMinimize', enabled),

  // 窗口
  minimizeWindow: () => ipcRenderer.invoke('window:minimize'),
  closeWindow: () => ipcRenderer.invoke('window:close'),
  maximizeWindow: () => ipcRenderer.invoke('window:maximize'),

  // 背景图
  saveBgImage: (dataUrl) => ipcRenderer.invoke('bg:save', dataUrl),
  loadBgImage: () => ipcRenderer.invoke('bg:load'),
  resetBgImage: () => ipcRenderer.invoke('bg:reset'),

  // 剪贴板
  copyText: (text) => ipcRenderer.invoke('clipboard:copy', text),

  // 事件
  onHealthUpdate: (cb) => {
    const listener = (_, data) => cb(data);
    ipcRenderer.on('health:update', listener);
    return () => ipcRenderer.removeListener('health:update', listener);
  },
  onStatsUpdate: (cb) => {
    const listener = (_, data) => cb(data);
    ipcRenderer.on('stats:update', listener);
    return () => ipcRenderer.removeListener('stats:update', listener);
  },
});
