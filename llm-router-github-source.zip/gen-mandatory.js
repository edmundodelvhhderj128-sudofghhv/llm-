// 生成强制拦截模块的编码关键词（一次性脚本，产物不包含明文）
const crypto = require('crypto');

const WORDS = [
  // 色情
  '色情', '淫秽', '裸聊', '卖淫', '嫖娼', '情色', '色情网站', '色情视频', '黄色网站', '情色交易',
  // 恐怖/暴力
  '恐怖袭击', '恐怖主义', '爆炸物制作', '制爆', '枪支买卖', '毒品制作', '制毒', '杀人碎尸', '绑架勒索', '极端主义', '自杀式袭击', '人体炸弹',
  // 政治敏感（违法类）
  '颠覆国家政权', '分裂国家', '煽动颠覆', '邪教组织', '法轮功', '六四事件', '天安门事件'
];

function rot13(s) {
  return s.replace(/[a-zA-Z]/g, c => {
    const base = c <= 'Z' ? 65 : 97;
    return String.fromCharCode(((c.charCodeAt(0) - base + 13) % 26) + base);
  });
}

// 按 6 个一组分段编码
const CHUNK_SIZE = 6;
const chunks = [];
for (let i = 0; i < WORDS.length; i += CHUNK_SIZE) {
  const part = WORDS.slice(i, i + CHUNK_SIZE);
  const json = JSON.stringify(part);
  chunks.push(Buffer.from(rot13(json), 'utf8').toString('base64'));
}

console.log('words:', WORDS.length, 'chunks:', chunks.length);
chunks.forEach((c, i) => console.log(`C${i}: ${c}`));
console.log('--- sha256 of decoded ---');
const decoded = chunks.flatMap(c => JSON.parse(rot13(Buffer.from(c, 'base64').toString('utf8'))));
console.log('decoded count:', decoded.length, 'sample:', decoded.slice(0, 3).join('/'));
