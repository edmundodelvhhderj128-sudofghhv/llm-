/**
 * 端到端集成测试（不启动 Electron GUI）
 * 运行: node test-integration.js
 * 验证: 本地代理 /v1/chat/completions 故障切换、跨模型回退、流式、/v1/completions 格式转换、响应头
 */
const http = require('http');
const assert = require('assert');

// ---- 拦截 require('electron')，提供最小 mock ----
const Module = require('module');
const origLoad = Module._load;
let userDataDir = require('fs').mkdtempSync(require('path').join(require('os').tmpdir(), 'llm-router-test-'));
Module._load = function (request, parent, isMain) {
  if (request === 'electron') {
    return {
      app: { getPath: () => userDataDir },
      ipcMain: { handle: () => {} }
    };
  }
  return origLoad.apply(this, arguments);
};

const { ConfigManager } = require('./src/config');
const { Router } = require('./src/router');
const { ProxyServer } = require('./src/proxy');

// ---- 工具 ----
function requestJson(port, path, options = {}) {
  return new Promise((resolve, reject) => {
    const data = options.body ? JSON.stringify(options.body) : null;
    const req = http.request({
      host: '127.0.0.1',
      port,
      path,
      method: options.method || 'GET',
      headers: {
        'Content-Type': 'application/json',
        ...(data ? { 'Content-Length': Buffer.byteLength(data) } : {}),
        ...(options.headers || {})
      }
    }, (res) => {
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => {
        const text = Buffer.concat(chunks).toString('utf-8');
        resolve({ status: res.statusCode, headers: res.headers, text, json: safeParse(text) });
      });
    });
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

function safeParse(text) {
  try { return JSON.parse(text); } catch { return null; }
}

// ---- 模拟上游服务商 ----
function startUpstream(name, options = {}) {
  const server = http.createServer((req, res) => {
    server._count = (server._count || 0) + 1;
    const url = req.url;
    if (url === '/v1/models') {
      res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify({ data: (options.models || []).map(m => ({ id: m })) }));
      return;
    }
    if (url === '/v1/chat/completions') {
      let body = '';
      req.on('data', c => body += c);
      req.on('end', () => {
        const parsed = JSON.parse(body);
        const model = parsed.model || '';
        // 模拟失败：指定模型返回 500
        if (options.failModels && options.failModels.includes(model)) {
          res.statusCode = 500;
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ error: { message: `upstream ${name} failed for ${model}` } }));
          return;
        }
        // 模拟流式
        if (parsed.stream) {
          res.setHeader('Content-Type', 'text/event-stream');
          const chunks = ['你', '好', '，', '世', '界'];
          let i = 0;
          const timer = setInterval(() => {
            if (i >= chunks.length) {
              res.write('data: [DONE]\n\n');
              res.end();
              clearInterval(timer);
              return;
            }
            const payload = JSON.stringify({
              id: 'cmpl-test', object: 'chat.completion.chunk', created: 0, model,
              choices: [{ index: 0, delta: { content: chunks[i] }, finish_reason: null }]
            });
            res.write(`data: ${payload}\n\n`);
            i++;
          }, 20);
        } else {
          res.setHeader('Content-Type', 'application/json');
          // 回显消息信息，供压缩测试断言（消息数 + 压缩标记）
          const compressedMark = (parsed.messages || []).some(m => String(m.content || '').includes('已压缩')) ? 'compressed=yes' : 'compressed=no';
          const echo = options.echoBlocked ? '这是恐怖袭击相关的一段回复内容' : `回复来自${name}|msgs=${(parsed.messages || []).length}|${compressedMark}`;
          res.end(JSON.stringify({
            id: 'cmpl-test', object: 'chat.completion', created: 0, model,
            choices: [{ index: 0, message: { role: 'assistant', content: echo }, finish_reason: 'stop' }],
            usage: { prompt_tokens: 10, completion_tokens: 5, total_tokens: 15 }
          }));
        }
      });
      return;
    }
    if (url === '/v1/embeddings') {
      res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify({ object: 'list', data: [{ embedding: [0.1, 0.2], index: 0 }], usage: { total_tokens: 3 } }));
      return;
    }
    if (url === '/v1/images/generations') {
      let body = '';
      req.on('data', c => body += c);
      req.on('end', () => {
        const parsed = JSON.parse(body);
        if (options.failImage && options.failImage.includes(parsed.model)) {
          res.statusCode = 500;
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ error: { message: 'image failed' } }));
          return;
        }
        res.setHeader('Content-Type', 'application/json');
        res.end(JSON.stringify({ created: 1, data: [{ b64_json: Buffer.from('fake-image-' + parsed.model).toString('base64') }] }));
      });
      return;
    }
    if (url === '/v1/videos/generations') {
      let body = '';
      req.on('data', c => body += c);
      req.on('end', () => {
        const parsed = JSON.parse(body);
        res.setHeader('Content-Type', 'application/json');
        res.end(JSON.stringify({ id: 'vid-' + (server._vidCount = (server._vidCount || 0) + 1), status: 'queued', model: parsed.model }));
      });
      return;
    }
    const vidMatch = url.match(/^\/v1\/videos\/generations\/([^/]+)$/);
    if (vidMatch) {
      res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify({ id: vidMatch[1], status: 'completed', url: 'http://127.0.0.1:' + server.address().port + '/video.mp4' }));
      return;
    }
    res.statusCode = 404;
    res.end('{}');
  });
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => resolve({ port: server.address().port, server, count: () => server._count || 0, setOptions: (o) => Object.assign(options, o) }));
  });
}

let passed = 0;
function test(name, fn) {
  return Promise.resolve()
    .then(fn)
    .then(() => { passed++; console.log(`  ok ${name}`); })
    .catch(e => { console.log(`  FAIL ${name}: ${e.message}`); process.exitCode = 1; });
}

(async () => {
  // 上游1: 只有 gpt-4，gpt-4 失败 500（触发故障切换）；gpt-3.5-turbo 成功
  const up1 = await startUpstream('A渠道', {
    models: ['gpt-4', 'gpt-3.5-turbo'],
    failModels: ['gpt-4']
  });
  // 上游2: 支持 gpt-4 + gpt-4o-mini，全部成功
  const up2 = await startUpstream('B渠道', { models: ['gpt-4', 'gpt-4o-mini'] });

  const config = new ConfigManager();
  config.reset();
  config.set('proxyPort', 0); // 让系统分配端口（ProxyServer.start(0) 会监听随机端口）

  config.addProvider({
    name: 'A渠道',
    baseUrl: `http://127.0.0.1:${up1.port}`,
    keys: ['key-a'],
    models: ['gpt-4', 'gpt-3.5-turbo'],
    priority: 1
  });
  config.addProvider({
    name: 'B渠道',
    baseUrl: `http://127.0.0.1:${up2.port}`,
    keys: ['key-b'],
    models: ['gpt-4', 'gpt-4o-mini'],
    priority: 2
  });

  const router = new Router(config, require('os').tmpdir());
  const proxy = new ProxyServer(config, router);
  await proxy.start(0);
  const port = proxy.port;
  console.log(`代理已启动: http://127.0.0.1:${port}`);

  // ---- 1. 健康检查 ----
  await test('GET /health 返回 ok', async () => {
    const r = await requestJson(port, '/health');
    assert.strictEqual(r.status, 200);
    assert.strictEqual(r.json.status, 'ok');
  });

  // ---- 2. 模型列表 ----
  await test('GET /v1/models 聚合模型', async () => {
    const r = await requestJson(port, '/v1/models');
    assert.strictEqual(r.status, 200);
    const ids = r.json.data.map(m => m.id).sort();
    assert.deepStrictEqual(ids, ['gpt-3.5-turbo', 'gpt-4', 'gpt-4o-mini']);
  });

  // ---- 3. 故障切换：A 渠道 gpt-4 失败 -> 切到 B 渠道 ----
  await test('POST /v1/chat/completions 故障切换 (A失败->B成功)', async () => {
    const r = await requestJson(port, '/v1/chat/completions', {
      method: 'POST',
      body: { model: 'gpt-4', messages: [{ role: 'user', content: '故障切换测试消息' }], noCache: true }
    });
    assert.strictEqual(r.status, 200, r.text);
    assert.ok(r.json.choices[0].message.content.includes('B渠道'));
    assert.strictEqual(decodeURIComponent(r.headers['x-router-provider']), 'B渠道');
    assert.strictEqual(decodeURIComponent(r.headers['x-router-model']), 'gpt-4');
  });

  // ---- 4. 跨模型回退：所有服务商 gpt-4 都失败 -> 回退 gpt-3.5-turbo ----
  await test('跨模型回退 (gpt-4全败 -> gpt-3.5-turbo)', async () => {
    // 让 B 渠道也失败
    const req = await requestJson(port, '/v1/chat/completions', {
      method: 'POST',
      body: { model: 'gpt-4', messages: [{ role: 'user', content: '回退测试消息' }], noCache: true }
    });
    // 第一次 B 渠道成功，正常
    assert.strictEqual(req.status, 200, req.text);

    // 修改 B 渠道也失败后重试 —— 通过关闭 B 上游
    up2.server.close();
    const r = await requestJson(port, '/v1/chat/completions', {
      method: 'POST',
      body: { model: 'gpt-4', messages: [{ role: 'user', content: '回退测试消息' }], noCache: true }
    });
    assert.strictEqual(r.status, 200, r.text);
    assert.strictEqual(decodeURIComponent(r.headers['x-router-model']), 'gpt-3.5-turbo');
    assert.strictEqual(decodeURIComponent(r.headers['x-router-provider']), 'A渠道');
  });

  // ---- 5. 流式输出 ----
  await test('POST /v1/chat/completions 流式 (SSE)', async () => {
    const r = await requestJson(port, '/v1/chat/completions', {
      method: 'POST',
      body: { model: 'gpt-3.5-turbo', messages: [{ role: 'user', content: 'hi' }], stream: true }
    });
    assert.strictEqual(r.status, 200);
    assert.ok(r.headers['content-type'].includes('text/event-stream'));
    assert.ok(r.text.includes('data:'), '应有 SSE data 块');
    assert.ok(r.text.includes('[DONE]'));
    // 内容应包含流式拼接的文本
    assert.ok(r.text.includes('你') || r.text.includes('好'));
  });

  // ---- 6. /v1/completions 文本补全格式转换 ----
  await test('POST /v1/completions 返回 completions 格式', async () => {
    const r = await requestJson(port, '/v1/completions', {
      method: 'POST',
      body: { model: 'gpt-3.5-turbo', prompt: 'hello' }
    });
    assert.strictEqual(r.status, 200, r.text);
    assert.strictEqual(r.json.object, 'text_completion');
    assert.ok(typeof r.json.choices[0].text === 'string');
  });

  // ---- 7. /v1/embeddings ----
  await test('POST /v1/embeddings 可用', async () => {
    const r = await requestJson(port, '/v1/embeddings', {
      method: 'POST',
      body: { model: 'gpt-3.5-turbo', input: 'hello' }
    });
    assert.strictEqual(r.status, 200, r.text);
    assert.ok(r.json.data[0].embedding.length > 0);
  });

  // ---- 10. 内存命中缓存 ----
  await test('非流式缓存：第二次请求命中，上游只调一次', async () => {
    const before = up1.count();
    const body = { model: 'gpt-3.5-turbo', messages: [{ role: 'user', content: '缓存测试问题' }], temperature: 0.7 };
    const r1 = await requestJson(port, '/v1/chat/completions', { method: 'POST', body });
    assert.strictEqual(r1.status, 200, r1.text);
    assert.notStrictEqual(r1.headers['x-router-cache'], 'HIT', '首次不应命中');
    const r2 = await requestJson(port, '/v1/chat/completions', { method: 'POST', body });
    assert.strictEqual(r2.headers['x-router-cache'], 'HIT', '第二次应命中缓存');
    assert.strictEqual(r2.json.choices[0].message.content, r1.json.choices[0].message.content, '内容应一致');
    assert.strictEqual(up1.count() - before, 1, '上游应只调用一次');
  });

  await test('流式缓存：流式命中重放 SSE，流式/非流式共用缓存', async () => {
    const before = up1.count();
    // 第一次流式（未命中，完成后写缓存）
    const r1 = await requestJson(port, '/v1/chat/completions', {
      method: 'POST',
      body: { model: 'gpt-3.5-turbo', messages: [{ role: 'user', content: '流式缓存测试' }], stream: true }
    });
    assert.strictEqual(r1.status, 200, r1.text);
    assert.ok(r1.text.includes('data:'), '应有 SSE 数据');
    // 第二次流式（命中）
    const r2 = await requestJson(port, '/v1/chat/completions', {
      method: 'POST',
      body: { model: 'gpt-3.5-turbo', messages: [{ role: 'user', content: '流式缓存测试' }], stream: true }
    });
    assert.strictEqual(r2.headers['x-router-cache'], 'HIT', '流式第二次应命中');
    assert.ok(r2.text.includes('[DONE]'));
    assert.ok(r2.text.includes('你好') || r2.text.includes('世界'), '重放内容应完整');
    // 第三次非流式（也应命中——共用缓存）
    const r3 = await requestJson(port, '/v1/chat/completions', {
      method: 'POST',
      body: { model: 'gpt-3.5-turbo', messages: [{ role: 'user', content: '流式缓存测试' }] }
    });
    assert.strictEqual(r3.headers['x-router-cache'], 'HIT', '非流式应命中同一缓存');
    assert.strictEqual(up1.count() - before, 1, '上游应只调用一次');
  });

  await test('缓存统计生效（命中数/条目数）', () => {
    const stats = router.getCacheStats();
    assert.ok(stats.hits >= 3, `命中数应>=3，实际 ${stats.hits}`);
    assert.ok(stats.entries >= 1, '应有缓存条目');
    assert.ok(stats.maxBytes > 0);
  });

  // ---- 11. 开源接口 ----
  await test('GET /openapi.json 返回 OpenAPI 3.0 规范', async () => {
    const r = await requestJson(port, '/openapi.json');
    assert.strictEqual(r.status, 200);
    assert.strictEqual(r.json.openapi, '3.0.3');
    assert.ok(r.json.info.title.includes('智能中转'));
    assert.ok(r.json.paths['/v1/chat/completions']?.post, '应包含聊天补全接口定义');
    assert.ok(r.json.paths['/v1/embeddings']?.post, '应包含嵌入接口定义');
    assert.ok(r.json.components === undefined || true);
  });

  await test('GET /docs 返回接口文档页', async () => {
    const r = await requestJson(port, '/docs');
    assert.strictEqual(r.status, 200);
    assert.ok(r.headers['content-type'].includes('text/html'));
    assert.ok(r.text.includes('API 文档'));
    assert.ok(r.text.includes('/api/status'));
  });

  await test('GET /api/status 返回运行时状态', async () => {
    const r = await requestJson(port, '/api/status');
    assert.strictEqual(r.status, 200);
    assert.strictEqual(r.json.name, 'zimu-transit-router');
    assert.strictEqual(r.json.version, '3.0.2');
    assert.strictEqual(r.json.license, 'MIT');
    assert.ok(r.json.proxy.port > 0);
    assert.ok(r.json.cache && typeof r.json.cache.hits === 'number');
    assert.ok(r.json.providers.total >= 2);
  });

  // ---- 12. 智能模块端到端（Trace/护栏/语义缓存/驻留） ----
  await test('X-Trace-Id 透传与日志记录', async () => {
    const traceId = 'test-trace-001';
    const r = await requestJson(port, '/v1/chat/completions', {
      method: 'POST',
      headers: { 'X-Trace-Id': traceId },
      body: { model: 'gpt-3.5-turbo', messages: [{ role: 'user', content: 'trace 端到端测试内容' }], noCache: true }
    });
    assert.strictEqual(r.status, 200, r.text);
    assert.strictEqual(r.headers['x-trace-id'], traceId, '应回显 Trace ID');
    const logs = router.tracer.recent(100, {});
    assert.ok(logs.some(l => l.traceId === traceId && l.status === 'success'), '日志应包含该 Trace');
  });

  await test('内容护栏：敏感词输入拦截返回 403', async () => {
    config.set('guard', { enabled: true, maskPII: false, blockSensitive: true, sensitiveWords: ['违禁测试'] });
    const r = await requestJson(port, '/v1/chat/completions', {
      method: 'POST',
      body: { model: 'gpt-3.5-turbo', messages: [{ role: 'user', content: '这是一段包含违禁测试的内容' }] }
    });
    assert.strictEqual(r.status, 403, '应返回 403 而非 502');
    assert.ok(r.json.error.type === 'blocked_by_guard');
    config.set('guard', { enabled: false, maskPII: true, blockSensitive: false, sensitiveWords: [] });
  });

  await test('语义缓存：语义相似请求命中 SEMANTIC-HIT', async () => {
    config.set('semanticCache', { enabled: true, threshold: 0.95, maxEntries: 500, embeddingProviderId: null, embeddingModel: null });
    const r1 = await requestJson(port, '/v1/chat/completions', {
      method: 'POST',
      body: { model: 'gpt-3.5-turbo', messages: [{ role: 'user', content: '语义缓存端到端内容甲' }] }
    });
    assert.strictEqual(r1.status, 200, r1.text);
    // 同义改写（mock 上游嵌入向量相同 → 相似度 1.0）
    const r2 = await requestJson(port, '/v1/chat/completions', {
      method: 'POST',
      body: { model: 'gpt-3.5-turbo', messages: [{ role: 'user', content: '语义缓存端到端内容甲的同义改写' }] }
    });
    assert.strictEqual(r2.headers['x-router-cache'], 'SEMANTIC-HIT', r2.text);
    config.set('semanticCache', { enabled: false, threshold: 0.95, maxEntries: 500 });
  });

  await test('数据驻留：区域白名单过滤后无可用服务商', async () => {
    config.set('residency', { enabled: true, allowedRegions: ['XX'] });
    const r = await requestJson(port, '/v1/chat/completions', {
      method: 'POST',
      body: { model: 'gpt-3.5-turbo', messages: [{ role: 'user', content: '驻留过滤测试内容' }], noCache: true }
    });
    assert.strictEqual(r.status, 502, '区域被过滤应导致路由失败');
    config.set('residency', { enabled: false, allowedRegions: [] });
  });

  await test('GET /api/status 包含智能模块信息', async () => {
    const r = await requestJson(port, '/api/status');
    assert.strictEqual(r.status, 200);
    assert.ok(r.json.smart, '应有 smart 段');
    assert.ok(r.json.smart.healthcheck && r.json.smart.healthcheck.total === 10, '体检应含 10 项');
    assert.ok(r.json.smart.slo && typeof r.json.smart.slo.p95Ms === 'number');
  });

  await test('空请求体不崩溃：返回 400', async () => {
    // 无 Content-Type / 空 body 的 POST
    const r = await new Promise((resolve, reject) => {
      const req = http.request({ host: '127.0.0.1', port, path: '/v1/chat/completions', method: 'POST' }, (res) => {
        const chunks = [];
        res.on('data', c => chunks.push(c));
        res.on('end', () => resolve({ status: res.statusCode, text: Buffer.concat(chunks).toString('utf8') }));
      });
      req.on('error', reject);
      req.end();
    });
    assert.strictEqual(r.status, 400, '应返回 400 而非崩溃: ' + r.text);
    // 服务仍存活
    const health = await requestJson(port, '/health');
    assert.strictEqual(health.status, 200, '进程应存活');
  });

  await test('非法 JSON 请求体不崩溃：返回 400', async () => {
    const r = await new Promise((resolve, reject) => {
      const data = Buffer.from('{bad json', 'utf8');
      const req = http.request({ host: '127.0.0.1', port, path: '/v1/chat/completions', method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': data.length } }, (res) => {
        const chunks = [];
        res.on('data', c => chunks.push(c));
        res.on('end', () => resolve({ status: res.statusCode, text: Buffer.concat(chunks).toString('utf8') }));
      });
      req.on('error', reject);
      req.write(data);
      req.end();
    });
    assert.strictEqual(r.status, 400, '应返回 400: ' + r.text);
    const health = await requestJson(port, '/health');
    assert.strictEqual(health.status, 200, '进程应存活');
  });

  // ---- 13. 多模态：图片/视频生成 ----
  await test('POST /v1/images/generations 图片生成 + 路由头', async () => {
    const r = await requestJson(port, '/v1/images/generations', {
      method: 'POST',
      body: { model: 'gpt-4', prompt: '一只猫' }
    });
    assert.strictEqual(r.status, 200, r.text);
    assert.ok(r.json.data[0].b64_json, '应返回 b64_json');
    assert.ok(r.headers['x-router-provider'], '应有服务商头');
  });

  await test('图片智能调度：请求模型缺失时自动选用同能力模型', async () => {
    // 服务商 A 有 image 能力模型？给 A 加一个图片模型
    const p = config.getProviders().find(x => x.name === 'A渠道');
    config.updateProvider(p.id, { models: [...(p.models || []), 'agnes-image-2.1-flash'] });
    const r = await requestJson(port, '/v1/images/generations', {
      method: 'POST',
      body: { model: '不存在的图片模型', prompt: '测试图片' }
    });
    assert.strictEqual(r.status, 200, r.text);
    assert.strictEqual(decodeURIComponent(r.headers['x-router-model']), 'agnes-image-2.1-flash', '应自动调度到图片模型');
    assert.strictEqual(r.headers['x-router-switched'], '1', '应标记切换');
    // 还原
    config.updateProvider(p.id, { models: p.models.filter(m => m !== 'agnes-image-2.1-flash') });
  });

  await test('POST /v1/videos/generations 提交 + GET 轮询状态', async () => {
    const r = await requestJson(port, '/v1/videos/generations', {
      method: 'POST',
      body: { model: 'gpt-4', prompt: '海浪视频' }
    });
    assert.strictEqual(r.status, 200, r.text);
    const taskId = r.json.id;
    assert.ok(taskId, '应返回任务 ID');
    assert.strictEqual(r.json.status, 'queued');
    // 轮询
    const s = await requestJson(port, '/v1/videos/generations/' + taskId);
    assert.strictEqual(s.status, 200, s.text);
    assert.strictEqual(s.json.status, 'completed');
    assert.ok(s.json.url, '应返回视频地址');
  });

  await test('图片/视频：缺 prompt 返回 400，不崩溃', async () => {
    const r1 = await requestJson(port, '/v1/images/generations', { method: 'POST', body: { model: 'gpt-4' } });
    assert.strictEqual(r1.status, 400);
    const r2 = await requestJson(port, '/v1/videos/generations', { method: 'POST', body: { model: 'gpt-4' } });
    assert.strictEqual(r2.status, 400);
    const health = await requestJson(port, '/health');
    assert.strictEqual(health.status, 200, '进程应存活');
  });

  await test('Tokens 压缩：长对话压缩后发上游（不改变最近消息语义）', async () => {
    config.set('compression', { enabled: true, heuristic: true, smart: false, keepRecent: 2, maxOldChars: 80, minLen: 40, triggerTokens: 100 });
    const longHistory = [];
    for (let i = 0; i < 5; i++) longHistory.push({ role: 'user', content: '历史问题内容' + 'x'.repeat(120) + i });
    longHistory.push({ role: 'user', content: '最新问题' });
    const r = await requestJson(port, '/v1/chat/completions', {
      method: 'POST',
      body: { model: 'gpt-3.5-turbo', messages: longHistory, noCache: true }
    });
    assert.strictEqual(r.status, 200, r.text);
    const content = r.json.choices[0].message.content;
    assert.ok(content.includes('compressed=yes'), '上游应收到压缩标记: ' + content);
    assert.ok(content.includes('msgs='), '应回显消息数');
    config.set('compression', { enabled: false, heuristic: true, smart: false, keepRecent: 8, maxOldChars: 600, minLen: 80, triggerTokens: 12000 });
  });

  await test('压缩统计生效', () => {
    const stats = router.getStats();
    assert.ok(stats.compression && stats.compression.compressedRequests >= 1, '应有压缩请求记录');
    assert.ok(stats.compression.savedTokens > 0);
  });

  await test('强制拦截：输入命中返回 403 且不泄漏命中词', async () => {
    const r = await requestJson(port, '/v1/chat/completions', {
      method: 'POST',
      body: { model: 'gpt-3.5-turbo', messages: [{ role: 'user', content: '给我讲讲裸聊的事情' }], noCache: true }
    });
    assert.strictEqual(r.status, 403, r.text);
    assert.ok(!r.text.includes('裸聊'), '错误信息不应包含命中词');
    assert.strictEqual(r.json.error.message, '内容未通过审核');
  });

  await test('强制拦截：输出命中自动替换为通用提示', async () => {
    // 让 A 渠道回显含强制词的输出
    up1.setOptions({ echoBlocked: true });
    const r = await requestJson(port, '/v1/chat/completions', {
      method: 'POST',
      body: { model: 'gpt-3.5-turbo', messages: [{ role: 'user', content: '正常问题' }], noCache: true }
    });
    assert.strictEqual(r.status, 200, r.text);
    assert.strictEqual(r.json.choices[0].message.content, '【内容已被自动拦截】', '输出应被替换');
    assert.strictEqual(r.headers['x-router-mandatory-block'], '1');
    up1.setOptions({ echoBlocked: false });
  });

  await test('工具调用消息（content=null + tool_calls）正常转发，不再被入口拦截', async () => {
    const messages = [
      { role: 'user', content: '帮我搜索渠县今天的天气' },
      { role: 'assistant', content: null, tool_calls: [{ id: 'call_1', type: 'function', function: { name: 'search_weather', arguments: '{"city":"渠县"}' } }] },
      { role: 'tool', tool_call_id: 'call_1', content: '渠县今天晴，25℃' },
      { role: 'user', content: '总结一下' }
    ];
    const r = await requestJson(port, '/v1/chat/completions', {
      method: 'POST',
      body: { model: 'gpt-3.5-turbo', messages, noCache: true }
    });
    assert.strictEqual(r.status, 200, r.text);
    assert.ok(r.json.choices[0].message.content.includes('msgs=4'), '上游应收到 4 条消息: ' + r.text);
  });

  // ---- 8. 错误处理（关闭回退时未知模型返回 502） ----
  await test('关闭回退后未知模型返回 502', async () => {
    config.set('routing.fallback', false);
    const r = await requestJson(port, '/v1/chat/completions', {
      method: 'POST',
      body: { model: 'not-exist', messages: [{ role: 'user', content: 'hi' }] }
    });
    assert.strictEqual(r.status, 502);
    assert.ok(r.json.error.message.includes('not-exist'));
    config.set('routing.fallback', true);
  });

  // ---- 9. 统计 ----
  await test('getStats 包含请求记录与切换信息', () => {
    const stats = router.getStats();
    assert.ok(stats.totalRequests >= 5);
    assert.ok(stats.recentRequests.some(r => r.model === 'gpt-3.5-turbo' && r.status === 'success'));
  });

  proxy.stop();
  up1.server.close();
  console.log(`\n通过 ${passed} 项集成测试`);
  process.exit(process.exitCode || 0);
})().catch(e => { console.error('集成测试崩溃:', e); process.exit(1); });
