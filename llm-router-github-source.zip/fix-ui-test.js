// 修正测试：通过 window.eval 访问顶层 const state（jsdom 作用域差异）
const fs = require('fs');
const path = require('path');

let t = fs.readFileSync('test-ui.js', 'utf8');
// 用辅助函数替换 window.state 访问
t = t.split('window.state.currentPage = ').join('window.eval(\'state.currentPage = \' + JSON.stringify(').replaceAll('window.state.config', 'window.eval(\'state.config\')');
// 上一步的 split/join 需要更精确处理，改用整体替换策略
fs.writeFileSync('test-ui.js', t, 'utf8');
console.log('patched (rough)');
