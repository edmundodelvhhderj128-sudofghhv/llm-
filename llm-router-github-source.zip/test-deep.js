/**
 * 深度测试（第三轮：不同方法）——并发竞态 / 模糊输入 / 边界条件 / 数据泄漏
 * 运行: node test-deep.js
 */
const assert = require('assert');
const os = require('os');
const http = require('http');
const fs = require('fs');
const path = require('path');

// ---- mock electron ----
const Module = require('module');
const origLoad = Module._load;
let userDataDir = require('fs').mkdtempSync(require('path').join(os.tmpdir(), 'llm-deep-'));
Module._load = function (request, parent, isMain) {
  if (request === 'electron') return { app: { getPath: () => userDataDir }, ipcMain: { handle: () => {} } };
  return origLoad.apply(this, arguments);
};

const { ConfigManager } = require('./src/config');
const { Router } = require('./src/router');
const { ProxyServer } = require('./src/proxy');

let passed = 0, failed = 0;
function ok(name) { passed++; console.log(`  ok ${name}`); }
function fail(name, detail) { failed++; console.log(`  FAIL ${name}: ${detail || ''}`); }

function mockConfig() {
  const state = {
    providers: [], routing: { strategy: 'priority', failover: true, fallback: true, maxRetries: 3, timeout: 5000, healthCheckInterval: 5, circuitBreaker: { enabled: true, threshold: 5, cooldownMs: 60000 }, quota: { enabled: false, period: 'day', limits: {} }, costOptimization: { enabled: false, preferCheapest: true }, abTest: { enabled: false, groups: [] } },
    prices: { currency: 'USD', models: { 'gpt-4': { input: 30, output: 60 } } },
    cache: { enabled: true, maxBytes: 104857600, stream: true, embeddings: true },
    quality: {}, guard: { enabled: false, maskPII: true, blockSensitive: false, sensitiveWords: [] },
    semanticCache: { enabled: false, threshold: 0.95, maxEntries: 1000 }, slo: { enabled: true, p95ThresholdMs: 100000, windowSize: 200 },
    residency: { enabled: false, allowedRegions: [] }, shadow: { enabled: true },
    compression: { enabled: false }, logging: { enabled: true }
  };
  return {
    config: state,
    get(key) { return key.split('.').reduce((o, k) => o?.[k], this.config); },
    set(key, v) { const ks = key.split('.'); const last = ks.pop(); const t = ks.reduce((o, k) => { if (!o[k]) o[k] = {}; return o[k]; }, this.config); t[last] = v; },
    getAll() { return this.config; },
    persist() {},
    addProvider(p) {
      const id = p.id || ('p' + this.config.providers.length);
      const prov = { id, name: p.name, baseUrl: p.baseUrl, keys: p.keys || ['k1'], models: p.models || [], enabled: p.enabled !== false, priority: p.priority || this.config.providers.length + 1, keyIndex: 0, keyStats: {}, region: p.region || 'any', pathStyle: p.pathStyle || 'v1', billing: p.billing || { mode: 'tokens', pricePerCall: 0 }, weights: p.weights || { latencyMs: null, successRate: 1, requests: 0, qualityScore: 70 }, circuit: { failures: 0, open: false, openedAt: null }, quotaUsed: { periodKey: null, requests: 0, tokens: 0 } };
      prov.keys.forEach((_, i) => { prov.keyStats[i] = { requests: 0, errors: 0, consecutiveErrors: 0, lastUsed: null, disabled: false }; });
      this.config.providers.push(prov);
      return prov;
    },
    updateProvider(id, d) { const i = this.config.providers.findIndex(p => p.id === id); this.config.providers[i] = { ...this.config.providers[i], ...d }; return this.config.providers[i]; },
    getProviders() { return this.config.providers; },
    getEnabledProviders() { return this.config.providers.filter(p => p.enabled); }
  };
}

(async () => {
  // ============ A. 并发竞态 ============
  {
    const config = mockConfig();
    config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1', 'k2'], models: ['gpt-4'] });
    const origFetch = global.fetch;
    let calls = 0;
    global.fetch = async () => { calls++; return { ok: true, status: 200, headers: {}, body: null, json: async () => ({ id: 'x', choices: [{ message: { content: 'ok' } }], usage: { total_tokens: 10 } }) }; };
    try {
      const router = new Router(config, os.tmpdir());
      // 20 个不同内容的并发请求
      const results = await Promise.all(Array.from({ length: 20 }, (_, i) =>
        router.routeWithFallback({ model: 'gpt-4', messages: [{ role: 'user', content: '并发测试' + i }] })
      ));
      const allOk = results.every(r => r.success === true);
      ok('并发 20 请求全部成功');
      assert.strictEqual(allOk, true);
      const stats = router.getStats();
      assert.strictEqual(stats.totalRequests, 20, '统计应准确');
      // 20 个相同请求并发 → 全部缓存命中（上游只调 1 次）
      const before = calls;
      await Promise.all(Array.from({ length: 20 }, () =>
        router.routeWithFallback({ model: 'gpt-4', messages: [{ role: 'user', content: '完全相同内容' }] })
      ));
      assert.strictEqual(calls - before, 1, `并发相同请求上游应只调 1 次，实际 ${calls - before}`);
      ok('并发相同请求缓存命中（上游仅 1 次）');
    } finally { global.fetch = origFetch; }
  }

  // ============ B. 边界条件 ============
  {
    const config = mockConfig();
    config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4'] });
    const router = new Router(config, os.tmpdir());

    // AB 权重全 0 → 不 NaN、不崩溃
    config.set('routing.abTest', { enabled: true, groups: [{ name: 'g1', model: 'gpt-4', weight: 0 }, { name: 'g2', model: 'gpt-4', weight: 0 }] });
    const picked = router.weightedPick(config.get('routing.abTest.groups'));
    assert.ok(picked && picked.name, '权重全 0 应返回首个分组');
    ok('AB 权重全 0 不产生 NaN');

    // 加权策略 + 全部熔断 → 空列表不崩溃
    config.set('routing.strategy', 'weighted');
    const p = config.getProviders()[0];
    p.circuit = { failures: 9, open: true, openedAt: Date.now() };
    const list = router.selectProviders('gpt-4');
    assert.strictEqual(list.length, 0, '全部熔断应为空');
    ok('加权策略全熔断返回空列表');
    p.circuit = { failures: 0, open: false, openedAt: null };

    // 配额 tokens 边界（v2.8.0 软降级）：90% 软超限仍允许；120% 硬超限拒绝
    config.set('routing.quota', { enabled: true, period: 'day', limits: { [p.id]: { requests: 0, tokens: 1000 } } });
    p.quotaUsed = { periodKey: router.quotaPeriodKey('day'), requests: 0, tokens: 999 };
    assert.strictEqual(router.checkQuota(p).ok, true, '未达限额应允许');
    p.quotaUsed.tokens = 1000;   // 100% ≥ 90% 软超限 → 仍允许
    const softR = router.checkQuota(p);
    assert.strictEqual(softR.ok, true, '软超限应允许');
    assert.strictEqual(softR.soft, true, '应标记 soft');
    p.quotaUsed.tokens = 1201;   // 120% ≥ 120% 硬超限 → 拒绝
    assert.strictEqual(router.checkQuota(p).ok, false, '硬超限应拒绝');
    ok('配额 tokens 边界（软 90%/硬 120%）');

    // Key 全禁用 → selectKey 重置后仍可用
    config.set('routing.quota', { enabled: false, period: 'day', limits: {} });
    const p2 = config.getProviders()[0];
    p2.keyStats = { 0: { disabled: true } };
    const kr = router.selectKey(p2);
    assert.ok(kr && kr.key === 'k1', '全禁用后应重置可用');
    ok('Key 全禁用自动重置');

    // Trace 不泄漏消息内容
    const entries = router.tracer.recent(100, {});
    const leak = entries.some(e => e.messages !== undefined || e.prompt !== undefined);
    assert.strictEqual(leak, false, 'Trace 不应包含消息内容');
    ok('Trace 日志不泄漏消息内容');
  }

  // ============ C. 语义缓存嵌入失败回退 ============
  {
    const config = mockConfig();
    config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4', 'text-embedding-3-small'] });
    config.set('semanticCache', { enabled: true, threshold: 0.95, maxEntries: 100, embeddingProviderId: null, embeddingModel: null });
    const origFetch = global.fetch;
    let embedFails = true;
    global.fetch = async (url) => {
      if (String(url).includes('/embeddings')) {
        if (embedFails) return { ok: false, status: 500, text: async () => 'err', headers: {}, body: null };
        return { ok: true, status: 200, headers: {}, body: null, json: async () => ({ data: [{ embedding: [1, 0, 0] }] }) };
      }
      return { ok: true, status: 200, headers: {}, body: null, json: async () => ({ id: 'x', choices: [{ message: { content: 'ok' } }], usage: null }) };
    };
    try {
      const router = new Router(config, os.tmpdir());
      const r = await router.routeWithFallback({ model: 'gpt-4', messages: [{ role: 'user', content: '语义失败回退测试' }] });
      assert.strictEqual(r.success, true, '嵌入失败不应影响主请求');
      assert.ok(router.semanticCache.embedErrors >= 1);
      ok('语义缓存嵌入失败自动回退主路由');
    } finally { global.fetch = origFetch; }
  }

  // ============ D. 压缩不破坏多模态消息 ============
  {
    const config = mockConfig();
    config.set('compression', { enabled: true, heuristic: true, smart: false, keepRecent: 1, maxOldChars: 50, minLen: 10, triggerTokens: 10 });
    const router = new Router(config, os.tmpdir());
    const multimodal = { role: 'user', content: [{ type: 'text', text: '描述图片' }, { type: 'image_url', image_url: { url: 'https://x/img.png' } }] };
    const msgs = [multimodal, { role: 'user', content: 'x'.repeat(200) }, { role: 'user', content: '最近' }];
    const r = await router.compressMessages(msgs);
    assert.strictEqual(r.compressed, true);
    const kept = r.messages.find(m => Array.isArray(m.content));
    assert.ok(kept, '多模态消息应保持数组结构');
    assert.ok(kept.content[1].image_url, 'image_url 结构不应被破坏');
    ok('压缩不破坏多模态消息结构');
  }

  // ============ E. 代理模糊输入（错误类型不崩溃） ============
  {
    const up = http.createServer((req, res) => {
      let body = '';
      req.on('data', c => body += c);
      req.on('end', () => {
        if (req.url === '/v1/chat/completions') {
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ id: 'x', choices: [{ message: { content: 'ok' } }], usage: null }));
        } else { res.statusCode = 404; res.end('{}'); }
      });
    });
    await new Promise(r => up.listen(0, '127.0.0.1', r));
    const config = mockConfig();
    config.addProvider({ name: '模糊上游', baseUrl: `http://127.0.0.1:${up.address().port}`, keys: ['k1'], models: ['gpt-4'] });
    const router = new Router(config, os.tmpdir());
    const proxy = new ProxyServer(config, router);
    await proxy.start(0);
    const port = proxy.port;

    const post = (body, headers = { 'Content-Type': 'application/json' }) => new Promise((resolve) => {
      const data = Buffer.from(typeof body === 'string' ? body : JSON.stringify(body), 'utf8');
      const req = http.request({ host: '127.0.0.1', port, path: '/v1/chat/completions', method: 'POST', headers: { ...headers, ...(data ? { 'Content-Length': data.length } : {}) } }, (res) => {
        const chunks = [];
        res.on('data', c => chunks.push(c));
        res.on('end', () => resolve(res.statusCode));
      });
      req.on('error', () => resolve(0));
      req.write(data); req.end();
    });

    const invalidCases = [
      { model: 123, messages: [{ role: 'user', content: 'hi' }] },          // model 非字符串
      { model: 'gpt-4', messages: '不是数组' },                             // messages 非数组
      { model: 'gpt-4', messages: [123, 'str'] },                           // 消息元素非对象
      { model: 'gpt-4' },                                                   // 缺 messages
      { messages: [{ role: 'user', content: 'hi' }] },                      // 缺 model
      {},                                                                   // 空对象
      null                                                                  // null body
    ];
    const validCases = [
      { model: 'gpt-4', messages: [{ role: 'user', content: 'x'.repeat(100000) }] }, // 超长内容（合法）
      { model: 'gpt-4', messages: [{ role: 'user', content: 'emoji😀中文🚀' }] }     // unicode（合法）
    ];
    let allOk = true;
    for (const c of invalidCases) {
      const status = await post(c);
      if (![400, 502, 0].includes(status)) { allOk = false; console.log('    非法请求未拒绝:', status, JSON.stringify(c).slice(0, 60)); }
    }
    for (const c of validCases) {
      const status = await post(c);
      if (status !== 200) { allOk = false; console.log('    合法请求被拒:', status, JSON.stringify(c).slice(0, 60)); }
    }
    // 非法 JSON
    const badJson = await post('{bad json', { 'Content-Type': 'application/json' });
    assert.ok([400, 502].includes(badJson), '非法 JSON 应 400/502');
    // 进程存活
    const alive = await new Promise((resolve) => {
      http.get({ host: '127.0.0.1', port, path: '/health' }, (res) => { res.resume(); resolve(res.statusCode === 200); }).on('error', () => resolve(false));
    });
    assert.strictEqual(alive, true, '模糊输入后代理必须存活');
    assert.strictEqual(allOk, true, '所有模糊输入应返回 400/502');
    ok('代理模糊输入（9 类恶意请求）不崩溃');
    proxy.stop();
    up.close();
  }

  // ============ F. 价格表：内置保留/删除不复活 ============
  {
    try {
      const cfgPath = path.join(userDataDir, 'config.json');
      fs.writeFileSync(cfgPath, JSON.stringify({ prices: { currency: 'USD', models: { 'my-custom-model': { input: 1, output: 2 } } } }), 'utf8');
      const cfg = new ConfigManager();
      const models = cfg.get('prices.models');
      assert.ok(models['gpt-4'], '内置 gpt-4 价格应保留');
      assert.ok(models['deepseek-chat'], '内置 deepseek-chat 价格应保留');
      assert.strictEqual(models['my-custom-model'].input, 1, '用户价格应保留');
      ok('配置合并：内置价格表始终保留');
    } catch (e) { fail('配置合并：内置价格表始终保留', e.message); }

    try {
      const cfgPath = path.join(userDataDir, 'config.json');
      fs.writeFileSync(cfgPath, JSON.stringify({ prices: { currency: 'USD', models: {} } }), 'utf8');
      const cfg = new ConfigManager();
      let models = { ...cfg.get('prices.models') };
      delete models['gpt-4'];
      const removed = [...(cfg.get('prices.removed') || []), 'gpt-4'];
      cfg.set('prices.removed', removed);
      cfg.set('prices.models', models);
      const cfg2 = new ConfigManager();
      assert.ok(!cfg2.get('prices.models')['gpt-4'], '删除的内置价格不应复活');
      assert.ok(cfg2.get('prices.models')['gpt-4o'], '其他内置价格应保留');
      ok('删除的价格不复活');
    } catch (e) { fail('删除的价格不复活', e.message); }

    try {
      const cfgPath = path.join(userDataDir, 'config.json');
      fs.writeFileSync(cfgPath, JSON.stringify({ prices: { currency: 'USD', models: { 'gpt-4o': { input: 9, output: 9 } }, removed: ['deepseek-chat'] } }), 'utf8');
      const cfg = new ConfigManager();
      const router = new Router(cfg, os.tmpdir());
      router.syncPrices();
      assert.ok(!cfg.get('prices.models')['deepseek-chat'], '同步不应复活被删除的 deepseek-chat');
      assert.strictEqual(cfg.get('prices.models')['gpt-4o'].input, 9, '用户改价应保留');
      ok('syncPrices 跳过已删除模型');
    } catch (e) { fail('syncPrices 跳过已删除模型', e.message); }
  }

  console.log(`\n通过 ${passed} 项, 失败 ${failed} 项`);
  process.exit(failed > 0 ? 1 : 0);
})().catch(e => { console.error('测试崩溃:', e); process.exit(1); });
