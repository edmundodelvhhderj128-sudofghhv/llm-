/**
 * OmniRoute 借鉴升级测试（v2.7.0）：规则压缩 + 不可重试错误快速失败
 * 运行: node test-omniroute.js
 */
const assert = require('assert');
const os = require('os');
const fs = require('fs');
const path = require('path');

const Module = require('module');
const origLoad = Module._load;
const userDataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'llm-omni-'));
Module._load = function (request, parent, isMain) {
  if (request === 'electron') return { app: { getPath: () => userDataDir }, ipcMain: { handle: () => {} } };
  return origLoad.apply(this, arguments);
};

const { compressProse, isCodeLikeText, RULES } = require('./src/prose-compress');
const { Router } = require('./src/router');

let passed = 0, failed = 0;
function ok(name) { passed++; console.log(`  ok ${name}`); }
function fail(name, detail) { failed++; console.log(`  FAIL ${name}: ${detail || ''}`); }

function mockConfig() {
  const state = {
    providers: [], routing: { failover: true, maxRetries: 3, timeout: 60000, fallbackTimeoutMs: 20000, strategy: 'priority', circuitBreaker: { enabled: true, threshold: 5, cooldownMs: 60000 } },
    guard: {}, quality: {}, compression: { enabled: true, heuristic: true, prose: true, smart: false, keepRecent: 2, maxOldChars: 200, minLen: 10, triggerTokens: 10 },
    semanticCache: {}, slo: {}, residency: {}, shadow: {}, cache: { enabled: false }, logging: { enabled: true }, local: {}, prices: { models: {} }, memory: {}
  };
  return {
    config: state,
    get(key) { return key.split('.').reduce((o, k) => o?.[k], this.config); },
    set(key, v) { const ks = key.split('.'); const last = ks.pop(); const t = ks.reduce((o, k) => { if (!o[k]) o[k] = {}; return o[k]; }, this.config); t[last] = v; },
    getAll() { return this.config; },
    persist() {},
    addProvider(p) {
      const prov = { id: p.id || 'p' + this.config.providers.length, name: p.name, baseUrl: p.baseUrl || 'https://x.example.com', keys: p.keys || ['k1'], models: p.models || [], enabled: true, priority: p.priority || 1, keyIndex: 0, keyStats: {}, region: 'any', pathStyle: 'v1', kind: 'remote', billing: {}, weights: { latencyMs: null, successRate: 1, requests: 0 }, circuit: { failures: 0, open: false, openedAt: null }, quotaUsed: {} };
      prov.keys.forEach((_, i) => { prov.keyStats[i] = { disabled: false }; });
      this.config.providers.push(prov); return prov;
    },
    updateProvider(id, d) { const i = this.config.providers.findIndex(p => p.id === id); this.config.providers[i] = { ...this.config.providers[i], ...d }; return this.config.providers[i]; },
    getProviders() { return this.config.providers; },
    getEnabledProviders() { return this.config.providers.filter(p => p.enabled); }
  };
}

(async () => {
  // ============ 规则压缩：中文 ============
  {
    try {
      const zh = '你好，请帮我看看这个问题，谢谢！我觉得这个问题可能是由于网络原因导致的，其实很简单，非常感谢你。';
      const r = compressProse(zh);
      assert.ok(r.savedChars > 0, '中文应压缩出空间');
      assert.ok(!r.text.includes('你好'), '问候语应删除');
      assert.ok(!r.text.includes('谢谢'), '客套应删除');
      assert.ok(!r.text.includes('我觉得'), '口头禅应删除');
      assert.ok(r.text.includes('网络原因'), '语义应保留');
      assert.ok(r.appliedRules.length >= 3, '应应用多条规则');
      ok('规则压缩：中文客套/口头禅删除且语义保留');
    } catch (e) { fail('中文规则压缩', e.message); }
  }

  // ============ 规则压缩：英文 + 代码保护 ============
  {
    try {
      const en = 'Hi there, thank you so much! I was wondering if you could please help me with my code. Basically, I need to understand it.';
      const r = compressProse(en);
      assert.ok(r.savedChars > 0, '英文应压缩');
      assert.ok(!/thank you so much/i.test(r.text), '过度感谢应删除');
      assert.ok(!/Basically/i.test(r.text), '填充词应删除');
      // 代码保护
      const code = '```python\ndef hello():\n    print("你好")\n    return 1\n```\n请解释这段代码';
      const r2 = compressProse(code);
      assert.ok(r2.text.includes('def hello()'), '代码块应完整保留');
      assert.ok(r2.text.includes('print'), '代码内容不受影响');
      assert.ok(isCodeLikeText('const a = 1;\nfunction b() { return a; }\nconsole.log(b());\nconst c = 2;'), '代码行识别');
      assert.ok(!isCodeLikeText('这是一段普通的中文对话内容，没有代码。'), '散文不应识别为代码');
      ok('规则压缩：英文规则 + 代码块保护 + 代码识别');
    } catch (e) { fail('英文/代码保护', e.message); }
  }

  // ============ 压缩管道集成（prose + 截断叠加） ============
  {
    try {
      const config = mockConfig();
      config.addProvider({ id: 'p1', name: '商汤', keys: ['k'], models: ['glm-5.2'] });
      const router = new Router(config, os.tmpdir());
      const old = [
        { role: 'user', content: '你好，请帮我看看这个问题，谢谢！' },
        { role: 'assistant', content: '我觉得这个问题可能是网络原因，其实很简单。' },
        { role: 'user', content: '非常感谢你的解答，再见！' },
        { role: 'assistant', content: '好的，不客气，有问题随时找我。' }
      ];
      const r = await router.compressMessages([
        { role: 'system', content: 'sys' },
        ...old,
        { role: 'user', content: '新问题' }
      ]);
      assert.ok(r.compressed, '应触发压缩');
      const joined = r.messages.map(m => m.content || '').join(' ');
      assert.ok(!joined.includes('你好，请'), 'prose 应删除问候');
      assert.ok(!joined.includes('非常感谢你的解答'), 'prose 应删除客套');
      assert.ok(router.compressionStats.prose >= 1, 'prose 统计应记录');
      ok('压缩管道：prose 规则压缩集成生效');
    } catch (e) { fail('压缩管道集成', e.message); }
  }

  // ============ 不可重试错误快速失败 ============
  {
    try {
      const config = mockConfig();
      config.addProvider({ id: 'p1', name: '坏渠道', keys: ['k-bad', 'k-good'], models: ['glm-5.2'], priority: 1 });
      config.addProvider({ id: 'p2', name: '好渠道', keys: ['k'], models: ['glm-5.2'], priority: 2 });
      const router = new Router(config, os.tmpdir());
      // hopeless 检测
      assert.ok(router.isHopelessError(new Error('Cloudflare error 1010 browser_signature_banned')));
      assert.ok(router.isHopelessError(new Error('insufficient_quota')));
      assert.ok(router.isHopelessError(new Error('account suspended')));
      assert.ok(!router.isHopelessError(new Error('服务商返回错误: 400 Failed to build prompt: No user query found')));
      assert.ok(!router.isHopelessError(new Error('429 inference tpm exhausted')));
      // 端到端：坏渠道 hopeless → Key 立即禁用 → 切到好渠道
      let calls = [];
      const origFetch = global.fetch;
      global.fetch = async (url, opts) => {
        const auth = opts.headers.Authorization || '';
        calls.push(auth);
        if (auth.includes('k-bad')) {
          return { ok: false, status: 403, text: async () => '{"error":{"message":"browser_signature_banned cloudflare"}}' };
        }
        return { ok: true, status: 200, json: async () => ({ choices: [{ message: { content: '好渠道回复' } }], usage: null }), text: async () => '' };
      };
      try {
        const r = await router.tryRouteModel('glm-5.2', { messages: [{ role: 'user', content: 'hi' }] }, {});
        assert.ok(r.success, '应最终成功');
        assert.strictEqual(r.data.choices[0].message.content, '好渠道回复');
        const badKey = config.getProviders()[0].keyStats[0];
        assert.strictEqual(badKey.disabled, true, '坏 Key 应立即禁用（不等 3 次）');
        assert.ok(calls.length <= 2, '不应在坏渠道上反复尝试');
        ok('不可重试错误：Key 立即禁用 + 快速切换好渠道');
      } finally { global.fetch = origFetch; }
    } catch (e) { fail('不可重试错误', e.message); }
  }

  // ============ 规则集完整性 ============
  {
    try {
      assert.ok(RULES.length >= 25, '规则数应 ≥25: ' + RULES.length);
      const names = new Set(RULES.map(r => r.name));
      assert.strictEqual(names.size, RULES.length, '规则名应唯一');
      ok('规则集完整（' + RULES.length + ' 条中英文规则）');
    } catch (e) { fail('规则集', e.message); }
  }

  // ============ 消息级去重（v2.7.1 session-dedup） ============
  {
    try {
      const config = mockConfig();
      config.addProvider({ id: 'p1', name: '商汤', keys: ['k'], models: ['glm-5.2'] });
      const router = new Router(config, os.tmpdir());
      // 构造含重复 system 和重复旧消息的对话
      const dupMsgs = [
        { role: 'system', content: '你是助手' },
        { role: 'system', content: '你是助手' },           // 重复 system
        { role: 'user', content: '问题一' },
        { role: 'assistant', content: '回答一' },
        { role: 'user', content: '问题一' },               // 重复旧消息
        { role: 'assistant', content: '回答一' },          // 重复旧消息
        { role: 'user', content: '新问题' }
      ];
      const r = await router.compressMessages(dupMsgs);
      const sysCount = r.messages.filter(m => m.role === 'system' && m.content === '你是助手').length;
      assert.strictEqual(sysCount, 1, '重复 system 只保留一条');
      const userCount = r.messages.filter(m => m.role === 'user' && m.content === '问题一').length;
      assert.strictEqual(userCount, 1, '重复旧消息只保留一条');
      assert.ok(r.messages.some(m => m.content === '新问题'), '最近消息保留');
      assert.ok(router.compressionStats.dedup >= 1, 'dedup 统计应记录');
      ok('消息级去重：重复 system/旧消息无损去重');
    } catch (e) { fail('消息级去重', e.message); }
  }

  // ============ v2.8.0 升级：lkgp / 软降级 / 指数退避 / headroom ============
  {
    try {
      const config = mockConfig();
      config.addProvider({ id: 'slow', name: '慢渠道', baseUrl: 'http://slow.example', keys: ['k'], models: ['glm-5.2'], priority: 1 });
      config.addProvider({ id: 'fast', name: '快渠道', baseUrl: 'http://fast.example', keys: ['k'], models: ['glm-5.2'], priority: 2 });
      const router = new Router(config, os.tmpdir());

      // 1) lkgp：成功记录 + 优先 + 失败清除
      router.lkgp.set('glm-5.2', 'fast');
      let sp = router.selectProviders('glm-5.2');
      assert.strictEqual(sp[0].id, 'fast', 'lkgp 渠道应排第一');
      router.lkgp.set('glm-5.2', 'slow');
      sp = router.selectProviders('glm-5.2');
      assert.strictEqual(sp[0].id, 'slow', 'lkgp 随记录变化');
      router.lkgp.delete('glm-5.2');
      sp = router.selectProviders('glm-5.2');
      assert.strictEqual(sp[0].id, 'slow', '无 lkgp 时按优先级');
      config.set('routing', { ...config.get('routing'), lkgp: false });
      router.lkgp.set('glm-5.2', 'fast');
      sp = router.selectProviders('glm-5.2');
      assert.strictEqual(sp[0].id, 'slow', '关闭 lkgp 不生效');
      config.set('routing', { ...config.get('routing'), lkgp: true });

      // 2) 指数退避：level 增长 + 封顶 + 成功重置
      config.set('routing', { ...config.get('routing'), rateLimitBackoffMs: 60000, rateLimitBackoffMaxMs: 600000 });
      const prov = config.getProviders()[0];
      router.applyRateLimitBackoff(prov);
      const lvl1 = prov.backoffLevel;
      assert.strictEqual(lvl1, 1);
      assert.ok(prov.rateLimitedUntil > Date.now() + 55000, '第一级 ~60s');
      router.applyRateLimitBackoff(prov);
      assert.strictEqual(prov.backoffLevel, 2);
      assert.ok(prov.rateLimitedUntil > Date.now() + 115000, '第二级 ~120s');
      // 封顶：模拟很多级
      prov.backoffLevel = 20;
      router.applyRateLimitBackoff(prov);
      assert.ok(prov.rateLimitedUntil - Date.now() <= 600000 + 5000, '封顶 10 分钟');
      // 成功重置（限流渠道不在候选中，直接验证 recordSuccess 的重置逻辑）
      router.recordSuccess(prov, 0, 'glm-5.2', { data: {}, latency: 1, usage: null });
      assert.strictEqual(prov.backoffLevel, 0, '成功后退避等级重置');
      assert.strictEqual(prov.rateLimitedUntil, null, '成功后退避解除');
      ok('lkgp 优先/开关 + 指数退避/封顶/成功重置');
    } catch (e) { fail('v2.8.0 lkgp/退避', e.message); }
  }

  // ============ headroom 结构化压缩（v2.8.0） ============
  {
    try {
      const { compactStructured } = require('./src/prose-compress');
      const json = '{\n  "model": "gpt-4o",\n  "messages": [\n    { "role": "user", "content": "你好" },\n    { "role": "assistant", "content": "你好，我是助手" },\n    { "role": "user", "content": "请介绍一下你自己" }\n  ],\n  "temperature": 0.7,\n  "max_tokens": 2048,\n  "stream": false,\n  "top_p": 1,\n  "frequency_penalty": 0,\n  "presence_penalty": 0,\n  "n": 1\n}';
      assert.ok(json.length > 200, '测试 JSON 应超 200 字符门槛');
      const r = compactStructured(json);
      assert.ok(r.saved > 0, 'JSON 应紧凑化');
      assert.strictEqual(JSON.parse(r.text).model, 'gpt-4o', '紧凑后仍可 parse（无损）');
      const md = '| 模型 | 价格 |\n| --- | --- |\n| gpt-4o | 2.5 |';
      const r2 = compactStructured(md);
      assert.ok(r2.saved > 0, '表格应紧凑化');
      assert.ok(!r2.text.includes('| --- |'), '分隔行空格应清理');
      // 非结构化文本不动
      const r3 = compactStructured('这是一段普通文本，没有结构化内容。');
      assert.strictEqual(r3.saved, 0);
      ok('headroom：JSON/表格紧凑化无损 + 普通文本不动');
    } catch (e) { fail('headroom', e.message); }
  }

  // ============ 提示缓存亲和（v2.8.1 prompt-cache affinity） ============
  {
    try {
      const config = mockConfig();
      config.addProvider({ id: 'p1', name: '渠道一', baseUrl: 'http://one.example', keys: ['k'], models: ['glm-5.2'], priority: 1 });
      config.addProvider({ id: 'p2', name: '渠道二', baseUrl: 'http://two.example', keys: ['k'], models: ['glm-5.2'], priority: 2 });
      const router = new Router(config, os.tmpdir());
      const sys = '你是智能助手，请用中文回答。';
      const key = router.computeAffinityKey([{ role: 'system', content: sys }, { role: 'user', content: 'hi' }]);
      assert.ok(key && key.includes(sys.slice(0, 20)), '亲和键应基于 system 前缀');
      assert.strictEqual(router.computeAffinityKey([{ role: 'user', content: 'hi' }]), null, '无 system 返回 null');
      // 记录后优先路由
      router.promptCacheAffinity.set(key, 'p2');
      let sp = router.selectProviders('glm-5.2', { affinityKey: key });
      assert.strictEqual(sp[0].id, 'p2', '亲和渠道应排第一');
      assert.strictEqual(router.affinityStats.hits, 1, '命中计数');
      // 无亲和键不影响
      sp = router.selectProviders('glm-5.2', {});
      assert.strictEqual(sp[0].id, 'p1', '无亲和键按优先级');
      // 关闭后不生效
      config.set('routing', { ...config.get('routing'), promptCacheAffinity: false });
      sp = router.selectProviders('glm-5.2', { affinityKey: key });
      assert.strictEqual(sp[0].id, 'p1', '关闭后不生效');
      // stats 输出
      const stats = router.getStats();
      assert.ok(stats.routing.promptCacheAffinity.hitRate >= 0, 'stats 含亲和统计');
      ok('提示缓存亲和：键计算/优先路由/命中统计/开关');
    } catch (e) { fail('提示缓存亲和', e.message); }
  }

  // ============ 抽取式句子压缩（v2.8.2 relevance） ============
  {
    try {
      const { extractiveCompress } = require('./src/prose-compress');
      // 长文本 + 低信息句 → 删除
      const long = '你好，欢迎咨询！我们很高兴为您服务。' +
        '我们的产品支持多种功能，包括对话、图片生成、视频生成和文本嵌入，可以满足不同的业务需求。' +
        '好的，好的，没问题。' +
        '其中对话功能支持流式输出与工具调用，这是最核心的能力之一。' +
        '谢谢您的提问，感谢您的关注！' +
        '图片生成支持多种尺寸与风格，视频生成支持异步任务轮询，嵌入支持批量向量化。' +
        '嗯嗯，就是这样。' +
        '有问题请随时联系我们，祝您使用愉快！' +
        '此外还支持模型路由与故障切换，自动选择最稳定的服务商，保证服务不中断。' +
        '好的好的，明白了，谢谢您的介绍。' +
        '配额管理可以按周期限制每个服务商的调用量，防止超出预算，非常实用。' +
        '再见，欢迎下次再来咨询！';
      assert.ok(long.length >= 250, '测试文本应超门槛（实际 ' + long.length + '）');
      const r = extractiveCompress(long);
      assert.ok(r.saved > 0, '应删除低信息句: saved=' + r.saved);
      assert.ok(!r.text.includes('好的，好的'), '客套句应删除');
      assert.ok(!r.text.includes('嗯嗯'), '语气词句应删除');
      assert.ok(!r.text.includes('谢谢您的提问'), '感谢句应删除');
      assert.ok(r.text.includes('图片生成支持多种尺寸'), '关键信息应保留');
      assert.ok(r.text.includes('对话功能支持流式输出'), '核心句应保留');
      // 短文本不动
      const r2 = extractiveCompress('这是一段短文本。');
      assert.strictEqual(r2.saved, 0, '短文本不压缩');
      // 代码不参与
      const r3 = extractiveCompress('const a = 1;\nfunction b() { return a; }\nconsole.log(b());');
      assert.strictEqual(r3.saved, 0, '代码不参与抽取压缩');
      ok('抽取式句子压缩：删低信息句/保留关键句/短文本与代码保护');
    } catch (e) { fail('抽取式句子压缩', e.message); }
  }

  // ============ v2.9.0 策略扩充 + 引擎补齐 ============
  {
    try {
      const config = mockConfig();
      config.addProvider({ id: 'p1', name: '渠道一', baseUrl: 'http://one.example', keys: ['k'], models: ['glm-5.2'], priority: 1 });
      config.addProvider({ id: 'p2', name: '渠道二', baseUrl: 'http://two.example', keys: ['k'], models: ['glm-5.2'], priority: 2 });
      config.addProvider({ id: 'p3', name: '渠道三', baseUrl: 'http://three.example', keys: ['k'], models: ['glm-5.2'], priority: 3 });
      const router = new Router(config, os.tmpdir());

      // least-used：请求量少的优先
      router.stats.providerStats.p1 = { requests: 10, success: 8, fail: 2, errors: [], cost: 0, tokens: 0 };
      router.stats.providerStats.p2 = { requests: 2, success: 2, fail: 0, errors: [], cost: 0, tokens: 0 };
      router.stats.providerStats.p3 = { requests: 5, success: 5, fail: 0, errors: [], cost: 0, tokens: 0 };
      config.set('routing', { ...config.get('routing'), strategy: 'least-used' });
      let sp = router.selectProviders('glm-5.2', {});
      assert.strictEqual(sp[0].id, 'p2', 'least-used 应优先请求量少的');
      assert.strictEqual(sp[sp.length - 1].id, 'p1', '请求量多的排最后');

      // cost-optimized：低成本优先
      config.set('routing', { ...config.get('routing'), strategy: 'cost-optimized' });
      config.set('prices', { models: { 'glm-5.2': { input: 10, output: 20 } } });
      config.getProviders()[0].billing = { mode: 'count', pricePerCall: 0.01 };  // p1 按次 0.01
      sp = router.selectProviders('glm-5.2', {});
      assert.strictEqual(sp[0].id, 'p1', 'cost-optimized 应优先低成本渠道');
      config.getProviders()[0].billing = { mode: 'tokens', pricePerCall: 0 };

      // reset-aware：配额余量多优先
      config.set('routing', { ...config.get('routing'), strategy: 'reset-aware', quota: { enabled: true, period: 'day', limits: { p1: { requests: 10 }, p2: { requests: 10 }, p3: { requests: 10 } } } });
      config.getProviders().forEach(p => { p.quotaUsed = { periodKey: router.quotaPeriodKey('day'), requests: 0, tokens: 0 }; });
      config.getProviders()[1].quotaUsed.requests = 8;  // p2 余量少
      sp = router.selectProviders('glm-5.2', {});
      assert.strictEqual(sp[0].id, 'p1', 'reset-aware 应优先余量多渠道');
      assert.ok(sp.findIndex(p => p.id === 'p2') > sp.findIndex(p => p.id === 'p1'), '余量少的靠后');
      config.set('routing', { ...config.get('routing'), quota: { enabled: false, period: 'day', limits: {} } });

      // p2c：返回全部且首位是二者之一
      config.set('routing', { ...config.get('routing'), strategy: 'p2c' });
      const p2cList = router.selectProviders('glm-5.2', {});
      assert.strictEqual(p2cList.length, 3, 'p2c 应返回全部渠道');
      assert.ok(['p1', 'p2', 'p3'].includes(p2cList[0].id), 'p2c 首位应是候选之一');

      // strict-random / auto 不崩溃且返回全部
      config.set('routing', { ...config.get('routing'), strategy: 'strict-random' });
      assert.strictEqual(router.selectProviders('glm-5.2', {}).length, 3);
      config.set('routing', { ...config.get('routing'), strategy: 'auto' });
      assert.strictEqual(router.selectProviders('glm-5.2', {}).length, 3, 'auto 应返回全部');
      config.set('routing', { ...config.get('routing'), strategy: 'priority' });

      ok('策略扩充：least-used/cost-optimized/reset-aware/p2c/strict-random/auto');
    } catch (e) { fail('策略扩充', e.message); }
  }

  // ============ 引擎补齐：rtk / ionizer / ultra ============
  {
    try {
      const { filterCommandOutput, sampleTable, conservativePrune } = require('./src/prose-compress');
      // rtk：命令输出冗余过滤
      const cmd = '> npm run build\n2026-08-23 10:00:01 INFO starting\n2026-08-23 10:00:02 INFO compiling\n10% |=>|\n40% |====>|\n100% |==========|\nBuild complete in 3.2s\n'; 
      const r1 = filterCommandOutput(cmd);
      assert.ok(r1.saved > 0, 'rtk 应删除时间戳/进度行');
      assert.ok(r1.text.includes('npm run build'), '命令本身保留');
      assert.ok(r1.text.includes('Build complete'), '关键输出保留');
      // ionizer：大表格采样
      let md = '| id | name |\n| --- | --- |\n';
      for (let i = 0; i < 15; i++) md += '| ' + i + ' | item' + i + ' |\n';
      const r2 = sampleTable(md);
      assert.ok(r2.saved > 0, 'ionizer 应压缩大表格');
      assert.ok(r2.text.includes('已省略'), '应标注省略');
      assert.ok(r2.text.includes('item0') && r2.text.includes('item14'), '首尾行保留');
      // ultra：空行压缩 + 重复段落
      const r3 = conservativePrune('第一段内容，有实际信息。\n\n\n\n\n第二段内容。\n\n第一段内容，有实际信息。');
      assert.ok(r3.saved > 0, 'ultra 应压缩');
      assert.ok(!r3.text.includes('\n\n\n\n'), '连续空行应压缩');
      ok('引擎补齐：rtk 命令输出过滤/ionizer 表格采样/ultra 保守剪枝');
    } catch (e) { fail('引擎补齐', e.message); }
  }

  console.log(`\n通过 ${passed} 项, 失败 ${failed} 项`);
  process.exit(failed > 0 ? 1 : 0);
})().catch(e => { console.error('测试崩溃:', e); process.exit(1); });
