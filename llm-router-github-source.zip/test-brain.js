/**
 * 路由大脑测试（v2.5.0）
 * 运行: node test-brain.js
 */
const assert = require('assert');
const os = require('os');
const fs = require('fs');
const path = require('path');

const Module = require('module');
const origLoad = Module._load;
const userDataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'llm-brain-'));
Module._load = function (request, parent, isMain) {
  if (request === 'electron') return { app: { getPath: () => userDataDir }, ipcMain: { handle: () => {} } };
  return origLoad.apply(this, arguments);
};

const { Router } = require('./src/router');
const { ToolRegistry } = require('./src/tools');
const { BrainEngine } = require('./src/brain');
const { ModelMemory } = require('./src/model-memory');

let passed = 0, failed = 0;
function ok(name) { passed++; console.log(`  ok ${name}`); }
function fail(name, detail) { failed++; console.log(`  FAIL ${name}: ${detail || ''}`); }

function mockConfig() {
  const state = {
    providers: [], routing: { failover: true, maxRetries: 2, timeout: 5000, strategy: 'priority', circuitBreaker: { enabled: true, threshold: 5, cooldownMs: 60000 } },
    guard: {}, quality: {}, compression: {}, semanticCache: {}, slo: {}, residency: {}, shadow: {},
    cache: { enabled: false }, logging: { enabled: true },
    local: { backend: 'llama', llamaPort: 11435, tools: true, maxToolRounds: 5, brainEnabled: true, brainAutoStart: true, brainIntervalMin: 15, brainWakeOnEvents: true },
    prices: { models: {} }, memory: { enabled: true, autoAddModels: true, learnFeatures: true }
  };
  return {
    config: state,
    get(key) { return key.split('.').reduce((o, k) => o?.[k], this.config); },
    set(key, v) { const ks = key.split('.'); const last = ks.pop(); const t = ks.reduce((o, k) => { if (!o[k]) o[k] = {}; return o[k]; }, this.config); t[last] = v; },
    getAll() { return this.config; },
    persist() {},
    addProvider(p) {
      const prov = { id: p.id || 'p' + this.config.providers.length, name: p.name, baseUrl: p.baseUrl || '', keys: p.keys || ['k1'], models: p.models || [], enabled: true, priority: 1, keyIndex: 0, keyStats: {}, region: 'any', pathStyle: 'v1', kind: p.kind || 'remote', billing: { mode: 'tokens', pricePerCall: 0 }, weights: { latencyMs: null, successRate: 1, requests: 0 }, circuit: { failures: 0, open: false, openedAt: null }, quotaUsed: {} };
      prov.keys.forEach((_, i) => { prov.keyStats[i] = { disabled: false }; });
      this.config.providers.push(prov); return prov;
    },
    updateProvider(id, d) { const i = this.config.providers.findIndex(p => p.id === id); this.config.providers[i] = { ...this.config.providers[i], ...d }; return this.config.providers[i]; },
    getProviders() { return this.config.providers; },
    getEnabledProviders() { return this.config.providers.filter(p => p.enabled); }
  };
}

(async () => {
  // ============ 路由排除本地（大脑不参与对话回答） ============
  {
    try {
      const config = mockConfig();
      config.addProvider({ id: 'p1', name: '商汤', keys: ['k'], models: ['glm-5.2'] });
      config.addProvider({ id: 'local1', name: '本地', keys: ['local'], models: ['Qwen2.5-7B-Instruct'], kind: 'local' });
      const router = new Router(config, os.tmpdir());
      // selectProviders：本地渠道被排除
      const sp = router.selectProviders('Qwen2.5-7B-Instruct');
      assert.ok(sp.length === 0, 'selectProviders 应排除本地渠道');
      // 回退候选：仅本地渠道提供的模型不参与
      const fb = router.buildFallbackCandidates('glm-5.2', 'chat');
      assert.ok(!fb.includes('Qwen2.5-7B-Instruct'), '回退候选不应含仅本地提供的模型');
      // 若云端渠道也提供该模型，则仍可回退
      config.addProvider({ id: 'p2', name: '云端2', keys: ['k2'], models: ['Qwen2.5-7B-Instruct'] });
      const fb2 = router.buildFallbackCandidates('glm-5.2', 'chat');
      assert.ok(fb2.includes('Qwen2.5-7B-Instruct'), '云端渠道提供的同名模型仍可回退');
      ok('路由排除本地渠道（对话路由与回退候选）');
    } catch (e) { fail('路由排除本地渠道', e.message); }
  }

  // ============ 大脑运行：分析 + 调用工具 + 决策日志 ============
  {
    try {
      const config = mockConfig();
      config.addProvider({ id: 'p1', name: '商汤', keys: ['k'], models: ['glm-5.2'] });
      const router = new Router(config, os.tmpdir());
      const memory = new ModelMemory(config, userDataDir);
      router.setModelMemory(memory);
      const toolCalls = [];
      const fakeEngine = {
        running: true,
        chatWithTools: async (opts) => {
          toolCalls.push(opts);
          return {
            result: { data: { choices: [{ message: { content: '发现商汤渠道限流频繁，已切换到加权策略并降低其优先级。' } }] }, latency: 100, usage: null },
            toolRuns: [{ name: 'switch_strategy', args: '{"strategy":"weighted"}', ok: true }, { name: 'set_provider_enabled', args: '{"providerId":"p1","enabled":false}', ok: false, error: '拒绝停用唯一渠道' }]
          };
        },
        cfg: () => ({ modelFile: 'qwen.gguf' })
      };
      const tools = new ToolRegistry({ config, router, memory, tracer: router.tracer });
      const brain = new BrainEngine({ config, router, localEngine: fakeEngine, toolRegistry: tools, memory, tracer: router.tracer });
      const r = await brain.run('测试触发', { force: true });
      assert.ok(r.ok);
      assert.strictEqual(r.tools.length, 2, '应记录 2 次工具调用');
      assert.ok(r.summary.includes('加权'), '应输出决策总结');
      assert.strictEqual(brain.decisionCount, 1);
      assert.strictEqual(brain.history.length, 1);
      assert.ok(brain.history[0].reason.includes('测试'));
      assert.ok(toolCalls[0].messages[0].role === 'system' && toolCalls[0].messages[0].content.includes('路由大脑'), '系统提示词应定义大脑角色');
      assert.ok(toolCalls[0].tools.length === 12, '应提供全部 12 个工具');
      assert.ok(memory.data.features['brain_run'], '应记录 brain_run 功能');
      ok('大脑运行：快照分析 + 工具调用 + 决策日志 + 记忆');
    } catch (e) { fail('大脑运行', e.message); }
  }

  // ============ 大脑守卫：引擎未运行 / 停用 ============
  {
    try {
      const config = mockConfig();
      const router = new Router(config, os.tmpdir());
      const brain = new BrainEngine({ config, router, localEngine: { running: false }, toolRegistry: null, memory: null });
      const r1 = await brain.run('测试', { force: true });
      assert.ok(!r1.ok && r1.error.includes('引擎未运行'), '引擎未运行应拒绝');
      config.set('local', { brainEnabled: false });
      const brain2 = new BrainEngine({ config, router, localEngine: { running: true }, toolRegistry: { toolsPayload: () => [] }, memory: null });
      const r2 = await brain2.run('测试', { force: true });
      assert.ok(!r2.ok && r2.error.includes('停用'), '大脑停用应拒绝');
      ok('大脑守卫：引擎未运行/停用时拒绝运行');
    } catch (e) { fail('大脑守卫', e.message); }
  }

  // ============ 事件唤醒（熔断/限流/Key保护）+ 节流 ============
  {
    try {
      const config = mockConfig();
      const router = new Router(config, os.tmpdir());
      let runs = 0;
      const fakeEngine = { running: true, cfg: () => ({ modelFile: 'qwen.gguf' }) };
      const brain = new BrainEngine({ config, router, localEngine: fakeEngine, toolRegistry: null, memory: null });
      brain.run = async (reason) => { runs++; return { ok: true, reason }; };
      brain.notify('circuit_break');
      brain.notify('rate_limit_backoff');   // 120s 内节流，应忽略
      brain.notify('key_guard');
      assert.strictEqual(runs, 1, '事件唤醒应节流（120s 内仅 1 次）');
      brain.lastNotifyAt = 0;
      brain.notify('circuit_break');
      assert.strictEqual(runs, 2, '节流期过后可再次唤醒');
      ok('事件唤醒 + 120s 节流');
    } catch (e) { fail('事件唤醒', e.message); }
  }

  // ============ 快照收集（含状态/统计/记忆/日志/配置） ============
  {
    try {
      const config = mockConfig();
      config.addProvider({ id: 'p1', name: '商汤', keys: ['k'], models: ['glm-5.2'] });
      const router = new Router(config, os.tmpdir());
      const memory = new ModelMemory(config, userDataDir);
      const tools = new ToolRegistry({ config, router, memory, tracer: router.tracer });
      const brain = new BrainEngine({ config, router, localEngine: { running: true, cfg: () => ({ modelFile: 'qwen.gguf' }) }, toolRegistry: tools, memory, tracer: router.tracer });
      const snap = await brain.collectSnapshot();
      assert.ok(snap.includes('渠道状态'), '快照应含渠道状态');
      assert.ok(snap.includes('全局统计'), '快照应含统计');
      assert.ok(snap.includes('当前配置'), '快照应含当前配置');
      assert.ok(snap.includes('商汤'), '快照应含渠道名');
      ok('快照收集（状态/统计/配置）');
    } catch (e) { fail('快照收集', e.message); }
  }

  // ============ 自学习：决策效果评估 + 经验沉淀 + 记得住 ============
  {
    try {
      const config = mockConfig();
      config.addProvider({ id: 'p1', name: '商汤', keys: ['k'], models: ['glm-5.2'] });
      const router = new Router(config, os.tmpdir());
      const memory = new ModelMemory(config, userDataDir);
      const tools = new ToolRegistry({ config, router, memory, tracer: router.tracer });
      const brain = new BrainEngine({ config, router, localEngine: { running: true, cfg: () => ({ modelFile: 'q.gguf' }) }, toolRegistry: tools, memory, tracer: router.tracer });

      // 造一条带基线的决策（pending）
      brain.history.unshift({
        time: new Date().toISOString(), reason: '测试', tools: [{ name: 'switch_strategy', ok: true }],
        summary: 'x', durationMs: 100,
        baseline: { strategy: 'random', totalRequests: 100, successRate: 70, avgLatencyMs: 2000, totalCostUsd: 1.0 },
        effect: 'pending'
      });
      // 模拟指标变化：成功率 80（+10）、延迟 1500（-25%）、成本 0.8（-20%）→ 应判 good
      const realExec = brain.tools.execute.bind(brain.tools);
      brain.tools.execute = async (name, args) => {
        if (name === 'get_stats') return {
          ok: true, totalRequests: 108, successRate: 80, avgLatencyMs: 1500, totalCostUsd: 0.8,
          providerStats: [], modelStats: {}
        };
        return realExec(name, args);
      };
      await brain.evaluateLastDecision();
      assert.strictEqual(brain.history[0].effect, 'good', '成功率/延迟/成本全面改善应判 good');
      assert.strictEqual(brain.lessons.length, 1, 'good 决策应沉淀 1 条经验');
      assert.ok(brain.lessons[0].action.includes('switch_strategy'));
      assert.strictEqual(brain.lessons[0].times, 1);

      // 重复相同操作再次 good → 经验去重 + 次数累加
      brain.history.unshift({ time: new Date().toISOString(), reason: 'x', tools: [{ name: 'switch_strategy', ok: true }], summary: 'y', baseline: { totalRequests: 108, successRate: 80, avgLatencyMs: 1500, totalCostUsd: 0.8 }, effect: 'pending' });
      brain.tools.execute = async (name) => {
        if (name === 'get_stats') return { ok: true, totalRequests: 120, successRate: 92, avgLatencyMs: 1200, totalCostUsd: 0.7 };
        return realExec(name);
      };
      await brain.evaluateLastDecision();
      assert.strictEqual(brain.lessons.length, 1, '相同经验应去重');
      assert.strictEqual(brain.lessons[0].times, 2, '次数应累加');

      // 效果变差 → bad 不入经验
      brain.history.unshift({ time: new Date().toISOString(), reason: 'x', tools: [{ name: 'switch_strategy', ok: true }], summary: 'z', baseline: { totalRequests: 108, successRate: 80, avgLatencyMs: 1000 }, effect: 'pending' });
      brain.tools.execute = async (name) => {
        if (name === 'get_stats') return { ok: true, totalRequests: 120, successRate: 50, avgLatencyMs: 3000, totalCostUsd: 2 };
        return realExec(name);
      };
      await brain.evaluateLastDecision();
      assert.strictEqual(brain.history[0].effect, 'bad', '指标恶化应判 bad');
      assert.strictEqual(brain.lessons.length, 1, 'bad 决策不应沉淀经验');

      // 样本不足 → pending
      brain.history.unshift({ time: new Date().toISOString(), reason: 'x', tools: [], summary: 'w', baseline: { totalRequests: 120, successRate: 50 }, effect: 'pending' });
      brain.tools.execute = async (name) => {
        if (name === 'get_stats') return { ok: true, totalRequests: 121, successRate: 50, avgLatencyMs: 3000, totalCostUsd: 2 };
        return realExec(name);
      };
      await brain.evaluateLastDecision();
      assert.strictEqual(brain.history[0].effect, 'pending', '新请求不足 3 条应保持待评估');

      // 快照包含历史决策与经验（记得住）
      brain.tools.execute = realExec;
      const snap = await brain.collectSnapshot();
      assert.ok(snap.includes('我的历史决策与成效'), '快照应含历史决策成效');
      assert.ok(snap.includes('积累的经验'), '快照应含经验库');
      assert.ok(snap.includes('switch_strategy'), '快照经验应含工具名');

      // 持久化：经验写入 memory.data.brainLessons
      brain.persistLessons();
      assert.strictEqual(memory.data.brainLessons.length, 1, '经验应持久化到记忆文件');
      const brain2 = new BrainEngine({ config, router, localEngine: { running: true }, toolRegistry: tools, memory, tracer: router.tracer });
      assert.strictEqual(brain2.lessons.length, 1, '重新加载应恢复经验（记得住）');
      ok('自学习：效果评估/经验沉淀/去重/样本不足/快照回顾/持久化');
    } catch (e) { fail('自学习', e.message); }
  }

  // ============ 流量避让（v2.6.3：本地推理不拖慢用户请求） ============
  {
    try {
      const config = mockConfig();
      const router = new Router(config, os.tmpdir());
      const memory = new ModelMemory(config, userDataDir);
      let engineCalls = 0;
      const fakeEngine = {
        running: true,
        chatWithTools: async () => { engineCalls++; return { result: { data: { choices: [{ message: { content: 'x' } }] }, latency: 1 }, toolRuns: [] }; },
        cfg: () => ({ modelFile: 'q.gguf' })
      };
      const tools = new ToolRegistry({ config, router, memory, tracer: router.tracer });
      const brain = new BrainEngine({ config, router, localEngine: fakeEngine, toolRegistry: tools, memory, tracer: router.tracer });

      // 繁忙（最近 2 分钟有请求）→ 自动触发应顺延，不调用引擎
      router.lastActivityAt = Date.now() - 30000;
      const r1 = await brain.run('定时巡检');
      assert.ok(!r1.ok && r1.deferred === true, '繁忙时应顺延');
      assert.strictEqual(engineCalls, 0, '顺延期间不应调用引擎');

      // 手动触发 force 不避让
      router.lastActivityAt = Date.now();
      const r2 = await brain.run('手动', { force: true });
      assert.ok(r2.ok, '手动触发应强制执行');
      assert.strictEqual(engineCalls, 1, '手动触发应调用引擎');

      // 空闲（无近期请求）→ 正常执行
      router.lastActivityAt = Date.now() - 10 * 60000;
      const r3 = await brain.run('定时巡检');
      assert.ok(r3.ok, '空闲时应正常执行');
      assert.strictEqual(engineCalls, 2, '空闲巡检应调用引擎');

      // 清理顺延定时器
      if (brain._deferredTimer) clearTimeout(brain._deferredTimer);
      ok('流量避让：繁忙顺延/手动强制/空闲执行');
    } catch (e) { fail('流量避让', e.message); }
  }

  console.log(`\n通过 ${passed} 项, 失败 ${failed} 项`);
  process.exit(failed > 0 ? 1 : 0);
})().catch(e => { console.error('测试崩溃:', e); process.exit(1); });
