/**
 * 内置记忆系统测试（v2.3.0）
 * 运行: node test-memory.js
 */
const assert = require('assert');
const os = require('os');
const fs = require('fs');
const path = require('path');

const Module = require('module');
const origLoad = Module._load;
const userDataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'llm-mem-'));
Module._load = function (request, parent, isMain) {
  if (request === 'electron') return { app: { getPath: () => userDataDir }, ipcMain: { handle: () => {} } };
  return origLoad.apply(this, arguments);
};

const { Router } = require('./src/router');
const { ModelMemory, classifyModel } = require('./src/model-memory');

let passed = 0, failed = 0;
function ok(name) { passed++; console.log(`  ok ${name}`); }
function fail(name, detail) { failed++; console.log(`  FAIL ${name}: ${detail || ''}`); }

function mockConfig() {
  const state = {
    providers: [], routing: { failover: true, maxRetries: 2, timeout: 5000 }, guard: {}, quality: {}, compression: {},
    semanticCache: {}, slo: {}, residency: {}, shadow: {}, cache: { enabled: false }, logging: { enabled: true },
    memory: { enabled: true, autoAddModels: true, probeIntervalHours: 6, maxModelsPerChannel: 200 }
  };
  return {
    config: state,
    get(key) { return key.split('.').reduce((o, k) => o?.[k], this.config); },
    set(key, v) { const ks = key.split('.'); const last = ks.pop(); const t = ks.reduce((o, k) => { if (!o[k]) o[k] = {}; return o[k]; }, this.config); t[last] = v; },
    getAll() { return this.config; },
    persist() {},
    addProvider(p) {
      const prov = { id: p.id || 'p' + this.config.providers.length, name: p.name, baseUrl: p.baseUrl, keys: p.keys || ['k1'], models: p.models || [], enabled: true, priority: 1, keyIndex: 0, keyStats: {}, region: 'any', pathStyle: p.pathStyle || 'v1', billing: {}, weights: {}, circuit: {}, quotaUsed: {} };
      prov.keys.forEach((_, i) => { prov.keyStats[i] = { disabled: false }; });
      this.config.providers.push(prov); return prov;
    },
    updateProvider(id, d) { const i = this.config.providers.findIndex(p => p.id === id); this.config.providers[i] = { ...this.config.providers[i], ...d }; return this.config.providers[i]; },
    getProviders() { return this.config.providers; },
    getEnabledProviders() { return this.config.providers.filter(p => p.enabled); }
  };
}

(async () => {
  // ============ 分类 ============
  {
    try {
      assert.strictEqual(classifyModel('dall-e-3'), 'image');
      assert.strictEqual(classifyModel('agnes-image-2.1-flash'), 'image');
      assert.strictEqual(classifyModel('agnes-video-2.5'), 'video');
      assert.strictEqual(classifyModel('text-embedding-3-small'), 'embedding');
      assert.strictEqual(classifyModel('whisper-1'), 'audio');
      assert.strictEqual(classifyModel('gpt-4o'), 'chat');
      assert.strictEqual(classifyModel('glm-5.2'), 'chat');
      ok('模型能力分类（对话/图片/视频/嵌入/音频）');
    } catch (e) { fail('模型能力分类', e.message); }
  }

  // ============ 记住模型 + Key 级权限 ============
  {
    try {
      const config = mockConfig();
      const p = config.addProvider({ id: 'p1', name: '商汤', baseUrl: 'https://token.sensenova.cn', keys: ['key-A', 'key-B'], models: [] });
      const mm = new ModelMemory(config, userDataDir, null);
      mm.rememberModels('p1', '商汤', ['glm-5.2', 'deepseek-v4-flash', 'agnes-image-2.0-flash'], 'key-A');
      mm.rememberModels('p1', '商汤', ['glm-5.2', 'sensenova-6.8-flash-lite'], 'key-B');
      const ch = mm.data.channels['p1'];
      assert.ok(ch.models['glm-5.2'], 'glm-5.2 应被记住');
      assert.strictEqual(ch.models['glm-5.2'].keys.length, 2, '两个 Key 都能访问 glm-5.2');
      assert.strictEqual(ch.models['deepseek-v4-flash'].keys.length, 1, 'deepseek 只有 key-A 能访问');
      assert.strictEqual(ch.models['agnes-image-2.0-flash'].capability, 'image');
      assert.strictEqual(ch.models['sensenova-6.8-flash-lite'].keys.length, 1);
      ok('记住模型 + Key 级权限学习（同渠道多 Key 不同模型）');
    } catch (e) { fail('记住模型 + Key 级权限', e.message); }
  }

  // ============ 调用记录与习惯 ============
  {
    try {
      const config = mockConfig();
      config.addProvider({ id: 'p1', name: '商汤', baseUrl: 'https://token.sensenova.cn', keys: ['key-A'], models: [] });
      const mm = new ModelMemory(config, userDataDir, null);
      for (let i = 0; i < 8; i++) mm.recordCall({ providerId: 'p1', providerName: '商汤', model: 'glm-5.2', key: 'key-A', ok: true, latency: 200, cost: 0.01 });
      mm.recordCall({ providerId: 'p1', providerName: '商汤', model: 'glm-5.2', key: 'key-A', ok: false, latency: null, cost: 0 });
      mm.recordCall({ providerId: 'p1', providerName: '商汤', model: 'dall-e-3', key: 'key-A', ok: true, latency: 3000, cost: 0.04 });
      const m = mm.data.channels['p1'].models['glm-5.2'];
      assert.strictEqual(m.calls, 9);
      assert.strictEqual(m.success, 8);
      assert.strictEqual(m.fail, 1);
      assert.strictEqual(m.latencySum, 1600);
      assert.ok(Math.abs(m.costSum - 0.08) < 1e-9);
      assert.strictEqual(mm.data.lastUsedByCapability['chat'], 'glm-5.2');
      assert.strictEqual(mm.data.lastUsedByCapability['image'], 'dall-e-3');
      assert.strictEqual(mm.data.totalCalls, 10);
      assert.ok(mm.data.usageByHour[String(new Date().getHours())]['glm-5.2'] >= 8, '分时习惯应记录');
      ok('调用记录与习惯学习（统计/分时/各能力默认模型）');
    } catch (e) { fail('调用记录与习惯', e.message); }
  }

  // ============ 探测渠道（每 Key 拉取模型） ============
  {
    try {
      const config = mockConfig();
      const p = config.addProvider({ id: 'p1', name: '模拟', baseUrl: 'https://mock.example.com', keys: ['key-A', 'key-B'], models: [] });
      const router = new Router(config, os.tmpdir());
      const mm = new ModelMemory(config, userDataDir, router);
      const origFetch = global.fetch;
      global.fetch = async (url, opts) => {
        const auth = opts.headers.Authorization;
        const isA = auth.includes('key-A');
        return {
          ok: true, status: 200, headers: {}, body: null,
          json: async () => ({ data: (isA ? ['gpt-4o', 'dall-e-3'] : ['gpt-4o', 'agnes-video-2.5']).map(m => ({ id: m })) })
        };
      };
      try {
        const results = await mm.probeChannel(p);
        assert.strictEqual(results.length, 2, '应分别用两个 Key 探测');
        const ch = mm.data.channels['p1'];
        assert.ok(ch.models['dall-e-3'], 'key-A 的图片模型应被记住');
        assert.ok(ch.models['agnes-video-2.5'], 'key-B 的视频模型应被记住');
        assert.strictEqual(ch.models['dall-e-3'].keys.length, 1);
        assert.strictEqual(ch.models['gpt-4o'].keys.length, 2);
        ok('渠道探测（每 Key 独立拉取，权限分类正确）');
      } finally { global.fetch = origFetch; }
    } catch (e) { fail('渠道探测', e.message); }
  }

  // ============ 自动并入渠道列表（含上限） ============
  {
    try {
      const config = mockConfig();
      const p = config.addProvider({ id: 'p1', name: '模拟', baseUrl: 'https://mock.example.com', keys: ['k'], models: ['gpt-4o'] });
      const mm = new ModelMemory(config, userDataDir, null);
      const many = [];
      for (let i = 0; i < 500; i++) many.push('model-' + i);
      mm.rememberModels('p1', '模拟', many, 'k');
      config.set('memory', { ...config.get('memory'), maxModelsPerChannel: 50 });
      const added = mm.syncModelsToProviders();
      assert.strictEqual(config.getProviders()[0].models.length, 50, '渠道模型应受上限约束');
      assert.ok(config.getProviders()[0].models.includes('gpt-4o'), '原有模型应保留');
      assert.ok(config.getProviders()[0].models.includes('model-0'), '记忆模型应并入');
      assert.ok(added > 0);
      ok('自动并入渠道列表（保留原有 + 上限控制）');
    } catch (e) { fail('自动并入渠道列表', e.message); }
  }

  // ============ 推荐 ============
  {
    try {
      const config = mockConfig();
      const mm = new ModelMemory(config, userDataDir, null);
      // 慢且贵但成功率高 vs 快且便宜成功率稍低
      mm.recordCall({ providerId: 'p1', providerName: 'A', model: 'slow-expensive', key: 'k', ok: true, latency: 4000, cost: 0.1 });
      mm.recordCall({ providerId: 'p1', providerName: 'A', model: 'slow-expensive', key: 'k', ok: true, latency: 4000, cost: 0.1 });
      mm.recordCall({ providerId: 'p2', providerName: 'B', model: 'fast-cheap', key: 'k', ok: true, latency: 150, cost: 0.001 });
      mm.recordCall({ providerId: 'p2', providerName: 'B', model: 'fast-cheap', key: 'k', ok: true, latency: 150, cost: 0.001 });
      const rec = mm.recommendByCapability();
      assert.strictEqual(rec.chat.model, 'fast-cheap', '应推荐综合更优的模型');
      assert.strictEqual(rec.image, null, '无图片使用记录时不推荐');
      ok('按能力推荐（成功率/延迟/成本综合）');
    } catch (e) { fail('推荐', e.message); }
  }

  // ============ 持久化与清空 ============
  {
    try {
      const config = mockConfig();
      const mm = new ModelMemory(config, userDataDir, null);
      mm.rememberModels('p1', 'A', ['gpt-4o'], 'k');
      mm.recordCall({ providerId: 'p1', providerName: 'A', model: 'gpt-4o', key: 'k', ok: true, latency: 100, cost: 0 });
      mm.save();
      const mm2 = new ModelMemory(config, userDataDir, null);
      assert.ok(mm2.data.channels['p1'], '重新加载应保留数据');
      assert.strictEqual(mm2.data.channels['p1'].models['gpt-4o'].calls, 1);
      mm2.clear();
      assert.strictEqual(Object.keys(mm2.data.channels).length, 0, '清空后应无渠道数据');
      ok('持久化（JSON 落盘）与清空');
    } catch (e) { fail('持久化与清空', e.message); }
  }

  // ============ 功能使用追踪（全软件接入） ============
  {
    try {
      const config = mockConfig();
      const mm = new ModelMemory(config, userDataDir, null);
      for (let i = 0; i < 30; i++) mm.trackFeature('cache_hit');
      for (let i = 0; i < 5; i++) mm.trackFeature('cache_miss');
      mm.trackFeature('fallback', { detail: '3 个候选' });
      mm.trackFeature('circuit_break', { ok: false, detail: 'A 连续失败' });
      mm.trackFeature('quality_judge');
      const f = mm.data.features['cache_hit'];
      assert.strictEqual(f.count, 30);
      assert.strictEqual(f.errorCount, 0);
      assert.ok(f.byHour[String(new Date().getHours())] >= 30);
      assert.strictEqual(mm.data.events.length, 38, '事件流应记录');
      // 事件环上限 100
      for (let i = 0; i < 120; i++) mm.trackFeature('cache_hit');
      assert.ok(mm.data.events.length <= 100, '事件环形缓冲上限 100');
      // 洞察
      const report = mm.getReport();
      const insights = report.featureInsights;
      assert.ok(insights.some(i => i.text.includes('缓存命中率')), '应有缓存命中率洞察');
      assert.ok(insights.some(i => i.level === 'warn' && i.text.includes('熔断')), '应有熔断警告');
      assert.ok(!report.featureStats.some(s => s.id === 'content_guard'), '强制拦截不可在 UI 展示');
      assert.ok(report.featureStats.find(s => s.id === 'cache_hit'), '功能统计应含缓存命中');
      // 关闭学习
      config.set('memory', { ...config.get('memory'), learnFeatures: false });
      mm.trackFeature('cache_hit');
      assert.strictEqual(mm.data.features['cache_hit'].count, 150, '关闭后不再记录');
      ok('功能使用追踪（计数/事件流/洞察/强制拦截隐藏/开关）');
    } catch (e) { fail('功能使用追踪', e.message); }
  }

  // ============ 路由钩子 ============
  {
    try {
      const config = mockConfig();
      config.addProvider({ id: 'p1', name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4'] });
      const router = new Router(config, os.tmpdir());
      const mm = new ModelMemory(config, userDataDir, null);
      router.setModelMemory(mm);
      const origFetch = global.fetch;
      global.fetch = async () => ({ ok: true, status: 200, headers: {}, body: null, json: async () => ({ id: 'x', choices: [{ message: { content: 'ok' } }], usage: null }) });
      try {
        await router.routeWithFallback({ model: 'gpt-4', messages: [{ role: 'user', content: 'hi' }] });
        assert.strictEqual(mm.data.channels['p1'].models['gpt-4'].calls, 1, '成功调用应写入记忆');
      } finally { global.fetch = origFetch; }
      ok('路由调用自动写入记忆');
    } catch (e) { fail('路由钩子', e.message); }
  }

  console.log(`\n通过 ${passed} 项, 失败 ${failed} 项`);
  process.exit(failed > 0 ? 1 : 0);
})().catch(e => { console.error('测试崩溃:', e); process.exit(1); });
