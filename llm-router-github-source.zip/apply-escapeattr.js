// 应用 escapeAttr 到模型名相关属性/onclick（修复引号注入隐患）
const fs = require('fs');

const file = 'renderer/app.js';
let src = fs.readFileSync(file, 'utf8');
const before = src;

// 1. 模型列表页：data-name 属性
src = src.replace('data-name="${name.toLowerCase()}"', 'data-name="${escapeAttr(name.toLowerCase())}"');
// 2. 模型列表页：复制按钮 onclick
src = src.replace("onclick=\"copyToClipboard('${name}')\"", "onclick=\"copyToClipboard('${escapeAttr(name)}')\"");
// 3. 测试页：option value
src = src.replace(
  '${uniqueModels.map(m => `<option value="${m}">${escapeHtml(m)}</option>`).join(\'\')}',
  '${uniqueModels.map(m => `<option value="${escapeAttr(m)}">${escapeHtml(m)}</option>`).join(\'\')}'
);
// 4. 价格表：data-price-model 属性（两处输入框）
src = src.replaceAll('data-price-model="${escapeHtml(name)}"', 'data-price-model="${escapeAttr(name)}"');
// 5. 价格表：保存/删除 onclick
src = src.replace("onclick=\"savePriceRow('${escapeHtml(name)}')\"", "onclick=\"savePriceRow('${escapeAttr(name)}')\"");
src = src.replace("onclick=\"removePriceRow('${escapeHtml(name)}')\"", "onclick=\"removePriceRow('${escapeAttr(name)}')\"");

fs.writeFileSync(file, src, 'utf8');
console.log('done, bytes:', before.length, '->', src.length);
