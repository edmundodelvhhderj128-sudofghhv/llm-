// 版本号统一到 2.0.4
const fs = require('fs');

const p = JSON.parse(fs.readFileSync('package.json', 'utf8'));
p.version = '2.0.4';
p.description = p.description.replace('2.0.3', '2.0.4');
fs.writeFileSync('package.json', JSON.stringify(p, null, 2) + '\n', 'utf8');

let proxy = fs.readFileSync('src/proxy.js', 'utf8');
proxy = proxy.replace("version: '2.0.3'", "version: '2.0.4'");
fs.writeFileSync('src/proxy.js', proxy, 'utf8');

let main = fs.readFileSync('main.js', 'utf8');
main = main.replace('子沐智能中转路由 v2.0.3', '子沐智能中转路由 v2.0.4');
fs.writeFileSync('main.js', main, 'utf8');

let app = fs.readFileSync('renderer/app.js', 'utf8');
app = app.replace('子沐智能中转路由 v2.0.3 · 动漫主题版', '子沐智能中转路由 v2.0.4 · 动漫主题版');
fs.writeFileSync('renderer/app.js', app, 'utf8');

console.log('version -> 2.0.4 done');
