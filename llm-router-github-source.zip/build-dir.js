// 构建 win-unpacked（dir），禁用 asar 完整性校验，用于排查启动失败
const { build, Platform, Arch } = require('electron-builder');

const archToType = new Map();
archToType.set(Arch.x64, ['dir']);

const targets = new Map();
targets.set(Platform.WINDOWS, archToType);

build({
  targets,
  config: {
    asarIntegrity: false,
    win: { signAndEditExecutable: false }
  }
})
  .then(() => { console.log('BUILD_OK'); process.exit(0); })
  .catch((err) => { console.error('BUILD_FAIL:', err.stack || err); process.exit(1); });
