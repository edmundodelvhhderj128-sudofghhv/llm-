/**
 * UI 冒烟测试（jsdom）——逐页渲染 + 模拟点击关键按钮，抓渲染异常与失效控件
 * 运行: node test-ui.js
 * 注意: app.js 顶层 const 不在 window 上，需用 window.eval 访问（jsdom 作用域）
 */
const fs = require('fs');
const path = require('path');
const { JSDOM, VirtualConsole } = require('jsdom');

const html = fs.readFileSync(path.join(__dirname, 'renderer', 'index.html'), 'utf8');
const appJs = fs.readFileSync(path.join(__dirname, 'renderer', 'app.js'), 'utf8');

let passed = 0, failed = 0;
function ok(name) { passed++; console.log(`  ok ${name}`); }
function fail(name, detail) { failed++; console.log(`  FAIL ${name}: ${detail || ''}`); }

const errors = [];
const virtualConsole = new VirtualConsole();
virtualConsole.on('jsdomError', (e) => errors.push('jsdomError: ' + (e.message || e)));
virtualConsole.on('error', (...args) => errors.push('console.error: ' + args.join(' ')));

const presets = [
  { name: 'Agnes 国内', baseUrl: 'https://apihub.agnes-ai.cn', region: 'CN', note: '', models: ['agnes-2.5-flash'] },
  { name: 'Agnes 国际', baseUrl: 'https://apihub.agnes-ai.com', region: 'US', note: '', models: ['agnes-2.5-flash'] },
  { name: '商汤日日新 SenseNova', baseUrl: 'https://token.sensenova.cn', region: 'CN', note: '', models: ['sensenova-6.7-flash-lite'] }
];
const smartMock = {
  quality: { enabled: false, judgeProviderId: null, judgeModel: null, sampleRate: 0.1, heuristic: true },
  guard: { enabled: false, maskPII: true, blockSensitive: false, sensitiveWords: [] },
  semanticCache: { enabled: false, threshold: 0.95, maxEntries: 2000, embeddingProviderId: null, embeddingModel: null },
  slo: { enabled: true, p95ThresholdMs: 4000, windowSize: 200 },
  residency: { enabled: false, allowedRegions: [] },
  shadow: { enabled: true },
  logging: { enabled: true, maxEntries: 10000, days: 7 },
  stats: {
    totalRequests: 10, successCount: 9, failCount: 1, totalCost: 0.05,
    providers: [{ id: 'p1', name: '测试渠道', keyCount: 1, modelCount: 2, enabled: true, requests: 10, success: 9, fail: 1, cost: 0.05, tokens: 1234, latency: 120, successRate: 0.9, qualityScore: 80, billing: { mode: 'tokens', pricePerCall: 0 } }],
    modelStats: { 'mock-model': { requests: 10, success: 9, fail: 1, cost: 0.05, tokens: 1234 } },
    recentRequests: [{ time: new Date().toISOString(), model: 'mock-model', provider: '测试渠道', status: 'success', latency: 120, switched: false, cached: false }],
    cache: { hits: 3, misses: 7, hitRate: 30, entries: 2, maxBytes: 1073741824, sizeBytes: 1024, evictions: 0 },
    semanticCache: { enabled: false, hits: 0, misses: 0, hitRate: 0, entries: 0, embedErrors: 0 },
    slo: { enabled: true, degraded: false, p95Ms: 300, thresholdMs: 4000, degradedCount: 0, recoveredCount: 0 },
    drift: { active: false, items: [] },
    quality: { enabled: false },
    compression: { compressedRequests: 2, savedTokens: 3500, heuristic: 2, smart: 0, config: { enabled: false, heuristic: true, smart: false, providerId: null, model: null, keepRecent: 8, maxOldChars: 600, minLen: 80, triggerTokens: 12000 } },
    quota: { enabled: false, providers: [] },
    abTest: { enabled: false, groups: [] }
  },
  healthcheck: {
    items: Array.from({ length: 10 }, (_, i) => ({ id: i + 1, name: '项' + (i + 1), desc: '', status: i < 5 ? 'ok' : 'partial', enabled: true, hint: '' })),
    summary: { ok: 5, partial: 5, missing: 0, disabled: 0, total: 10 },
    hasEmbeddingModel: false
  }
};
const configMock = {
  version: '2.1.2', proxyPort: 3456, currency: 'USD', autoStart: false, trayMinimize: true,
  providers: [
    { id: 'p1', name: '测试渠道', baseUrl: 'https://api.example.com', keys: ['k1'], models: ['mock-model'], enabled: true, priority: 1, keyIndex: 0, keyStats: {}, region: 'CN', pathStyle: 'v1', billing: { mode: 'tokens', pricePerCall: 0 }, weights: {}, circuit: {}, quotaUsed: {} }
  ],
  routing: { strategy: 'priority', failover: true, fallback: true, maxRetries: 3, timeout: 30000, healthCheckInterval: 5, circuitBreaker: { enabled: true, threshold: 5, cooldownMs: 60000 }, quota: { enabled: false, period: 'day', limits: {} }, costOptimization: { enabled: false, preferCheapest: true }, abTest: { enabled: false, groups: [] } },
  prices: { currency: 'USD', models: { 'mock-model': { input: 1, output: 2 } } },
  cache: { enabled: true, maxBytes: 1073741824, stream: true, embeddings: true }
};

let addProviderCalls = [];
let setSmartCalls = [];
const api = {
  getConfig: async () => JSON.parse(JSON.stringify(configMock)),
  saveConfig: async (c) => c,
  resetConfig: async () => JSON.parse(JSON.stringify(configMock)),
  addProvider: async (p) => { addProviderCalls.push(p); return { id: 'new-' + addProviderCalls.length, ...p }; },
  updateProvider: async (id, d) => d,
  removeProvider: async () => true,
  fetchModels: async () => ['mock-model'],
  fetchAllModels: async () => ({}),
  getHealthStatus: async () => ({}),
  runHealthCheck: async () => ({}),
  checkProvider: async () => ({}),
  testRoute: async () => ({ data: { choices: [{ message: { content: 'ok' } }] }, meta: { model: 'mock-model', provider: '测试渠道', latency: 10 } }),
  getProxyStatus: async () => ({ running: true, port: 3456, url: 'http://localhost:3456' }),
  setProxyPort: async () => true,
  restartProxy: async () => ({}),
  getStats: async () => smartMock.stats,
  resetStats: async () => smartMock.stats,
  getPrices: async () => ({ currency: 'USD', models: {} }),
  setPrice: async () => true,
  removePrice: async () => true,
  syncPrices: async () => ({ synced: 0, models: {} }),
  setCurrency: async () => 'USD',
  getAutoStart: async () => false,
  setAutoStart: async (v) => v,
  setTrayMinimize: async (v) => v,
  minimizeWindow: async () => {},
  closeWindow: async () => {},
  maximizeWindow: async () => false,
  saveBgImage: async () => ({}),
  loadBgImage: async () => null,
  resetBgImage: async () => true,
  copyText: async () => true,
  onHealthUpdate: () => () => {},
  onStatsUpdate: () => () => {},
  getCache: async () => ({ config: configMock.cache, stats: smartMock.stats.cache }),
  setCache: async () => ({}),
  clearCache: async () => ({}),
  getLogs: async () => [{ traceId: 't1', time: new Date().toISOString(), model: 'mock-model', requestedModel: 'mock-model', provider: '测试渠道', status: 'success', latency: 10, switched: false, cached: false, qualityScore: 80, shadow: { actual: '测试渠道', weightedFirst: '测试渠道', same: true }, strategy: 'priority' }],
  exportLogs: async () => [],
  clearLogs: async () => true,
  getSmart: async () => JSON.parse(JSON.stringify(smartMock)),
  setSmart: async (section, data) => { setSmartCalls.push({ section, data }); return data; },
  getPresets: async () => JSON.parse(JSON.stringify(presets)),
  // 记忆系统
  getMemory: async () => ({
    enabled: true, autoAddModels: true, totalCalls: 12, updatedAt: new Date().toISOString(),
    channels: [{ id: 'p1', name: '模拟渠道', baseUrl: 'https://api.example.com', lastProbedAt: new Date().toISOString(), modelCount: 3, models: [
      { name: 'gpt-4o', capability: 'chat', keyCount: 2, calls: 10, success: 9, fail: 1, successRate: 90, avgLatency: 120, avgCost: 0.001, lastUsed: new Date().toISOString() },
      { name: 'dall-e-3', capability: 'image', keyCount: 1, calls: 2, success: 2, fail: 0, successRate: 100, avgLatency: 3000, avgCost: 0.04, lastUsed: new Date().toISOString() }
    ] }],
    topModels: [{ name: 'gpt-4o', calls: 10, success: 9, successRate: 90, capability: 'chat' }],
    usageByHour: [{ hour: 12, top: [{ model: 'gpt-4o', count: 3 }] }],
    lastUsedByCapability: { chat: 'gpt-4o', image: 'dall-e-3' },
    recommendations: { chat: { model: 'gpt-4o', calls: 10, successRate: 90, avgLatency: 120 }, image: null, video: null, embedding: null }
  }),
  probeMemory: async () => ({ results: {}, report: { channels: [], topModels: [], totalCalls: 0, recommendations: {} } }),
  syncMemoryModels: async () => ({ added: 0, report: { channels: [], totalCalls: 0 } }),
  clearMemory: async () => ({ channels: [], totalCalls: 0, recommendations: {} }),
  setMemoryConfig: async (d) => d,
  trackFeature: async () => true,
  // 本地模型
  getLocalStatus: async () => ({ backend: 'llama', state: 'running', running: true, port: 11435, engineExists: true, engineVersion: 'b5450', modelExists: true, modelSize: 5000000000, modelApprox: 4.68 * 1024 ** 3, modelName: 'qwen2.5-7b-instruct-q4_k_m.gguf', ollamaBase: 'http://127.0.0.1:11434', ollamaModel: 'qwen2.5:7b', progress: null, lastError: null, ctxSize: 8192, threads: 4, tools: true }),
  getLocalTools: async () => ({ tools: [{ type: 'function', function: { name: 'get_status', description: 'x', parameters: { type: 'object', properties: {} } } }, { type: 'function', function: { name: 'switch_strategy', description: 'y', parameters: { type: 'object', properties: {} } } }] }),
  downloadLocalEngine: async () => ({ ok: true }),
  downloadLocalModel: async () => ({ ok: true }),
  startLocal: async () => ({ ok: true, running: true }),
  stopLocal: async () => ({ ok: true }),
  setLocalConfig: async (d) => d,
  runLocalTool: async (name, args) => ({ ok: true, strategy: 'weighted' }),
  onLocalEvent: async () => {},
  getDataUsage: async () => ({ logs: 40960, local: 4600000000, cache: 5242880, blob: 0, memory: 20480, config: 10240 }),
  cleanupData: async () => ({ ok: true }),
  getRemote: async () => ({ enabled: false, port: 3457, username: 'admin', hasPassword: true, listening: false, localProxyPort: 3456 }),
  setRemote: async (d) => d,
  setRemotePassword: async () => ({ ok: true }),
  genRemoteNginx: async () => ({ nginxConf: 'server {\n    server_name router.example.com;\n    proxy_pass http://127.0.0.1:3457;\n}', certbotCmd: 'certbot ...', renewCmd: 'crontab ...', tips: ['t1'] }),
  testRemote: async () => ({ ok: true, remote: { app: '子沐智能中转路由', version: '3.0.0' } }),
  migrateRemote: async () => ({ ok: true, providers: 2, models: 10, version: '3.0.0', note: '迁移完成' }),
  getBrainStatus: async () => ({ enabled: true, autoRunning: true, engineRunning: true, intervalMin: 15, wakeOnEvents: true, decisionCount: 2, lastRunAt: new Date().toISOString(), history: [{ time: new Date().toISOString(), reason: '手动触发', tools: [{ name: 'switch_strategy', ok: true }], summary: '已切换到加权策略', durationMs: 1000 }] }),
  runBrain: async (reason) => ({ ok: true, reason, summary: '测试决策', tools: [] }),
  setBrainConfig: async (d) => d,
  onBrainEvent: async () => {}
};

const dom = new JSDOM(html, {
  runScripts: 'dangerously',
  url: 'http://localhost/',
  pretendToBeVisual: true,
  virtualConsole,
  beforeParse(window) {
    window.api = api;
    window.confirm = () => true;
    window.alert = () => {};
    if (!window.URL.createObjectURL) {
      window.URL.createObjectURL = () => 'blob:mock';
      window.URL.revokeObjectURL = () => {};
    }
    // jsdom 不支持下载导航（真实浏览器无此问题）
    window.HTMLAnchorElement.prototype.click = () => {};
    window.addEventListener('error', (e) => errors.push('window.error: ' + (e.error?.stack || e.message)));
  }
});

const { window } = dom;
const { document } = window;
const S = (expr) => window.eval(expr); // 访问顶层 const state

const script = document.createElement('script');
script.textContent = appJs;
document.body.appendChild(script);
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

(async () => {
  await sleep(800);

  // 基础
  try {
    if (S('state.config')) ok('init: 配置已加载');
    else fail('init: 配置未加载');
  } catch (e) { fail('init', e.message); }

  // 逐页渲染
  for (const page of ['providers', 'models', 'routing', 'health', 'test', 'stats', 'smart', 'memory', 'local', 'logs', 'settings']) {
    try {
      S(`state.currentPage = '${page}'; renderPage();`);
      const len = document.getElementById('content').innerHTML.length;
      if (len > 50) ok(`页面渲染: ${page} (${len} 字符)`);
      else fail(`页面渲染: ${page}`, '内容过短');
    } catch (e) { fail(`页面渲染: ${page}`, e.message); }
  }

  // 空状态含预设按钮
  try {
    S('state.currentPage = "providers"; state.config.providers = []; renderPage();');
    const htmlStr = document.getElementById('content').innerHTML;
    if (htmlStr.includes('从预设添加')) ok('空状态包含「从预设添加」按钮');
    else fail('空状态包含「从预设添加」按钮', '未找到');
    S('state.config.providers = JSON.parse(JSON.stringify(' + JSON.stringify(configMock.providers) + '));');
  } catch (e) { fail('空状态预设按钮', e.message); }

  // 告警横幅分支：漂移告警 + SLO 降级 + 语义缓存命中标记
  try {
    S('state.currentPage = "stats"; state.stats.drift = { active: true, items: [{ provider: "渠道A", baseline: 90, recent: 60, drop: 30 }] }; state.stats.slo = { degraded: true, p95Ms: 5000, thresholdMs: 4000, degradedCount: 1 }; state.stats.recentRequests[0].cached = true; state.stats.recentRequests[0].cacheType = "semantic"; renderPage();');
    const st = document.getElementById('content').innerHTML;
    if (st.includes('漂移告警')) ok('统计页漂移告警横幅');
    else fail('统计页漂移告警横幅', '未找到');
    S('state.currentPage = "smart"; state.smart.stats.slo.degraded = true; state.smart.stats.drift = { active: true, items: [{ provider: "渠道A", baseline: 90, recent: 60, drop: 30 }] }; renderPage();');
    const sm = document.getElementById('content').innerHTML;
    if (sm.includes('SLO 降级模式运行中') && sm.includes('漂移告警')) ok('智能页告警横幅（漂移+SLO）');
    else fail('智能页告警横幅', '未找到');
  } catch (e) { fail('告警横幅分支', e.message); }

  // 预设弹窗 + 添加
  try {
    await window.openPresetsModal();
    if (document.getElementById('presetsModal')) ok('预设弹窗打开');
    else fail('预设弹窗打开', '未找到');
    await window.addFromPreset('Agnes 国内');
    const call = addProviderCalls.find(c => c.baseUrl === 'https://apihub.agnes-ai.cn');
    if (call) ok('预设添加: Agnes 国内 baseUrl 正确');
    else fail('预设添加: Agnes 国内', '未调用 addProvider');
    window.closePresetsModal();
  } catch (e) { fail('预设弹窗/添加', e.message); }

  // 手动添加（region/pathStyle/billing）
  try {
    window.openProviderModal();
    document.getElementById('pName').value = '新渠道';
    document.getElementById('pUrl').value = 'https://open.bigmodel.cn/api/paas/v4';
    document.getElementById('pKeys').value = 'key1';
    document.getElementById('pRegion').value = 'cn';
    document.getElementById('pPathStyle').value = 'none';
    await window.saveProvider();
    const call = addProviderCalls[addProviderCalls.length - 1];
    if (call && call.region === 'CN' && call.pathStyle === 'none') ok('手动添加服务商: region/pathStyle 正确');
    else fail('手动添加服务商', JSON.stringify(call));
  } catch (e) { fail('手动添加服务商', e.message); }

  // 智能页：质量评分
  try {
    S('state.currentPage = "smart"; renderPage();');
    await sleep(100);
    const btn = [...document.querySelectorAll('button')].find(b => b.textContent.includes('保存质量评分'));
    if (!btn) { fail('智能页质量评分按钮', '未找到按钮'); }
    else {
      document.getElementById('qEnabled').classList.add('active');
      document.getElementById('qJudgeModel').value = 'agnes-2.5-flash';
      await window.saveSmartSection('quality');
      const call = setSmartCalls.find(c => c.section === 'quality');
      if (call && call.data.enabled === true && call.data.judgeModel === 'agnes-2.5-flash') ok('质量评分保存: 数据正确');
      else fail('质量评分保存', JSON.stringify(call));
    }
  } catch (e) { fail('智能页质量评分', e.message); }

  // 智能页其他保存
  try {
    S('renderPage();');
    await sleep(100);
    await window.saveSmartSection('guard');
    await window.saveSmartSection('semanticCache');
    await window.saveSmartSection('slo');
    await window.saveResidencyShadow();
    const sections = setSmartCalls.filter(c => ['guard', 'semanticCache', 'slo', 'residency', 'shadow'].includes(c.section));
    if (sections.length >= 5) ok(`智能页保存按钮: ${sections.length} 次调用`);
    else fail('智能页保存按钮', `仅 ${sections.length} 次`);
  } catch (e) { fail('智能页保存按钮', e.message); }

  // 日志页
  try {
    S('state.currentPage = "logs"; renderPage();');
    await sleep(100);
    const box = document.getElementById('logListBox');
    if (box && box.innerHTML.includes('t1')) ok('日志页加载');
    else fail('日志页加载', box ? box.innerHTML.slice(0, 120) : 'no box');
    await window.showLogDetail('t1');
    if (document.querySelector('.modal')) ok('日志详情弹窗');
    else fail('日志详情弹窗', '未找到');
  } catch (e) { fail('日志页', e.message); }

  // 路由保存
  try {
    S('state.currentPage = "routing"; renderPage();');
    document.getElementById('routingStrategy').value = 'weighted';
    await window.saveRouting();
    ok('路由配置保存（weighted）');
  } catch (e) { fail('路由配置保存', e.message); }

  // 设置页按钮
  try {
    S('state.currentPage = "settings"; renderPage();');
    await sleep(100);
    await window.toggleAutoStart();
    await window.toggleTrayMinimize();
    await window.changeCurrency();
    await window.saveCacheSettings();
    ok('设置页按钮（自启/托盘/货币/缓存）');
  } catch (e) { fail('设置页按钮', e.message); }

  // 模型页：能力标签
  try {
    S('state.currentPage = "models"; renderPage();');
    const ml = document.getElementById('content').innerHTML;
    if (ml.includes('💬 对话')) ok('模型页能力标签（对话）');
    else fail('模型页能力标签', '未找到对话标签');
  } catch (e) { fail('模型页能力标签', e.message); }

  // 测试页：模式切换（图片/视频）
  try {
    S('state.currentPage = "test"; renderPage();');
    const mode = document.getElementById('testMode');
    if (!mode) { fail('测试页模式选择', '未找到'); }
    else {
      mode.value = 'image';
      window.onTestModeChange();
      if (document.getElementById('testStreamLabel').style.display === 'none') ok('测试页切图片模式（隐藏流式选项）');
      else fail('测试页切图片模式', '流式选项未隐藏');
      mode.value = 'chat';
      window.onTestModeChange();
      ok('测试页切回对话模式');
    }
  } catch (e) { fail('测试页模式切换', e.message); }

  // 记忆页：渲染与探测按钮
  try {
    S('state.currentPage = "memory"; renderPage();');
    await sleep(150);
    const mm = document.getElementById('content').innerHTML;
    if (mm.includes('内置记忆') && mm.includes('gpt-4o')) ok('记忆页渲染（渠道模型+习惯）');
    else fail('记忆页渲染', mm.slice(0, 120));
    await window.probeMemoryNow();
    ok('记忆页立即探测按钮');
    await window.clearMemoryNow();
    ok('记忆页清空按钮');
  } catch (e) { fail('记忆页', e.message); }

  // 统计重置
  try {
    S('state.currentPage = "stats"; renderPage();');
    await window.resetStats();
    ok('统计重置');
  } catch (e) { fail('统计重置', e.message); }

  // 设置页：修改代理端口
  try {
    S('state.currentPage = "settings"; renderPage();');
    document.getElementById('proxyPort').value = '4567';
    await window.changeProxyPort();
    ok('设置页修改代理端口');
  } catch (e) { fail('设置页修改代理端口', e.message); }

  // 导出配置（URL.createObjectURL 已 mock）
  try {
    window.exportConfig();
    ok('导出配置');
  } catch (e) { fail('导出配置', e.message); }

  // 智能页：Tokens 压缩保存
  try {
    S('state.currentPage = "smart"; renderPage();');
    await sleep(100);
    if (document.getElementById('cmpEnabled')) {
      document.getElementById('cmpEnabled').classList.add('active');
      document.getElementById('cmpModel').value = 'deepseek-chat';
      await window.saveSmartSection('compression');
      const call = setSmartCalls.find(c => c.section === 'compression');
      if (call && call.data.enabled === true && call.data.model === 'deepseek-chat') ok('压缩设置保存');
      else fail('压缩设置保存', JSON.stringify(call));
    } else {
      fail('压缩设置保存', '未找到压缩配置区');
    }
  } catch (e) { fail('压缩设置保存', e.message); }

  // 日志页：过滤与重置
  try {
    S('state.currentPage = "logs"; renderPage();');
    await sleep(100);
    document.getElementById('logFilterModel').value = 'mock-model';
    window.applyLogFilter();
    await sleep(50);
    ok('日志页过滤');
    window.resetLogFilter();
    await sleep(50);
    ok('日志页重置过滤');
  } catch (e) { fail('日志页过滤/重置', e.message); }

  // 服务商弹窗内一键获取模型
  try {
    window.openProviderModal();
    document.getElementById('pName').value = '获取模型渠道';
    document.getElementById('pUrl').value = 'https://api.example.com';
    document.getElementById('pKeys').value = 'k1';
    await window.fetchModelsInModal();
    const modelsVal = document.getElementById('pModels').value;
    if (modelsVal.includes('mock-model')) ok('弹窗内一键获取模型');
    else fail('弹窗内一键获取模型', modelsVal);
  } catch (e) { fail('弹窗内一键获取模型', e.message); }

  // 测试页非流式
  try {
    S('state.currentPage = "test"; renderPage();');
    document.getElementById('testModel').value = 'mock-model';
    document.getElementById('testStream').checked = false;
    document.getElementById('chatInput').value = '你好';
    await window.sendTestMessage();
    const msgs = document.getElementById('chatMessages').innerHTML;
    if (msgs.includes('ok')) ok('测试页非流式发送');
    else fail('测试页非流式发送', msgs.slice(0, 120));
  } catch (e) { fail('测试页非流式发送', e.message); }

  // 收集错误
  if (errors.length > 0) fail('无 JS 运行时错误', errors.slice(0, 5).join(' | '));
  else ok('无 JS 运行时错误');

  console.log(`\n通过 ${passed} 项, 失败 ${failed} 项`);
  process.exit(failed > 0 ? 1 : 0);
})().catch(e => { console.error('测试崩溃:', e); process.exit(1); });
