/**
 * 超长会话压力测试（第五轮）——长历史/大消息/长流式/压缩联动/内存监测
 * 运行: node test-long-session.js
 */
const assert = require('assert');
const os = require('os');
const http = require('http');
const fs = require('fs');
const path = require('path');

const Module = require('module');
const origLoad = Module._load;
const userDataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'llm-long-'));
Module._load = function (request, parent, isMain) {
  if (request === 'electron') return { app: { getPath: () => userDataDir }, ipcMain: { handle: () => {} } };
  return origLoad.apply(this, arguments);
};

const { Router } = require('./src/router');
const { ProxyServer } = require('./src/proxy');

let passed = 0, failed = 0;
function ok(name) { passed++; console.log(`  ok ${name}`); }
function fail(name, detail) { failed++; console.log(`  FAIL ${name}: ${detail || ''}`); }

function mockConfig() {
  const state = {
    providers: [], routing: { strategy: 'priority', failover: true, fallback: true, maxRetries: 3, timeout: 60000, healthCheckInterval: 5, circuitBreaker: { enabled: true, threshold: 5, cooldownMs: 60000 }, quota: { enabled: false, period: 'day', limits: {} }, costOptimization: { enabled: false, preferCheapest: true }, abTest: { enabled: false, groups: [] } },
    prices: { currency: 'USD', models: {} }, cache: { enabled: true, maxBytes: 268435456, stream: true, embeddings: true },
    quality: {}, guard: { enabled: false, maskPII: true, blockSensitive: false, sensitiveWords: [] },
    semanticCache: { enabled: false, threshold: 0.95, maxEntries: 1000 }, slo: { enabled: true, p95ThresholdMs: 1000000, windowSize: 200 },
    residency: { enabled: false, allowedRegions: [] }, shadow: { enabled: true }, compression: { enabled: false }, logging: { enabled: true }
  };
  return {
    config: state,
    get(key) { return key.split('.').reduce((o, k) => o?.[k], this.config); },
    set(key, v) { const ks = key.split('.'); const last = ks.pop(); const t = ks.reduce((o, k) => { if (!o[k]) o[k] = {}; return o[k]; }, this.config); t[last] = v; },
    getAll() { return this.config; },
    persist() {},
    addProvider(p) {
      const id = p.id || ('p' + this.config.providers.length);
      const prov = { id, name: p.name, baseUrl: p.baseUrl, keys: p.keys || ['k1'], models: p.models || [], enabled: p.enabled !== false, priority: 1, keyIndex: 0, keyStats: {}, region: 'any', pathStyle: 'v1', billing: { mode: 'tokens', pricePerCall: 0 }, weights: { latencyMs: null, successRate: 1, requests: 0, qualityScore: 70 }, circuit: { failures: 0, open: false, openedAt: null }, quotaUsed: { periodKey: null, requests: 0, tokens: 0 } };
      prov.keys.forEach((_, i) => { prov.keyStats[i] = { requests: 0, errors: 0, consecutiveErrors: 0, lastUsed: null, disabled: false }; });
      this.config.providers.push(prov); return prov;
    },
    updateProvider(id, d) { const i = this.config.providers.findIndex(p => p.id === id); this.config.providers[i] = { ...this.config.providers[i], ...d }; return this.config.providers[i]; },
    getProviders() { return this.config.providers; },
    getEnabledProviders() { return this.config.providers.filter(p => p.enabled); }
  };
}

// 上游：回显消息统计 + 支持超长流式（N 块）+ usage 尾块
function startUpstream(opts = {}) {
  const server = http.createServer((req, res) => {
    server._count = (server._count || 0) + 1;
    let body = '';
    req.on('data', c => body += c);
    req.on('end', () => {
      if (req.url === '/v1/chat/completions') {
        const parsed = JSON.parse(body || '{}');
        if (parsed.stream) {
          res.setHeader('Content-Type', 'text/event-stream');
          const chunks = opts.streamChunks || 2000;
          const chunkText = opts.chunkText || '块';
          let i = 0;
          const timer = setInterval(() => {
            if (i >= chunks) {
              res.write(`data: ${JSON.stringify({ id: 's', object: 'chat.completion.chunk', created: 0, model: parsed.model, choices: [{ index: 0, delta: {}, finish_reason: 'stop' }], usage: { total_tokens: chunks } })}\n\n`);
              res.write('data: [DONE]\n\n');
              res.end();
              clearInterval(timer);
              return;
            }
            res.write(`data: ${JSON.stringify({ id: 's', choices: [{ delta: { content: chunkText + i + ',' } }] })}\n\n`);
            i++;
          }, 0);
        } else {
          const msgs = parsed.messages || [];
          const totalChars = msgs.reduce((s, m) => s + (typeof m?.content === 'string' ? m.content.length : 0), 0);
          const compressed = msgs.some(m => String(m.content || '').includes('已压缩'));
          const first = msgs[0];
          const last = msgs[msgs.length - 1];
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({
            id: 'x', choices: [{ message: { content: 'echo:' + JSON.stringify({ msgCount: msgs.length, totalChars, compressed, firstContent: typeof first?.content === 'string' ? first.content.slice(0, 30) : 'nonstring', lastContent: typeof last?.content === 'string' ? last.content.slice(0, 30) : 'nonstring' }) } }],
            usage: { total_tokens: 100 }
          }));
        }
      } else { res.statusCode = 404; res.end('{}'); }
    });
  });
  return new Promise(r => server.listen(0, '127.0.0.1', () => r({ port: server.address().port, server, count: () => server._count || 0 })));
}

const postJson = (port, body) => new Promise((resolve) => {
  const data = Buffer.from(JSON.stringify(body), 'utf8');
  const req = http.request({ host: '127.0.0.1', port, path: '/v1/chat/completions', method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': data.length } }, (res) => {
    const chunks = [];
    res.on('data', c => chunks.push(c));
    res.on('end', () => resolve({ status: res.statusCode, text: Buffer.concat(chunks).toString('utf8') }));
  });
  req.on('error', () => resolve({ status: 0, text: '' }));
  req.write(data); req.end();
});

(async () => {
  const memBefore = process.memoryUsage();

  const up = await startUpstream({ streamChunks: 2000 });
  const config = mockConfig();
  config.addProvider({ name: '长会话上游', baseUrl: `http://127.0.0.1:${up.port}`, keys: ['k1'], models: ['gpt-4'] });
  const router = new Router(config, os.tmpdir());
  const proxy = new ProxyServer(config, router);
  await proxy.start(0);
  const port = proxy.port;

  // ============ 1. 超长历史（500 条消息 ≈ 150KB） ============
  {
    const messages = [];
    for (let i = 0; i < 500; i++) {
      messages.push({ role: 'user', content: `第${i}条消息，包含一些背景信息${'长文本'.repeat(50)}` });
    }
    const r = await postJson(port, { model: 'gpt-4', messages, noCache: true });
    assert.strictEqual(r.status, 200, r.text.slice(0, 200));
    const echo = JSON.parse(JSON.parse(r.text).choices[0].message.content.replace('echo:', ''));
    assert.strictEqual(echo.msgCount, 500, '上游应收到全部 500 条');
    assert.ok(echo.totalChars >= 80000, `总字符应≥80000，实际 ${echo.totalChars}`);
    ok('超长历史 500 条（150KB）完整透传');
  }

  // ============ 2. 超长单条消息（2MB） ============
  {
    const r = await postJson(port, { model: 'gpt-4', messages: [{ role: 'user', content: 'A'.repeat(2 * 1024 * 1024) }], noCache: true });
    assert.strictEqual(r.status, 200, r.text.slice(0, 200));
    ok('超长单条消息 2MB 正常处理');
  }

  // ============ 3. 超长历史 + 压缩联动 ============
  {
    config.set('compression', { enabled: true, heuristic: true, smart: false, keepRecent: 3, maxOldChars: 200, minLen: 50, triggerTokens: 100 });
    const messages = [];
    for (let i = 0; i < 200; i++) messages.push({ role: 'user', content: '旧消息长内容' + 'y'.repeat(300) + i });
    const lastMsg = '最新问题：总结一下';
    messages.push({ role: 'user', content: lastMsg });
    const r = await postJson(port, { model: 'gpt-4', messages, noCache: true });
    assert.strictEqual(r.status, 200, r.text.slice(0, 200));
    const echo = JSON.parse(JSON.parse(r.text).choices[0].message.content.replace('echo:', ''));
    assert.strictEqual(echo.compressed, true, '上游应收到压缩标记');
    // 启发式：条数不变、内容缩短、最近消息原文保留
    assert.strictEqual(echo.msgCount, 201, '启发式压缩不改变条数');
    assert.ok(echo.totalChars < 50000, `压缩后总字符应显著减少，实际 ${echo.totalChars}`);
    assert.strictEqual(echo.lastContent, lastMsg.slice(0, 30), '最近消息必须原文保留');
    config.set('compression', { enabled: false, heuristic: true, smart: false, keepRecent: 8, maxOldChars: 600, minLen: 80, triggerTokens: 12000 });
    ok(`超长会话压缩联动（6.4万字符 → ${echo.totalChars}，最近消息保留）`);
  }

  // ============ 4. 超长流式输出（2000 块）+ 缓存重放 ============
  {
    const body = { model: 'gpt-4', messages: [{ role: 'user', content: '长输出' }], stream: true };
    const r1 = await new Promise((resolve) => {
      const data = Buffer.from(JSON.stringify(body), 'utf8');
      const req = http.request({ host: '127.0.0.1', port, path: '/v1/chat/completions', method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': data.length } }, (res) => {
        const chunks = [];
        res.on('data', c => chunks.push(c));
        res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, text: Buffer.concat(chunks).toString('utf8') }));
      });
      req.on('error', () => resolve({ status: 0, headers: {}, text: '' }));
      req.write(data); req.end();
    });
    assert.strictEqual(r1.status, 200);
    assert.ok(r1.text.includes('块1999,'), '超长流式应完整收到末尾内容');
    assert.ok(r1.text.includes('[DONE]'));
    assert.ok(r1.text.includes('"total_tokens":2000'), 'usage 尾块应保留');
    const len1 = r1.text.length;
    // 第二次：缓存命中重放
    const r2 = await new Promise((resolve) => {
      const data = Buffer.from(JSON.stringify(body), 'utf8');
      const req = http.request({ host: '127.0.0.1', port, path: '/v1/chat/completions', method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': data.length } }, (res) => {
        const chunks = [];
        res.on('data', c => chunks.push(c));
        res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, text: Buffer.concat(chunks).toString('utf8') }));
      });
      req.on('error', () => resolve({ status: 0, headers: {}, text: '' }));
      req.write(data); req.end();
    });
    assert.strictEqual(r2.headers['x-router-cache'], 'HIT', '第二次应缓存命中');
    // 缓存重放是紧凑单块，字节数不同但内容必须完整一致
    assert.ok(r2.text.includes('块0,块1,块2,'), '重放应包含开头内容');
    assert.ok(r2.text.includes('块1999,'), '重放应包含末尾内容');
    assert.ok(r2.text.includes('[DONE]'), '重放应含 [DONE]');
    assert.ok(r2.text.includes('"total_tokens":2000'), '重放应含 usage');
    ok('超长流式 2000 块完整转发 + 缓存重放内容一致');
  }

  // ============ 5. 超过 body 上限（>50MB）→ 应拒绝不崩溃 ============
  {
    const big = 'B'.repeat(51 * 1024 * 1024);
    const r = await postJson(port, { model: 'gpt-4', messages: [{ role: 'user', content: big }] });
    assert.ok(r.status === 400 || r.status === 413, `超 50MB 应拒绝，实际 ${r.status}`);
    // 进程存活
    const alive = await new Promise((resolve) => {
      http.get({ host: '127.0.0.1', port, path: '/health' }, (res) => { res.resume(); resolve(res.statusCode === 200); }).on('error', () => resolve(false));
    });
    assert.strictEqual(alive, true);
    ok('51MB 请求体被拒绝且进程存活');
  }

  // ============ 6. 内存监测 ============
  {
    global.gc && global.gc();
    const memAfter = process.memoryUsage();
    const rssGrowthMB = (memAfter.rss - memBefore.rss) / 1024 / 1024;
    const heapGrowthMB = (memAfter.heapUsed - memBefore.heapUsed) / 1024 / 1024;
    // 宽松上界：允许缓存/日志数据占用，但不应失控
    assert.ok(rssGrowthMB < 400, `RSS 增长 ${rssGrowthMB.toFixed(0)}MB 超界`);
    console.log(`    内存: RSS +${rssGrowthMB.toFixed(0)}MB, Heap +${heapGrowthMB.toFixed(0)}MB`);
    ok('超长会话后内存无失控增长');
  }

  proxy.stop();
  up.server.close();
  console.log(`\n通过 ${passed} 项, 失败 ${failed} 项`);
  process.exit(failed > 0 ? 1 : 0);
})().catch(e => { console.error('测试崩溃:', e); process.exit(1); });
