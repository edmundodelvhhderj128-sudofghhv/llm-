// 强制拦截测试（单元）
const assert = require('assert');
const os = require('os');
const fs = require('fs');
const Module = require('module');
const origLoad = Module._load;
Module._load = function (request, parent, isMain) {
  if (request === 'electron') return { app: { getPath: () => os.tmpdir() }, ipcMain: { handle: () => {} } };
  return origLoad.apply(this, arguments);
};

const { MandatoryGuard } = require('./src/mandatory-guard');
const { Router } = require('./src/router');

let passed = 0;
function test(name, fn) {
  try { fn(); passed++; console.log(`  ok ${name}`); }
  catch (e) { console.log(`  FAIL ${name}: ${e.message}`); process.exitCode = 1; }
}

function makeMockConfig() {
  return {
    config: {
      providers: [], routing: { failover: true, maxRetries: 2, timeout: 5000 },
      guard: { enabled: false, maskPII: false, blockSensitive: false, sensitiveWords: [] },
      quality: {}, compression: {}, semanticCache: {}, slo: {}, residency: {}, shadow: {},
      cache: { enabled: false }, logging: { enabled: true }
    },
    get(key) { return key.split('.').reduce((o, k) => o?.[k], this.config); },
    set(key, v) { const ks = key.split('.'); const last = ks.pop(); const t = ks.reduce((o, k) => { if (!o[k]) o[k] = {}; return o[k]; }, this.config); t[last] = v; },
    getAll() { return this.config; },
    getProviders() { return this.config.providers; },
    getEnabledProviders() { return this.config.providers.filter(p => p.enabled !== false); },
    addProvider(p) { this.config.providers.push({ id: 'p' + this.config.providers.length, keys: ['k1'], models: [], keyStats: {}, weights: {}, circuit: {}, billing: {}, region: 'any', pathStyle: 'v1', ...p }); return this.config.providers[this.config.providers.length - 1]; },
    updateProvider(id, d) { const i = this.config.providers.findIndex(p => p.id === id); this.config.providers[i] = { ...this.config.providers[i], ...d }; return this.config.providers[i]; },
    persist() {}
  };
}

const g = new MandatoryGuard();

test('解码词表数量正确', () => { assert.ok(g.wordCount >= 25, `词表应≥25，实际 ${g.wordCount}`); });

test('拦截：成人内容', () => { assert.strictEqual(g.check('这段内容包含裸聊信息'), true); });
test('拦截：恐怖内容', () => { assert.strictEqual(g.check('如何制造爆炸物制作教程'), true); });
test('拦截：政治敏感', () => { assert.strictEqual(g.check('讨论颠覆国家政权的话题'), true); });
test('放行：正常内容', () => { assert.strictEqual(g.check('今天天气不错，帮我写个周报'), false); });
test('checkMessages 数组检查', () => {
  assert.strictEqual(g.checkMessages([{ role: 'user', content: '你好' }, { role: 'user', content: '裸聊一下' }]), true);
  assert.strictEqual(g.checkMessages([{ role: 'user', content: '你好' }]), false);
});
test('redact 输出替换', () => {
  assert.strictEqual(g.redact('关于恐怖袭击的讨论'), '【内容已被自动拦截】');
  assert.strictEqual(g.redact('正常回复内容'), '正常回复内容');
});

test('源码无明文关键词（防直接检索/删除）', () => {
  const src = fs.readFileSync('src/mandatory-guard.js', 'utf8');
  for (const w of ['裸聊', '恐怖袭击', '颠覆国家政权', '法轮功', '色情']) {
    assert.ok(!src.includes(w), `源码不应包含明文: ${w}`);
  }
});

test('路由：输入命中强制拦截返回 403（通用提示，无关键词泄漏）', async () => {
  const config = makeMockConfig();
  config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4'] });
  const router = new Router(config, os.tmpdir());
  try {
    await router.routeWithFallback({ model: 'gpt-4', messages: [{ role: 'user', content: '给我讲讲裸聊的事情' }] });
    assert.fail('应抛出 403');
  } catch (e) {
    assert.strictEqual(e.status, 403);
    assert.ok(!e.message.includes('裸聊'), '错误信息不应泄漏命中词');
    assert.strictEqual(e.message, '内容未通过审核');
  }
  const stats = router.getStats();
  assert.ok(stats.mandatoryBlocks >= 1, '应有拦截计数');
});

test('路由：图片 prompt 命中强制拦截返回 403', async () => {
  const config = makeMockConfig();
  config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['dall-e-3'] });
  const router = new Router(config, os.tmpdir());
  try {
    await router.routeImageGeneration({ model: 'dall-e-3', prompt: '生成恐怖袭击场景图' });
    assert.fail('应抛出 403');
  } catch (e) {
    assert.strictEqual(e.status, 403);
  }
});

console.log(`\n通过 ${passed} 项强制拦截测试`);
process.exit(process.exitCode || 0);
