// 直接调用 electron-builder API 构建（绕过 CLI 参数解析兼容问题）
// 配置读取 package.json 的 "build" 字段
const { build, Platform, Arch } = require('electron-builder');

const archToType = new Map();
archToType.set(Arch.x64, ['portable']);

const targets = new Map();
targets.set(Platform.WINDOWS, archToType);

build({ targets })
  .then(() => { console.log('BUILD_OK'); process.exit(0); })
  .catch((err) => { console.error('BUILD_FAIL:', err.stack || err); process.exit(1); });
