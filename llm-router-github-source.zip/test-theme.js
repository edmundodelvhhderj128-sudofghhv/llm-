// 浅色主题静态审计（v2.2.6）：黑字 + 浅底 + 放大
const assert = require('assert');
const fs = require('fs');

const css = fs.readFileSync('renderer/styles.css', 'utf8');
const js = fs.readFileSync('renderer/app.js', 'utf8');

let passed = 0;
function ok(name) { passed++; console.log(`  ok ${name}`); }

// 1. 主题变量为深色
assert.ok(css.includes('--text-main: #1f2937'), '主文字应为深色 #1f2937');
ok('主文字变量为深色 (#1f2937)');

// 2. body 默认色为深色变量
assert.ok(/:root[\s\S]*?--text-main: #1f2937/.test(css));
assert.ok(css.includes('html, body') && css.includes('color: var(--text-main)'), 'body 文字应为深色');
ok('body 文字为深色');

// 3. 卡片为不透明白底
assert.ok(css.includes('--card-bg: rgba(255, 255, 255, 0.92)'), '卡片应为不透明白底');
assert.ok(css.includes('.glass-card {\n  background: var(--card-bg)'), 'glass-card 使用浅色底');
ok('卡片浅色底（黑字可读）');

// 4. CSS 中不再有白色文字类颜色（color: rgba(255,255,255...)
const whiteTextInCss = (css.match(/color:\s*rgba\(255,\s*255,\s*255/g) || []).length;
assert.strictEqual(whiteTextInCss, 0, `CSS 中不应有白色文字（剩余 ${whiteTextInCss} 处）`);
ok('CSS 无白色文字');

// 5. app.js 内联样式无白色文字
const whiteInline = (js.match(/color:\s*rgba\(255,\s*255,\s*255/g) || []).length;
assert.strictEqual(whiteInline, 0, `app.js 内联不应有白色文字（剩余 ${whiteInline} 处）`);
ok('app.js 内联无白色文字');

// 6. 字号放大：基础 16px
assert.ok(css.includes('font-size: 16px;'), '基础字号应为 16px');
ok('基础字号 16px');

// 7. 关键元素字号放大
const sizeChecks = [
  ['标题栏', '.app-title', '20px'],
  ['页面标题', '.stripe-title', '22px'],
  ['导航', '.nav-label', '16px'],
  ['按钮', '.btn', '15px'],
  ['标签', '.label', '14px'],
  ['统计数字', '.stat-value', '36px'],
  ['聊天消息', '.chat-msg', '15.5px'],
  ['输入框', '.input', '15px'],
  ['弹窗标题', '.modal-title', '22px'],
  ['正文列表行', '.table-row', null]
];
for (const [name, sel, size] of sizeChecks) {
  if (size) {
    const re = new RegExp(sel.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '[\\s\\S]{0,200}?font-size:\\s*' + size.replace('.', '\\.'));
    assert.ok(re.test(css), `${name}(${sel}) 字号应为 ${size}`);
    ok(`${name} 字号 ${size}`);
  }
}

// 8. 无遗留深色背景内联盒子
const darkBg = (js.match(/background: rgba\(0,\s*0,\s*0/g) || []).length;
assert.strictEqual(darkBg, 0, `app.js 不应有深色背景内联（剩余 ${darkBg}）`);
ok('无深色背景内联盒子');

console.log(`\n主题审计通过 ${passed} 项`);
process.exit(0);
