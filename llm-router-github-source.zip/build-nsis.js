// 构建 NSIS 安装包
const { build, Platform, Arch } = require('electron-builder');

const archToType = new Map();
archToType.set(Arch.x64, ['nsis']);

const targets = new Map();
targets.set(Platform.WINDOWS, archToType);

build({ targets })
  .then(() => { console.log('BUILD_OK'); process.exit(0); })
  .catch((err) => { console.error('BUILD_FAIL:', err.stack || err); process.exit(1); });
