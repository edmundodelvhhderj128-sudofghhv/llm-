/**
 * 模型后端切换测试（v2.5.1）——记忆/智能板块模型任务可切本地模型
 * 运行: node test-backend.js
 */
const assert = require('assert');
const os = require('os');
const fs = require('fs');
const path = require('path');

const Module = require('module');
const origLoad = Module._load;
const userDataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'llm-backend-'));
Module._load = function (request, parent, isMain) {
  if (request === 'electron') return { app: { getPath: () => userDataDir }, ipcMain: { handle: () => {} } };
  return origLoad.apply(this, arguments);
};

const { Router } = require('./src/router');

let passed = 0, failed = 0;
function ok(name) { passed++; console.log(`  ok ${name}`); }
function fail(name, detail) { failed++; console.log(`  FAIL ${name}: ${detail || ''}`); }

function mockConfig() {
  const state = {
    providers: [], routing: { failover: true, maxRetries: 2, timeout: 5000, strategy: 'priority' },
    guard: {}, quality: { enabled: true, judgeProviderId: 'p1', judgeModel: 'judge-m', sampleRate: 1, heuristic: true, judgeBackend: 'auto' },
    compression: { enabled: true, heuristic: true, smart: true, smartBackend: 'auto', keepRecent: 4, maxOldChars: 200, minLen: 10, triggerTokens: 10 },
    semanticCache: { enabled: true, threshold: 0.95, maxEntries: 100, embedBackend: 'auto' },
    slo: {}, residency: {}, shadow: {}, cache: { enabled: false }, logging: { enabled: true },
    local: { backend: 'llama', llamaPort: 11435, tools: true }, prices: { models: {} }, memory: {}
  };
  return {
    config: state,
    get(key) { return key.split('.').reduce((o, k) => o?.[k], this.config); },
    set(key, v) { const ks = key.split('.'); const last = ks.pop(); const t = ks.reduce((o, k) => { if (!o[k]) o[k] = {}; return o[k]; }, this.config); t[last] = v; },
    getAll() { return this.config; },
    persist() {},
    addProvider(p) {
      const prov = { id: p.id || 'p' + this.config.providers.length, name: p.name, baseUrl: p.baseUrl || '', keys: p.keys || ['k1'], models: p.models || [], enabled: true, priority: 1, keyIndex: 0, keyStats: {}, region: 'any', pathStyle: 'v1', kind: p.kind || 'remote', billing: { mode: 'tokens', pricePerCall: 0 }, weights: { latencyMs: null, successRate: 1, requests: 0 }, circuit: { failures: 0, open: false, openedAt: null }, quotaUsed: {} };
      prov.keys.forEach((_, i) => { prov.keyStats[i] = { disabled: false }; });
      this.config.providers.push(prov); return prov;
    },
    updateProvider(id, d) { const i = this.config.providers.findIndex(p => p.id === id); this.config.providers[i] = { ...this.config.providers[i], ...d }; return this.config.providers[i]; },
    getProviders() { return this.config.providers; },
    getEnabledProviders() { return this.config.providers.filter(p => p.enabled); }
  };
}

function fakeEngine(over = {}) {
  return {
    running: true,
    chat: async () => ({ data: { choices: [{ message: { content: '92' } }] }, latency: 100, usage: null }),
    embeddings: async () => [0.1, 0.2, 0.3],
    ...over
  };
}

(async () => {
  // ============ backendFor 决策逻辑 ============
  {
    try {
      const config = mockConfig();
      const router = new Router(config, os.tmpdir());
      router.localEngine = { running: true };
      assert.strictEqual(router.backendFor('quality.judgeBackend'), 'local', 'auto+引擎跑→local');
      router.localEngine = { running: false };
      assert.strictEqual(router.backendFor('quality.judgeBackend'), 'cloud', 'auto+引擎停→cloud');
      config.set('quality', { judgeBackend: 'cloud' });
      router.localEngine = { running: true };
      assert.strictEqual(router.backendFor('quality.judgeBackend'), 'cloud', 'cloud 强制云端');
      config.set('quality', { judgeBackend: 'local' });
      router.localEngine = { running: false };
      assert.strictEqual(router.backendFor('quality.judgeBackend'), 'cloud', 'local 指定但引擎停→回落 cloud');
      ok('backendFor：auto/cloud/local 决策逻辑');
    } catch (e) { fail('backendFor', e.message); }
  }

  // ============ judge 走本地模型 ============
  {
    try {
      const config = mockConfig();
      config.addProvider({ id: 'p1', name: '商汤', keys: ['k'], models: ['glm-5.2'] });
      const router = new Router(config, os.tmpdir());
      let localCalls = 0;
      router.localEngine = fakeEngine({ chat: async () => { localCalls++; return { data: { choices: [{ message: { content: '92' } }] }, latency: 10, usage: null }; } });
      const score = await router.scoreQuality(config.getProviders()[0], 'glm-5.2', '这是一段不错的回答内容');
      assert.strictEqual(localCalls, 1, '应调用本地引擎');
      assert.ok(score > 80 && score <= 100, '应得到 92 与启发式的均值: ' + score);
      // 云端模式：不调本地
      config.set('quality', { judgeBackend: 'cloud' });
      router.localEngine = { running: true };
      const origFetch = global.fetch;
      global.fetch = async () => ({ ok: true, status: 200, json: async () => ({ choices: [{ message: { content: '80' } }] }), text: async () => '' });
      try {
        await router.scoreQuality(config.getProviders()[0], 'glm-5.2', 'x'.repeat(200));
        assert.strictEqual(localCalls, 1, 'cloud 模式不应再调本地');
      } finally { global.fetch = origFetch; }
      ok('质量评分后端：auto 用本地 / cloud 用云端');
    } catch (e) { fail('judge 本地', e.message); }
  }

  // ============ 智能摘要走本地模型 ============
  {
    try {
      const config = mockConfig();
      config.addProvider({ id: 'p1', name: '商汤', keys: ['k'], models: ['glm-5.2'] });
      const router = new Router(config, os.tmpdir());
      let localCalls = 0;
      router.localEngine = fakeEngine({ chat: async () => { localCalls++; return { data: { choices: [{ message: { content: '摘要内容' } }] }, latency: 10, usage: null }; } });
      const s = await router.smartCompress([{ role: 'user', content: 'A'.repeat(500) }, { role: 'assistant', content: 'B'.repeat(500) }]);
      assert.strictEqual(localCalls, 1, '应调用本地引擎做摘要');
      assert.strictEqual(s, '摘要内容');
      ok('LLM 摘要后端：auto 用本地');
    } catch (e) { fail('摘要本地', e.message); }
  }

  // ============ 语义缓存嵌入走本地模型 ============
  {
    try {
      const config = mockConfig();
      config.addProvider({ id: 'p1', name: '商汤', keys: ['k'], models: ['text-embedding-x'] });
      const router = new Router(config, os.tmpdir());
      let localEmb = 0;
      router.localEngine = fakeEngine({ embeddings: async () => { localEmb++; return [0.5, 0.6]; } });
      const emb = await router.embedText('你好世界');
      assert.strictEqual(localEmb, 1, '应调用本地嵌入');
      assert.deepStrictEqual(emb, [0.5, 0.6]);
      // 引擎停 → 回落云端
      config.set('semanticCache', { embedBackend: 'auto' });
      router.localEngine = { running: false };
      const origFetch = global.fetch;
      global.fetch = async (url) => ({ ok: true, status: 200, json: async () => ({ data: [{ embedding: [1, 2, 3] }] }), text: async () => '' });
      try {
        const emb2 = await router.embedText('你好');
        assert.deepStrictEqual(emb2, [1, 2, 3], '引擎停应回落云端嵌入');
      } finally { global.fetch = origFetch; }
      ok('语义缓存嵌入后端：auto 本地优先/回落云端');
    } catch (e) { fail('嵌入本地', e.message); }
  }

  // ============ 配置默认值 ============
  {
    try {
      const { ConfigManager } = require('./src/config');
      const cfg = new ConfigManager();
      const q = cfg.get('quality'), c = cfg.get('compression'), s = cfg.get('semanticCache');
      assert.strictEqual(q.judgeBackend, 'auto');
      assert.strictEqual(c.smartBackend, 'auto');
      assert.strictEqual(s.embedBackend, 'auto');
      ok('配置默认：三处后端默认 auto');
    } catch (e) { fail('配置默认', e.message); }
  }

  console.log(`\n通过 ${passed} 项, 失败 ${failed} 项`);
  process.exit(failed > 0 ? 1 : 0);
})().catch(e => { console.error('测试崩溃:', e); process.exit(1); });
