/**
 * 本地模型引擎（v2.4.0）——内置 Qwen2.5-7B-Instruct
 *
 * 双后端：
 *   1. llama.cpp server（默认，真正"内置"）：应用自动下载 llama-server.exe + GGUF 模型，
 *      子进程运行在 127.0.0.1:<port>，OpenAI 兼容 API，支持 tools（function calling）
 *   2. Ollama（可选）：若用户已装 Ollama，可切换后端直接使用（零下载）
 *
 * 路由无缝接入：callProvider 对 kind='local' 的渠道走 engine.chat()，
 * 返回结构与云端一致（非流式 {data,latency,usage} / 流式 {data:{stream,headers}}）。
 */
const fs = require('fs');
const path = require('path');
const { spawn, spawnSync } = require('child_process');
const { Downloader, fileUrl } = require('./downloader');
const extractZip = require('extract-zip');

const DEFAULT_LLAMA_TAG = 'b5450';
const DEFAULT_MODEL = { org: 'Qwen', repo: 'Qwen2.5-7B-Instruct-GGUF', file: 'qwen2.5-7b-instruct-q4_k_m.gguf', approxBytes: 4.68 * 1024 ** 3 };

class LocalEngine {
  /**
   * @param {object} config ConfigManager
   * @param {string} userDataDir
   */
  constructor(config, userDataDir) {
    this.config = config;
    this.base = path.join(userDataDir, 'local');
    this.engineDir = path.join(this.base, 'llama');
    this.modelsDir = path.join(this.base, 'models');
    this.downloader = new Downloader({ userDataDir });
    this.process = null;
    this.running = false;
    this.waking = false;       // 唤醒中标志（v2.6.2：防止并发请求重复触发启动）
    this.state = 'idle';           // idle|downloading-engine|downloading-model|ready|running|error
    this.progress = null;          // { kind, percent, received, total, speedBps }
    this.lastError = null;
    this.onEvent = null;           // (ev) => {}  事件：状态/进度变化，供 main 推送到渲染进程
  }

  cfg() {
    return {
      backend: 'llama',                    // llama | ollama | cloud（cloud=用云端渠道模型代替本地引擎）
      llamaPort: 11435,
      llamaTag: DEFAULT_LLAMA_TAG,
      source: 'hf-mirror',                 // 模型下载源：hf-mirror（国内镜像，推荐）| modelscope | hf
      modelOrg: DEFAULT_MODEL.org,
      modelRepo: DEFAULT_MODEL.repo,
      modelFile: 'qwen2.5-7b-instruct-q4_k_m-00001-of-00002.gguf',  // 主文件（llama.cpp -m，自动拼分片）
      modelFiles: [                         // 全部模型文件（分片；单文件时仅主文件）
        'qwen2.5-7b-instruct-q4_k_m-00001-of-00002.gguf',
        'qwen2.5-7b-instruct-q4_k_m-00002-of-00002.gguf'
      ],
      ctxSize: 8192,
      threads: 4,
      ollamaBase: 'http://127.0.0.1:11434',
      ollamaModel: 'qwen2.5:7b',
      maxToolRounds: 5,
      cloudChannel: null,                  // 云端渠道模型：'providerId||model'（backend='cloud' 时使用）
      ...(this.config.get('local') || {})
    };
  }

  /**
   * 解析「云端渠道模型」配置（backend='cloud' 时使用）
   * @returns {{ provider: object|null, model: string, ready: boolean }}
   */
  cloudTarget() {
    const raw = String(this.cfg().cloudChannel || '');
    const sep = raw.indexOf('||');
    if (sep <= 0) return { provider: null, model: '', ready: false };
    const providerId = raw.slice(0, sep);
    const model = raw.slice(sep + 2);
    const provider = this.config.getProviders().find(p => p.id === providerId) || null;
    return { provider, model, ready: !!(provider && model) };
  }

  engineExe() {
    return path.join(this.engineDir, 'llama-server.exe');
  }

  modelPath() {
    return path.join(this.modelsDir, this.cfg().modelFile);
  }

  /** 全部模型文件（含分片）；显式配置了分片列表就用它，否则单文件 */
  modelFiles() {
    const cfg = this.cfg();
    if (cfg.modelFiles && cfg.modelFiles.length) return [...new Set(cfg.modelFiles)];
    return [cfg.modelFile];
  }

  allModelsPresent() {
    for (const f of this.modelFiles()) {
      if (!fs.existsSync(path.join(this.modelsDir, f))) return false;
    }
    return true;
  }

  totalModelSize() {
    let s = 0;
    for (const f of this.modelFiles()) {
      const p = path.join(this.modelsDir, f);
      if (fs.existsSync(p)) s += fs.statSync(p).size;
    }
    return s;
  }

  emit(ev) {
    try { this.onEvent && this.onEvent(ev); } catch (e) {}
  }

  // ---------- 状态 ----------
  status() {
    const cfg = this.cfg();
    const engineExists = fs.existsSync(this.engineExe());
    const modelExists = this.allModelsPresent();
    const modelSize = this.totalModelSize();
    const base = {
      backend: cfg.backend,
      state: this.state,
      running: this.running,
      waking: this.waking,
      port: cfg.llamaPort,
      engineExists,
      engineVersion: cfg.llamaTag,
      modelExists,
      modelFiles: this.modelFiles().map(f => ({ name: f, exists: fs.existsSync(path.join(this.modelsDir, f)) })),
      modelPath: this.modelPath(),
      modelSize,
      modelApprox: DEFAULT_MODEL.approxBytes,
      modelName: cfg.modelFile,
      ollamaBase: cfg.ollamaBase,
      ollamaModel: cfg.ollamaModel,
      progress: this.progress,
      lastError: this.lastError,
      ctxSize: cfg.ctxSize,
      threads: cfg.threads,
      tools: (this.config.get('local') || {}).tools !== false,
      cloudChannel: cfg.cloudChannel || null,
      cloudProviderName: null,
      cloudModel: null,
      cloudReady: false
    };
    if (cfg.backend === 'cloud') {
      const t = this.cloudTarget();
      return {
        ...base,
        backend: 'cloud',
        running: !!this.running,
        waking: false,
        state: this.running ? 'running' : (t.ready ? 'ready' : 'idle'),
        modelName: t.model || null,
        cloudProviderName: t.provider ? t.provider.name : null,
        cloudModel: t.model || null,
        cloudReady: t.ready
      };
    }
    return base;
  }

  // ---------- 下载引擎（llama.cpp 二进制） ----------
  async downloadEngine() {
    const cfg = this.cfg();
    if (cfg.backend === 'cloud') return { ok: true, note: '当前后端为云端渠道模型，无需下载引擎' };
    if (cfg.backend !== 'llama') return { ok: true, note: '当前后端为 Ollama，无需下载引擎' };
    this.state = 'downloading-engine';
    this.lastError = null;
    this.emit({ type: 'state', state: this.state });
    try {
      fs.mkdirSync(this.engineDir, { recursive: true });
      const zipPath = path.join(this.engineDir, 'llama.zip');
      const assets = [`llama-${cfg.llamaTag}-bin-win-avx2-x64.zip`, `llama-${cfg.llamaTag}-bin-win-cpu-x64.zip`];
      let done = false;
      for (const asset of assets) {
        const url = `https://github.com/ggml-org/llama.cpp/releases/download/${cfg.llamaTag}/${asset}`;
        try {
          await this.downloader.download(url, zipPath, {
            onProgress: (p) => { this.progress = { kind: 'engine', ...p }; this.emit({ type: 'progress', progress: this.progress }); }
          });
          done = true;
          break;
        } catch (e) {
          console.log(`[本地引擎] ${asset} 下载失败: ${e.message}`);
        }
      }
      if (!done) throw new Error('llama.cpp 二进制下载失败（avx2/cpu 均不可用），可在设置中更换 llamaTag 或改用 Ollama 后端');

      // 解压并定位 llama-server.exe
      const extractDir = path.join(this.engineDir, 'extract');
      fs.rmSync(extractDir, { recursive: true, force: true });
      fs.mkdirSync(extractDir, { recursive: true });
      await extractZip(zipPath, { dir: extractDir });
      fs.rmSync(zipPath, { force: true });
      const exe = this.findFile(extractDir, 'llama-server.exe');
      if (!exe) throw new Error('解压后未找到 llama-server.exe');
      fs.copyFileSync(exe, this.engineExe());
      fs.rmSync(extractDir, { recursive: true, force: true });
      this.state = fs.existsSync(this.modelPath()) ? 'ready' : 'idle';
      this.emit({ type: 'state', state: this.state });
      return { ok: true, engine: this.engineExe() };
    } catch (e) {
      this.state = 'error';
      this.lastError = e.message;
      this.emit({ type: 'state', state: this.state });
      return { ok: false, error: e.message };
    }
  }

  findFile(dir, name) {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const en of entries) {
      const full = path.join(dir, en.name);
      if (en.isFile() && en.name.toLowerCase() === name.toLowerCase()) return full;
      if (en.isDirectory()) {
        const r = this.findFile(full, name);
        if (r) return r;
      }
    }
    return null;
  }

  // ---------- 下载模型（GGUF，支持分片） ----------
  async downloadModel() {
    const cfg = this.cfg();
    if (cfg.backend === 'cloud') return { ok: true, note: '当前后端为云端渠道模型，无需下载模型' };
    this.state = 'downloading-model';
    this.lastError = null;
    this.emit({ type: 'state', state: this.state });
    try {
      fs.mkdirSync(this.modelsDir, { recursive: true });
      const files = this.modelFiles();
      for (const file of files) {
        const url = fileUrl(cfg.source, cfg.modelOrg, cfg.modelRepo, file);
        const dest = path.join(this.modelsDir, file);
        if (fs.existsSync(dest) && fs.statSync(dest).size > 100 * 1024 * 1024) continue; // 已下载跳过
        await this.downloader.download(url, dest, {
          onProgress: (p) => { this.progress = { kind: 'model', file, ...p }; this.emit({ type: 'progress', progress: this.progress }); }
        });
      }
      this.state = fs.existsSync(this.engineExe()) ? 'ready' : 'idle';
      this.emit({ type: 'state', state: this.state });
      return { ok: true, size: this.totalModelSize(), files: this.modelFiles() };
    } catch (e) {
      this.state = 'error';
      this.lastError = e.message;
      this.emit({ type: 'state', state: this.state });
      return { ok: false, error: e.message };
    }
  }

  // ---------- 启动 / 停止 ----------
  async start() {
    const cfg = this.cfg();
    if (this.running) return { ok: true, running: true };
    if (this.waking) return { ok: true, waking: true };   // 已在唤醒中，避免重复启动
    this.waking = true;
    try {
      return await this._startInner(cfg);
    } finally {
      this.waking = false;
    }
  }

  async _startInner(cfg) {
    if (cfg.backend === 'cloud') {
      // 云端渠道模型：不下载、不启进程，校验所选渠道可用即可
      const t = this.cloudTarget();
      if (!t.ready) {
        this.lastError = '未选择云端渠道模型（请在「本地模型引擎」处选择渠道与模型）';
        this.state = 'error';
        this.emit({ type: 'state', state: this.state });
        return { ok: false, error: this.lastError };
      }
      this.running = true;
      this.state = 'running';
      this.lastError = null;
      this.emit({ type: 'state', state: this.state });
      return { ok: true, running: true, backend: 'cloud', provider: t.provider.name, model: t.model };
    }
    if (cfg.backend === 'ollama') {
      // Ollama 外部进程：只做连通性检查
      const ok = await this.pingOllama();
      this.running = ok;
      this.state = ok ? 'running' : 'error';
      if (!ok) this.lastError = 'Ollama 未运行或不可达: ' + cfg.ollamaBase;
      this.emit({ type: 'state', state: this.state });
      return { ok, running: ok, backend: 'ollama' };
    }
    if (this.running) return { ok: true, running: true };
    if (!fs.existsSync(this.engineExe())) return { ok: false, error: '引擎未下载，请先下载 llama.cpp 引擎' };
    if (!fs.existsSync(this.modelPath())) return { ok: false, error: '模型未下载，请先下载 Qwen2.5-7B-Instruct GGUF' };

    const args = [
      '-m', this.modelPath(),
      '--host', '127.0.0.1',
      '--port', String(cfg.llamaPort),
      '-c', String(cfg.ctxSize || 8192),
      '-t', String(cfg.threads || 4),
      '--jinja',                          // chat template + tools 支持
      // 注意：不能用 --embeddings（那是"仅嵌入模式"，会禁用聊天端点返回 501）；
      // 只设 --pooling 即可让 /v1/embeddings 可用，同时聊天正常
      '--pooling', 'mean',                // 嵌入池化（OAI 兼容端点必需；不影响对话）
      '--n-predict', '-1',
      '--no-webui'
    ];
    this.state = 'running';
    this.emit({ type: 'state', state: this.state });
    try {
      this.process = spawn(this.engineExe(), args, { stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
      this.process.stdout.on('data', (d) => { if (this.onEvent) this.onEvent({ type: 'engine-log', line: String(d).slice(0, 300) }); });
      this.process.stderr.on('data', (d) => { if (this.onEvent) this.onEvent({ type: 'engine-log', line: String(d).slice(0, 300) }); });
      this.process.on('exit', (code) => {
        this.running = false;
        this.state = 'ready';
        this.process = null;
        this.emit({ type: 'state', state: this.state, exitCode: code });
      });
      this.process.on('error', (err) => {
        this.running = false;
        this.state = 'error';
        this.lastError = err.message;
        this.emit({ type: 'state', state: this.state });
      });

      // 等待 /health 就绪（最多 60s）
      const ok = await this.waitReady(60000);
      this.running = ok;
      if (!ok) {
        this.lastError = '引擎启动超时（60s 内未就绪），请查看引擎日志';
        this.state = 'error';
        this.emit({ type: 'state', state: this.state });
      } else {
        this.state = 'running';
        this.emit({ type: 'state', state: this.state });
      }
      return { ok, running: ok, port: cfg.llamaPort };
    } catch (e) {
      this.running = false;
      this.state = 'error';
      this.lastError = e.message;
      this.emit({ type: 'state', state: this.state });
      return { ok: false, error: e.message };
    }
  }

  async waitReady(timeoutMs) {
    const cfg = this.cfg();
    const url = `http://127.0.0.1:${cfg.llamaPort}/health`;
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      try {
        const r = await fetch(url, { signal: AbortSignal.timeout(2000) });
        if (r.ok) return true;
      } catch (e) { /* 未就绪，继续等 */ }
      await new Promise(r => setTimeout(r, 1000));
    }
    return false;
  }

  async pingOllama() {
    const cfg = this.cfg();
    try {
      const r = await fetch(cfg.ollamaBase + '/api/tags', { signal: AbortSignal.timeout(3000) });
      return r.ok;
    } catch (e) { return false; }
  }

  async stop() {
    if (this.cfg().backend === 'cloud') {
      // 云端渠道模型：无本地进程，只需置为未运行
      this.running = false;
      this.state = 'ready';
      this.emit({ type: 'state', state: this.state });
      return { ok: true };
    }
    if (this.process) {
      try {
        spawnSync('taskkill', ['/pid', String(this.process.pid), '/T', '/F'], { windowsHide: true });
      } catch (e) { /* 已退出 */ }
      try { this.process.kill(); } catch (e) {}
      this.process = null;
    }
    this.running = false;
    this.state = 'ready';
    this.emit({ type: 'state', state: this.state });
    return { ok: true };
  }

  // ---------- 推理调用（OpenAI 兼容，与 callProvider 返回结构一致） ----------
  resolveBase() {
    const cfg = this.cfg();
    if (cfg.backend === 'cloud') return '';            // 云端渠道模型不走本地 HTTP 端点
    return cfg.backend === 'ollama' ? cfg.ollamaBase : `http://127.0.0.1:${cfg.llamaPort}`;
  }

  resolveModelName() {
    const cfg = this.cfg();
    if (cfg.backend === 'cloud') return this.cloudTarget().model || '';
    return cfg.backend === 'ollama' ? cfg.ollamaModel : cfg.modelFile;
  }

  /**
   * @param {object} opts { model, messages, stream, tools, temperature, max_tokens, timeout }
   * @returns {Promise<{data, latency, usage}>} 与 callProvider 一致
   */
  async chat(opts = {}) {
    const { messages = [], stream = false, tools = null, temperature, max_tokens, timeout = 300000 } = opts;
    // 云端渠道模型后端：不需要本地进程在跑，直接委托给所选云端渠道模型
    if (this.cfg().backend === 'cloud') return this.cloudChat(opts);
    // H6 修复：chat 入口也触发 autoWake，避免流式请求在空闲后第一个失败（503）
    if (!this.running && this.routerAutoWakeHook) {
      try { this.routerAutoWakeHook(); } catch (e) { /* 唤醒失败不影响请求 */ }
    }
    if (!this.running) {
      const err = new Error('本地模型引擎未运行（请在「本地模型」页启动）');
      err.status = 503;
      throw err;
    }
    const cfg = this.cfg();
    const url = `${this.resolveBase()}/v1/chat/completions`;
    const body = {
      model: this.resolveModelName(),
      messages,
      stream: !!stream,
      temperature: temperature ?? 0.7,
      max_tokens: max_tokens ?? 2048
    };
    if (tools && tools.length && (this.config.get('local') || {}).tools !== false) body.tools = tools;

    const startTime = Date.now();
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeout);
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        signal: controller.signal
      });
      const latency = Date.now() - startTime;
      if (!response.ok) {
        const text = await response.text();
        const err = new Error(`本地引擎返回错误: ${response.status} ${text.slice(0, 300)}`);
        err.status = response.status;
        throw err;
      }
      if (stream) {
        return { data: { stream: response.body, headers: response.headers }, latency, usage: null };
      }
      const data = await response.json();
      return { data, latency, usage: data.usage || null };
    } finally {
      clearTimeout(timeoutId);
    }
  }

  /**
   * 云端渠道模型推理（backend='cloud'）：委托给 main 注入的 cloudCaller，
   * 由它用 router.callProvider 调用所选渠道的模型。返回结构与 chat() 完全一致。
   * @param {object} opts { messages, stream, tools, temperature, max_tokens, timeout }
   * @returns {Promise<{data, latency, usage}>}
   */
  async cloudChat(opts = {}) {
    const { messages = [], stream = false, tools = null, temperature, max_tokens, timeout = 300000 } = opts;
    if (typeof this.cloudCaller !== 'function') {
      const err = new Error('云端渠道模型后端未接入（调用器未初始化）');
      err.status = 503;
      throw err;
    }
    const t = this.cloudTarget();
    if (!t.ready) {
      const err = new Error('未选择云端渠道模型（请在「本地模型引擎」处选择渠道与模型）');
      err.status = 400;
      throw err;
    }
    return await this.cloudCaller({
      provider: t.provider,
      model: t.model,
      messages,
      stream: !!stream,
      tools: tools && tools.length ? tools : null,
      temperature,
      max_tokens,
      timeout
    });
  }

  /**
   * 本地嵌入（v2.5.1）：语义缓存可用本地模型做向量（数据不出本机）
   * @returns {Promise<Array|null>} 向量或 null
   */
  async embeddings(input, timeout = 30000) {
    // 云端渠道模型后端：返回 null，让 router 回落到它自己的云端嵌入路径（语义缓存配置）
    if (this.cfg().backend === 'cloud') return null;
    if (!this.running) return null;
    try {
      const url = `${this.resolveBase()}/v1/embeddings`;
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: this.resolveModelName(), input: String(input).slice(0, 2000) }),
        signal: AbortSignal.timeout(timeout)
      });
      if (!res.ok) return null;
      const data = await res.json();
      const emb = data?.data?.[0]?.embedding;
      // 有效性校验：非空、非全零、无 NaN（instruct 模型嵌入可能退化 → 回落云端）
      if (!Array.isArray(emb) || emb.length === 0) return null;
      let nonzero = 0, allFinite = true;
      for (const v of emb) {
        if (!Number.isFinite(v)) { allFinite = false; break; }
        if (Math.abs(v) > 1e-9) nonzero++;
      }
      if (!allFinite || nonzero === 0) return null;
      return emb;
    } catch (e) {
      return null;
    }
  }

  /**
   * 本地模型工具循环：模型发起 tool_calls → 执行 → 回填 → 继续，直到无工具调用或达上限
   */
  async chatWithTools({ model, messages, tools, temperature, max_tokens, timeout }) {
    const cfg = this.cfg();
    const maxRounds = cfg.maxToolRounds || 5;
    let msgs = messages;
    let rounds = 0;
    const toolRuns = [];
    for (;;) {
      const result = await this.chat({ model, messages: msgs, stream: false, tools, temperature, max_tokens, timeout });
      const msg = result.data?.choices?.[0]?.message;
      if (!msg) return { result, toolRuns };
      const calls = msg.tool_calls || [];
      if (calls.length === 0) return { result, toolRuns };
      if (rounds >= maxRounds) {
        // 达上限：把提示拼进消息让模型给出最终答复
        msgs = [...msgs, msg, { role: 'user', content: '工具调用已达上限，请直接基于已有信息回答。' }];
        const final = await this.chat({ model, messages: msgs, stream: false, tools: null, temperature, max_tokens, timeout });
        return { result: final, toolRuns };
      }
      rounds++;
      msgs = [...msgs, msg];
      for (const c of calls) {
        const name = c.function?.name;
        const argsText = c.function?.arguments || '{}';
        let out;
        try { out = await this.toolExecutor(name, argsText); } catch (e) { out = { ok: false, error: e.message }; }
        toolRuns.push({ name, args: argsText.slice(0, 200), ok: !!out.ok, error: out.error || null });
        msgs.push({ role: 'tool', tool_call_id: c.id, content: JSON.stringify(out).slice(0, 3000) });
      }
    }
  }
}

module.exports = { LocalEngine, DEFAULT_MODEL, DEFAULT_LLAMA_TAG };
