/**
 * Trace 调用日志（可观测性）——磁盘持久化 JSONL，支持问题回放/导出/过滤
 * 每次请求记录：路由决策、候选排序、实际服务商/模型、切换、缓存、成本、质量分、漂移、错误等
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

class TraceLogger {
  constructor(config, userDataDir) {
    this.config = config;
    this.logDir = path.join(userDataDir, 'logs');
    this.entries = [];        // 内存缓存最近条目（加速 UI 过滤）
    this.maxInMemory = 2000;
    this.maxEntries = 10000;  // 单文件上限（超出滚动新文件）
    this.days = 7;            // 保留天数
    try { fs.mkdirSync(this.logDir, { recursive: true }); } catch (e) {}
    this.loadToday();
  }

  todayFile() {
    const d = new Date();
    const pad = n => String(n).padStart(2, '0');
    return path.join(this.logDir, `requests-${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}.jsonl`);
  }

  loadToday() {
    try {
      const file = this.todayFile();
      if (fs.existsSync(file)) {
        const lines = fs.readFileSync(file, 'utf-8').split('\n').filter(l => l.trim());
        this.entries = lines.slice(-this.maxInMemory).map(l => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
      }
    } catch (e) { console.error('加载日志失败:', e.message); }
  }

  /**
   * 记录一条请求日志
   * M5 修复：写盘失败不再静默 console.error，改为降级到 stderr 标记
   *  并自增 writeFailures 计数，让上游 / 状态端点能看到日志系统的健康度
   */
  write(entry) {
    const cfg = this.config.get('logging') || {};
    if (cfg.enabled === false) return;
    const rec = {
      traceId: entry.traceId || this.newTraceId(),
      time: new Date().toISOString(),
      ...entry
    };
    this.entries.push(rec);
    if (this.entries.length > this.maxInMemory) this.entries.shift();
    this.writeFailures = this.writeFailures || 0;
    try {
      const file = this.todayFile();
      fs.appendFileSync(file, JSON.stringify(rec) + '\n');
      // 滚动：超过条数或天数则归档清理
      this.rotate();
    } catch (e) {
      // M5 修复：失败计数 + 降级标记（最近一次失败原因）
      this.writeFailures++;
      this.lastWriteError = `${new Date().toISOString()} ${e.message}`;
      // stderr 报警（用户能立即看到）
      process.stderr.write(`[trace] 写日志失败（${this.writeFailures} 次累计）: ${e.message}\n`);
    }
  }

  /**
   * M5 修复：状态查询（供 IPC 端点暴露给 UI 显示）
   */
  status() {
    return {
      inMemoryEntries: this.entries.length,
      maxInMemory: this.maxInMemory,
      writeFailures: this.writeFailures || 0,
      lastWriteError: this.lastWriteError || null,
      logDir: this.logDir,
      todayFile: this.todayFile()
    };
  }

  newTraceId() {
    return crypto.randomBytes(8).toString('hex');
  }

  rotate() {
    try {
      const files = fs.readdirSync(this.logDir).filter(f => f.endsWith('.jsonl')).sort();
      // 只保留最近 days 天（按文件名日期）
      const cutoff = new Date();
      cutoff.setDate(cutoff.getDate() - (this.config.get('logging.days') || 7));
      for (const f of files) {
        const m = f.match(/requests-(\d{4})-(\d{2})-(\d{2})\.jsonl/);
        if (!m) continue;
        const d = new Date(+m[1], +m[2] - 1, +m[3]);
        if (d < cutoff) {
          try { fs.unlinkSync(path.join(this.logDir, f)); } catch (e) {}
        }
      }
    } catch (e) {}
  }

  /**
   * 查询最近日志（支持过滤）
   */
  recent(limit = 200, filter = {}) {
    let list = this.entries;
    if (filter.model) list = list.filter(e => (e.model || '').includes(filter.model));
    if (filter.provider) list = list.filter(e => (e.provider || '').includes(filter.provider));
    if (filter.status) list = list.filter(e => e.status === filter.status);
    if (filter.cached !== undefined && filter.cached !== '') list = list.filter(e => !!e.cached === (filter.cached === '1' || filter.cached === true));
    if (filter.switched !== undefined && filter.switched !== '') list = list.filter(e => !!e.switched === (filter.switched === '1' || filter.switched === true));
    if (filter.qualityLow) list = list.filter(e => e.qualityScore != null && e.qualityScore < 60);
    return list.slice(-limit).reverse();
  }

  /**
   * 导出全部（合并所有日志文件）
   */
  exportAll() {
    try {
      const files = fs.readdirSync(this.logDir).filter(f => f.endsWith('.jsonl')).sort();
      const out = [];
      for (const f of files) {
        const lines = fs.readFileSync(path.join(this.logDir, f), 'utf-8').split('\n').filter(l => l.trim());
        for (const l of lines) { try { out.push(JSON.parse(l)); } catch {} }
      }
      return out;
    } catch (e) { return this.entries; }
  }

  clear() {
    this.entries = [];
    try {
      const files = fs.readdirSync(this.logDir).filter(f => f.endsWith('.jsonl'));
      for (const f of files) fs.unlinkSync(path.join(this.logDir, f));
    } catch (e) {}
  }
}

module.exports = { TraceLogger };
