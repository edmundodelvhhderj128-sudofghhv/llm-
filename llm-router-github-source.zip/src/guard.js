/**
 * 内容护栏（安全与合规）——PII 掩码 + 敏感词拦截，纯本地正则实现，不依赖外部 API
 */
class ContentGuard {
  constructor(config) {
    this.config = config;
    this.piiPatterns = [
      { name: '邮箱', regex: /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g },
      { name: '手机号', regex: /(?<!\d)1[3-9]\d{9}(?!\d)/g },
      { name: '身份证号', regex: /(?<!\d)[1-9]\d{5}(?:18|19|20)\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])\d{3}[\dXx](?!\d)/g },
      { name: 'IPv4', regex: /(?<!\d)(?:\d{1,3}\.){3}\d{1,3}(?!\d)/g },
      { name: 'API密钥', regex: /\b(?:sk|pk|ak|rk)-[A-Za-z0-9_-]{12,}\b/g },
      { name: 'Bearer令牌', regex: /\bBearer\s+[A-Za-z0-9._~+/=-]{16,}\b/g },
      { name: 'URL', regex: /https?:\/\/[^\s"'<>]+/g }
    ];
  }

  cfg() {
    return this.config.get('guard') || {};
  }

  /**
   * 敏感词拦截检查（用于输入）
   * @returns {boolean} 是否命中敏感词
   */
  hasSensitive(text) {
    const cfg = this.cfg();
    if (!cfg.blockSensitive) return false;
    const words = (cfg.sensitiveWords || []).filter(w => w && w.trim());
    if (words.length === 0) return false;
    const lower = String(text || '').toLowerCase();
    return words.some(w => lower.includes(String(w).toLowerCase().trim()));
  }

  /**
   * PII 掩码（用于输出）
   * @returns {{text: string, masked: boolean, patterns: string[]}}
   */
  mask(text) {
    const cfg = this.cfg();
    if (!cfg.maskPII) return { text, masked: false, patterns: [] };
    let out = String(text || '');
    const found = [];
    for (const p of this.piiPatterns) {
      if (p.regex.test(out)) {
        found.push(p.name);
        out = out.replace(p.regex, m => {
          if (p.name === 'URL') return '<URL>';
          if (m.length <= 4) return '*'.repeat(m.length);
          return m.slice(0, 2) + '*'.repeat(Math.min(m.length - 4, 8)) + m.slice(-2);
        });
        p.regex.lastIndex = 0;
      }
    }
    return { text: out, masked: found.length > 0, patterns: found };
  }

  /**
   * 检查输入消息列表是否命中敏感词
   */
  checkMessages(messages) {
    if (!this.cfg().blockSensitive) return { blocked: false, reasons: [] };
    const reasons = [];
    for (const m of messages || []) {
      if (typeof m?.content === 'string' && this.hasSensitive(m.content)) {
        reasons.push('命中敏感词');
        break;
      }
    }
    return { blocked: reasons.length > 0, reasons };
  }
}

module.exports = { ContentGuard };
