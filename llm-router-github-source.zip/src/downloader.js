/**
 * 通用文件下载器（v2.4.0 本地模型）
 * - 分块流式下载 + Range 断点续传（.part 文件）
 * - 进度/速度回调
 * - ModelScope / HuggingFace / GitHub 多源 URL 构造
 * 仅依赖 Node 内置 fetch（Node 18+/Electron 主进程）
 */
const fs = require('fs');
const path = require('path');

function fileUrl(source, org, repo, file) {
  switch (source) {
    case 'modelscope':
      return `https://modelscope.cn/models/${org}/${repo}/resolve/master/${file}`;
    case 'hf-mirror':
      return `https://hf-mirror.com/${org}/${repo}/resolve/main/${file}`;
    case 'hf':
      return `https://huggingface.co/${org}/${repo}/resolve/main/${file}`;
    default:
      return file; // 视为完整 URL
  }
}

class Downloader {
  /**
   * @param {object} opts { userDataDir }
   */
  constructor(opts = {}) {
    this.userDataDir = opts.userDataDir || '.';
  }

  /**
   * HEAD 请求获取文件大小与 Accept-Ranges 支持
   */
  async head(url, timeout = 15000) {
    const res = await fetch(url, { method: 'HEAD', redirect: 'follow', signal: AbortSignal.timeout(timeout) });
    if (!res.ok && res.status !== 302 && res.status !== 307) {
      // 部分 CDN 不支持 HEAD，退化返回 null
      return null;
    }
    const length = parseInt(res.headers.get('content-length') || '0', 10);
    return { length: length || 0, acceptRanges: (res.headers.get('accept-ranges') || '').toLowerCase() === 'bytes' };
  }

  /**
   * 下载文件到 dest（断点续传）
   * @param {string} url
   * @param {string} dest 目标文件绝对路径
   * @param {object} opts { onProgress({received,total,percent,speedBps}), resume=true }
   * @returns {Promise<string>} 完成后的 dest
   */
  async download(url, dest, opts = {}) {
    const onProgress = opts.onProgress || (() => {});
    const resume = opts.resume !== false;
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    const part = dest + '.part';

    let start = 0;
    let total = 0;
    try {
      const h = await this.head(url);
      if (h) total = h.length;
    } catch (e) { /* HEAD 失败不致命 */ }

    if (resume && fs.existsSync(part)) {
      start = fs.statSync(part).size;
      if (total && start >= total) start = total;
    }

    const headers = {};
    if (start > 0) headers.Range = `bytes=${start}-`;
    // 大文件下载不设总超时（断点续传兜底），避免 AbortSignal.timeout(0) 立即中止
    const res = await fetch(url, { headers, redirect: 'follow' });
    if (!res.ok && res.status !== 206) {
      const err = new Error(`下载失败 HTTP ${res.status}: ${url}`);
      err.status = res.status;
      throw err;
    }
    if (total === 0) total = start + parseInt(res.headers.get('content-length') || '0', 10);
    if (!res.body) throw new Error('响应无流式体，无法下载');

    const fd = fs.openSync(part, 'a');
    const reader = res.body.getReader();
    let received = start;
    let lastReport = Date.now();
    let lastBytes = received;
    const idleTimeoutMs = opts.idleTimeoutMs || 60000;   // 空闲超时：长时间无数据视为网络挂起，中止以便续传重试
    try {
      for (;;) {
        let chunk;
        try {
          chunk = await Promise.race([
            reader.read(),
            new Promise((_, rej) => setTimeout(() => rej(new Error('下载空闲超时（60s 无数据），已中止，可重新下载续传')), idleTimeoutMs))
          ]);
        } catch (e) {
          if (e.message && e.message.includes('空闲超时')) throw e;
          throw e;
        }
        const { done, value } = chunk;
        if (done) break;
        if (value && value.length) {
          fs.writeSync(fd, value, 0, value.length);
          received += value.length;
          const now = Date.now();
          if (now - lastReport >= 300) {
            const speedBps = Math.round(((received - lastBytes) * 1000) / (now - lastReport));
            lastReport = now; lastBytes = received;
            onProgress({ received, total, percent: total ? Math.min(100, +(received / total * 100).toFixed(2)) : 0, speedBps });
          }
        }
      }
    } finally {
      fs.closeSync(fd);
    }
    onProgress({ received, total, percent: 100, speedBps: 0 });
    fs.renameSync(part, dest);
    return dest;
  }
}

module.exports = { Downloader, fileUrl };
