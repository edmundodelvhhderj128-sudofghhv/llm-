/**
 * 本地代理服务器 v2.0 - OpenAI 兼容 API
 * 提供本地 /v1/chat/completions, /v1/models, /v1/completions, /v1/embeddings 等接口
 * 自动通过智能路由转发请求，透传实际使用的模型/服务商信息（X-Router-* 头）
 */
const express = require('express');

class ProxyServer {
  constructor(config, router) {
    this.config = config;
    this.router = router;
    this.remote = null;    // 远程访问管理（v3.0.2，由 main 注入）
    this.app = express();
    this.server = null;
    this.port = null;
    this.setupMiddleware();
    this.setupRoutes();
  }

  /** 注入远程管理并挂载路由（v3.0.2） */
  attachRemote(remoteManager, ctx) {
    this.remote = remoteManager;
    if (remoteManager) remoteManager.attach(this.app, ctx);
  }

  setupMiddleware() {
    this.app.use(express.json({ limit: '50mb' }));
    this.app.use(express.urlencoded({ extended: true }));

    // CORS
    this.app.use((req, res, next) => {
      res.header('Access-Control-Allow-Origin', '*');
      res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
      res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
      if (req.method === 'OPTIONS') return res.sendStatus(200);
      next();
    });

    // 请求日志
    this.app.use((req, _res, next) => {
      console.log(`[Proxy] ${req.method} ${req.path}`);
      next();
    });

    // 远程访问认证（v3.0.2）：非本机请求必须认证；本机/登录/健康检查放行
    this.app.use((req, res, next) => {
      if (!this.remote) return next();
      if (this.remote.isLocal(req)) return next();
      if (req.path === '/remote/login' || req.path === '/health' || req.path === '/api/status') return next();
      this.remote.authMiddleware()(req, res, next);
    });
  }

  /**
   * 附加路由元信息响应头（实际模型 / 服务商 / 是否切换 / 延迟 / 缓存）
   * 注: HTTP 头只允许 ASCII，非 ASCII 值统一 encodeURIComponent，客户端需 decodeURIComponent
   */
  attachMetaHeaders(res, meta) {
    if (!meta) return;
    const enc = (v) => encodeURIComponent(String(v));
    if (meta.model) res.setHeader('X-Router-Model', enc(meta.model));
    if (meta.provider) res.setHeader('X-Router-Provider', enc(meta.provider));
    if (meta.providerId) res.setHeader('X-Router-Provider-Id', meta.providerId);
    if (meta.latency != null) res.setHeader('X-Router-Latency', String(meta.latency));
    if (meta.switched) res.setHeader('X-Router-Switched', '1');
    else if (meta.switched === false) res.setHeader('X-Router-Switched', '0');
    if (meta.cached) res.setHeader('X-Router-Cache', meta.cacheType === 'semantic' ? 'SEMANTIC-HIT' : 'HIT');
  }

  /**
   * 缓存命中时重放 chat 格式 SSE
   */
  replayChatSse(res, cachedData) {
    const content = cachedData?.choices?.[0]?.message?.content || '';
    const id = cachedData?.id || 'chatcmpl-cache';
    const created = cachedData?.created || Math.floor(Date.now() / 1000);
    const model = cachedData?.model || '';
    const usage = cachedData?.usage || null;
    const finish = cachedData?.choices?.[0]?.finish_reason || 'stop';
    const send = (obj) => res.write(`data: ${JSON.stringify(obj)}\n\n`);

    send({ id, object: 'chat.completion.chunk', created, model, choices: [{ index: 0, delta: { role: 'assistant', content: '' }, finish_reason: null }] });
    if (content) {
      send({ id, object: 'chat.completion.chunk', created, model, choices: [{ index: 0, delta: { content }, finish_reason: null }] });
    }
    send({ id, object: 'chat.completion.chunk', created, model, choices: [{ index: 0, delta: {}, finish_reason: finish }], usage });
    res.write('data: [DONE]\n\n');
    res.end();
  }

  /**
   * 缓存命中时重放 completions 格式 SSE
   */
  replayCompletionsSse(res, cachedData) {
    const content = cachedData?.choices?.[0]?.message?.content || cachedData?.choices?.[0]?.text || '';
    const id = cachedData?.id || 'cmpl-cache';
    const created = cachedData?.created || Math.floor(Date.now() / 1000);
    const model = cachedData?.model || '';
    const usage = cachedData?.usage || null;
    const send = (obj) => res.write(`data: ${JSON.stringify(obj)}\n\n`);

    if (content) {
      send({ id, object: 'text_completion', created, model, choices: [{ text: content, index: 0, logprobs: null, finish_reason: null }] });
    }
    send({ id, object: 'text_completion', created, model, choices: [{ text: '', index: 0, logprobs: null, finish_reason: 'stop' }], usage });
    res.write('data: [DONE]\n\n');
    res.end();
  }

  /**
   * 从 chat 流式 SSE 文本重建完整响应（用于完成后回写缓存）
   */
  reconstructFromChatSse(sseText) {
    let content = '';
    let id = null, created = null, model = null, finish = 'stop', usage = null;
    for (const line of String(sseText || '').split('\n')) {
      if (!line.startsWith('data: ')) continue;
      const payload = line.substring(6).trim();
      if (payload === '[DONE]') continue;
      try {
        const json = JSON.parse(payload);
        if (!id && json.id) id = json.id;
        if (json.created != null) created = json.created;
        if (json.model) model = json.model;
        const delta = json.choices?.[0]?.delta?.content || '';
        if (delta) content += delta;
        if (json.choices?.[0]?.finish_reason) finish = json.choices[0].finish_reason;
        if (json.usage) usage = json.usage;
      } catch (e) { /* skip malformed chunk */ }
    }
    if (!content) return null;
    return {
      id: id || 'chatcmpl-cache',
      object: 'chat.completion',
      created: created || Math.floor(Date.now() / 1000),
      model: model || '',
      choices: [{ index: 0, message: { role: 'assistant', content }, finish_reason: finish }],
      usage
    };
  }

  /**
   * 流式转发并收集原始 SSE（用于回写缓存）
   * 监听客户端断连，及时取消上游读取，避免客户端断开后仍在拉取上游带宽
   */
  async pipeAndCollect(req, res, reader) {
    let collected = '';
    let aborted = false;
    const onClose = () => { aborted = true; try { reader.cancel(); } catch (e) {} };
    req.on('close', onClose);
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        if (aborted) break;
        res.write(Buffer.from(value));
        collected += Buffer.from(value).toString('utf-8');
      }
    } catch (e) {
      console.error('流式响应中断:', e.message);
    } finally {
      req.removeListener('close', onClose);
    }
    res.end();
    return collected;
  }

  setupRoutes() {
    // 健康检查
    this.app.get('/health', (_req, res) => {
      res.json({ status: 'ok', name: 'zimu-transit-router', product: '子沐智能中转路由', version: '3.0.2', timestamp: new Date().toISOString() });
    });

    // 运行时状态（开源接口）
    this.app.get('/api/status', (_req, res) => {
      res.json(this.getRuntimeStatus());
    });

    // OpenAPI 3.0 规范（开源接口）
    this.app.get('/openapi.json', (_req, res) => {
      res.json(this.getOpenApiSpec());
    });

    // 接口文档页（开源接口）
    this.app.get('/docs', (_req, res) => {
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.send(this.getDocsHtml());
    });

    // 获取模型列表
    this.app.get('/v1/models', (_req, res) => {
      const models = this.router.getAllModels();
      res.json({
        object: 'list',
        data: models.map(m => ({
          id: m.id,
          object: 'model',
          created: Math.floor(Date.now() / 1000),
          owned_by: m.providers.map(p => p.name).join(','),
          providers: m.providers,
          price: m.price || null
        }))
      });
    });

    // 聊天补全
    this.app.post('/v1/chat/completions', async (req, res) => {
      const { model, messages, stream, ...rest } = req.body || {};

      const bodyErr = this.validateChatBody({ model, messages });
      if (bodyErr) {
        return res.status(400).json({
          error: { message: bodyErr, type: 'invalid_request_error' }
        });
      }

      const traceId = req.headers['x-trace-id'] || undefined;
      try {
        const result = await this.router.routeWithFallback({
          model, messages, stream, ...rest
        }, { traceId });
        if (traceId) res.setHeader('X-Trace-Id', traceId);

        const { data, meta } = result;

        if (stream) {
          // 流式响应
          res.setHeader('Content-Type', 'text/event-stream');
          res.setHeader('Cache-Control', 'no-cache');
          res.setHeader('Connection', 'keep-alive');
          res.setHeader('X-Accel-Buffering', 'no');
          this.attachMetaHeaders(res, meta);

          if (meta.cached) {
            // 缓存命中：直接重放 SSE（零上游调用）
            this.replayChatSse(res, data);
            return;
          }

          // 转发上游流 + 收集原始 SSE，完成后回写缓存
          const reader = data.stream.getReader();
          const collected = await this.pipeAndCollect(req, res, reader);
          const reconstructed = this.reconstructFromChatSse(collected);
          // 流式用量回填：SSE 末帧可能携带 usage，补记 token/成本/配额（recordSuccess 发起时 usage 尚不可知）
          // C3 修复：同时传入 messages，无 usage 时用本地估算
          this.router.applyStreamUsage(meta.providerId, meta.keyIndex, meta.model, reconstructed?.usage, messages);
          const cacheCfg = this.config.get('cache') || {};
          if (cacheCfg.enabled && cacheCfg.stream !== false && reconstructed) {
            const cacheKey = this.router.getCacheKey(model, messages, rest);
            this.router.cachePut(cacheKey, reconstructed);
          }
        } else {
          this.attachMetaHeaders(res, meta);
          // 内容护栏：输出 PII 掩码（非流式）
          const masked = this.maskResponseOutput(data);
          if (masked) res.setHeader('X-Router-Guard', 'MASKED:' + masked.join(','));
          // 强制内容拦截：输出命中 → 替换为通用提示
          if (this.applyMandatoryOutput(data)) res.setHeader('X-Router-Mandatory-Block', '1');
          res.json(data);
        }
      } catch (error) {
        console.error('路由失败:', error.message);
        if (traceId) res.setHeader('X-Trace-Id', traceId);
        // 4xx（如护栏 403）透传状态码，其余统一 502
        const status = error.status >= 400 && error.status < 500 ? error.status : 502;
        res.status(status).json({
          error: {
            message: error.message,
            type: error.status >= 400 && error.status < 500 ? 'blocked_by_guard' : 'routing_error',
            code: error.status || 'internal_error'
          }
        });
      }
    });

    // 文本补全（修复：转换为 chat 格式请求，并把响应转回 completions 格式；流式同步转换）
    this.app.post('/v1/completions', async (req, res) => {
      const { model, prompt, stream, ...rest } = req.body || {};

      if (typeof model !== 'string' || !model.trim()) {
        return res.status(400).json({
          error: { message: 'model 参数必须是字符串', type: 'invalid_request_error' }
        });
      }

      const messages = prompt != null ? [{ role: 'user', content: String(prompt) }] : [];
      const traceId = req.headers['x-trace-id'] || undefined;
      try {
        const result = await this.router.routeWithFallback({
          model, messages, stream, ...rest
        }, { traceId });
        if (traceId) res.setHeader('X-Trace-Id', traceId);

        const { data, meta } = result;

        if (stream) {
          // 流式：把 chat 格式的 SSE 转换为 completions 格式
          res.setHeader('Content-Type', 'text/event-stream');
          res.setHeader('Cache-Control', 'no-cache');
          res.setHeader('Connection', 'keep-alive');
          res.setHeader('X-Accel-Buffering', 'no');
          this.attachMetaHeaders(res, meta);

          if (meta.cached) {
            // 缓存命中：直接重放 completions 格式 SSE
            this.replayCompletionsSse(res, data);
            return;
          }

          const reader = data.stream.getReader();
          const decoder = new TextDecoder();
          let buffer = '';
          let rawSse = '';

          try {
            while (true) {
              const { done, value } = await reader.read();
              if (done) break;

              const chunkText = decoder.decode(value, { stream: true });
              rawSse += chunkText;
              buffer += chunkText;
              const lines = buffer.split('\n');
              buffer = lines.pop() || '';

              for (const line of lines) {
                if (!line.startsWith('data: ')) continue;
                const payload = line.substring(6).trim();
                if (payload === '[DONE]') {
                  res.write('data: [DONE]\n\n');
                  continue;
                }
                try {
                  const json = JSON.parse(payload);
                  const delta = json.choices?.[0]?.delta?.content || '';
                  const out = {
                    id: json.id,
                    object: 'text_completion',
                    created: json.created,
                    model: json.model,
                    choices: [{
                      text: delta,
                      index: 0,
                      logprobs: null,
                      finish_reason: json.choices?.[0]?.finish_reason || null
                    }]
                  };
                  res.write(`data: ${JSON.stringify(out)}\n\n`);
                } catch (e) { /* skip malformed chunk */ }
              }
            }
            res.end();
          } catch (e) {
            console.error('流式响应中断:', e.message);
            res.end();
          }

          // 完成后回写缓存 + 流式用量回填
          const reconstructed = this.reconstructFromChatSse(rawSse);
          this.router.applyStreamUsage(meta.providerId, meta.keyIndex, meta.model, reconstructed?.usage);
          const cacheCfg = this.config.get('cache') || {};
          if (cacheCfg.enabled && cacheCfg.stream !== false && reconstructed) {
            const cacheKey = this.router.getCacheKey(model, messages, rest);
            this.router.cachePut(cacheKey, reconstructed);
          }
        } else {
          // 非流式：chat 响应 -> completions 响应
          this.attachMetaHeaders(res, meta);
          let content = data.choices?.[0]?.message?.content || '';
          const out = {
            id: data.id,
            object: 'text_completion',
            created: data.created,
            model: data.model,
            choices: [{
              text: content,
              index: 0,
              logprobs: null,
              finish_reason: data.choices?.[0]?.finish_reason || 'stop'
            }],
            usage: data.usage || null
          };
          // 内容护栏：输出 PII 掩码
          const masked = this.maskResponseOutput(out);
          if (masked) res.setHeader('X-Router-Guard', 'MASKED:' + masked.join(','));
          // 强制内容拦截：输出命中 → 替换为通用提示
          if (this.applyMandatoryOutput(out)) res.setHeader('X-Router-Mandatory-Block', '1');
          res.json(out);
        }
      } catch (error) {
        console.error('路由失败:', error.message);
        if (traceId) res.setHeader('X-Trace-Id', traceId);
        const status = error.status >= 400 && error.status < 500 ? error.status : 502;
        res.status(status).json({
          error: { message: error.message, type: error.status >= 400 && error.status < 500 ? 'blocked_by_guard' : 'routing_error' }
        });
      }
    });

    // 嵌入向量（修复：支持故障切换与 Key 轮换）
    this.app.post('/v1/embeddings', async (req, res) => {
      const { model, input } = req.body || {};
      if (typeof model !== 'string' || !model.trim()) {
        return res.status(400).json({
          error: { message: 'model 参数必须是字符串', type: 'invalid_request_error' }
        });
      }

      try {
        const data = await this.router.routeEmbedding({ ...req.body });
        if (data && data._cached) {
          res.setHeader('X-Router-Cache', 'HIT');
          delete data._cached;
        }
        res.json(data);
      } catch (error) {
        console.error('嵌入路由失败:', error.message);
        const status = error.status >= 400 && error.status < 500 ? error.status : 502;
        res.status(status).json({
          error: { message: error.message, type: error.status >= 400 && error.status < 500 ? 'blocked_by_guard' : 'routing_error' }
        });
      }
    });

    // 图片生成（多模态 v3.0.2）
    this.app.post('/v1/images/generations', async (req, res) => {
      const { model, prompt } = req.body || {};
      if (typeof model !== 'string' || !model.trim()) {
        return res.status(400).json({ error: { message: 'model 参数必须是字符串', type: 'invalid_request_error' } });
      }
      if (!prompt) {
        return res.status(400).json({ error: { message: 'prompt 参数是必需的', type: 'invalid_request_error' } });
      }
      const traceId = req.headers['x-trace-id'] || undefined;
      try {
        const result = await this.router.routeImageGeneration({ ...(req.body || {}) }, { traceId });
        if (traceId) res.setHeader('X-Trace-Id', traceId);
        this.attachMetaHeaders(res, result.meta);
        res.json(result.data);
      } catch (error) {
        console.error('图片生成失败:', error.message);
        if (traceId) res.setHeader('X-Trace-Id', traceId);
        const status = error.status >= 400 && error.status < 500 ? error.status : 502;
        res.status(status).json({
          error: { message: error.message, type: error.status >= 400 && error.status < 500 ? 'blocked_by_guard' : 'routing_error' }
        });
      }
    });

    // 视频生成（多模态 v3.0.2，异步任务）
    this.app.post('/v1/videos/generations', async (req, res) => {
      const { model, prompt } = req.body || {};
      if (typeof model !== 'string' || !model.trim()) {
        return res.status(400).json({ error: { message: 'model 参数必须是字符串', type: 'invalid_request_error' } });
      }
      if (!prompt) {
        return res.status(400).json({ error: { message: 'prompt 参数是必需的', type: 'invalid_request_error' } });
      }
      const traceId = req.headers['x-trace-id'] || undefined;
      try {
        const result = await this.router.routeVideoGeneration({ ...(req.body || {}) }, { traceId });
        if (traceId) res.setHeader('X-Trace-Id', traceId);
        this.attachMetaHeaders(res, result.meta);
        res.json(result.data);
      } catch (error) {
        console.error('视频生成失败:', error.message);
        if (traceId) res.setHeader('X-Trace-Id', traceId);
        const status = error.status >= 400 && error.status < 500 ? error.status : 502;
        res.status(status).json({
          error: { message: error.message, type: error.status >= 400 && error.status < 500 ? 'blocked_by_guard' : 'routing_error' }
        });
      }
    });

    // 视频任务状态查询
    this.app.get('/v1/videos/generations/:taskId', async (req, res) => {
      try {
        const data = await this.router.getVideoTask(req.params.taskId);
        res.json(data);
      } catch (error) {
        console.error('视频任务查询失败:', error.message);
        const status = error.status >= 400 && error.status < 500 ? error.status : 502;
        res.status(status).json({ error: { message: error.message, type: 'video_task_error' } });
      }
    });

    // 错误处理中间件：JSON 解析失败 / 处理器异常统一返回 400 JSON（避免进程崩溃）
    this.app.use((err, _req, res, next) => {
      console.error('代理请求错误:', err.message);
      if (res.headersSent) return next(err);
      res.status(400).json({
        error: { message: '请求体解析失败: ' + err.message, type: 'bad_request' }
      });
    });

    // 404 兜底（v3.0.2：/remote/* 交给后注册的远程路由，否则返回 404）
    this.app.use((req, res, next) => {
      if (req.path.startsWith('/remote/')) return next();
      res.status(404).json({
        error: { message: '未找到接口', type: 'not_found' }
      });
    });
  }

  async start(port, opts = {}) {
    return this._startWithRetry(port, opts || {}, 0);
  }

  /**
   * 启动并附带端口冲突重试（上限 MAX_PORT_RETRY，避免端口区间被占满时无限递归）
   */
  _startWithRetry(port, opts, attempt) {
    const MAX_PORT_RETRY = 20;
    return new Promise((resolve, reject) => {
      try {
        const host = opts.host || '127.0.0.1';
        this.server = this.app.listen(port, host, () => {
          // 端口为 0 时读取系统分配的实际端口
          this.port = this.server.address()?.port || port;
          console.log(`代理服务器运行在 http://${host}:${this.port}`);
          resolve(this);
        });

        this.server.on('error', (err) => {
          if (err.code === 'EADDRINUSE' && attempt < MAX_PORT_RETRY) {
            console.log(`端口 ${port} 被占用，尝试 ${port + 1}... (${attempt + 1}/${MAX_PORT_RETRY})`);
            this._startWithRetry(port + 1, opts, attempt + 1).then(resolve).catch(reject);
          } else if (err.code === 'EADDRINUSE') {
            reject(new Error(`端口 ${port} 及后续 ${MAX_PORT_RETRY} 个端口均被占用，无法启动代理`));
          } else {
            reject(err);
          }
        });
      } catch (e) {
        reject(e);
      }
    });
  }

  stop() {
    if (this.server) {
      try {
        this.server.closeAllConnections();
      } catch (e) {
        // Node < 18 没有 closeAllConnections
      }
      try {
        this.server.close(() => {
          console.log('代理服务器已停止');
        });
      } catch (e) {}
      this.server.removeAllListeners();
      this.server = null;
      this.port = null;
    }
  }

  async restart(port) {
    this.stop();
    await this.start(port);
    return this.getStatus();
  }

  getStatus() {
    return {
      running: !!this.server,
      port: this.port,
      url: this.port ? `http://localhost:${this.port}` : null
    };
  }

  /**
   * 请求体校验：model 必须非空字符串；messages 元素必须为对象；content 可为字符串/数组/null
   * （null 合法：assistant 的 tool_calls 消息 content 为 null，tool 角色消息依赖 tool_call_id）
   * @returns {string|null} 错误信息（null=合法）
   */
  validateChatBody({ model, messages }) {
    if (typeof model !== 'string' || !model.trim()) return 'model 参数必须是字符串';
    if (!Array.isArray(messages)) return 'messages 参数必须是数组';
    for (const m of messages) {
      if (!m || typeof m !== 'object') return 'messages 元素必须是对象';
      if (m.content != null && typeof m.content !== 'string' && !Array.isArray(m.content)) {
        return 'messages 元素的 content 必须是字符串、数组或 null';
      }
    }
    return null;
  }

  /**
   * 内容护栏：对非流式输出做 PII 掩码
   * @returns {string[]|null} 命中的 PII 类型列表（无掩码返回 null）
   */
  maskResponseOutput(data) {
    const guard = this.router?.guard;
    if (!guard || !(guard.cfg() || {}).maskPII) return null;
    const choices = data?.choices;
    if (!Array.isArray(choices)) return null;
    const found = new Set();
    for (const c of choices) {
      const content = c?.message?.content ?? c?.text;
      if (typeof content === 'string') {
        const r = guard.mask(content);
        if (r.masked) {
          if (c.message) c.message.content = r.text;
          else c.text = r.text;
          r.patterns.forEach(p => found.add(p));
        }
      }
    }
    return found.size > 0 ? Array.from(found) : null;
  }

  /**
   * 强制内容拦截：输出命中强制词 → 替换为通用提示（不可关闭，仅非流式）
   * @returns {boolean} 是否命中拦截
   */
  applyMandatoryOutput(data) {
    const g = this.router?.mandatoryGuard;
    if (!g) return false;
    let blocked = false;
    for (const c of (data?.choices || [])) {
      const content = c?.message?.content ?? c?.text;
      if (typeof content === 'string' && g.check(content)) {
        const replaced = g.redact(content);
        if (c.message) c.message.content = replaced;
        else c.text = replaced;
        blocked = true;
      }
    }
    if (blocked) this.router.countMandatoryBlock();
    return blocked;
  }

  /**
   * 运行时状态（供 /api/status 开源接口使用）
   */
  getRuntimeStatus() {
    const stats = this.router.getStats();
    return {
      name: 'zimu-transit-router',
      product: '子沐智能中转路由',
      version: '3.0.2',
      license: 'MIT',
      proxy: this.getStatus(),
      routing: {
        strategy: stats.routing?.strategy || this.config.get('routing.strategy'),
        circuitBreaker: stats.routing?.circuitBreaker || {},
        quotaEnabled: !!stats.quota?.enabled
      },
      smart: {
        qualityEnabled: !!(this.config.get('quality') || {}).enabled,
        guardEnabled: !!(this.config.get('guard') || {}).enabled,
        semanticCache: stats.semanticCache || {},
        slo: stats.slo || {},
        residencyEnabled: !!(this.config.get('residency') || {}).enabled,
        drift: stats.drift || {},
        healthcheck: this.router.getHealthCheck().summary
      },
      providers: {
        total: (this.config.getProviders() || []).length,
        enabled: (this.config.getEnabledProviders() || []).length
      },
      cache: stats.cache || {},
      requestStats: {
        totalRequests: stats.totalRequests || 0,
        successCount: stats.successCount || 0,
        failCount: stats.failCount || 0
      }
    };
  }

  /**
   * OpenAPI 3.0 规范（供 /openapi.json 开源接口使用）
   */
  getOpenApiSpec() {
    const routerHeaders = {
      'X-Router-Model': { schema: { type: 'string' }, description: '实际使用的模型（发生回退时与请求模型不同）' },
      'X-Router-Provider': { schema: { type: 'string' }, description: '实际使用的服务商' },
      'X-Router-Provider-Id': { schema: { type: 'string' }, description: '实际使用的服务商 ID' },
      'X-Router-Latency': { schema: { type: 'string' }, description: '本次请求延迟（ms）' },
      'X-Router-Switched': { schema: { type: 'string' }, description: '是否发生跨模型切换（1=是）' },
      'X-Router-Cache': { schema: { type: 'string' }, description: '是否命中内存缓存（HIT）' }
    };
    const errorResp = {
      description: '路由失败/参数错误',
      content: {
        'application/json': {
          schema: {
            type: 'object',
            properties: {
              error: {
                type: 'object',
                properties: {
                  message: { type: 'string' },
                  type: { type: 'string' },
                  code: { type: 'string' }
                }
              }
            }
          }
        }
      }
    };

    return {
      openapi: '3.0.3',
      info: {
        title: '子沐智能中转路由 API',
        description: '多模型智能中转/路由代理：OpenAI 兼容接口，支持故障切换、加权路由、熔断、配额、跨模型回退、内存缓存。Base URL: http://localhost:<port>/v1，API Key 任意值。',
        version: '3.0.2',
        license: { name: 'MIT', url: 'https://opensource.org/licenses/MIT' }
      },
      servers: [{ url: 'http://localhost:3456', description: '本地代理服务器（默认端口，可在设置页修改）' }],
      tags: [
        { name: '模型', description: '模型列表' },
        { name: '对话', description: '聊天补全' },
        { name: '补全', description: '文本补全' },
        { name: '嵌入', description: '嵌入向量' },
        { name: '生成', description: '图片/视频生成（多模态）' },
        { name: '系统', description: '健康检查/状态/规范' }
      ],
      paths: {
        '/v1/models': {
          get: {
            tags: ['模型'],
            summary: '获取所有可用模型（含价格与支持的服务商）',
            responses: {
              200: {
                description: '模型列表',
                content: {
                  'application/json': {
                    schema: {
                      type: 'object',
                      properties: {
                        object: { type: 'string' },
                        data: {
                          type: 'array',
                          items: {
                            type: 'object',
                            properties: {
                              id: { type: 'string' },
                              object: { type: 'string' },
                              owned_by: { type: 'string' },
                              providers: { type: 'array' },
                              price: { type: 'object', nullable: true }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        },
        '/v1/chat/completions': {
          post: {
            tags: ['对话'],
            summary: '聊天补全（智能路由转发，支持流式与缓存）',
            requestBody: {
              required: true,
              content: {
                'application/json': {
                  schema: {
                    type: 'object',
                    required: ['model', 'messages'],
                    properties: {
                      model: { type: 'string', example: 'gpt-4' },
                      messages: {
                        type: 'array',
                        items: {
                          type: 'object',
                          properties: {
                            role: { type: 'string', enum: ['system', 'user', 'assistant'] },
                            content: { type: 'string' }
                          }
                        }
                      },
                      stream: { type: 'boolean', default: false, description: '是否流式输出（SSE）' },
                      temperature: { type: 'number' },
                      max_tokens: { type: 'integer' },
                      noCache: { type: 'boolean', description: 'true 时绕过内存缓存' }
                    }
                  }
                }
              }
            },
            responses: {
              200: {
                description: '补全结果（OpenAI chat.completion 格式）',
                headers: routerHeaders
              },
              400: errorResp,
              502: errorResp
            }
          }
        },
        '/v1/completions': {
          post: {
            tags: ['补全'],
            summary: '文本补全（自动转换为聊天格式路由）',
            requestBody: {
              required: true,
              content: {
                'application/json': {
                  schema: {
                    type: 'object',
                    required: ['model'],
                    properties: {
                      model: { type: 'string' },
                      prompt: { type: 'string' },
                      stream: { type: 'boolean', default: false }
                    }
                  }
                }
              }
            },
            responses: {
              200: { description: 'text_completion 格式结果', headers: routerHeaders },
              400: errorResp,
              502: errorResp
            }
          }
        },
        '/v1/embeddings': {
          post: {
            tags: ['嵌入'],
            summary: '文本嵌入（支持故障切换与缓存）',
            requestBody: {
              required: true,
              content: {
                'application/json': {
                  schema: {
                    type: 'object',
                    required: ['model', 'input'],
                    properties: {
                      model: { type: 'string' },
                      input: { oneOf: [{ type: 'string' }, { type: 'array', items: { type: 'string' } }] }
                    }
                  }
                }
              }
            },
            responses: {
              200: { description: '嵌入结果', headers: { 'X-Router-Cache': routerHeaders['X-Router-Cache'] } },
              400: errorResp,
              502: errorResp
            }
          }
        },
        '/v1/images/generations': {
          post: {
            tags: ['生成'],
            summary: '图片生成（OpenAI 兼容，智能调度图片大模型，含故障切换）',
            requestBody: {
              required: true,
              content: {
                'application/json': {
                  schema: {
                    type: 'object',
                    required: ['model', 'prompt'],
                    properties: {
                      model: { type: 'string', example: 'dall-e-3' },
                      prompt: { type: 'string' },
                      n: { type: 'integer', default: 1 },
                      size: { type: 'string', example: '1024x1024' },
                      response_format: { type: 'string', enum: ['url', 'b64_json'] }
                    }
                  }
                }
              }
            },
            responses: {
              200: { description: '图片结果（url 或 b64_json）', headers: routerHeaders },
              400: errorResp,
              403: errorResp,
              502: errorResp
            }
          }
        },
        '/v1/videos/generations': {
          post: {
            tags: ['生成'],
            summary: '视频生成（异步任务，智能调度视频大模型，含故障切换）',
            requestBody: {
              required: true,
              content: {
                'application/json': {
                  schema: {
                    type: 'object',
                    required: ['model', 'prompt'],
                    properties: {
                      model: { type: 'string', example: 'agnes-video-2.5' },
                      prompt: { type: 'string' },
                      duration: { type: 'integer' },
                      resolution: { type: 'string', example: '1080p' }
                    }
                  }
                }
              }
            },
            responses: {
              200: { description: '任务已提交（含 id 与 status），用 /v1/videos/generations/:id 轮询', headers: routerHeaders },
              400: errorResp,
              403: errorResp,
              502: errorResp
            }
          }
        },
        '/v1/videos/generations/{taskId}': {
          get: {
            tags: ['生成'],
            summary: '视频任务状态查询（轮询直到 completed）',
            parameters: [{ name: 'taskId', in: 'path', required: true, schema: { type: 'string' } }],
            responses: {
              200: { description: '任务状态与结果（url 等）' },
              404: errorResp,
              502: errorResp
            }
          }
        },
        '/health': {
          get: {
            tags: ['系统'],
            summary: '健康检查',
            responses: { 200: { description: '服务状态' } }
          }
        },
        '/api/status': {
          get: {
            tags: ['系统'],
            summary: '运行时状态（版本/代理/缓存/统计/服务商数）',
            responses: { 200: { description: '运行时状态 JSON' } }
          }
        },
        '/openapi.json': {
          get: {
            tags: ['系统'],
            summary: 'OpenAPI 3.0 规范（本文件）',
            responses: { 200: { description: 'OpenAPI 规范' } }
          }
        },
        '/docs': {
          get: {
            tags: ['系统'],
            summary: '接口文档页',
            responses: { 200: { description: 'HTML 文档页' } }
          }
        }
      }
    };
  }

  /**
   * 接口文档 HTML 页（供 /docs 开源接口使用）
   */
  getDocsHtml() {
    const port = this.port || 3456;
    const rows = [
      ['GET', '/health', '健康检查'],
      ['GET', '/api/status', '运行时状态（版本/代理/缓存/统计）'],
      ['GET', '/openapi.json', 'OpenAPI 3.0 规范'],
      ['GET', '/docs', '本页面'],
      ['GET', '/v1/models', '获取所有可用模型（含价格/能力标签）'],
      ['POST', '/v1/chat/completions', '聊天补全（支持流式/缓存/回退）'],
      ['POST', '/v1/completions', '文本补全'],
      ['POST', '/v1/embeddings', '文本嵌入'],
      ['POST', '/v1/images/generations', '图片生成（智能调度图片大模型）'],
      ['POST', '/v1/videos/generations', '视频生成（异步任务，智能调度视频大模型）'],
      ['GET', '/v1/videos/generations/:taskId', '视频任务状态查询']
    ];
    const headers = [
      ['X-Router-Model', '实际使用的模型'],
      ['X-Router-Provider', '实际使用的服务商'],
      ['X-Router-Switched', '是否跨模型切换 (1)'],
      ['X-Router-Latency', '请求延迟 (ms)'],
      ['X-Router-Cache', '缓存命中 (HIT)']
    ];
    return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>子沐智能中转路由 - API 文档</title>
<style>
body{font-family:'Microsoft YaHei',sans-serif;background:#f5f7fa;color:#2c3e50;margin:0;padding:32px;}
h1{font-size:24px;}h2{font-size:18px;margin-top:28px;border-left:4px solid #4A90D9;padding-left:10px;}
table{border-collapse:collapse;width:100%;max-width:820px;background:#fff;box-shadow:0 2px 8px rgba(0,0,0,.08);}
th,td{border:1px solid #e2e8f0;padding:10px 14px;text-align:left;font-size:14px;}
th{background:#4A90D9;color:#fff;}
td code,code{background:#eef2f7;padding:2px 6px;border-radius:4px;font-size:13px;}
.mono{font-family:monospace;}
pre{background:#1e293b;color:#e2e8f0;padding:16px;border-radius:8px;overflow:auto;max-width:820px;font-size:13px;}
.badge{display:inline-block;background:#4ECDC4;color:#fff;padding:2px 10px;border-radius:10px;font-size:12px;}
</style>
</head>
<body>
<h1>子沐智能中转路由 API 文档</h1>
<p><span class="badge">MIT License</span> <span class="badge">OpenAI 兼容</span> <span class="badge">本地代理 :${port}</span></p>
<h2>接口一览</h2>
<table><tr><th>方法</th><th>路径</th><th>说明</th></tr>
${rows.map(r => `<tr><td><code>${r[0]}</code></td><td><code>${r[1]}</code></td><td>${r[2]}</td></tr>`).join('\n')}
</table>
<h2>路由信息响应头</h2>
<table><tr><th>响应头</th><th>说明</th></tr>
${headers.map(h => `<tr><td><code>${h[0]}</code></td><td>${h[1]}</td></tr>`).join('\n')}
</table>
<h2>快速开始</h2>
<p>Base URL: <code>http://localhost:${port}/v1</code>（API Key 任意值）</p>
<pre>curl http://localhost:${port}/v1/chat/completions \\
  -H "Content-Type: application/json" \\
  -H "Authorization: Bearer ***" \\
  -d '{"model":"gpt-4","messages":[{"role":"user","content":"你好"}]}'</pre>
<h2>OpenAPI 规范</h2>
<p>机器可读规范：<code><a href="/openapi.json">/openapi.json</a></code>，可直接导入 Postman / Apifox / Swagger UI。</p>
</body>
</html>`;
  }
}

module.exports = { ProxyServer };
