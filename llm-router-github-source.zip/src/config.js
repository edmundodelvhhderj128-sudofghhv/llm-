const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { app } = require('electron');

// 预设渠道商模板（服务商页「从预设添加」用），覆盖主流 OpenAI 兼容服务商
// region: 数据驻留区域（CN=国内 / US=海外 / EU / any=不限）
const PROVIDER_PRESETS = [
  { name: 'Agnes 国内', baseUrl: 'https://apihub.agnes-ai.cn', region: 'CN', note: 'Agnes AI 国内节点（OpenAI 兼容，含图片/视频生成）', models: ['agnes-2.5-flash', 'agnes-2.0-flash', 'agnes-2.5-pro', 'agnes-image-2.1-flash', 'agnes-video-2.5'] },
  { name: 'Agnes 国际', baseUrl: 'https://apihub.agnes-ai.com', region: 'US', note: 'Agnes AI 国际节点（OpenAI 兼容，含图片/视频生成）', models: ['agnes-2.5-flash', 'agnes-2.0-flash', 'agnes-2.5-pro', 'agnes-image-2.1-flash', 'agnes-video-2.5'] },
  { name: 'OpenAI', baseUrl: 'https://api.openai.com', region: 'US', note: 'GPT 系列官方接口（含 DALL·E 图片）', models: ['gpt-4o', 'gpt-4o-mini', 'gpt-4-turbo', 'o1-mini', 'dall-e-3', 'gpt-image-1'] },
  { name: 'DeepSeek', baseUrl: 'https://api.deepseek.com', region: 'CN', note: 'DeepSeek 官方接口（价格极低）', models: ['deepseek-chat', 'deepseek-reasoner'] },
  { name: '商汤日日新 SenseNova', baseUrl: 'https://token.sensenova.cn', region: 'CN', note: '商汤 SenseNova 开放平台（含图片生成）', models: ['sensenova-6.7-flash-lite', 'deepseek-v4-flash', 'sensenova-u1-fast'] },
  { name: '智谱 GLM', baseUrl: 'https://open.bigmodel.cn/api/paas/v4', pathStyle: 'none', region: 'CN', note: '智谱清言官方接口（接口路径含 /api/paas/v4），glm-4.5-flash 免费', models: ['glm-4.5', 'glm-4.5-flash', 'glm-4-plus', 'glm-4-flash'] },
  { name: 'Moonshot Kimi', baseUrl: 'https://api.moonshot.cn', region: 'CN', note: 'Kimi 官方接口', models: ['moonshot-v1-8k', 'moonshot-v1-32k', 'moonshot-v1-128k'] },
  { name: '阿里云百炼', baseUrl: 'https://dashscope.aliyuncs.com/compatible-mode/v1', pathStyle: 'none', region: 'CN', note: '通义千问官方（DashScope OpenAI 兼容模式）', models: ['qwen-max', 'qwen-plus', 'qwen-turbo', 'qwen2.5-72b-instruct'] },
  { name: '硅基流动 SiliconFlow', baseUrl: 'https://api.siliconflow.cn', region: 'CN', note: '开源模型聚合（含 bge-m3 嵌入与 SDXL/Kolors 图片）', models: ['Qwen/Qwen2.5-72B-Instruct', 'deepseek-ai/DeepSeek-V3', 'BAAI/bge-m3', 'stabilityai/stable-diffusion-xl-base-1.0', 'Kwai-Kolors/Kolors'] },
  { name: '腾讯混元', baseUrl: 'https://api.hunyuan.cloud.tencent.com', region: 'CN', note: '腾讯混元官方接口（含图片/视频生成）', models: ['hunyuan-turbos-latest', 'hunyuan-lite', 'hunyuan-image', 'hunyuan-video'] },
  { name: 'MiniMax', baseUrl: 'https://api.minimax.chat', region: 'CN', note: 'MiniMax 官方接口（含图片/视频生成）', models: ['MiniMax-M2', 'abab6.5s-chat', 'image-01', 'hailuo-02'] },
  { name: '百度千帆', baseUrl: 'https://qianfan.baidubce.com/v2', pathStyle: 'none', region: 'CN', note: '文心一言官方接口（接口路径含 /v2）', models: ['ernie-4.5-turbo-128k', 'ernie-3.5-8k'] },
  { name: 'Google Gemini', baseUrl: 'https://generativelanguage.googleapis.com/v1beta/openai', pathStyle: 'none', region: 'US', note: 'Gemini 官方 OpenAI 兼容端点（含图片生成）', models: ['gemini-2.5-flash', 'gemini-2.5-pro', 'gemini-2.0-flash', 'gemini-2.5-flash-image-preview'] },
  { name: 'OpenRouter', baseUrl: 'https://openrouter.ai/api/v1', pathStyle: 'none', region: 'US', note: '全球模型聚合（含图片生成模型）', models: ['openai/gpt-4o-mini', 'anthropic/claude-3.5-sonnet', 'google/gemini-2.5-flash', 'openai/dall-e-3', 'stabilityai/stable-diffusion-xl'] },
  { name: 'Groq', baseUrl: 'https://api.groq.com/openai/v1', pathStyle: 'none', region: 'US', note: '超高速推理（Llama 系列，接口路径含 /openai/v1）', models: ['llama-3.3-70b-versatile', 'llama-3.1-8b-instant'] },
  { name: 'Mistral', baseUrl: 'https://api.mistral.ai', region: 'EU', note: 'Mistral 官方接口', models: ['mistral-large-latest', 'mistral-small-latest'] },
  { name: '本地 Ollama', baseUrl: 'http://localhost:11434', region: 'any', note: '本地模型（免费，含 bge-m3 嵌入）', models: ['qwen2.5:7b', 'llama3.2:3b', 'bge-m3'] },
  { name: 'LM Studio', baseUrl: 'http://localhost:1234', region: 'any', note: '本地模型推理（免费）', models: [] }
];

// 内置常见模型价格表（美元 / 每百万 tokens），用于价格管理页与成本优化
// 单位: input/output = $ per 1M tokens
const BUILTIN_PRICES = {
  'gpt-4o': { input: 2.5, output: 10 },
  'gpt-4o-mini': { input: 0.15, output: 0.6 },
  'gpt-4-turbo': { input: 10, output: 30 },
  'gpt-4': { input: 30, output: 60 },
  'gpt-3.5-turbo': { input: 0.5, output: 1.5 },
  'o1': { input: 15, output: 60 },
  'o1-mini': { input: 3, output: 12 },
  'o3-mini': { input: 1.1, output: 4.4 },
  'claude-3-5-sonnet': { input: 3, output: 15 },
  'claude-3-5-haiku': { input: 0.8, output: 4 },
  'claude-3-opus': { input: 15, output: 75 },
  'claude-3-sonnet': { input: 3, output: 15 },
  'claude-3-haiku': { input: 0.25, output: 1.25 },
  'deepseek-chat': { input: 0.14, output: 0.28 },
  'deepseek-reasoner': { input: 0.55, output: 2.19 },
  'gemini-1.5-pro': { input: 1.25, output: 5 },
  'gemini-1.5-flash': { input: 0.075, output: 0.3 },
  'gemini-2.0-flash': { input: 0.1, output: 0.4 },
  'moonshot-v1-8k': { input: 0.6, output: 0.6 },
  'moonshot-v1-32k': { input: 1.2, output: 1.2 },
  'moonshot-v1-128k': { input: 3, output: 3 },
  'qwen-max': { input: 0.36, output: 1.08 },
  'qwen-plus': { input: 0.08, output: 0.24 },
  'qwen-turbo': { input: 0.03, output: 0.09 },
  'llama-3.1-8b': { input: 0.05, output: 0.05 },
  'llama-3.1-70b': { input: 0.5, output: 0.5 },
  'llama-3.1-405b': { input: 3, output: 3 },
  'mistral-large': { input: 2, output: 6 },
  'mistral-small': { input: 0.2, output: 0.6 },
  'text-embedding-3-small': { input: 0.02, output: 0 },
  'text-embedding-3-large': { input: 0.13, output: 0 },
  'bge-m3': { input: 0, output: 0 }
};

class ConfigManager {
  constructor() {
    const userDataPath = app.getPath('userData');
    this.configPath = path.join(userDataPath, 'config.json');
    this.config = this.load();

    // H5 修复：高频写盘合并（quota / 统计 / 远程状态等高频字段）
    // - 这些字段可能每 100ms 更新一次，原 persist 每次同步写盘会拖慢请求
    // - 改为 debounce 30s 写盘；同时启动时强制 flush 一次保证数据不丢
    this._persistTimer = null;
    this._persistDelayMs = 30000;
    this._lastFlushAt = Date.now();
  }

  load() {
    try {
      if (fs.existsSync(this.configPath)) {
        // 兼容带 UTF-8 BOM 的配置文件（部分编辑器/脚本会写入 BOM）
        const raw = fs.readFileSync(this.configPath, 'utf-8').replace(/^\uFEFF/, '');
        const loaded = JSON.parse(raw);
        return this.mergeDefaults(loaded);
      }
    } catch (e) {
      console.error('加载配置失败:', e.message);
    }
    return this.defaultConfig();
  }

  // 旧版本配置升级：合并缺失字段，保证新功能有默认值
  mergeDefaults(loaded) {
    const def = this.defaultConfig();
    const merged = {
      ...def,
      ...loaded,
      routing: {
        ...def.routing,
        ...(loaded.routing || {}),
        circuitBreaker: { ...def.routing.circuitBreaker, ...(loaded.routing?.circuitBreaker || {}) },
        quota: { ...def.routing.quota, ...(loaded.routing?.quota || {}) },
        costOptimization: { ...def.routing.costOptimization, ...(loaded.routing?.costOptimization || {}) },
        abTest: { ...def.routing.abTest, ...(loaded.routing?.abTest || {}) }
      },
      prices: {
        ...def.prices,
        ...(loaded.prices || {}),
        // 内置价格表始终并入：用户配置里的价格覆盖默认值，但默认值不丢失
        models: { ...def.prices.models, ...(loaded.prices?.models || {}) },
        removed: Array.isArray(loaded.prices?.removed) ? loaded.prices.removed : []
      },
      cache: { ...def.cache, ...(loaded.cache || {}) },
      logging: { ...def.logging, ...(loaded.logging || {}) },
      quality: { ...def.quality, ...(loaded.quality || {}) },
      guard: { ...def.guard, ...(loaded.guard || {}) },
      semanticCache: { ...def.semanticCache, ...(loaded.semanticCache || {}) },
      slo: { ...def.slo, ...(loaded.slo || {}) },
      residency: { ...def.residency, ...(loaded.residency || {}) },
      shadow: { ...def.shadow, ...(loaded.shadow || {}) },
      compression: { ...def.compression, ...(loaded.compression || {}) },
      memory: { ...def.memory, ...(loaded.memory || {}) },
      local: { ...def.local, ...(loaded.local || {}) },
      remote: { ...def.remote, ...(loaded.remote || {}) },
      stats: { ...def.stats, ...(loaded.stats || {}) }
    };

    // v1 老配置迁移：旧版健康检测间隔 bug 默认值为 300（分钟），迁移为 5
    // （300 只可能是旧版本 bug 默认值，正常用户不会刻意设置 5 小时）
    if (merged.routing.healthCheckInterval === 300) {
      merged.routing.healthCheckInterval = 5;
      console.log('配置迁移: 健康检测间隔 300 -> 5 分钟');
    }

    // 用户手动删除的价格不复活
    if (Array.isArray(merged.prices.removed)) {
      for (const r of merged.prices.removed) {
        delete merged.prices.models[r];
      }
    }

    return merged;
  }

  defaultConfig() {
    return {
      version: '2.0.0',
      proxyPort: 3456,
      autoStartProxy: true,
      autoStart: false,          // 开机自启
      trayMinimize: true,        // 最小化到托盘
      currency: 'USD',           // 显示货币: USD | CNY
      providers: [],
      routing: {
        strategy: 'priority',    // priority | round-robin | random | weighted
        failover: true,
        fallback: true,          // 跨模型回退
        lkgp: true,              // 记住最后成功渠道优先路由（v2.8.0 借鉴 OmniRoute）
        promptCacheAffinity: true, // 提示缓存亲和（v2.8.1 借鉴 OmniRoute）：同 system 前缀固定渠道，吃满上游缓存
        intentRouting: true,       // 请求级意图/复杂度识别（v2.10.0 借鉴 OmniRoute intentClassifier）：回退按任务匹配排序，支持 model=auto
        modelStrength: {},         // 模型强度覆盖（v2.10.0）：{ strong: ['模型名片段'], fast: ['模型名片段'] }
        maxRetries: 3,
        maxKeyRetries: null,  // null=同渠道所有 Key 都试完才切渠道；N=每渠道最多试 N 个 Key 后切渠道（v3.0.3：同渠道多 Key 重试）
        timeout: 60000,          // 单次上游请求超时（毫秒）；流式只影响首包，60s 给慢上游留余地（v2.6.3）
        fallbackTimeoutMs: 20000, // 回退候选单次尝试上限（v2.6.4：微信等严格超时通道快速遍历可用渠道）
        healthCheckInterval: 5,  // 分钟
        rateLimitBackoffMs: 60000, // 429 限流退避基数（指数退避 base，v2.8.0）
        rateLimitBackoffMaxMs: 600000, // 429 退避封顶（10 分钟，v2.8.0 借鉴 OmniRoute cooldownCap）
        autoRepairPrompt: true,   // 对话不以 user 结尾时自动补空 user 消息（适配商汤等严格要求的上游）
        circuitBreaker: {
          enabled: true,
          threshold: 5,          // 连续失败 N 次熔断
          cooldownMs: 60000      // 熔断冷却时间
        },
        quota: {
          enabled: false,
          period: 'day',         // hour | day | week | month
          limits: {}             // providerId -> { requests: N, tokens: N }
        },
        costOptimization: {
          enabled: false,
          preferCheapest: true   // true=最便宜优先，false=最贵优先
        },
        abTest: {
          enabled: false,
          groups: []             // [{ name, model, weight }]
        }
      },
      prices: {
        currency: 'USD',
        models: { ...BUILTIN_PRICES },
        removed: []   // 用户手动删除的模型价格（合并内置表时不再复活）
      },
      // 内存命中缓存（v2.0.2 新增）
      cache: {
        enabled: true,
        maxBytes: 1024 * 1024 * 1024,   // 1GB
        stream: true,                    // 缓存流式请求（命中时重放 SSE）
        embeddings: true                 // 缓存嵌入请求
      },
      // 可观测性与反馈闭环（v2.1.0）
      logging: {
        enabled: true,        // Trace 调用日志（磁盘 JSONL）
        maxEntries: 10000,
        days: 7
      },
      quality: {
        enabled: false,       // 质量评分（judge 模型）
        judgeProviderId: null,
        judgeModel: null,
        sampleRate: 0.1,      // 采样率
        heuristic: true,       // 内置启发式评分（无 judge 时兜底）
        judgeBackend: 'auto'   // judge 后端（v2.5.1）：auto=本地引擎在跑优先用本地 | cloud | local
      },
      guard: {
        enabled: false,       // 内容护栏
        maskPII: true,        // 输出 PII 掩码
        blockSensitive: false,// 输入敏感词拦截
        sensitiveWords: []    // 敏感词黑名单（用户可编辑）
      },
      semanticCache: {
        enabled: false,       // 语义缓存（需可用 embeddings 服务商）
        threshold: 0.95,
        maxEntries: 2000,
        embeddingProviderId: null,  // 留空自动选择
        embeddingModel: null,       // 留空自动选择
        embedBackend: 'auto'        // 嵌入后端（v2.5.1）：auto=本地引擎在跑优先用本地 | cloud | local
      },
      slo: {
        enabled: true,        // SLO 智能限流（延迟 p95 降级保护）
        p95ThresholdMs: 4000,
        windowSize: 200
      },
      residency: {
        enabled: false,       // 数据驻留（区域白名单）
        allowedRegions: []    // 例如 ['CN']，只走这些区域的服务商
      },
      shadow: {
        enabled: true,         // 影子决策记录（对比备选策略，不额外调用）
        realDualRun: false,    // 影子真实双跑（v2.11.0）：采样请求额外发给加权首选渠道对比质量/延迟（会消耗上游调用）
        sampleRate: 0.1        // 双跑采样率
      },
      // Tokens 压缩（v2.2.1）：长对话在不影响语义的前提下压缩后发送上游，节省成本
      compression: {
        enabled: false,
        heuristic: true,       // 免费启发式：超长旧消息截断压缩
        dedup: true,           // 消息级去重（v2.7.1，借鉴 OmniRoute session-dedup）：相同 system/旧消息只保留一条，无损
        prose: true,           // 规则压缩（v2.7.0，借鉴 OmniRoute Caveman）：截断前先删客套/填充/冗余（中英文，无损语义）
        smart: false,          // LLM 智能摘要：把超长旧历史合成摘要（需配压缩模型）
        providerId: null,      // 压缩用服务商（留空复用 judge 或首个可用）
        model: null,           // 压缩模型（留空复用 judgeModel 或自动选择）
        keepRecent: 8,         // 保留最近 N 条消息不压缩
        maxOldChars: 600,      // 旧消息单条压缩后最大字符数
        minLen: 80,            // 单条消息超过该长度才压缩
        triggerTokens: 12000,  // 估算总 tokens 超过该值才触发压缩
        smartBackend: 'auto'   // 摘要后端（v2.5.1）：auto=本地引擎在跑优先用本地 | cloud | local
      },
      // 内置记忆系统（v2.3.0）：学习渠道模型画像与用户习惯
      memory: {
        enabled: true,
        autoAddModels: true,   // 探测到的模型自动并入渠道模型列表
        learnFeatures: true,   // 全软件功能使用学习（缓存/熔断/回退/健康检测/渠道管理等）
        probeIntervalHours: 6, // 自动探测间隔
        maxModelsPerChannel: 200
      },
      // 本地模型（v2.4.0）：内置 Qwen2.5-7B-Instruct，本地推理 + 工具管理路由
      local: {
        backend: 'llama',                    // llama（内置 llama.cpp）| ollama（外部 Ollama）
        llamaPort: 11435,
        llamaTag: 'b5450',
        source: 'hf-mirror',                 // 模型下载源：hf-mirror（国内镜像，推荐）| modelscope | hf
        modelOrg: 'Qwen',
        modelRepo: 'Qwen2.5-7B-Instruct-GGUF',
        modelFile: 'qwen2.5-7b-instruct-q4_k_m-00001-of-00002.gguf',  // 主文件（llama.cpp -m，自动拼分片）
        modelFiles: [                         // 全部模型文件（分片；单文件时仅主文件）
          'qwen2.5-7b-instruct-q4_k_m-00001-of-00002.gguf',
          'qwen2.5-7b-instruct-q4_k_m-00002-of-00002.gguf'
        ],
        ctxSize: 8192,
        threads: 4,
        ollamaBase: 'http://127.0.0.1:11434',
        ollamaModel: 'qwen2.5:7b',
        maxToolRounds: 5,
        tools: true,                         // 本地模型工具集开关（管理路由用）
        // 自动休眠/唤醒（v2.6.2）：空闲 N 分钟自动停引擎释放内存，路由有请求自动唤醒
        idleSleepMinutes: 15,                // 0=关闭自动休眠
        autoWake: true,                      // 路由请求进来自动唤醒引擎
        // 路由大脑（v2.5.0）：本地模型作为路由器大脑，不参与对话回答
        brainEnabled: true,                  // 大脑总开关
        brainAutoStart: true,                // 引擎运行后自动开始定时巡检
        brainIntervalMin: 15,                // 定时巡检间隔（分钟）
        brainWakeOnEvents: true              // 熔断/限流/Key保护 事件唤醒
      },
      stats: {
        totalRequests: 0,
        successCount: 0,
        failCount: 0,
        providerStats: {}
      },
      // 远程访问与迁移（v3.0.0）：云服务器域名绑定 + 账号密码 + 跨设备迁移
      remote: {
        enabled: false,          // 远程访问总开关（开启后监听 0.0.0.0:port，务必设账号密码）
        port: 3457,              // 远程监听端口
        username: 'admin',       // 远程账号
        passwordHash: null,      // sha256(salt+password)，不存明文
        salt: null,
        tokenHours: 24,
        allowMigrate: true       // 允许远程导出配置（渠道+Key）
      }
    };
  }

  save(data) {
    this.config = { ...this.config, ...data };
    this.persist();
    return this.config;
  }

  persist() {
    // H5 修复：原子写（先写 .tmp 再 rename），避免断电/进程崩溃时配置文件截断损坏
    try {
      const dir = path.dirname(this.configPath);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      const tmp = this.configPath + '.tmp';
      const content = JSON.stringify(this.config, null, 2);
      fs.writeFileSync(tmp, content, 'utf-8');
      // rename 在同一文件系统上是原子操作（POSIX 语义；Windows NTFS 也基本满足）
      fs.renameSync(tmp, this.configPath);
      this._lastFlushAt = Date.now();
    } catch (e) {
      console.error('保存配置失败:', e.message);
    }
  }

  /**
   * H5 修复：防抖落盘（高频写场景专用）。
   * 配额/统计/远程状态等每请求都变的字段用这个写盘，30s 内合并写一次。
   * 用户主动改配置（set / save）仍走 persist() 立即写。
   */
  persistDebounced(delayMs) {
    if (this._persistTimer) return;
    const delay = typeof delayMs === 'number' ? delayMs : this._persistDelayMs;
    this._persistTimer = setTimeout(() => {
      this._persistTimer = null;
      this.persist();
    }, delay);
  }

  /** 强制立即 flush（应用退出前 / 用户主动保存） */
  flushNow() {
    if (this._persistTimer) { clearTimeout(this._persistTimer); this._persistTimer = null; }
    this.persist();
  }

  /** 退出时清理（清理 timer，强制 flush 一次） */
  shutdown() {
    this.flushNow();
  }

  getAll() {
    return this.config;
  }

  get(key) {
    return key.split('.').reduce((obj, k) => obj?.[k], this.config);
  }

  set(key, value) {
    const keys = key.split('.');
    const last = keys.pop();
    const target = keys.reduce((obj, k) => {
      // 仅当中间键缺失（undefined）时创建容器；避免把合法的 0 / '' / false 误判为「不存在」而覆盖
      if (obj[k] === undefined) obj[k] = {};
      return obj[k];
    }, this.config);
    target[last] = value;
    this.persist();
  }

  reset() {
    this.config = this.defaultConfig();
    this.persist();
    return this.config;
  }

  // --- 服务商管理 ---
  addProvider(provider) {
    const p = {
      id: crypto.randomUUID(),
      name: provider.name || '未命名服务商',
      baseUrl: provider.baseUrl || '',
      keys: provider.keys || [],
      models: provider.models || [],
      enabled: provider.enabled !== false,
      priority: provider.priority || this.config.providers.length + 1,
      keyIndex: 0,
      keyStats: {},
      region: provider.region || 'any',  // 数据驻留区域：any | CN | US | EU ...
      pathStyle: provider.pathStyle || 'v1',  // 接口路径：'v1'=自动拼 /v1；'none'=完整路径（智谱/千帆/Groq 等）
      kind: provider.kind || 'remote',        // 渠道类型（v2.4.0）：remote=云端 OpenAI 兼容；local=内置本地模型引擎
      // 计费方式（v2.0.4）：tokens=按 tokens 计费（配合价格表），count=按调用次数计费（固定单价/次）
      billing: provider.billing || { mode: 'tokens', pricePerCall: 0 },
      weights: { latencyMs: null, successRate: 1, requests: 0 },  // 加权路由用
      circuit: { failures: 0, open: false, openedAt: null },        // 熔断状态
      quotaUsed: { periodKey: null, requests: 0, tokens: 0 }        // 配额用量
    };
    // 初始化 key 统计
    p.keys.forEach((k, i) => {
      p.keyStats[i] = { requests: 0, errors: 0, consecutiveErrors: 0, lastUsed: null, disabled: false };
    });
    this.config.providers.push(p);
    this.persist();
    return p;
  }

  updateProvider(id, data, opts = {}) {
    const idx = this.config.providers.findIndex(p => p.id === id);
    if (idx === -1) return null;

    const old = this.config.providers[idx];
    // M1 修复：写操作自增 _configVersion（用于 healthcheck 乐观锁 CAS）
    // 每次 updateProvider 调用都让 _configVersion +1（包括纯 quota/stats 写入），
    // healthcheck 检测前读快照，恢复时再读一次 CAS，
    // 若中间有任何 updateProvider 介入（典型场景：请求失败触发 disableKey），
    // 版本号不一致，健康检测会跳过本次自动恢复。
    const newVersion = (old._configVersion || 0) + 1;
    const updated = { ...old, ...data, _configVersion: newVersion };

    // 如果 keys 变了，重新初始化 keyStats（保留旧的统计数据）
    if (data.keys && data.keys.length !== old.keys.length) {
      const newKeyStats = {};
      data.keys.forEach((k, i) => {
        newKeyStats[i] = old.keyStats?.[i] || { requests: 0, errors: 0, consecutiveErrors: 0, lastUsed: null, disabled: false };
      });
      updated.keyStats = newKeyStats;
      updated.keyIndex = 0;
    }

    this.config.providers[idx] = updated;
    // H5 修复：debounce 选项供高频写场景（quota/stats/keyStats）合并落盘
    if (opts.debounce) this.persistDebounced();
    else this.persist();
    return updated;
  }

  removeProvider(id) {
    this.config.providers = this.config.providers.filter(p => p.id !== id);
    // 同步清理配额限制
    if (this.config.routing?.quota?.limits?.[id]) {
      delete this.config.routing.quota.limits[id];
    }
    this.persist();
    return true;
  }

  getProviders() {
    return this.config.providers;
  }

  getEnabledProviders() {
    return this.config.providers.filter(p => p.enabled);
  }
}

module.exports = { ConfigManager, BUILTIN_PRICES, PROVIDER_PRESETS };
