/**
 * 请求级意图/复杂度识别（v2.10.0，借鉴 OmniRoute intentClassifier + complexityRouter + taskFitness）
 *
 * 1. classifyIntent：基于正则/关键词的轻量意图分类（免费、微秒级，不用 LLM）：
 *    code（代码生成/调试）/ translate（翻译）/ math（数学）/ summary（总结）/
 *    creative（创意写作）/ chat（默认问答）
 * 2. complexityScore：按输入规模 + 意图 + 结构评估复杂度（simple/medium/complex）
 * 3. modelStrength：按模型名启发式判断"强度"（strong/medium/fast）
 * 4. taskFitness：模型 × 意图 × 复杂度的匹配评分（回退排序 / auto 选模型用）
 */

const CODE_HINTS = /```|~~~|<\/?[a-z]+>|\b(function|const|let|var|class|import|export|def|return|if|else|for|while|async|await|lambda|=>|print\(|console\.|require\(|git|npm|yarn|docker|curl|api)\b|接口|代码|报错|错误|调试|修复|bug|编译|运行|部署|脚本|函数|写法|实现/i;
const TRANSLATE_HINTS = /翻译|译成|translate|translation|译一下|翻成/i;
const MATH_HINTS = /计算|数学|方程|积分|导数|求和|概率|统计|几何|微积分|solve|equation|calculate|math|∑|√|π|\b\d+\s*[+\-*/×÷]\s*\d+/;
const SUMMARY_HINTS = /总结|摘要|概括|归纳|要点|提炼|summar|要点列出|简而言之/i;
const CREATIVE_HINTS = /写(一)?(首|篇|个)|创作|小说|诗歌|故事|剧本|文案|广告语|对联|作文|创意|脑洞|情节|角色设定/i;
const CODE_INTENT_WORDS = /(帮我)?(写|生成|实现|解释|优化|重构|修复|调试).{0,20}(代码|函数|脚本|程序|接口)|(代码|程序|脚本).{0,20}(报错|问题|bug|优化|重构)/i;

/**
 * 意图分类
 * @param {Array} messages
 * @returns {{ intent: string, confidence: number }}
 */
function classifyIntent(messages) {
  const text = (messages || []).map(m => {
    if (typeof m?.content === 'string') return m.content;
    if (Array.isArray(m?.content)) return m.content.map(c => c?.text || '').join(' ');
    return '';
  }).join('\n').slice(0, 3000);

  const scores = { code: 0, translate: 0, math: 0, summary: 0, creative: 0, chat: 0.1 };
  if (CODE_HINTS.test(text)) scores.code += 3;
  if (CODE_INTENT_WORDS.test(text)) scores.code += 2;
  if (TRANSLATE_HINTS.test(text)) scores.translate += 4;
  if (MATH_HINTS.test(text)) scores.math += 4;
  if (SUMMARY_HINTS.test(text)) scores.summary += 3.5;
  if (CREATIVE_HINTS.test(text)) scores.creative += 3;

  // 加权：代码优先（代码类请求最需要强模型）
  if (scores.code > 0) scores.code += 1;

  const entries = Object.entries(scores).sort((a, b) => b[1] - a[1]);
  const top = entries[0];
  const second = entries[1] || ['chat', 0];
  const confidence = top[1] > 0 ? Math.min(0.99, top[1] / (top[1] + second[1] + 0.5)) : 0;
  return { intent: top[0], confidence: +confidence.toFixed(2) };
}

/**
 * 复杂度评估
 * @returns {{ level: 'simple'|'medium'|'complex', score: number, tokens: number }}
 */
function complexityScore(messages) {
  let chars = 0;
  let hasArrayContent = false;
  for (const m of messages || []) {
    if (typeof m?.content === 'string') chars += m.content.length;
    else if (Array.isArray(m?.content)) { chars += m.content.map(c => (c?.text || '').length).reduce((a, b) => a + b, 0); hasArrayContent = true; }
  }
  const tokens = Math.ceil(chars / 2);
  let score = 0;
  if (tokens > 4000) score += 3;
  else if (tokens > 1000) score += 2;
  else if (tokens > 300) score += 1;
  if (hasArrayContent) score += 1;      // 多模态
  const intent = classifyIntent(messages).intent;
  if (intent === 'code' || intent === 'math') score += 1;
  if (intent === 'creative') score += 1; // 长文创作
  const level = score >= 4 ? 'complex' : score >= 2 ? 'medium' : 'simple';
  return { level, score, tokens };
}

/**
 * 模型强度（名称启发式，用户可覆盖）
 * @param {string} model
 * @param {object} overrides { strong: [..], fast: [..] }（来自配置 routing.modelStrength）
 * @returns {'strong'|'medium'|'fast'}
 */
function modelStrength(model, overrides = {}) {
  const m = String(model || '').toLowerCase();
  if ((overrides.strong || []).some(x => m.includes(String(x).toLowerCase()))) return 'strong';
  if ((overrides.fast || []).some(x => m.includes(String(x).toLowerCase()))) return 'fast';
  if (/(pro|max|ultra|plus|opus|sonnet|premium|premier|glm-4|glm-5|4o|o1|o3|claude-3-5|claude-3-7|kimi-?k2|deepseek-(r1|v3)|qwen3|qwen-max|gpt-4|flash-thinking|thinking)/.test(m)) return 'strong';
  if (/(flash|mini|tiny|nano|fast|speed|light|lite|small|instant|cheap|8b|7b|1\.5b|3b|sensenova-6\.(7|8)-flash|agnes-2\.[01]-flash|deepseek-v4-flash)/.test(m)) return 'fast';
  return 'medium';
}

/**
 * 任务-模型匹配度（0~1.5+）：
 * 强模型利于复杂/代码/数学；快模型利于简单闲聊（便宜快）
 */
function taskFitness(model, intent, complexityLevel, overrides = {}) {
  const strength = modelStrength(model, overrides);
  const base = strength === 'strong' ? 1 : strength === 'medium' ? 0.6 : 0.35;
  let fit = base;
  const hard = intent === 'code' || intent === 'math' || intent === 'creative';
  if (hard && strength === 'strong') fit += 0.3;
  if (hard && strength === 'fast') fit -= 0.15;
  if (complexityLevel === 'complex' && strength === 'strong') fit += 0.3;
  if (complexityLevel === 'complex' && strength === 'fast') fit -= 0.2;
  if ((intent === 'chat' || intent === 'translate' || intent === 'summary') && strength === 'fast') fit += 0.25;
  if (complexityLevel === 'simple' && strength === 'fast') fit += 0.2;
  if (complexityLevel === 'simple' && strength === 'strong') fit -= 0.35;
  return +fit.toFixed(3);
}

/**
 * 综合：对一条请求算出 意图/复杂度/推荐模型强度档
 */
function analyzeRequest(messages, overrides = {}) {
  const intent = classifyIntent(messages);
  const complexity = complexityScore(messages);
  const hard = intent.intent === 'code' || intent.intent === 'math' || intent.intent === 'creative' || complexity.level === 'complex';
  return {
    intent: intent.intent,
    intentConfidence: intent.confidence,
    complexity: complexity.level,
    complexityScore: complexity.score,
    tokens: complexity.tokens,
    preferredStrength: hard ? 'strong' : 'fast'
  };
}

module.exports = { classifyIntent, complexityScore, modelStrength, taskFitness, analyzeRequest };
