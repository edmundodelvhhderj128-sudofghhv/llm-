/**
 * 内存命中缓存（LRU）- 利用内存空间缓存 LLM 响应，降低重复请求成本、提高命中率
 *
 * 特性：
 * - 按字节数限制内存占用（默认 1GB），超出后按 LRU 淘汰最久未使用的条目
 * - 缓存键 = sha1(模型 + 消息 + 参数)，stream 标志不参与（流式/非流式共用缓存）
 * - 记录 命中/未命中/淘汰/占用 统计，供设置页展示
 */
const crypto = require('crypto');

// 默认上限：1GB
const DEFAULT_MAX_BYTES = 1024 * 1024 * 1024;
// 条目数上限：防止小响应过多导致 Map 开销失控
const DEFAULT_MAX_ENTRIES = 20000;
// 每条目固定内存开销估算（对象/Map 节点等）
const ENTRY_OVERHEAD = 256;

class MemoryCache {
  constructor(options = {}) {
    this.maxBytes = options.maxBytes || DEFAULT_MAX_BYTES;
    this.maxEntries = options.maxEntries || DEFAULT_MAX_ENTRIES;
    // Map 的插入顺序即 LRU 顺序（get/put 时 delete + set 移到末尾）
    this.entries = new Map();
    this.usedBytes = 0;
    this.hits = 0;
    this.misses = 0;
    this.evictions = 0;
  }

  /**
   * 生成缓存键（与 stream 标志无关，保证流式/非流式共用同一份缓存）
   * @param {string} model 请求模型
   * @param {Array} messages 消息数组
   * @param {Object} rest 其余参数（temperature/max_tokens 等，已剔除 stream/noCache）
   * @param {string} variant 变体签名（如压缩配置），用于隔离不同机制下的缓存条目
   */
  static key(model, messages, rest = {}, variant = '') {
    const payload = JSON.stringify({ model, messages, rest, variant });
    return crypto.createHash('sha1').update(payload).digest('hex');
  }

  /**
   * 估算响应占用的内存字节数（JSON 序列化长度 × 2 近似 UTF-16 存储 + 开销）
   */
  getSize(value) {
    try {
      return Buffer.byteLength(JSON.stringify(value), 'utf8') * 2 + ENTRY_OVERHEAD;
    } catch (e) {
      return 1024;
    }
  }

  /**
   * 读取缓存（命中则更新 LRU 顺序）
   * @returns {Object|null} 缓存的响应数据
   */
  get(key) {
    const entry = this.entries.get(key);
    if (!entry) {
      this.misses++;
      return null;
    }
    this.hits++;
    entry.hits++;
    entry.lastAccess = Date.now();
    // LRU touch：移到 Map 末尾
    this.entries.delete(key);
    this.entries.set(key, entry);
    return entry.data;
  }

  /**
   * 写入缓存；超限按 LRU 淘汰
   * @returns {boolean} 是否成功写入（单条超过上限时返回 false）
   */
  put(key, data) {
    if (!data) return false;
    const size = this.getSize(data);
    // 单条响应超过总上限：不缓存（避免一条撑爆）
    if (size > this.maxBytes) return false;

    const existing = this.entries.get(key);
    if (existing) {
      this.usedBytes -= existing.size;
      this.entries.delete(key);
    }

    const entry = { data, size, hits: 0, createdAt: Date.now(), lastAccess: Date.now() };
    this.entries.set(key, entry);
    this.usedBytes += size;

    this.evictIfNeeded(key);
    return true;
  }

  /**
   * 淘汰最久未使用的条目，直到低于上限
   */
  evictIfNeeded(keepKey = null) {
    while (this.usedBytes > this.maxBytes && this.entries.size > 1) {
      const oldestKey = this.entries.keys().next().value;
      // 至少保留刚写入/刚访问的条目（避免单条大响应反复抖动）
      if (oldestKey === keepKey) {
        // 尝试淘汰第二旧的
        const it = this.entries.keys();
        it.next();
        const second = it.next().value;
        if (second == null) break;
        this.removeEntry(second);
        continue;
      }
      this.removeEntry(oldestKey);
    }
    while (this.entries.size > this.maxEntries) {
      const oldestKey = this.entries.keys().next().value;
      if (oldestKey == null) break;
      this.removeEntry(oldestKey);
    }
  }

  removeEntry(key) {
    const entry = this.entries.get(key);
    if (!entry) return;
    this.usedBytes -= entry.size;
    this.entries.delete(key);
    this.evictions++;
  }

  /**
   * 清空缓存
   */
  clear() {
    this.entries.clear();
    this.usedBytes = 0;
    this.hits = 0;
    this.misses = 0;
    this.evictions = 0;
  }

  /**
   * 统计信息
   */
  stats() {
    const total = this.hits + this.misses;
    return {
      maxBytes: this.maxBytes,
      sizeBytes: this.usedBytes,
      entries: this.entries.size,
      hits: this.hits,
      misses: this.misses,
      evictions: this.evictions,
      hitRate: total > 0 ? +((this.hits / total) * 100).toFixed(1) : 0
    };
  }
}

module.exports = { MemoryCache, DEFAULT_MAX_BYTES, DEFAULT_MAX_ENTRIES };
