/**
 * 强制内容拦截（合规安全，v2.2.2）
 *
 * 特性：
 * - 始终生效，不可通过配置 / UI / 服务商设置关闭
 * - 覆盖三类内容：成人内容、暴力恐怖、国内政治敏感（违法类）
 * - 关键词以编码形式（ROT13 + Base64 分段）存储，源码中无明文，提高被直接检索/删除的难度
 * - 输入拦截：命中直接拒绝请求（403，仅返回通用提示，不泄露命中词）
 * - 输出拦截：命中内容替换为通用提示（非流式）
 *
 * 说明：本模块运行于用户本机（Electron 主进程），属于"尽力加固"——
 * 任何本机代码理论上都可被修改，绝对不可删除在技术上无法保证。
 */
const crypto = require('crypto');

// 编码分片（ROT13(Base64(JSON(words)))），源码不含明文关键词
const ENCODED_CHUNKS = [
  'WyLoibLmg4UiLCLmt6vnp70iLCLoo7jogYoiLCLljZbmt6siLCLlq5blqLwiLCLmg4XoibIiXQ==',
  'WyLoibLmg4XnvZHnq5kiLCLoibLmg4Xop4bpopEiLCLpu4ToibLnvZHnq5kiLCLmg4XoibLkuqTmmJMiLCLmgZDmgJbooq3lh7siLCLmgZDmgJbkuLvkuYkiXQ==',
  'WyLniIbngrjnianliLbkvZwiLCLliLbniIYiLCLmnqrmlK/kubDljZYiLCLmr5Llk4HliLbkvZwiLCLliLbmr5IiLCLmnYDkurrnoo7lsLgiXQ==',
  'WyLnu5Hmnrbli5LntKIiLCLmnoHnq6/kuLvkuYkiLCLoh6rmnYDlvI/ooq3lh7siLCLkurrkvZPngrjlvLkiLCLpoqDopoblm73lrrbmlL/mnYMiLCLliIboo4Llm73lrrYiXQ==',
  'WyLnhb3liqjpoqDopoYiLCLpgqrmlZnnu4Tnu4ciLCLms5Xova7lip8iLCLlha3lm5vkuovku7YiLCLlpKnlronpl6jkuovku7YiXQ=='
];

function rot13(s) {
  return s.replace(/[a-zA-Z]/g, (c) => {
    const base = c <= 'Z' ? 65 : 97;
    return String.fromCharCode(((c.charCodeAt(0) - base + 13) % 26) + base);
  });
}

function decodeWords() {
  const out = [];
  for (const chunk of ENCODED_CHUNKS) {
    try {
      const json = rot13(Buffer.from(chunk, 'base64').toString('utf8'));
      const words = JSON.parse(json);
      if (Array.isArray(words)) out.push(...words);
    } catch (e) { /* 忽略损坏分片 */ }
  }
  return out;
}

const BLOCK_WORDS = decodeWords();
const GENERIC_REASON = '内容未通过审核';
const REDACT_TEXT = '【内容已被自动拦截】';

class MandatoryGuard {
  /**
   * 校验文本是否命中强制拦截
   */
  check(text) {
    if (!text) return false;
    const t = String(text).toLowerCase();
    return BLOCK_WORDS.some(w => t.includes(w.toLowerCase()));
  }

  /**
   * 校验消息数组
   */
  checkMessages(messages) {
    for (const m of messages || []) {
      if (typeof m?.content === 'string' && this.check(m.content)) return true;
    }
    return false;
  }

  /**
   * 输出替换：命中则替换为通用提示
   */
  redact(text) {
    return this.check(text) ? REDACT_TEXT : text;
  }

  get wordCount() {
    return BLOCK_WORDS.length;
  }

  get genericReason() {
    return GENERIC_REASON;
  }

  /**
   * 模块完整性指纹（供测试校验源码未被明文污染）
   */
  static fingerprint() {
    return crypto.createHash('sha256').update(JSON.stringify(BLOCK_WORDS)).digest('hex');
  }
}

module.exports = { MandatoryGuard };
