/**
 * 远程访问与迁移管理（v3.0.0）
 *
 * 功能：
 * 1. 远程认证：账号密码（sha256+salt 存储，不存明文）→ 签发 24h token；非本机请求必须带 token
 * 2. 迁移 API：/remote/export 导出完整配置（渠道+Key+价格+路由+记忆）供 B 电脑一键导入
 * 3. Nginx 反代一键配置：生成 server 块 + Let's Encrypt certbot 自动申请/续期命令
 *
 * 安全说明：
 * - 远程访问默认关闭；开启后监听 0.0.0.0:remote.port
 * - 迁移数据含 API Key，强烈建议配 Nginx + HTTPS 后使用
 */
const crypto = require('crypto');

class RemoteManager {
  constructor(config) {
    this.config = config;
    this.tokens = new Map();        // token -> expiresAt
    this.loginFails = new Map();    // ip -> { count, lockUntil } 登录失败限速
  }

  cfg() {
    return {
      enabled: false,          // 远程访问总开关
      port: 3457,              // 远程监听端口（本地代理默认 3456 不变）
      username: 'admin',
      passwordHash: null,      // sha256(salt + password)
      salt: crypto.randomBytes(8).toString('hex'),
      apiKey: null,            // 远程 API Key（v3.0.1）：静态 Key 免登录直连（可重置）
      tokenHours: 24,
      allowMigrate: true,      // 允许远程迁移（导出配置）
      ...(this.config.get('remote') || {})
    };
  }

  /** 确保远程 API Key 存在（启用时自动生成） */
  ensureApiKey() {
    const c = this.cfg();
    if (c.apiKey) return c.apiKey;
    const key = 'zr_' + crypto.randomBytes(20).toString('hex');
    this.config.set('remote', { ...c, apiKey: key });
    return key;
  }

  /** 重新生成远程 API Key（旧 Key 立即失效） */
  regenerateApiKey() {
    const c = this.cfg();
    const key = 'zr_' + crypto.randomBytes(20).toString('hex');
    this.config.set('remote', { ...c, apiKey: key });
    return key;
  }

  verifyApiKey(key) {
    const c = this.cfg();
    return !!c.apiKey && key === c.apiKey;
  }

  /** 设置账号密码（存哈希） */
  setCredentials(username, password) {
    const c = this.cfg();
    const salt = crypto.randomBytes(8).toString('hex');
    const hash = crypto.createHash('sha256').update(salt + password).digest('hex');
    this.config.set('remote', { ...c, username: username || 'admin', salt, passwordHash: hash });
    return { ok: true };
  }

  verifyPassword(password) {
    const c = this.cfg();
    if (!c.passwordHash) return false;
    const hash = crypto.createHash('sha256').update(c.salt + password).digest('hex');
    return hash === c.passwordHash;
  }

  /** 登录换取 token（带失败限速，防暴力破解） */
  login(username, password, ip) {
    const c = this.cfg();
    if (!c.enabled) return { ok: false, error: '远程访问未启用' };

    // 登录失败限速：同一来源 5 次失败后锁定 15 分钟
    const fail = this.loginFails.get(ip) || { count: 0, lockUntil: 0 };
    if (fail.lockUntil > Date.now()) {
      return { ok: false, error: '登录尝试过于频繁，请 15 分钟后再试' };
    }

    if (username !== c.username || !this.verifyPassword(password)) {
      fail.count += 1;
      if (fail.count >= 5) {
        fail.lockUntil = Date.now() + 15 * 60 * 1000; // 锁定 15 分钟
        console.warn(`[远程] 来源 ${ip} 登录失败 ${fail.count} 次，已临时锁定 15 分钟`);
      }
      this.loginFails.set(ip, fail);
      return {  ok: false, error: '账号或密码错误' };
    }

    // 登录成功：清除失败计数
    this.loginFails.delete(ip);
    const token = crypto.randomBytes(24).toString('hex');
    this.tokens.set(token, Date.now() + (c.tokenHours || 24) * 3600 * 1000);
    // 清理过期
    for (const [t, exp] of this.tokens) if (exp < Date.now()) this.tokens.delete(t);
    return { ok: true, token, expiresIn: (c.tokenHours || 24) * 3600 };
  }

  isTokenValid(token) {
    if (!token) return false;
    const exp = this.tokens.get(token);
    if (!exp) return false;
    if (exp < Date.now()) { this.tokens.delete(token); return false; }
    return true;
  }

  /**
   * 是否本机来源（放行，无需认证）
   * 安全修复：经过反向代理（Nginx 等）转发的请求，其 TCP 来源是代理本身（127.0.0.1），
   * 不能据此判定为「本机可信」。若请求携带 X-Forwarded-For / X-Real-IP 等代理头，
   * 说明实际来自外部，必须走账号密码 / Token 认证，避免免密穿透导出密钥。
   */
  isLocal(req) {
    if (req.headers['x-forwarded-for'] || req.headers['x-real-ip']) return false;
    const ip = req.socket?.remoteAddress || '';
    return ip === '127.0.0.1' || ip === '::1' || ip === '::ffff:127.0.0.1';
  }

  /** 提取真实来源 IP（优先取代理头，兼容反代场景） */
  clientIp(req) {
    const fwd = req.headers['x-forwarded-for'];
    if (fwd) return String(fwd).split(',')[0].trim();
    const real = req.headers['x-real-ip'];
    if (real) return String(real).trim();
    return req.socket?.remoteAddress || 'unknown';
  }

  /**
   * Express 认证中间件：
   * - 本机请求放行
   * - 远程模式关闭时：非本机一律 403
   * - 远程开启：需要 Bearer token 或 Basic 账号密码（Basic 登录即时换 token）
   */
  authMiddleware() {
    return (req, res, next) => {
      if (this.isLocal(req)) return next();
      const c = this.cfg();
      if (!c.enabled) {
        return res.status(403).json({ error: { message: '远程访问未启用' } });
      }
      const auth = req.headers.authorization || '';
      const apiKey = req.headers['x-router-remote-key'] || '';
      // 远程 API Key（v3.0.1）：专用头 或 Bearer 直接携带（免登录）
      if (apiKey && this.verifyApiKey(apiKey)) return next();
      if (auth.startsWith('Bearer ')) {
        const token = auth.slice(7).trim();
        if (this.isTokenValid(token)) return next();
        if (this.verifyApiKey(token)) return next();   // Bearer 也可带远程 Key
        return res.status(401).json({ error: { message: 'token 无效或已过期' } });
      }
      if (auth.startsWith('Basic ')) {
        try {
          const decoded = Buffer.from(auth.slice(6), 'base64').toString('utf8');
          const idx = decoded.indexOf(':');
          const u = decoded.slice(0, idx), p = decoded.slice(idx + 1);
          if (u === c.username && this.verifyPassword(p)) return next();
        } catch (e) { /* fallthrough */ }
        return res.status(401).json({ error: { message: '账号或密码错误' } });
      }
      return res.status(401).json({ error: { message: '需要认证' } });
    };
  }

  /**
   * 挂载远程路由到 express app
   */
  attach(app, ctx = {}) {
    // 登录（无需认证）
    app.post('/remote/login', expressJson(), (req, res) => {
      const { username, password } = req.body || {};
      const ip = this.clientIp(req);
      const r = this.login(username || '', password || '', ip);
      res.status(r.ok ? 200 : 401).json(r);
    });

    // 迁移导出（需认证）
    app.post('/remote/export', this.authMiddleware(), (req, res) => {
      const c = this.cfg();
      if (!c.allowMigrate) return res.status(403).json({ error: { message: '远程迁移已关闭' } });
      try {
        const { config, memory, version } = ctx.exportAll ? ctx.exportAll() : {};
        res.json({
          ok: true,
          app: '子沐智能中转路由',
          version,
          exportedAt: new Date().toISOString(),
          config,
          memory
        });
      } catch (e) {
        res.status(500).json({ ok: false, error: e.message });
      }
    });

    // 远程状态（需认证）
    app.get('/remote/status', this.authMiddleware(), (_req, res) => {
      res.json({ ok: true, app: '子沐智能中转路由', version: ctx.version, remote: true });
    });
  }
  /**
   * 生成 Nginx 反向代理配置（域名 → 本机远程端口）
   * @param {string} domain 如 router.example.com
   * @param {number} remotePort 远程端口（默认 cfg.port）
   * @returns {{ nginxConf: string, certbotCmd: string, renewCmd: string, tips: string[] }}
   */
  genNginxConf(domain, remotePort) {
    const port = remotePort || this.cfg().port || 3457;
    const nginxConf = `# 子沐智能中转路由 Nginx 反向代理（HTTP→HTTPS + WebSocket）
server {
    listen 80;
    server_name ${domain};

    # Let's Encrypt 验证路径（certbot 自动创建）
    location /.well-known/acme-challenge/ {
        root /var/www/certbot;
    }

    location / {
        return 301 https://$host$request_uri;
    }
}

server {
    listen 443 ssl http2;
    server_name ${domain};

    ssl_certificate     /etc/letsencrypt/live/${domain}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/${domain}/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;

    # 长响应/流式 SSE
    proxy_buffering off;
    proxy_read_timeout 300s;
    proxy_send_timeout 300s;
    client_max_body_size 100m;

    location / {
        proxy_pass http://127.0.0.1:${port};
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # WebSocket / SSE
        proxy_http_version 1.1;
        proxy_set_header Connection '';
        chunked_transfer_encoding off;
    }
}
`;
    const certbotCmd = `# 安装 certbot 后首次申请证书（需先解析 ${domain} → 本机公网 IP，并在防火墙放行 80/443）：
sudo certbot certonly --webroot -w /var/www/certbot -d ${domain} --email you@example.com --agree-tos --no-eff-email
# 然后：sudo nginx -s reload`;
    const renewCmd = `# 证书自动续期（Let's Encrypt 证书 90 天有效，建议 cron 每月执行两次）：
# crontab -e 添加：
# 0 3 1,15 * * sudo certbot renew --quiet --renew-hook "sudo nginx -s reload"`;
    return {
      nginxConf,
      certbotCmd,
      renewCmd,
      tips: [
        '1. 云服务器安全组放行 80/443 端口；2. 域名 A 记录解析到服务器公网 IP；3. 软件内启用远程访问并设置账号密码；4. 执行 certbot 申请证书后 reload nginx；5. 证书每 90 天自动续期（cron）',
        '迁移/远程调用含 API Key，务必走 HTTPS；远程访问默认关闭，用后可在软件内关闭' + '。'
      ]
    };
  }
}

// 兼容 proxy.js 的 express.json 引用（避免循环依赖，直接 require）
function expressJson() {
  // 从 express 获取（proxy.js 已加载）
  const express = require('express');
  return express.json({ limit: '20mb' });
}

module.exports = { RemoteManager };
