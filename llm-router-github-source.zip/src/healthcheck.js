/**
 * 健康检测器 v2.0 - 定期检查服务商和 Key 的可用性
 * 新增：Key 自动恢复（检测通过自动重新启用）、真实模型可用性检测、加权路由数据采集
 */
class HealthChecker {
  constructor(config, router) {
    this.config = config;
    this.router = router;
    this.memory = null;   // 记忆系统埋点（由 main 注入）
    this.interval = null;
    this.status = {};  // providerId -> { healthy, latency, lastCheck, error, keyStatus, modelStatus }
    this.onUpdate = null;
  }

  setMemory(mm) {
    this.memory = mm;
  }

  start() {
    const intervalMin = this.config.get('routing.healthCheckInterval') || 5;
    const intervalMs = intervalMin * 60 * 1000;

    // 立即检查一次
    this.checkAll();

    // 定时检查
    this.interval = setInterval(() => this.checkAll(), intervalMs);
    console.log(`健康检测已启动，间隔: ${intervalMin} 分钟`);
  }

  stop() {
    if (this.interval) {
      clearInterval(this.interval);
      this.interval = null;
    }
  }

  async checkAll() {
    const providers = this.config.getProviders();
    const promises = providers.map(p => {
      if (!p.enabled) {
        this.status[p.id] = { healthy: false, latency: null, lastCheck: new Date().toISOString(), error: '已禁用' };
        return Promise.resolve();
      }
      return this.checkProviderById(p.id);
    });

    await Promise.allSettled(promises);
    try {
      const vals = Object.values(this.status);
      this.memory?.trackFeature('health_check', {
        ok: vals.some(s => s.healthy),
        detail: `${vals.filter(s => s.healthy).length}/${vals.length} 渠道正常`
      });
    } catch (e) {}
    this.notifyUpdate();
    return this.status;
  }

  async checkProviderById(providerId) {
    const provider = this.config.getProviders().find(p => p.id === providerId);
    if (!provider) {
      this.status[providerId] = { healthy: false, error: '服务商不存在' };
      return this.status[providerId];
    }

    // 本地模型（v2.4.0）：引擎在跑即健康，无需 Key
    if (provider.kind === 'local') {
      const healthy = !!(this.memory && provider.running !== undefined ? provider.running : this.router?.localEngine?.running);
      this.status[providerId] = {
        healthy, latency: null, lastCheck: new Date().toISOString(),
        error: healthy ? null : '本地引擎未运行', keyStatus: [], modelStatus: [], kind: 'local'
      };
      this.notifyUpdate();
      return this.status[providerId];
    }

    if (!provider.keys.length) {
      this.status[providerId] = {
        healthy: false,
        latency: null,
        lastCheck: new Date().toISOString(),
        error: '未配置 API Key',
        keyStatus: []
      };
      this.notifyUpdate();
      return this.status[providerId];
    }

    // 检查每个 Key
    const keyStatus = [];
    let anyHealthy = false;
    const recoveredKeys = [];

    // M1 修复：乐观锁——读 provider 快照（含 configVersion），恢复 Key 时原子 CAS
    // 防止"检测通过准备恢复"和"请求失败被 disableKey"之间的竞态
    const snapshot = this.config.getProviders().find(p => p.id === providerId) || provider;
    const snapVersion = snapshot._configVersion || 0;

    for (let i = 0; i < provider.keys.length; i++) {
      const key = provider.keys[i];
      const stat = provider.keyStats?.[i] || {};
      const isDisabled = stat.disabled;

      // 被禁用的 Key 也做检测，通过则自动恢复（v1.1 特性，此处真正实现）
      const result = await this.checkKey(provider.baseUrl, key, provider);
      keyStatus.push({
        index: i,
        key: key.substring(0, 8) + '****',
        healthy: result.healthy,
        latency: result.latency,
        error: result.error,
        disabled: isDisabled,
        recovered: false
      });

      if (result.healthy) {
        anyHealthy = true;
        if (isDisabled) {
          // M1 修复：乐观锁 CAS——检测到恢复条件和写入时条件一致，才执行
          // - 当前 configVersion 不变（说明这段时间内未被 router.disableKey 改写）
          // - keyStats[i].disabled === true（仍然是被禁用状态）
          // 任一条件不满足说明有并发写入，跳过本次恢复
          const current = this.config.getProviders().find(p => p.id === providerId);
          const curVersion = current?._configVersion || 0;
          const curStat = current?.keyStats?.[i];
          if (curVersion === snapVersion && curStat?.disabled === true) {
            // 恢复 Key（写操作）
            this.router.resetKeys(provider, i);
            keyStatus[keyStatus.length - 1].disabled = false;
            keyStatus[keyStatus.length - 1].recovered = true;
            recoveredKeys.push(i + 1);
            console.log(`[自动恢复] 服务商 ${provider.name} 的 Key #${i + 1} 检测通过，已重新启用`);
          } else {
            // 有并发写入，本次不恢复（由 router.disableKey 的版本主导）
            keyStatus[keyStatus.length - 1].error = '检测通过但 Key 已被并发修改，跳过自动恢复';
          }
        }
      } else if (isDisabled) {
        // 仍然失败，保持禁用
        keyStatus[keyStatus.length - 1].error = (result.error || '') + '（保持禁用）';
      }
    }

    // 检查模型可用性（用第一个健康的 Key 拉取真实模型列表对比）
    let modelStatus = [];
    if (anyHealthy) {
      modelStatus = await this.checkModels(provider);
    }

    const healthyKey = keyStatus.find(k => k.healthy && !k.disabled);
    const status = {
      healthy: anyHealthy,
      latency: healthyKey?.latency || null,
      lastCheck: new Date().toISOString(),
      error: anyHealthy ? (recoveredKeys.length ? `已自动恢复 ${recoveredKeys.length} 个 Key` : null) : '所有 Key 不可用',
      keyStatus,
      modelStatus,
      recoveredCount: recoveredKeys.length
    };

    // 更新加权路由的延迟数据
    if (healthyKey?.latency) {
      const weights = provider.weights || {};
      const prev = weights.latencyMs || healthyKey.latency;
      weights.latencyMs = Math.round(prev * 0.7 + healthyKey.latency * 0.3);
      weights.requests = weights.requests || 0;
      this.config.updateProvider(provider.id, { weights });
    }

    this.status[providerId] = status;
    this.notifyUpdate();
    return this.status[providerId];
  }

  async checkKey(baseUrl, key, provider) {
    const start = Date.now();
    try {
      const url = `${this.router.apiBase({ baseUrl, pathStyle: provider?.pathStyle || 'v1' })}/models`;
      const response = await fetch(url, {
        headers: { 'Authorization': `Bearer ${key}` },
        signal: AbortSignal.timeout(10000)
      });

      const latency = Date.now() - start;

      if (response.ok) {
        return { healthy: true, latency, error: null };
      } else {
        let errorMsg;
        if (response.status === 401) errorMsg = '认证失败 (Key无效)';
        else if (response.status === 403) errorMsg = '权限不足';
        else if (response.status === 429) errorMsg = '请求频率超限';
        else errorMsg = `HTTP ${response.status}`;
        return { healthy: false, latency, error: errorMsg };
      }
    } catch (error) {
      const latency = Date.now() - start;
      let errorMsg = error.message;
      if (error.name === 'AbortError') errorMsg = '请求超时';
      else if (error.code === 'ENOTFOUND') errorMsg = '无法连接到服务器';
      else if (error.code === 'ECONNREFUSED') errorMsg = '连接被拒绝';
      return { healthy: false, latency, error: errorMsg };
    }
  }

  /**
   * 真实模型可用性检测：拉取服务商模型列表，与本地配置对比
   */
  async checkModels(provider) {
    const configured = provider.models || [];
    if (configured.length === 0) return [];

    try {
      const key = this.router.getActiveKey(provider);
      if (!key) return configured.map(m => ({ name: m, available: false, error: '无可用 Key' }));

      const url = `${this.router.apiBase(provider)}/models`;
      const response = await fetch(url, {
        headers: { 'Authorization': `Bearer ${key}` },
        signal: AbortSignal.timeout(10000)
      });

      if (!response.ok) {
        return configured.map(m => ({ name: m, available: false, error: `HTTP ${response.status}` }));
      }

      const data = await response.json();
      const remote = new Set((data.data || []).map(m => m.id));

      return configured.map(m => ({
        name: m,
        available: remote.has(m),
        error: remote.has(m) ? null : '服务商已下架该模型'
      }));
    } catch (e) {
      return configured.map(m => ({ name: m, available: false, error: e.message }));
    }
  }

  getStatus() {
    return this.status;
  }

  notifyUpdate() {
    if (this.onUpdate) this.onUpdate();
  }
}

module.exports = { HealthChecker };
