/**
 * 内置记忆系统（v2.3.0）
 *
 * 功能：
 * - 渠道模型画像：自动探测并持久化每个渠道的模型清单，按能力分类（对话/图片/视频/嵌入）
 * - Key 级权限学习：同一渠道不同 Key 可能解锁不同模型，按 Key 哈希记录访问权限（不存明文 Key）
 * - 使用习惯学习：记录每次调用的模型/渠道/成功失败/延迟/成本/小时，生成习惯画像与推荐
 * - 自动同步：探测到的模型可自动并入渠道模型列表（可配置上限），让路由直接可用
 *
 * 数据持久化：<userData>/model-memory.json（与 config.json 分离，可随时清空）
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// 与 router.inferModelCapability 保持一致的分类规则（避免循环依赖，此处独立实现）
function classifyModel(model) {
  const m = String(model || '').toLowerCase();
  if (/(image|dall-e|dalle|flux|sdxl|stable-diffusion|midjourney|kolors|seedream|janus|gpt-image|nano-banana|sensenova-u1|agnes-image|hunyuan-image|cogview|pixart|wanx|wan2|wan-2|doubao-seed)/.test(m)) return 'image';
  if (/(video|veo|sora|runway|kling|keling|hailuo|seedance|agnes-video|hunyuan-video|minimax-vl|skyreels)/.test(m)) return 'video';
  if (/(embed|text-embed|bge|mxbai|e5|m3$)/.test(m)) return 'embedding';
  if (/(audio|tts|stt|whisper|speech)/.test(m)) return 'audio';
  return 'chat';
}

class ModelMemory {
  constructor(config, userDataDir, router = null) {
    this.config = config;
    this.router = router;
    this.file = path.join(userDataDir, 'model-memory.json');
    this.data = this.load();
    this._saveTimer = null;
  }

  attachRouter(router) {
    this.router = router;
  }

  cfg() {
    return {
      enabled: true,
      autoAddModels: true,
      learnFeatures: true,       // 整软件功能使用学习（缓存/熔断/回退/管理操作等）
      probeIntervalHours: 6,
      maxModelsPerChannel: 200,
      ...(this.config.get('memory') || {})
    };
  }

  defaultData() {
    return {
      version: 1,
      updatedAt: null,
      totalCalls: 0,
      channels: {},        // providerId -> { name, baseUrl, lastProbedAt, models: {modelName -> entry} }
      usageByHour: {},     // hour -> { model -> count }
      lastUsedByCapability: {}, // capability -> model（最近一次成功使用的各能力模型）
      features: {},        // featureId -> { count, errorCount, firstSeen, lastUsed, byHour }
      events: [],          // 最近功能事件环形缓冲（上限 100 条）
      brainLessons: []     // 大脑积累的经验（v2.6.0 自学习沉淀）
    };
  }

  load() {
    try {
      if (fs.existsSync(this.file)) {
        const raw = fs.readFileSync(this.file, 'utf8').replace(/^\uFEFF/, '');
        const parsed = JSON.parse(raw);
        return { ...this.defaultData(), ...parsed };
      }
    } catch (e) { console.error('记忆加载失败:', e.message); }
    return this.defaultData();
  }

  save() {
    try {
      this.data.updatedAt = new Date().toISOString();
      fs.writeFileSync(this.file, JSON.stringify(this.data, null, 2));
    } catch (e) { console.error('记忆保存失败:', e.message); }
  }

  // 节流保存（高频调用时合并写盘）
  saveDebounced() {
    if (this._saveTimer) return;
    this._saveTimer = setTimeout(() => { this._saveTimer = null; this.save(); }, 3000);
  }

  keyHash(key) {
    return crypto.createHash('sha256').update(String(key || '')).digest('hex').slice(0, 16);
  }

  getChannel(providerId, providerName = '', baseUrl = '') {
    if (!this.data.channels[providerId]) {
      this.data.channels[providerId] = { name: providerName, baseUrl, lastProbedAt: null, models: {} };
    } else {
      if (providerName) this.data.channels[providerId].name = providerName;
      if (baseUrl) this.data.channels[providerId].baseUrl = baseUrl;
    }
    return this.data.channels[providerId];
  }

  /**
   * 记录某渠道（某 Key）下可见的模型清单
   */
  rememberModels(providerId, providerName, modelList, key = null) {
    const cfg = this.cfg();
    if (!cfg.enabled) return;
    const ch = this.getChannel(providerId, providerName);
    const now = new Date().toISOString();
    const kh = key ? this.keyHash(key) : null;
    for (const m of modelList || []) {
      if (!ch.models[m]) {
        ch.models[m] = { capability: classifyModel(m), firstSeen: now, lastSeen: now, keys: [], calls: 0, success: 0, fail: 0, lastUsed: null, latencySum: 0, costSum: 0 };
      } else {
        ch.models[m].lastSeen = now;
      }
      if (kh && !ch.models[m].keys.includes(kh)) ch.models[m].keys.push(kh);
    }
    ch.lastProbedAt = now;
    this.saveDebounced();
  }

  /**
   * 记录一次功能使用（整软件功能画像：缓存/压缩/熔断/回退/健康检测/渠道管理等）
   * @param {string} id 功能标识
   * @param {object} opts { ok, detail }
   */
  trackFeature(id, { ok = true, detail = '' } = {}) {
    const cfg = this.cfg();
    if (!cfg.enabled || cfg.learnFeatures === false) return;
    const now = new Date().toISOString();
    const f = this.data.features[id] || (this.data.features[id] = { count: 0, errorCount: 0, firstSeen: now, lastUsed: null, byHour: {} });
    f.count++;
    if (!ok) f.errorCount++;
    f.lastUsed = now;
    const hour = String(new Date().getHours());
    f.byHour[hour] = (f.byHour[hour] || 0) + 1;
    this.data.events.push({ t: now, id, ok: !!ok, detail: String(detail || '').slice(0, 120) });
    if (this.data.events.length > 100) this.data.events.splice(0, this.data.events.length - 100);
    this.saveDebounced();
  }

  /**
   * 记录一次调用（成功/失败）——习惯学习
   */
  recordCall({ providerId, providerName, model, key = null, ok = true, latency = null, cost = 0 }) {
    const cfg = this.cfg();
    if (!cfg.enabled || !model) return;
    const ch = this.getChannel(providerId, providerName);
    const now = new Date().toISOString();
    if (!ch.models[model]) {
      ch.models[model] = { capability: classifyModel(model), firstSeen: now, lastSeen: now, keys: [], calls: 0, success: 0, fail: 0, lastUsed: null, latencySum: 0, costSum: 0 };
    }
    const m = ch.models[model];
    m.calls++;
    if (ok) m.success++; else m.fail++;
    m.lastUsed = now;
    if (latency != null) m.latencySum += latency;
    if (cost) m.costSum += cost;
    if (key) {
      const kh = this.keyHash(key);
      if (!m.keys.includes(kh)) m.keys.push(kh);
    }

    // 分时使用习惯
    const hour = String(new Date().getHours());
    if (!this.data.usageByHour[hour]) this.data.usageByHour[hour] = {};
    this.data.usageByHour[hour][model] = (this.data.usageByHour[hour][model] || 0) + 1;
    this.data.totalCalls++;

    // 最近使用（按能力）
    if (ok) this.data.lastUsedByCapability[m.capability] = model;

    this.saveDebounced();
  }

  /**
   * 探测渠道：用每个 Key（上限 3 个）拉取 /v1/models，学习 Key 级模型权限
   */
  async probeChannel(provider) {
    const cfg = this.cfg();
    const results = [];
    if (!cfg.enabled || !provider || !provider.enabled) return results;
    const keys = (provider.keys || []).slice(0, 3);
    if (keys.length === 0) return results;
    if (!this.router) return results;

    for (const key of keys) {
      try {
        const url = `${this.router.apiBase(provider)}/models`;
        const res = await fetch(url, {
          headers: { 'Authorization': `Bearer ${key}` },
          signal: AbortSignal.timeout(10000)
        });
        if (res.ok) {
          const data = await res.json();
          const models = (data.data || []).map(m => m.id).filter(Boolean);
          this.rememberModels(provider.id, provider.name, models, key);
          results.push({ key: String(key).slice(0, 8) + '****', count: models.length });
        } else {
          results.push({ key: String(key).slice(0, 8) + '****', error: `HTTP ${res.status}` });
        }
      } catch (e) {
        results.push({ key: String(key).slice(0, 8) + '****', error: e.message });
      }
    }
    return results;
  }

  async probeAll() {
    const providers = this.config.getEnabledProviders();
    const out = {};
    for (const p of providers) {
      out[p.id] = await this.probeChannel(p);
    }
    this.syncModelsToProviders();
    // 探测结果日志（便于排查：为什么某个渠道没学到模型）
    try {
      const summary = Object.entries(out).map(([pid, results]) => {
        const ch = this.data.channels[pid];
        return `${ch?.name || pid}: ${results.length} 个Key探测，${Object.keys(ch?.models || {}).length} 个模型`;
      }).join('；');
      console.log('[记忆] 渠道探测完成: ' + (summary || '无渠道'));
    } catch (e) {}
    return out;
  }

  /**
   * 把记忆中的模型同步到渠道模型列表（自动并入，可配置上限），让路由直接可用
   */
  syncModelsToProviders() {
    const cfg = this.cfg();
    if (!cfg.autoAddModels) return 0;
    let added = 0;
    for (const [pid, ch] of Object.entries(this.data.channels)) {
      const provider = this.config.getProviders().find(p => p.id === pid);
      if (!provider) continue;
      const memModels = Object.keys(ch.models || {});
      if (memModels.length === 0) continue;
      const cap = cfg.maxModelsPerChannel || 200;
      const merged = [...new Set([...(provider.models || []), ...memModels])].slice(0, cap);
      if (merged.length !== (provider.models || []).length) {
        this.config.updateProvider(pid, { models: merged });
        added += merged.length - (provider.models || []).length;
      }
    }
    return added;
  }

  /**
   * 统计报告（UI 用）
   */
  getReport() {
    const channels = Object.entries(this.data.channels).map(([id, ch]) => {
      const models = Object.entries(ch.models || {}).map(([name, m]) => {
        const successRate = m.calls > 0 ? +((m.success / m.calls) * 100).toFixed(1) : null;
        const avgLatency = m.calls > 0 && m.latencySum ? Math.round(m.latencySum / m.calls) : null;
        const avgCost = m.calls > 0 ? +(m.costSum / m.calls).toFixed(6) : null;
        return { name, capability: m.capability, keyCount: (m.keys || []).length, calls: m.calls, success: m.success, fail: m.fail, successRate, avgLatency, avgCost, lastUsed: m.lastUsed, firstSeen: m.firstSeen };
      }).sort((a, b) => b.calls - a.calls);
      return { id, name: ch.name, baseUrl: ch.baseUrl, lastProbedAt: ch.lastProbedAt, modelCount: models.length, models };
    });

    // 常用模型 Top
    const callMap = {};
    for (const ch of Object.values(this.data.channels)) {
      for (const [name, m] of Object.entries(ch.models || {})) {
        if (!callMap[name]) callMap[name] = { calls: 0, success: 0, fail: 0, capabilities: new Set() };
        callMap[name].calls += m.calls; callMap[name].success += m.success; callMap[name].fail += m.fail;
        callMap[name].capabilities.add(m.capability);
      }
    }
    const topModels = Object.entries(callMap).map(([name, s]) => ({ name, calls: s.calls, success: s.success, fail: s.fail, successRate: s.calls ? +((s.success / s.calls) * 100).toFixed(1) : 0, capability: [...s.capabilities][0] || 'chat' })).sort((a, b) => b.calls - a.calls).slice(0, 10);

    // 分时习惯
    const usageByHour = Object.entries(this.data.usageByHour || {}).map(([hour, models]) => {
      const top = Object.entries(models).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([m, c]) => ({ model: m, count: c }));
      return { hour: Number(hour), top };
    }).sort((a, b) => a.hour - b.hour);

    // 推荐：按能力综合 成功率/延迟/成本/使用次数
    const recommendations = this.recommendByCapability();

    // 功能使用分析（隐藏强制拦截类：不可在 UI 展示）
    const hidden = new Set(['content_guard']);
    const featureStats = Object.entries(this.data.features || {})
      .filter(([id]) => !hidden.has(id))
      .map(([id, f]) => ({
        id, count: f.count, errorCount: f.errorCount, firstSeen: f.firstSeen, lastUsed: f.lastUsed,
        byHour: Object.entries(f.byHour || {}).map(([h, c]) => ({ hour: Number(h), count: c })).sort((a, b) => a.hour - b.hour)
      }))
      .sort((a, b) => b.count - a.count);

    const recentEvents = (this.data.events || [])
      .filter(e => !hidden.has(e.id))
      .slice(-40)
      .reverse()
      .map(e => ({ t: e.t, id: e.id, ok: e.ok, detail: e.detail }));

    const featureInsights = this.buildInsights(featureStats);

    return {
      enabled: this.cfg().enabled,
      autoAddModels: this.cfg().autoAddModels,
      learnFeatures: this.cfg().learnFeatures !== false,
      totalCalls: this.data.totalCalls,
      updatedAt: this.data.updatedAt,
      channels,
      topModels,
      usageByHour,
      lastUsedByCapability: this.data.lastUsedByCapability || {},
      recommendations,
      featureStats,
      recentEvents,
      featureInsights
    };
  }

  /**
   * 智能洞察：根据功能使用数据生成可执行建议
   */
  buildInsights(featureStats) {
    const g = (id) => featureStats.find(f => f.id === id);
    const out = [];
    const hit = g('cache_hit'), miss = g('cache_miss');
    if (hit && hit.count >= 20) {
      const rate = hit.count / (hit.count + (miss?.count || 0));
      if (rate >= 0.7) out.push({ level: 'good', text: `内存缓存命中率 ${Math.round(rate * 100)}%（${hit.count} 次），重复请求零成本返回，效果良好` });
      else if (rate <= 0.2) out.push({ level: 'info', text: `内存缓存命中率仅 ${Math.round(rate * 100)}%，大量请求未命中（可能都带 noCache），可检查调用方` });
    }
    if (g('semantic_cache_hit')) out.push({ level: 'good', text: `语义缓存命中 ${g('semantic_cache_hit').count} 次，相似问题直接复用答案，节省了上游调用与成本` });
    if (g('compression')) out.push({ level: 'info', text: `消息压缩已触发 ${g('compression').count} 次，长对话历史被自动精简，降低 tokens 消耗` });
    if (g('prompt_repair')) out.push({ level: 'info', text: `提示词自动修复 ${g('prompt_repair').count} 次（对话不以 user 结尾时自动补齐），规避了上游报错` });
    if (g('fallback') && g('fallback').count > 0) out.push({ level: g('fallback').count > 20 ? 'warn' : 'info', text: `跨模型回退 ${g('fallback').count} 次${g('fallback').count > 20 ? '，较频繁——可在模型页调高常用模型权重，或检查主模型可用性' : '，已自动切换备用模型保证服务'}` });
    if (g('rate_limit_backoff')) out.push({ level: g('rate_limit_backoff').count > 10 ? 'warn' : 'info', text: `限流退避 ${g('rate_limit_backoff').count} 次${g('rate_limit_backoff').count > 10 ? '——建议为该渠道增加 Key 或降低并发' : '，已自动避开被限流的渠道'}` });
    if (g('circuit_break')) out.push({ level: 'warn', text: `熔断触发 ${g('circuit_break').count} 次——某渠道连续失败被自动熔断，请在渠道页检查其稳定性与 Key 状态` });
    if (g('key_guard')) out.push({ level: 'info', text: `Key 保护触发 ${g('key_guard').count} 次（连续认证失败自动禁用），已防止失效 Key 继续被调用` });
    if (g('slo_degrade')) out.push({ level: 'info', text: `SLO 降级 ${g('slo_degrade').count} 次——延迟超标时自动避开慢渠道，恢复 ${g('slo_recover')?.count || 0} 次` });
    if (g('quality_judge') && g('quality_judge').count >= 5) out.push({ level: 'info', text: `质量评分已执行 ${g('quality_judge').count} 次，反馈会写入模型权重，持续优化路由选择` });
    if (g('image_gen') && g('image_gen').count > 0) out.push({ level: 'info', text: `图片生成使用 ${g('image_gen').count} 次——多模态工作流活跃，图片模型推荐见上方` });
    if (g('video_gen') && g('video_gen').count > 0) out.push({ level: 'info', text: `视频生成使用 ${g('video_gen').count} 次——视频任务耗时较长，路由已自动调度最合适的渠道` });
    if (g('provider_manage')) out.push({ level: 'info', text: `渠道管理操作 ${g('provider_manage').count} 次——新增/修改渠道后建议点「立即探测」刷新模型画像` });
    if (g('test_page')) out.push({ level: 'info', text: `测试页调用 ${g('test_page').count} 次——真实请求结果已进入模型画像与习惯学习` });
    if (out.length === 0) out.push({ level: 'info', text: '暂无足够的功能使用数据——正常使用一段时间后，这里会给出针对你使用习惯的优化建议' });
    return out;
  }

  /**
   * 按能力推荐模型：综合 成功率(0.5) + 延迟(0.3) + 成本(0.2)，样本不足时按最近使用
   */
  recommendByCapability() {
    const caps = ['chat', 'image', 'video', 'embedding', 'audio'];
    const out = {};
    for (const cap of caps) {
      const candidates = [];
      for (const ch of Object.values(this.data.channels)) {
        for (const [name, m] of Object.entries(ch.models || {})) {
          if (m.capability !== cap) continue;
          const calls = m.calls || 0;
          const rate = calls > 0 ? m.success / calls : 0;
          const avgLat = calls > 0 && m.latencySum ? m.latencySum / calls : null;
          const avgCost = calls > 0 ? m.costSum / calls : null;
          let score = 0;
          if (calls > 0) {
            score += rate * 0.5;
            if (avgLat != null) score += Math.max(0, 1 - avgLat / 5000) * 0.3;
            if (avgCost != null) score += Math.max(0, 1 - avgCost / 0.1) * 0.2;
            else score += 0.2;
          }
          candidates.push({ model: name, calls, successRate: +(rate * 100).toFixed(1), avgLatency: avgLat ? Math.round(avgLat) : null, avgCost: avgCost != null ? +avgCost.toFixed(6) : null, score: +score.toFixed(4), lastUsed: m.lastUsed });
        }
      }
      if (candidates.length === 0) { out[cap] = null; continue; }
      candidates.sort((a, b) => b.score - a.score || (b.calls - a.calls));
      // 有使用记录的优先；无记录但探测到的不推荐
      const used = candidates.filter(c => c.calls > 0);
      out[cap] = used.length ? used[0] : null;
    }
    return out;
  }

  clear() {
    this.data = this.defaultData();
    this.save();
  }

  getStats() {
    return {
      channels: Object.keys(this.data.channels).length,
      totalModels: Object.values(this.data.channels).reduce((s, c) => s + Object.keys(c.models || {}).length, 0),
      totalCalls: this.data.totalCalls,
      totalFeatures: Object.keys(this.data.features || {}).length,
      updatedAt: this.data.updatedAt
    };
  }
}

module.exports = { ModelMemory, classifyModel };
