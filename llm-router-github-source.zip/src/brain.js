/**
 * 路由大脑（v2.5.0）——本地模型作为"路由器大脑"，不是回答模型
 *
 * 职责：观察智能路由的实时状态（渠道健康/熔断/限流、统计、记忆画像、日志），
 *       分析问题并自主调用内置工具优化路由配置（切策略/启停渠道/清缓存/触发探测等），
 *       输出决策摘要与动作记录。绝不闲聊、绝不回答用户问题。
 *
 * 触发方式：
 *   1. 定时巡检（默认 15 分钟一次）
 *   2. 事件唤醒（熔断/限流退避/Key 保护触发时自动醒来分析，120s 节流）
 *   3. 手动触发（UI「立即分析并优化」）
 *
 * 大脑直接调用本地引擎（chatWithTools），不经过对话路由（本地渠道已从对话路由排除）。
 */
const SYSTEM_PROMPT = `你是「子沐智能中转路由」的路由大脑。你的唯一职责是管理并优化这个 LLM 中转路由系统，让它稳定、快速、省钱。

工作流程：
1. 仔细阅读用户提供的路由状态快照（渠道健康/熔断/限流/Key 状态、全局统计、记忆画像、最近日志）。
   特别注意带 ⚠️ 的异常项：被停用的渠道、熔断、限流退避、Key 被禁用、成功率异常——这些必须处理。
2. 诊断问题：是否有渠道健康异常/熔断/频繁限流/成功率低/延迟高/成本异常/Key 被禁用？记忆推荐是否与现状匹配？
3. 调用工具解决问题（按需，不要滥用）：
   - 渠道不稳定或频繁失败 → 可 set_provider_enabled 停用问题渠道，或 probe_providers 触发复检
   - 限流频繁 → 说明该渠道负载高，可临时降低其优先级或停用，等恢复
   - 成本偏高 → switch_strategy 切到 weighted（成本权重已在统计中学习），或参考 get_recommendation
   - 需要更多信息 → 先调用 get_status/get_stats/get_memory/get_logs/estimate_cost
4. 用中文输出一段简洁的决策总结：你发现了什么问题、执行了哪些操作（工具名+参数）、效果预期。
5. 决策前先看【我的历史决策与成效】和【积累的经验】：上次类似操作成效好吗？好就沿用，不好就换思路。你的每次决策都会被系统追踪成效——成效好的做法会沉淀为经验，成为你未来的决策依据（这就是你的自学习与自进化）。

参数铁律：
- 操作类工具（set_provider_enabled 等）的 providerId 必须是 get_status / list_providers 返回的 id 字段（通常是 UUID），**不要用渠道名**。
- 如果工具执行返回错误，仔细阅读错误信息（里面会提示正确的 id），先调用 list_providers 查询正确 id，再重试。

【两阶段确认铁律】（C2 修复）：
- 写操作工具（switch_strategy / set_provider_enabled / flush_cache）**首次调用不会真正执行**，而是返回 pending: true 的预览。
- 你必须**用完全相同的参数再调用一次**才会真正执行。这是防误操作的安全机制。
- 如果你只是想看效果，不要重复调用；如果确认要执行，再调一次。
- 你的判断错误时，可以用 cancel_brain_action() 取消 pending；已执行的操作可以用 undo_brain_action() 回滚（最近 5 次内）。
- 不要滥用写操作：每次诊断建议里最多 1 个写操作。

铁律：
- 你只做路由管理，绝不与用户闲聊，绝不回答知识性问题。
- 不要做无意义操作；一切正常时只输出"路由状态正常，无需调整"。
- 工具执行结果会以 tool 消息返回，务必阅读后再决定下一步。

【工具沙箱与白名单】（H4 修复）：
- 只读工具（get_status / get_stats / get_memory / list_providers / list_models / get_recommendation / get_logs / estimate_cost / probe_providers）：可自由调用，无副作用。
- 写操作工具（switch_strategy / set_provider_enabled / flush_cache）：会修改配置或清空缓存，必须【两阶段确认】（见上）。且【最小变更原则】要求：单次诊断里最多执行 1 个写操作——超过会被系统拒绝。
- 控制工具（cancel_brain_action / undo_brain_action）：用于管理自己刚才的操作，参数固定无副作用。
- 任何未在上述列表中的工具调用都会被沙箱拒绝，模型无法绕过。
`;
class BrainEngine {
  /**
   * @param {object} deps { config, router, localEngine, toolRegistry, memory, tracer }
   */
  constructor(deps = {}) {
    this.config = deps.config;
    this.router = deps.router;
    this.engine = deps.localEngine;
    this.tools = deps.toolRegistry;
    this.memory = deps.memory;
    this.tracer = deps.tracer;
    this.history = [];        // 决策历史（内存，最新在前，上限 50）
    this.lessons = [];        // 积累的经验（v2.6.0 自学习：由成效好的决策沉淀，持久化）
    this.decisionCount = 0;
    this.autoTimer = null;
    this.lastRunAt = null;
    this.lastNotifyAt = 0;
    this.onEvent = null;      // 事件回调（main 推送到渲染进程）
    this.loadLessons();
  }

  /** 加载持久化的经验（自学习记忆） */
  loadLessons() {
    try {
      this.lessons = (this.memory?.data?.brainLessons) || [];
    } catch (e) {
      this.lessons = [];
    }
  }

  /** 持久化经验 */
  persistLessons() {
    try {
      if (this.memory) {
        this.memory.data.brainLessons = this.lessons.slice(0, 20);
        this.memory.save();
      }
    } catch (e) {}
  }

  cfg() {
    return {
      brainEnabled: true,       // 大脑总开关
      brainAutoStart: true,     // 引擎运行后自动开始定时巡检
      brainIntervalMin: 15,     // 定时巡检间隔（分钟）
      brainWakeOnEvents: true,  // 熔断/限流/Key保护 事件唤醒
      ...(this.config.get('local') || {})
    };
  }

  status() {
    const c = this.cfg();
    return {
      enabled: c.brainEnabled,
      autoRunning: !!this.autoTimer,
      engineRunning: !!(this.engine && this.engine.running),
      intervalMin: c.brainIntervalMin,
      wakeOnEvents: c.brainWakeOnEvents,
      lastRunAt: this.lastRunAt,
      decisionCount: this.decisionCount,
      history: this.history.slice(0, 20),
      lessons: this.lessons.slice(0, 10)
    };
  }

  emit(ev) {
    try { this.onEvent && this.onEvent(ev); } catch (e) {}
  }

  /**
   * 收集路由状态快照（复用内置工具，紧凑文本）
   */
  async collectSnapshot() {
    const parts = [];
    const exec = (name, args = '{}') => this.tools ? this.tools.execute(name, args) : Promise.resolve({ ok: false, error: '工具集未初始化' });

    const st = await exec('get_status');
    if (st.ok) {
      const lines = (st.providers || []).map(p => {
        const flags = [];
        if (!p.enabled) flags.push('⚠️已停用');
        if (p.circuitOpen) flags.push('⚠️熔断');
        if (p.rateLimited) flags.push('⚠️限流退避');
        if (p.disabledKeys > 0) flags.push(`⚠️禁用Key=${p.disabledKeys}`);
        return `- ${p.name} [${p.kind === 'local' ? '本地' : '云端'}] ${p.enabled ? '启用' : '停用'} 健康=${p.healthy} 熔断=${p.circuitOpen} 限流退避=${p.rateLimited} 禁用Key=${p.disabledKeys} 优先级=${p.priority}${flags.length ? ' ' + flags.join(' ') : ''}`;
      });
      parts.push('【渠道状态】\n' + (lines.join('\n') || '（无渠道）'));
    }

    const stt = await exec('get_stats');
    if (stt.ok) {
      parts.push(`【全局统计】总请求=${stt.totalRequests} 成功率=${stt.successRate}% 均延迟=${stt.avgLatencyMs}ms 总成本=$${stt.totalCostUsd ?? 0}\n` +
        (stt.providerStats || []).map(p => `  - ${p.id}: 请求=${p.requests} 成功=${p.success} 失败=${p.fail} 成本=$${+(p.cost || 0).toFixed(4)}`).join('\n'));
    }

    const mem = await exec('get_memory');
    if (mem.ok && (mem.recommended || []).length) {
      parts.push('【记忆推荐】' + mem.recommended.map(r => `${r.capability}→${r.model}(${r.successRate}%)`).join('，'));
    }

    const logs = await exec('get_logs', '{"limit":10}');
    if (logs.ok && logs.logs && logs.logs.length) {
      parts.push('【最近日志】\n' + logs.logs.map(l =>
        `- ${l.time ? new Date(l.time).toLocaleTimeString() : ''} ${l.model} @${l.provider} ${l.status} ${l.latency != null ? l.latency + 'ms' : ''}${l.switched ? ' 回退' : ''}${l.cached ? ' 缓存' : ''}`
      ).join('\n'));
    }

    const strat = this.config.get('routing.strategy') || 'priority';
    parts.push(`【当前配置】路由策略=${strat} 故障切换=${this.config.get('routing.failover') !== false} 跨模型回退=${this.config.get('routing.fallback') !== false}`);

    // 自学习（v2.6.0）：历史决策成效 + 积累的经验，让大脑记得住、会自省
    const EFFECT_LABEL = { good: '✅改善', bad: '📉恶化', neutral: '➖持平', insufficient: '⏳样本不足', pending: '⏳待评估' };
    const evaled = this.history.filter(h => h.effect && h.effect !== 'pending').slice(0, 5);
    if (evaled.length) {
      parts.push('【我的历史决策与成效】\n' + evaled.map(h =>
        `- ${new Date(h.time).toLocaleString()} [${h.reason}] 工具[${(h.tools || []).map(t => t.name).join('+') || '无'}] 成效=${EFFECT_LABEL[h.effect] || h.effect}${h.effectDetail ? ' ' + h.effectDetail : ''}`
      ).join('\n'));
    }
    if (this.lessons.length) {
      parts.push('【积累的经验】\n' + this.lessons.slice(0, 5).map(l =>
        `- ${l.action}: ${l.detail || l.reason || ''}`
      ).join('\n'));
    }
    return parts.join('\n\n');
  }

  /** 当前指标基线（决策效果评估用） */
  async currentMetrics() {
    const s = this.tools ? await this.tools.execute('get_stats') : { ok: false };
    if (!s.ok) return null;
    return {
      strategy: this.config.get('routing.strategy'),
      totalRequests: s.totalRequests || 0,
      successRate: s.successRate ?? null,
      avgLatencyMs: s.avgLatencyMs ?? null,
      totalCostUsd: s.totalCostUsd ?? null
    };
  }

  /**
   * 自学习：评估最近一次未评估的决策的实际效果（对比决策时基线）
   * 新请求样本不足则标记 insufficient，等待下次再评
   */
  async evaluateLastDecision() {
    const last = this.history.find(h => !h.effect || h.effect === 'pending');
    if (!last || !last.baseline) return;
    const cur = await this.currentMetrics();
    if (!cur) return;
    const b = last.baseline;
    const newReqs = cur.totalRequests - (b.totalRequests || 0);
    if (newReqs < 3) {
      last.effect = 'pending';
      return;
    }
    let improved = 0, degraded = 0;
    const detail = [];
    if (b.successRate != null && cur.successRate != null) {
      const d = +(cur.successRate - b.successRate).toFixed(1);
      if (d >= 3) { improved++; detail.push(`成功率 +${d}%`); }
      else if (d <= -3) { degraded++; detail.push(`成功率 ${d}%`); }
    }
    if (b.avgLatencyMs && cur.avgLatencyMs) {
      const ratio = cur.avgLatencyMs / b.avgLatencyMs;
      if (ratio <= 0.9) { improved++; detail.push(`延迟 -${Math.round((1 - ratio) * 100)}%`); }
      else if (ratio >= 1.1) { degraded++; detail.push(`延迟 +${Math.round((ratio - 1) * 100)}%`); }
    }
    if (b.totalCostUsd != null && cur.totalCostUsd != null && b.totalCostUsd > 0) {
      const ratio = cur.totalCostUsd / b.totalCostUsd;
      if (ratio <= 0.95 && newReqs >= 3) { improved++; detail.push(`成本 -${Math.round((1 - ratio) * 100)}%`); }
      else if (ratio >= 1.05) { degraded++; detail.push(`成本 +${Math.round((ratio - 1) * 100)}%`); }
    }
    last.effect = improved > degraded ? 'good' : degraded > improved ? 'bad' : 'neutral';
    last.effectDetail = detail.join('，') || (newReqs >= 3 ? '指标平稳' : '');
    last.effectCheckedAt = new Date().toISOString();
    // 成效好的决策 → 沉淀为经验（自升级提示词依据）
    if (last.effect === 'good' && (last.tools || []).length) {
      this.learnLesson(last);
    }
    this.memory?.trackFeature('brain_effect', { detail: `${last.effect} ${last.effectDetail || ''}`, ok: last.effect !== 'bad' });
    this.emit({ type: 'effect', entry: last });
  }

  /**
   * 自学习：把成效好的操作沉淀为经验（去重 + 上限 20 条 + 持久化）
   */
  learnLesson(entry) {
    const action = (entry.tools || []).map(t => t.name).join('+') || 'noop';
    const existing = this.lessons.find(l => l.action === action);
    const lesson = {
      action,
      reason: entry.reason,
      detail: entry.effectDetail || '成效改善',
      at: entry.time,
      times: (existing ? existing.times : 0) + 1
    };
    if (existing) {
      existing.times = lesson.times;
      existing.at = lesson.at;
      existing.detail = lesson.detail || existing.detail;
    } else {
      this.lessons.unshift(lesson);
      if (this.lessons.length > 20) this.lessons.pop();
    }
    this.persistLessons();
    this.emit({ type: 'lesson', lesson });
  }

  /**
   * 大脑运行一次：分析快照 → 自主调用工具 → 输出决策总结
   * @param {string} reason 触发原因
   * @param {object} opts { force: true 手动触发不避让流量；auto 自动触发在流量繁忙时顺延 }
   */
  async run(reason = '手动触发', opts = {}) {
    const c = this.cfg();
    if (!c.brainEnabled) return { ok: false, error: '路由大脑已停用' };
    if (!this.engine || !this.engine.running) return { ok: false, error: '本地引擎未运行，无法启动大脑' };
    if (!this.tools) return { ok: false, error: '工具集未初始化' };

    // 流量避让（v2.6.3）：自动巡检/事件唤醒时，若最近 2 分钟有路由请求在跑，
    // 本地推理会占满 CPU 拖慢用户请求 → 顺延 3 分钟再跑；手动触发不受影响
    if (!opts.force) {
      const lastAct = this.router?.lastActivityAt || 0;
      const busy = (Date.now() - lastAct) < 120000;
      if (busy) {
        const delayMs = 3 * 60000;
        if (this._deferredTimer) clearTimeout(this._deferredTimer);
        this._deferredTimer = setTimeout(() => { this.run(reason).catch(() => {}); }, delayMs);
        this.emit({ type: 'deferred', reason, delayMs });
        return { ok: false, deferred: true, error: `流量繁忙，大脑巡检顺延 ${Math.round(delayMs / 60000)} 分钟` };
      }
    }

    const startAt = Date.now();
    try {
      // H4 修复：单次决策里写操作计数 reset（强制最小变更：单次 run 最多 1 个写操作）
      this.tools?.resetSessionWrites?.();
      // 自学习：先评估上次决策的实际效果（对比基线），再开始本次决策
      try { await this.evaluateLastDecision(); } catch (e) {}
      const snapshot = await this.collectSnapshot();
      const baseline = await this.currentMetrics();
      const { result, toolRuns } = await this.engine.chatWithTools({
        model: this.cfg().modelFile,
        messages: [
          { role: 'system', content: SYSTEM_PROMPT },
          { role: 'user', content: `请分析当前路由状态并执行必要的优化。\n触发原因：${reason}\n\n${snapshot}\n\n请给出你的诊断与操作（如无异常直接说明无需调整）。` }
        ],
        tools: this.tools.toolsPayload(),
        max_tokens: 600
      });

      const summary = (result?.data?.choices?.[0]?.message?.content || '').trim() || '(模型未输出总结)';
      const entry = {
        time: new Date().toISOString(),
        reason,
        tools: toolRuns || [],
        summary: summary.slice(0, 800),
        durationMs: Date.now() - startAt,
        baseline,           // 决策时的指标基线（自学习用）
        effect: 'pending',  // 待评估：下次决策时对比
        effectDetail: null
      };
      this.history.unshift(entry);
      if (this.history.length > 50) this.history.pop();
      this.decisionCount++;
      this.lastRunAt = entry.time;
      this.memory?.trackFeature('brain_run', { detail: reason, ok: true });
      this.emit({ type: 'decision', entry });
      return { ok: true, ...entry };
    } catch (e) {
      this.memory?.trackFeature('brain_run', { detail: reason, ok: false });
      this.emit({ type: 'error', error: e.message });
      return { ok: false, error: e.message };
    }
  }

  /**
   * 事件唤醒：熔断/限流/Key 保护等关键事件触发时自动分析（120s 节流）
   */
  notify(event) {
    const c = this.cfg();
    if (!c.brainEnabled || !c.brainWakeOnEvents) return;
    if (!this.engine || !this.engine.running) return;
    if (Date.now() - this.lastNotifyAt < 120000) return;   // 节流
    this.lastNotifyAt = Date.now();
    this.run('事件触发: ' + event).catch(() => {});
  }

  startAuto() {
    const c = this.cfg();
    if (this.autoTimer) return;
    if (!c.brainEnabled) return;
    const ms = (c.brainIntervalMin || 15) * 60 * 1000;
    this.autoTimer = setInterval(() => this.run('定时巡检').catch(() => {}), ms);
    this.emit({ type: 'auto', running: true, intervalMin: c.brainIntervalMin });
  }

  stopAuto() {
    if (this.autoTimer) {
      clearInterval(this.autoTimer);
      this.autoTimer = null;
    }
    this.emit({ type: 'auto', running: false });
  }
}

module.exports = { BrainEngine, SYSTEM_PROMPT };
