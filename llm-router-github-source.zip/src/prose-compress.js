/**
 * 规则式散文压缩（v2.7.0，借鉴 OmniRoute Caveman 压缩设计，MIT 协议）
 *
 * - 中英文规则集：删客套话/口头禅/冗余连接词/填充词/礼貌框架等，不改变语义
 * - 保护机制：```代码块```、行内代码、URL、JSON 结构不压缩
 * - 压缩后清理残留（多余空格/标点/空行）
 * - 英文句子首字母复原（压缩删除可能破坏句首大写）
 *
 * 用法：compressProse(text) -> { text, appliedRules, savedChars }
 * 由路由压缩管道在"启发式截断"之前调用（无损语义优先）
 */

// 保护占位符
const PROTECT_TOKENS = [];

function protect(text) {
  PROTECT_TOKENS.length = 0;
  let t = text;
  const markers = [];
  const capture = (re) => {
    t = t.replace(re, (m) => {
      const tok = `\u0000P${markers.length}\u0000`;
      markers.push(m);
      return tok;
    });
  };
  // 1. 代码块（三反引号/四反引号）
  capture(/```[\s\S]*?```|~~~[\s\S]*?~~~/g);
  // 2. 行内代码
  capture(/`[^`\n]{1,200}`/g);
  // 3. URL
  capture(/https?:\/\/[^\s"'<>)\]]+/g);
  // 4. JSON/对象结构片段（{...} 或 [...]，保守：仅保护含引号键的）
  capture(/\{[^{}\n]{0,300}\}/g);
  capture(/\[[^\[\]\n]{0,200}\]/g);
  PROTECT_TOKENS.push(...markers);
  return t;
}

function restore(text) {
  let t = text;
  PROTECT_TOKENS.forEach((m, i) => {
    t = t.split(`\u0000P${i}\u0000`).join(m);
  });
  return t;
}

// 中英文规则：{ pattern, replacement|fn, desc }
const RULES = [
  // ── 中文：客套与问候 ──
  { name: 'zh_greeting', pattern: /^(你好|您好|哈喽|嗨|早上好|下午好|晚上好|hello|hi|hey)[，。!！,.\s]*/gim, replacement: '', desc: '删问候语' },
  { name: 'zh_thanks', pattern: /(谢谢|感谢|多谢|辛苦(了|啦)|麻烦(了|您)?|拜托(了|啦))[，。!！,.\s]*/gi, replacement: '', desc: '删感谢客套' },
  { name: 'zh_polite', pattern: /(请|请您|麻烦您|劳驾|拜托您)\s*/gi, replacement: '', desc: '删礼貌词（语义保留）' },
  { name: 'zh_ending', pattern: /(谢谢|感谢|多谢|感恩|辛苦)[你您]*(了|啦)?[。！!]?\s*$/gim, replacement: '', desc: '删结尾客套' },
  { name: 'zh_apology', pattern: /(不好意思|抱歉|对不起|打扰(了|一下|您)?)[，。!！,.\s]*/gi, replacement: '', desc: '删道歉前置' },
  { name: 'zh_farewell', pattern: /(再见|拜拜|回见|下次聊)[。!！]?\s*$/gim, replacement: '', desc: '删道别' },
  // ── 中文：口头禅与填充 ──
  { name: 'zh_filler', pattern: /(就是|其实|反正|然后|那个|这个|怎么说呢|我觉得|我认为|我个人觉得|感觉|可能大概|大概可能|应该是|基本上|算是|有点|有点小)\s*/gi, replacement: '', desc: '删口头禅填充词' },
  { name: 'zh_hedge', pattern: /(我觉得|我认为|在我看来|据我了解|据说|听说|好像|貌似|似乎|大概|也许|或许|说不定)\s*/gi, replacement: '', desc: '删模糊限制词' },
  { name: 'zh_redundant', pattern: /(非常非常|特别特别|真的很|确实是|的确是|真的是|毫无疑问|显而易见|众所周知|众所周知的是)\s*/gi, replacement: '', desc: '删冗余强调' },
  // ── 中文：冗余连接与铺垫 ──
  { name: 'zh_connector', pattern: /(首先|其次|然后|再者|此外|另外|同时|与此同时|除此之外|总的来说|总而言之|综上所述|也就是说|换句话说|这样一来|这样的话)\s*[，,]\s*/gi, replacement: '', desc: '删冗余连接词（保留逗号后内容）' },
  { name: 'zh_preface', pattern: /(我想问一下|我想请教一下|我有个问题|我有一个问题|想请教你|帮我看看|帮我一下|麻烦帮我|能帮我|帮我)\s*/gi, replacement: '', desc: '删请求铺垫' },
  { name: 'zh_meta', pattern: /(请注意|需要注意的是|记住|别忘了|提醒一下|补充一下|顺便说一下)\s*/gi, replacement: '', desc: '删元评论' },
  // ── 中文：绝对化/重复 ──
  { name: 'zh_absolutize', pattern: /(百分之百|一百个|一百万个|非常之|极其之|极其|相当之)/gi, replacement: '', desc: '删绝对化前缀' },
  { name: 'zh_repeat', pattern: /([\u4e00-\u9fa5])\1{2,}/g, replacement: (m) => m[0] + m[1], desc: '重复字压缩（好好好→好好）' },
  // ── 英文：借鉴 OmniRoute Caveman 精选规则 ──
  { name: 'en_pleasantries', pattern: /(?<!make\s)(?<!be\s)\b(?:i'?d be happy to|i would be happy to|glad to help|happy to|thank you|thanks|no problem|you'?re welcome|certainly|of course|absolutely)\b[,.!?\s]*/gi, replacement: '', desc: '删英文客套' },
  { name: 'en_polite', pattern: /\b(?:please|kindly|could you please|would you please|can you please)\b\s*/gi, replacement: '', desc: '删英文礼貌词' },
  { name: 'en_hedging', pattern: /\b(?:it seems like|it appears that|i think that|i believe that|probably|possibly)\b\s*/gi, replacement: '', desc: '删英文模糊词' },
  { name: 'en_filler', pattern: /\b(?:basically|essentially|actually|literally|simply|currently)\b\s*/gi, replacement: '', desc: '删英文填充副词' },
  { name: 'en_leader', pattern: /^(?:i'?ll|i will|i can|i'?d|let me|you can|we will|we can|let'?s)\s+(?=[a-z])/gim, replacement: '', desc: '删英文引导短语' },
  { name: 'en_gratitude', pattern: /\b(?:thank you so much|thanks in advance|i really appreciate)\b[,.!?\s]*/gi, replacement: '', desc: '删英文过度感谢' },
  { name: 'en_qualifier', pattern: /\b(?:a bit|a little|somewhat|kind of|sort of)\b\s*/gi, replacement: '', desc: '删英文限定词' },
  { name: 'en_verbose', pattern: /\b(?:due to the fact that|the reason is because|in order to|so as to|in order for)\b/gi, replacement: (m) => (m.toLowerCase().includes('due to') || m.toLowerCase().includes('reason is')) ? 'because ' : 'to ', desc: '英文冗长替换' },
  { name: 'en_redundant', pattern: /\b(?:each and every|any and all|in addition to|as well as)\b/gi, replacement: (m) => m.toLowerCase().includes('in addition') ? '' : 'and ', desc: '英文冗余合并' },
  { name: 'en_meta', pattern: /^(?:note that|keep in mind that|remember that)\b\s*/gim, replacement: '', desc: '删英文元评论' },
  { name: 'en_explain', pattern: /\b(?:provide a detailed explanation of|give me a comprehensive explanation of|write an in-depth explanation of|create a thorough explanation of|explain in detail)\b/gi, replacement: 'explain ', desc: '英文冗长指令压缩' },
];

/**
 * 压缩一段散文文本
 * @param {string} text
 * @param {object} opts { codeLike: true 已判定为代码则不压缩 }
 * @returns {{ text: string, appliedRules: string[], savedChars: number }}
 */
function compressProse(text, opts = {}) {
  if (!text || typeof text !== 'string') return { text: text || '', appliedRules: [], savedChars: 0 };
  if (opts.codeLike) return { text, appliedRules: [], savedChars: 0 };

  const original = text;
  let t = protect(text);
  const appliedRules = [];
  const lower = t.toLowerCase();

  for (const rule of RULES) {
    const before = t;
    try {
      if (typeof rule.pattern.exec === 'function') rule.pattern.lastIndex = 0;
      if (typeof rule.replacement === 'function') {
        t = t.replace(rule.pattern, rule.replacement);
      } else {
        t = t.replace(rule.pattern, rule.replacement);
      }
    } catch (e) { /* 单条规则失败不影响整体 */ }
    if (t !== before) appliedRules.push(rule.name);
  }

  // 清理残留
  t = cleanup(t);
  // 英文句子首字母复原（占位符无字母，不受影响）——必须在 restore 之前，避免破坏代码块大小写
  if (/[a-zA-Z]/.test(t)) t = recapitalize(t);
  t = restore(t);

  // 压缩后反而更长则放弃
  if (t.length >= original.length) return { text: original, appliedRules: [], savedChars: 0 };
  return { text: t, appliedRules, savedChars: original.length - t.length };
}

function cleanup(text) {
  return text
    .replace(/[ \t]{2,}/g, ' ')
    .replace(/[ \t]+([,.;:!?，。；：！？])/g, '$1')
    .replace(/([.!?。！？]){2,}/g, (m) => m[m.length - 1])
    .replace(/[ \t]+$/gm, '')
    .replace(/\n{3,}/g, '\n\n')
    .replace(/^\n+/, '')
    .replace(/\n+$/, '')
    .replace(/[，,]\s*$/g, '')
    .replace(/^[，,、。\s]+/g, '');
}

function recapitalize(text) {
  return text.replace(/(^|[.!?][ \t]|\n[ \t]*)([a-z])/g, (_m, prefix, ch) => prefix + ch.toUpperCase());
}

/** 判断文本是否以代码为主（≥30% 行像代码）——不压缩 */
function isCodeLikeText(text) {
  const lines = String(text || '').split('\n').filter(l => l.trim().length > 0);
  if (lines.length < 3) return false;
  let codeLike = 0;
  for (const l of lines) {
    if (/^\s*(?:[{}[\](),;=<>+\-*/&|!?.:]|def |function |const |let |var |import |export |class |if |return |console\.|print\(|<\/?[a-z]+)/.test(l) ||
      /[\t]{2,}/.test(l) || /^[a-zA-Z_$][\w$]*\s*[=(:]/.test(l.trim())) codeLike++;
  }
  return codeLike / lines.length >= 0.3;
}

/**
 * headroom 表格/JSON 紧凑化（v2.8.0，借鉴 OmniRoute headroom 引擎）：
 * - 合法 JSON 文本：去多余空白紧凑化（无损，可 parse 才做）
 * - Markdown 表格：去掉单元格内多余空格（保守：只清分隔列两侧空格）
 */
function compactStructured(text) {
  if (!text || typeof text !== 'string') return { text: text || '', saved: 0 };
  const t = text.trim();

  // 1. Markdown 表格紧凑化（| a | b | -> |a|b|）——无长度门槛
  if (t.includes('|') && /^\s*\|/.test(t)) {
    const lines = t.split('\n');
    let saved = 0;
    const out = lines.map(l => {
      if (!l.includes('|')) return l;
      const compact = l.replace(/\s*\|\s*/g, '|');
      saved += l.length - compact.length;
      return compact;
    });
    if (saved > 0) return { text: out.join('\n'), saved };
  }

  // 2. JSON 紧凑化（可 parse 才做，保证无损）——需要一定体量才值得
  if (t.length >= 200 && ((t.startsWith('{') && t.endsWith('}')) || (t.startsWith('[') && t.endsWith(']')))) {
    try {
      const parsed = JSON.parse(t);
      const compact = JSON.stringify(parsed);
      if (compact.length < t.length) {
        return { text: compact, saved: t.length - compact.length };
      }
    } catch (e) { /* 非纯 JSON 或解析失败，跳过 */ }
  }

  return { text, saved: 0 };
}

/**
 * 抽取式句子压缩（v2.8.2，借鉴 OmniRoute relevance 引擎）：
 * 对超长散文按句评分，只删除明显的低信息句（问候/感谢/填充/极短句/重复句），
 * 删除量有上限（默认 30%），代码/JSON 等结构化内容不参与。
 * 保守优先：宁可少删不可误删。
 */
function extractiveCompress(text, opts = {}) {
  if (!text || typeof text !== 'string') return { text: text || '', saved: 0, removed: 0 };
  const t = text.trim();
  if (t.length < (opts.minLen || 250)) return { text, saved: 0, removed: 0 };
  if (isCodeLikeText(t)) return { text, saved: 0, removed: 0 };   // 代码不参与

  // 保护结构化内容：跳过含代码块/JSON/表格的文本
  if (/```|~~~|\{\s*"|\|\s*---/.test(t)) return { text, saved: 0, removed: 0 };

  // 按句子拆分（中文。！？；/ 英文 .!?；保留序号/小数）
  const sentences = t.split(/(?<=[。！？；!?;])\s*/).map(s => s.trim()).filter(Boolean);
  if (sentences.length < 6) return { text, saved: 0, removed: 0 };

  // 低信息句判定：问候/感谢/客套/填充/极短/重复
  const LOW_INFO = /^(你好|您好|嗨|哈喽|hello|hi|hey|谢谢|感谢|多谢|再见|拜拜|好的|嗯|哦|是的|对的|没问题|不客气|敬请期待|欢迎咨询|随时联系|请随时|有需要|有问题|如有|如需|希望能够|希望能|祝您|祝你|顺祝|此致|敬礼|以上|如下|好了|就这样|先说这些)[，。!！?？,.;；:：\s]*$/i;
  const REMOVE_PATTERN = /(^|[\s，。])(你好|您好|谢谢|感谢|麻烦|辛苦了|再见|拜拜|好的|嗯嗯|没问题|不客气|请问|请教|打扰|抱歉|不好意思|敬请|欢迎|请随时|有需要|如有问题|希望能够|祝好)([\s，。！!？?]|$)/i;

  const scored = sentences.map((s, i) => {
    let score = 0;
    if (s.length < 12) score -= 4;                     // 极短句
    if (s.length > 80) score += 2;                     // 长句通常信息量大
    if (LOW_INFO.test(s)) score -= 8;                  // 问候/客套整句
    if (REMOVE_PATTERN.test(s)) score -= 5;            // 句中含客套/填充词
    if (/^(谢谢|感谢|多谢|不客气|再见|拜拜|欢迎|祝|有问题请|请随时|如有|希望能够|好的好的)/.test(s)) score -= 8;  // 句首客套（重罚，确保优先删）
    if (/\d{2,}|https?:\/\/|['"“”]|[:：=]|%|￥|\$/.test(s)) score += 3;  // 含数据/引用/关键符号
    if (/^(但是|然而|因此|所以|首先|其次|最后|总结|总之|注意|重点|关键|重要)/.test(s)) score += 3;  // 结构句
    if (/^(嗯|哦|啊|额|呃|哈|好的|行|ok|好的好的)/i.test(s)) score -= 8;  // 语气词句
    // 与前面句子重复（前 30 字相似）
    if (i > 0 && sentences[i - 1].slice(0, 30) === s.slice(0, 30)) score -= 6;
    return { s, score };
  });

  const maxRemove = Math.floor(sentences.length * (opts.maxRatio || 0.4));
  if (maxRemove <= 0) return { text, saved: 0, removed: 0 };

  // 按分数升序删低分句（保留首句与末句，保证上下文连贯）
  const removable = scored.map((x, i) => ({ ...x, i }))
    .filter(x => x.i !== 0 && x.i !== scored.length - 1)
    .sort((a, b) => a.score - b.score);

  let removed = 0;
  const removeIdx = new Set();
  for (const x of removable) {
    if (removed >= maxRemove) break;
    if (x.score < -3) { removeIdx.add(x.i); removed++; }
  }
  if (removed === 0) return { text, saved: 0, removed: 0 };

  const out = sentences.filter((_, i) => !removeIdx.has(i)).join('');
  const saved = t.length - out.length;
  if (saved <= 0) return { text, saved: 0, removed: 0 };
  return { text: out, saved, removed };
}

/**
 * rtk 命令输出过滤（v2.9.0，借鉴 OmniRoute rtk 引擎）：
 * 检测终端/命令输出文本，删除冗余行（时间戳、进度条、重复警告、纯分隔行），
 * 保留命令本身与关键输出。仅当文本明显像命令输出时才处理。
 */
function filterCommandOutput(text) {
  if (!text || typeof text !== 'string') return { text: text || '', saved: 0 };
  const t = text;
  if (t.length < 100) return { text: t, saved: 0 };
  const lines = t.split('\n');
  // 命令输出特征：≥30% 行含 shell 提示符/时间戳/进度/路径前缀
  const FEATURE = /^\s*[>#$]\s|^\s*\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}|\d{1,3}%[\s|=>]+|^\s*(?:INFO|WARN|DEBUG|ERROR)\s|^\s*[a-zA-Z]:\\|^\s*\/[\w./-]+:\s/;
  const featCount = lines.filter(l => FEATURE.test(l)).length;
  if (featCount < lines.length * 0.3) return { text: t, saved: 0 };

  let saved = 0;
  const out = lines.filter(l => {
    // 纯进度条/分隔行删除
    if (/^\s*(?:-{5,}|={5,}|[\s|=>]+\d{0,3}%?\s*)$/.test(l.trim()) && l.trim().length > 5) { saved += l.length + 1; return false; }
    // 纯时间戳行 / 时间戳开头的日志噪音行删除
    if (/^\s*\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}/.test(l)) { saved += l.length + 1; return false; }
    return true;
  });
  if (saved <= 0) return { text: t, saved: 0 };
  return { text: out.join('\n'), saved };
}

/**
 * ionizer 表格行采样（v2.9.0，借鉴 OmniRoute ionizer 引擎）：
 * Markdown 表格超过 8 行时，保留表头 + 前 2 行 + 后 2 行，中间省略（注明）。
 */
function sampleTable(text) {
  if (!text || typeof text !== 'string') return { text: text || '', saved: 0 };
  const t = text.trim();
  if (!t.includes('|') || !/^\s*\|/.test(t)) return { text: t, saved: 0 };
  const lines = t.split('\n');
  const headerIdx = lines.findIndex(l => /^\s*\|/.test(l));
  if (headerIdx < 0) return { text: t, saved: 0 };
  const dataRows = lines.slice(headerIdx + 1).filter(l => /^\s*\|/.test(l) && !/^\s*\|[\s|-]+\|/.test(l));
  if (dataRows.length <= 8) return { text: t, saved: 0 };
  const keep = [lines[headerIdx], dataRows[0], dataRows[1], '| …（已省略 ' + (dataRows.length - 4) + ' 行）… |', dataRows[dataRows.length - 2], dataRows[dataRows.length - 1]];
  const out = keep.join('\n');
  const saved = t.length - out.length;
  return saved > 0 ? { text: out, saved } : { text: t, saved: 0 };
}

/**
 * ultra 保守剪枝（v2.9.0，借鉴 OmniRoute ultra 引擎，保守版）：
 * 只做完全无损的操作：连续空行压缩、重复段落（相同 60 字块出现 ≥2 次只留 1 次）。
 */
function conservativePrune(text) {
  if (!text || typeof text !== 'string') return { text: text || '', saved: 0 };
  let t = text;
  let saved = 0;
  // 1. 连续空行压缩（>2 个空行 -> 2 个）
  const before = t.length;
  t = t.replace(/\n{3,}/g, '\n\n');
  saved += before - t.length;
  // 2. 重复段落（相同 60 字块）
  const blocks = t.split(/\n{2,}/);
  if (blocks.length > 3) {
    const seen = new Set();
    const out = [];
    for (const b of blocks) {
      const key = b.trim().slice(0, 60);
      if (b.trim().length >= 40 && seen.has(key)) { saved += b.length + 2; continue; }
      if (b.trim().length >= 40) seen.add(key);
      out.push(b);
    }
    if (out.length !== blocks.length) t = out.join('\n\n');
  }
  return saved > 0 ? { text: t, saved } : { text, saved: 0 };
}

module.exports = { compressProse, isCodeLikeText, compactStructured, extractiveCompress, filterCommandOutput, sampleTable, conservativePrune, RULES };
