/**
 * SLO 智能限流——基于延迟 p95 的负载降级保护
 * 当滚动窗口内 p95 延迟超过阈值时自动进入"降级模式"（优先最快/最便宜路径），
 * 恢复稳定后自动解除。保护核心体验，避免昂贵工具链拖垮整体。
 */
class SloMonitor {
  constructor(config) {
    this.config = config;
    this.samples = [];        // 延迟样本（滚动窗口）
    this.degraded = false;
    this.degradedAt = null;
    this.degradedCount = 0;   // 累计进入降级次数
    this.recoveredCount = 0;
    this.onEvent = null;      // 事件回调（供记忆系统埋点）：{type:'degrade'|'recover'}
  }

  cfg() {
    return { enabled: true, p95ThresholdMs: 4000, windowSize: 200, recoverFactor: 0.8, ...(this.config.get('slo') || {}) };
  }

  /**
   * 采集一次延迟样本
   */
  sample(latencyMs) {
    const cfg = this.cfg();
    if (!cfg.enabled) return;
    if (latencyMs == null || latencyMs < 0) return;
    this.samples.push(latencyMs);
    const window = cfg.windowSize || 200;
    if (this.samples.length > window) this.samples.shift();
    this.evaluate();
  }

  /**
   * 计算 p95（升序排列取 95% 分位）
   */
  p95() {
    if (this.samples.length === 0) return 0;
    const sorted = [...this.samples].sort((a, b) => a - b);
    const idx = Math.min(sorted.length - 1, Math.floor(sorted.length * 0.95));
    return sorted[idx];
  }

  evaluate() {
    const cfg = this.cfg();
    if (this.samples.length < 20) return; // 样本不足不判定
    const p = this.p95();
    if (!this.degraded) {
      if (p > (cfg.p95ThresholdMs || 4000)) {
        this.degraded = true;
        this.degradedAt = Date.now();
        this.degradedCount++;
        if (this.onEvent) this.onEvent({ type: 'degrade' });
        console.log(`[SLO] p95 延迟 ${p}ms 超过阈值，进入降级模式`);
      }
    } else {
      // 恢复：p95 回落到阈值的 recoverFactor 以下
      if (p < (cfg.p95ThresholdMs || 4000) * (cfg.recoverFactor || 0.8)) {
        this.degraded = false;
        this.degradedAt = null;
        this.recoveredCount++;
        if (this.onEvent) this.onEvent({ type: 'recover' });
        console.log('[SLO] 延迟已恢复，解除降级模式');
      }
    }
  }

  /**
   * 降级模式下是否启用某服务商（跳过最慢的）
   * 简单实现：降级时只允许延迟 EMA 低于阈值的服务商
   */
  isProviderAllowed(provider) {
    if (!this.degraded) return true;
    const latency = provider?.weights?.latencyMs;
    if (latency == null) return true; // 无数据不拦截
    return latency <= ((this.config.get('slo') || {}).p95ThresholdMs || 4000);
  }

  stats() {
    const cfg = this.cfg();
    return {
      enabled: cfg.enabled,
      degraded: this.degraded,
      degradedAt: this.degradedAt,
      p95Ms: Math.round(this.p95()),
      thresholdMs: cfg.p95ThresholdMs,
      samples: this.samples.length,
      degradedCount: this.degradedCount,
      recoveredCount: this.recoveredCount
    };
  }

  reset() {
    this.samples = [];
    this.degraded = false;
    this.degradedAt = null;
  }
}

module.exports = { SloMonitor };
