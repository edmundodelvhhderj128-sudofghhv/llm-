/**
 * 内置工具集（v2.4.0）——给本地模型"工具"，让它能调用工具更好地管理智能路由
 *
 * 每个工具是 OpenAI function-calling 格式，本地模型（Qwen2.5-7B-Instruct）
 * 在对话中可自主决定调用；执行结果以 role:'tool' 消息回填，模型继续分析。
 * 云端模型请求透传 tools（由调用方处理）。
 *
 * 工具清单（12 个，全部只读或应用内配置操作，不触碰外部系统）：
 *   get_status / get_stats / get_memory / list_providers / list_models
 *   get_recommendation / get_logs / estimate_cost
 *   switch_strategy / set_provider_enabled / flush_cache / probe_providers
 */
class ToolRegistry {
  /**
   * @param {object} deps { config, router, memory, tracer }
   */
  constructor(deps = {}) {
    this.config = deps.config;
    this.router = deps.router;
    this.memory = deps.memory;
    this.tracer = deps.tracer;
    this.enabled = new Set(); // 默认全开，set 由配置覆盖

    // C2 修复：Brain 写操作两阶段确认 + 撤销栈
    // 关键设计：
    // 1. 写操作工具（switch_strategy / set_provider_enabled / flush_cache）首次调用
    //    不直接执行，而是进入「pending 态」并返回 dry-run 预览；
    // 2. Brain 必须调用「同工具+同参数」第二次才会真正执行（两阶段确认）；
    // 3. 撤销栈保留最近 5 次成功写操作，用户/UI 可一键回滚；
    // 4. pending 态每次只能存在一个，新调用会覆盖旧 pending。
    this._pendingWrite = null;
    this._undoStack = []; // [{ name, args, snapshot, executedAt }]
    this._undoMax = 5;

    // H4 修复：白名单/沙箱 + 最小变更原则
    // - READ_ONLY_TOOLS：Brain 任何时候都可以调，不会修改任何状态
    // - WRITE_TOOLS：会修改 config 或清空缓存，需两阶段确认
    // - _sessionWriteCount：单次 run() 决策里写操作执行计数，>1 时直接拒绝
    //   强制"一次诊断一次调整"，避免 Brain 一次性停用 5 个渠道
    this._sessionWriteCount = 0;
    this._sessionMaxWrites = 1;
  }

  /**
   * H4 修复：工具分类（只读 vs 写操作）
   */
  static get TOOL_CATEGORY() {
    return {
      READ_ONLY: new Set([
        'get_status', 'get_stats', 'get_memory', 'list_providers', 'list_models',
        'get_recommendation', 'get_logs', 'estimate_cost', 'probe_providers'
      ]),
      WRITE: new Set(['switch_strategy', 'set_provider_enabled', 'flush_cache']),
      CONTROL: new Set(['cancel_brain_action', 'undo_brain_action'])
    };
  }

  /**
   * H4 修复：判定工具分类
   */
  getToolCategory(name) {
    const c = ToolRegistry.TOOL_CATEGORY;
    if (c.READ_ONLY.has(name)) return 'read';
    if (c.WRITE.has(name)) return 'write';
    if (c.CONTROL.has(name)) return 'control';
    return 'unknown';
  }

  /**
   * H4 修复：单次决策写操作计数（Brain 每次 run() 前 reset）
   */
  resetSessionWrites() { this._sessionWriteCount = 0; }
  getSessionWrites() { return this._sessionWriteCount; }

  /**
   * H4 修复：单次写操作执行前的最小变更校验
   * - 已超 _sessionMaxWrites：拒绝（强制 Brain 分多次决策）
   * - 提供 _sessionMaxWrites 配项给用户（在 brain 高级设置里调）
   */
  _allowWrite(name) {
    if (this._sessionWriteCount >= this._sessionMaxWrites) {
      return {
        allowed: false,
        reason: `单次决策写操作已达上限 ${this._sessionMaxWrites}（最小变更原则）。Brain 应把剩余操作留到下次巡检再做。`
      };
    }
    return { allowed: true, reason: null };
  }

  /**
   * 把一次成功的写操作加入撤销栈（保留可回滚的快照）
   */
  _pushUndo(name, args, snapshot) {
    this._undoStack.unshift({ name, args: { ...args }, snapshot, executedAt: Date.now() });
    if (this._undoStack.length > this._undoMax) this._undoStack.pop();
  }

  /**
   * 获取当前 pending 写操作（供 UI 显示）
   */
  getPendingWrite() {
    return this._pendingWrite;
  }

  /**
   * 获取撤销栈（供 UI 展示）
   */
  getUndoStack() {
    return this._undoStack.map(e => ({
      name: e.name,
      args: e.args,
      executedAt: e.executedAt,
      ageMs: Date.now() - e.executedAt
    }));
  }

  /**
   * 回滚最近一次写操作
   * @returns {object} { ok, name, args, executedAt } 或 { ok:false, error }
   */
  undoLast() {
    if (this._undoStack.length === 0) return { ok: false, error: '撤销栈为空' };
    const entry = this._undoStack.shift();
    try {
      const snap = entry.snapshot;
      if (entry.name === 'switch_strategy' && snap.routingStrategy != null) {
        this.config.set('routing.strategy', snap.routingStrategy);
        this.config.persist?.();
        return { ok: true, name: entry.name, args: entry.args, executedAt: entry.executedAt, note: `已回滚到 routing.strategy=${snap.routingStrategy}` };
      }
      if (entry.name === 'set_provider_enabled' && snap.provider) {
        this.config.updateProvider(snap.provider.id, { enabled: snap.provider.enabled });
        return { ok: true, name: entry.name, args: entry.args, executedAt: entry.executedAt, note: `已回滚 ${snap.provider.name} 的 enabled=${snap.provider.enabled}` };
      }
      if (entry.name === 'flush_cache') {
        // 缓存无法回滚（已被清空），但保留接口一致性
        return { ok: true, name: entry.name, args: entry.args, executedAt: entry.executedAt, note: '缓存已清空，无法回滚' };
      }
      return { ok: false, error: `未知操作: ${entry.name}` };
    } catch (e) {
      return { ok: false, error: '回滚失败: ' + e.message };
    }
  }

  /**
   * OpenAI tools 格式（供本地模型调用）
   */
  toolsPayload() {
    const defs = this.definitions();
    return Object.entries(defs).map(([name, d]) => ({
      type: 'function',
      function: { name, description: d.description, parameters: d.parameters }
    }));
  }

  definitions() {
    return {
      get_status: {
        description: '查看所有渠道（服务商）的运行状态：健康、熔断、限流退避、Key 禁用情况',
        parameters: { type: 'object', properties: {}, additionalProperties: false }
      },
      get_stats: {
        description: '查看全局路由统计：请求数、成功率、平均延迟、总成本、各模型统计',
        parameters: { type: 'object', properties: {}, additionalProperties: false }
      },
      get_memory: {
        description: '查看内置记忆画像：常用模型、各能力推荐、用户使用习惯摘要',
        parameters: { type: 'object', properties: {}, additionalProperties: false }
      },
      list_providers: {
        description: '列出所有渠道及其启停状态、优先级、Key 数量、模型列表',
        parameters: { type: 'object', properties: {}, additionalProperties: false }
      },
      list_models: {
        description: '按渠道列出可用模型及能力分类（对话/图片/视频/嵌入）',
        parameters: { type: 'object', properties: {}, additionalProperties: false }
      },
      get_recommendation: {
        description: '获取某能力（chat/image/video/embedding）下综合最优的推荐模型',
        parameters: {
          type: 'object',
          properties: { capability: { type: 'string', enum: ['chat', 'image', 'video', 'embedding'], description: '能力类型' } },
          required: ['capability'], additionalProperties: false
        }
      },
      get_logs: {
        description: '查看最近的请求 Trace 日志（模型、渠道、状态、延迟、是否切换/缓存）',
        parameters: {
          type: 'object',
          properties: { limit: { type: 'integer', description: '条数，默认 20，最大 100' } },
          additionalProperties: false
        }
      },
      estimate_cost: {
        description: '估算某模型的单次调用成本（基于配置的价格表，美元）',
        parameters: {
          type: 'object',
          properties: { model: { type: 'string', description: '模型名' } },
          required: ['model'], additionalProperties: false
        }
      },
      switch_strategy: {
        description: '切换全局路由策略：priority(优先级)/weighted(加权)/random(随机)/round-robin(轮询)/cost(成本优先)',
        parameters: {
          type: 'object',
          properties: { strategy: { type: 'string', enum: ['priority', 'weighted', 'random', 'round-robin', 'cost'] } },
          required: ['strategy'], additionalProperties: false
        }
      },
      set_provider_enabled: {
        description: '启用或停用某个渠道（按渠道 id；可用 list_providers 查询 id）',
        parameters: {
          type: 'object',
          properties: { providerId: { type: 'string' }, enabled: { type: 'boolean' } },
          required: ['providerId', 'enabled'], additionalProperties: false
        }
      },
      flush_cache: {
        description: '清空内存命中缓存（释放内存，强制下次请求直连上游）',
        parameters: { type: 'object', properties: {}, additionalProperties: false }
      },
      probe_providers: {
        description: '立即触发一次所有渠道的健康检测',
        parameters: { type: 'object', properties: {}, additionalProperties: false }
      },
      cancel_brain_action: {
        description: '取消当前挂起的 Brain 写操作（pending 态）',
        parameters: { type: 'object', properties: {}, additionalProperties: false }
      },
      undo_brain_action: {
        description: '回滚最近一次已执行的 Brain 写操作（最多回滚最近 5 次）',
        parameters: { type: 'object', properties: {}, additionalProperties: false }
      }
    };
  }

  isEnabled(name) {
    return this.enabled.size === 0 || this.enabled.has(name);
  }

  /**
   * 执行一个工具
   * @param {string} name 工具名
   * @param {string|object} argsText JSON 字符串或对象
   * @returns {Promise<object>} { ok, ...data }
   */
  async execute(name, argsText) {
    let args = {};
    if (typeof argsText === 'string') {
      try { args = JSON.parse(argsText || '{}'); } catch (e) { return { ok: false, error: '参数不是合法 JSON: ' + e.message }; }
    } else if (argsText && typeof argsText === 'object') {
      args = argsText;
    }
    const def = this.definitions()[name];
    if (!def) return { ok: false, error: `未知工具: ${name}` };
    if (!this.isEnabled(name)) return { ok: false, error: `工具 ${name} 已被禁用` };

    // H4 修复：白名单/沙箱 - 未分类工具直接拒绝，防止 Brain 调用未注册工具绕过检查
    const category = this.getToolCategory(name);
    if (category === 'unknown') {
      return { ok: false, error: `工具 ${name} 未在沙箱白名单中，拒绝执行` };
    }

    try {
      const fn = this.handlers()[name];
      if (!fn) return { ok: false, error: `工具 ${name} 无实现` };
      const data = await fn(args);
      // H4 修复：写操作真正执行后递增计数（仅在"第二次"确认执行时）
      if (data && data.executed === true) {
        this._sessionWriteCount++;
      }
      if (data && data.error && !data.ok) {
        return { ok: false, error: data.error };
      }
      return { ok: true, ...data };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  }

  handlers() {
    const router = this.router, config = this.config, memory = this.memory;
    return {
      get_status: async () => {
        const out = [];
        for (const p of config.getProviders()) {
          const hc = config.get('health')?.lastResults?.[p.id];
          out.push({
            id: p.id, name: p.name, enabled: p.enabled, kind: p.kind || 'remote',
            healthy: p.kind === 'local' ? (router.localEngine?.running || false) : !!(hc?.healthy ?? true),
            circuitOpen: !!p.circuit?.open,
            rateLimited: !!(p.rateLimitedUntil && p.rateLimitedUntil > Date.now()),
            disabledKeys: Object.values(p.keyStats || {}).filter(k => k.disabled).length,
            priority: p.priority || 99
          });
        }
        return { providers: out };
      },
      get_stats: async () => {
        const s = router.getStats ? router.getStats() : null;
        if (!s) return { error: '统计不可用' };
        return {
          totalRequests: s.totalRequests, successCount: s.successCount, failCount: s.failCount,
          successRate: s.totalRequests ? +((s.successCount / s.totalRequests) * 100).toFixed(1) : 0,
          avgLatencyMs: s.avgLatencyMs ?? null, totalCostUsd: s.totalCost ?? 0,
          providerStats: Object.entries(s.providerStats || {}).map(([id, v]) => ({ id, ...v })),
          topModels: Object.entries(s.modelStats || {}).sort((a, b) => b[1].requests - a[1].requests).slice(0, 5).map(([m, v]) => ({ model: m, ...v }))
        };
      },
      get_memory: async () => {
        const r = memory?.getReport?.();
        if (!r) return { note: '记忆系统未启用' };
        return {
          totalCalls: r.totalCalls,
          recommended: Object.entries(r.recommendations || {}).filter(([, v]) => v).map(([cap, v]) => ({ capability: cap, model: v.model, successRate: v.successRate })),
          lastUsed: r.lastUsedByCapability || {},
          topModels: (r.topModels || []).slice(0, 5).map(t => ({ model: t.name, calls: t.calls, successRate: t.successRate }))
        };
      },
      list_providers: async () => {
        return {
          providers: config.getProviders().map(p => ({
            id: p.id, name: p.name, enabled: p.enabled, kind: p.kind || 'remote',
            baseUrl: p.baseUrl, priority: p.priority || 99, keyCount: (p.keys || []).length,
            models: p.models || []
          }))
        };
      },
      list_models: async () => {
        const caps = {};
        for (const p of config.getProviders()) {
          for (const m of p.models || []) {
            const cap = router.inferModelCapability ? router.inferModelCapability(m) : 'chat';
            (caps[cap] = caps[cap] || []).push({ model: m, provider: p.name });
          }
        }
        return { byCapability: caps };
      },
      get_recommendation: async ({ capability }) => {
        const r = memory?.getReport?.();
        const rec = r?.recommendations?.[capability];
        return rec ? { capability, recommended: rec } : { capability, recommended: null, note: '暂无足够数据' };
      },
      get_logs: async ({ limit } = {}) => {
        const n = Math.min(parseInt(limit, 10) || 20, 100);
        const logs = this.tracer?.recent?.(n) || [];
        return { logs: logs.map(l => ({ model: l.model, provider: l.provider, status: l.status, latency: l.latency, switched: l.switched, cached: l.cached, time: l.time })) };
      },
      estimate_cost: async ({ model }) => {
        const price = router.getPrice ? router.getPrice(model) : null;
        if (!price) return { model, note: '无价格配置（内置默认价）', estimatedUsd: 0 };
        const per1k = +((price.input || 0) / 1000 + (price.output || 0) / 1000).toFixed(6);
        return { model, inputPerM: price.input || 0, outputPerM: price.output || 0, estimatedPer1kInOutUsd: per1k };
      },
      switch_strategy: async ({ strategy }) => {
        // H4 修复：最小变更原则 - 单次决策最多 1 个写操作
        const allow = this._allowWrite('switch_strategy');
        if (!allow.allowed) return { ok: false, error: allow.reason };
        // C2 修复：两阶段确认 - 首次调用进入 pending 态，Brain 需再次调用同工具+同参数才真正执行
        const validStrategies = ['priority', 'weighted', 'random', 'round-robin', 'cost'];
        if (!validStrategies.includes(strategy)) return { ok: false, error: `不支持的策略: ${strategy}` };
        const current = this.config.get('routing.strategy');
        if (strategy === current) return { ok: true, note: '策略未变化，无需操作' };

        // 第二次调用 = 真正执行
        if (this._pendingWrite && this._pendingWrite.name === 'switch_strategy'
            && this._pendingWrite.args.strategy === strategy) {
          const oldStrategy = current;
          config.set('routing.strategy', strategy);
          config.persist?.();
          this._pendingWrite = null;
          this._pushUndo('switch_strategy', { strategy }, { routingStrategy: oldStrategy });
          this.memory?.trackFeature?.('brain_action_executed', { detail: `switch_strategy ${oldStrategy}->${strategy}` });
          return { ok: true, strategy, executed: true, note: '已切换路由策略' };
        }
        // 首次调用 = 进入 pending
        this._pendingWrite = { name: 'switch_strategy', args: { strategy }, at: Date.now() };
        this.memory?.trackFeature?.('brain_action_pending', { detail: `switch_strategy -> ${strategy}` });
        return {
          ok: true,
          pending: true,
          preview: `将切换路由策略: ${current} -> ${strategy}`,
          current,
          target: strategy,
          note: '【两阶段确认】此操作已挂起，Brain 需再调用一次 switch_strategy(' + strategy + ') 才会真正执行；调用其他写操作会覆盖此 pending；用户可在 UI 上看到此建议并选择拒绝'
        };
      },
      set_provider_enabled: async ({ providerId, enabled }) => {
        // H4 修复：最小变更原则 - 单次决策最多 1 个写操作
        const allow = this._allowWrite('set_provider_enabled');
        if (!allow.allowed) return { ok: false, error: allow.reason };
        let p = config.getProviders().find(x => x.id === providerId);
        if (!p) p = config.getProviders().find(x => x.name === providerId);
        if (!p) {
          const cand = config.getProviders().slice(0, 5).map(x => `${x.name}(id=${x.id})`).join('，');
          return { error: `渠道不存在: ${providerId}（可用：${cand}）` };
        }
        if (p.enabled === !!enabled) return { ok: true, note: '状态未变化，无需操作' };

        // C2 修复：两阶段确认
        if (this._pendingWrite && this._pendingWrite.name === 'set_provider_enabled'
            && this._pendingWrite.args.providerId === providerId
            && this._pendingWrite.args.enabled === !!enabled) {
          const oldEnabled = p.enabled;
          config.updateProvider(p.id, { enabled: !!enabled });
          this._pendingWrite = null;
          this._pushUndo('set_provider_enabled', { providerId, enabled: !!enabled }, { provider: { id: p.id, name: p.name, enabled: oldEnabled } });
          this.memory?.trackFeature?.('brain_action_executed', { detail: `set_provider_enabled ${p.name}=${!!enabled}` });
          return { ok: true, providerId: p.id, name: p.name, enabled: !!enabled, executed: true };
        }
        // 首次调用 = pending
        this._pendingWrite = { name: 'set_provider_enabled', args: { providerId, enabled: !!enabled }, at: Date.now() };
        this.memory?.trackFeature?.('brain_action_pending', { detail: `${p.name} enabled=${!!enabled}` });
        return {
          ok: true,
          pending: true,
          preview: `将${enabled ? '启用' : '停用'}渠道: ${p.name}`,
          providerId: p.id,
          name: p.name,
          targetEnabled: !!enabled,
          currentEnabled: p.enabled,
          note: '【两阶段确认】此操作已挂起，Brain 需再调用一次 set_provider_enabled(providerId=' + p.id + ', enabled=' + !!enabled + ') 才会真正执行'
        };
      },
      flush_cache: async () => {
        // H4 修复：最小变更原则 + 两阶段确认
        const allow = this._allowWrite('flush_cache');
        if (!allow.allowed) return { ok: false, error: allow.reason };
        if (this._pendingWrite && this._pendingWrite.name === 'flush_cache') {
          const n = router.clearCache?.() || 0;
          this._pendingWrite = null;
          this._pushUndo('flush_cache', {}, { cacheCleared: true });
          this.memory?.trackFeature?.('brain_action_executed', { detail: `flush_cache ${n}` });
          return { ok: true, cleared: n, executed: true };
        }
        this._pendingWrite = { name: 'flush_cache', args: {}, at: Date.now() };
        this.memory?.trackFeature?.('brain_action_pending', { detail: 'flush_cache' });
        return {
          ok: true,
          pending: true,
          preview: '将清空内存命中缓存（不可恢复）',
          note: '【两阶段确认】此操作已挂起，Brain 需再调用一次 flush_cache() 才会真正执行'
        };
      },
      probe_providers: async () => {
        // 触发健康检测（若在运行）
        if (global.__healthChecker__?.checkAll) {
          global.__healthChecker__.checkAll().catch(() => {});
          return { ok: true, note: '健康检测已触发' };
        }
        return { ok: true, note: '健康检测未运行（无定时器）' };
      },
      cancel_brain_action: async () => {
        // C2 修复：Brain 可主动取消自己刚才挂起的写操作
        if (!this._pendingWrite) return { ok: true, note: '无挂起的写操作' };
        const cancelled = this._pendingWrite;
        this._pendingWrite = null;
        this.memory?.trackFeature?.('brain_action_cancelled', { detail: cancelled.name });
        return { ok: true, cancelled, note: '已取消挂起的写操作' };
      },
      undo_brain_action: async () => {
        // C2 修复：Brain 可主动回滚最近一次写操作
        const r = this.undoLast();
        if (r.ok) this.memory?.trackFeature?.('brain_action_undone', { detail: r.name });
        return r;
      }
    };
  }
}

module.exports = { ToolRegistry };
