/**
 * 语义缓存——用嵌入相似度匹配语义等价的请求，命中即返回（延迟趋近零、成本为零）
 * 降本提速的"最后一公里"：精确缓存只命中字面相同的请求，语义缓存可命中改写/同义表达
 */
class SemanticCache {
  constructor(config) {
    this.config = config;
    // H2 修复：entries 按 variant 隔离存储，避免不同压缩/路由配置下的回复互相串味
    // 结构：Map<variant, Map<textHash, entry>>
    this.entries = new Map();
    this.used = 0;
    this.hits = 0;
    this.misses = 0;
    this.embedErrors = 0;
  }

  cfg() {
    const c = this.config.get('semanticCache') || {};
    return { enabled: false, threshold: 0.95, maxEntries: 2000, ...c };
  }

  /**
   * H2 修复：获取指定 variant 的存储桶（不存在则创建）
   * 用 Map<variant, ...> 隔离不同压缩/路由配置下的回复，
   * 避免"近似但不同"的回复在不同 variant 间互相命中
   */
  _bucket(variant) {
    const v = String(variant || '__default__');
    if (!this.entries.has(v)) this.entries.set(v, new Map());
    return this.entries.get(v);
  }

  /**
   * 余弦相似度
   */
  static cosine(a, b) {
    if (!Array.isArray(a) || !Array.isArray(b) || a.length !== b.length || a.length === 0) return 0;
    let dot = 0, na = 0, nb = 0;
    for (let i = 0; i < a.length; i++) {
      dot += a[i] * b[i];
      na += a[i] * a[i];
      nb += b[i] * b[i];
    }
    if (na === 0 || nb === 0) return 0;
    return dot / (Math.sqrt(na) * Math.sqrt(nb));
  }

  hash(text) {
    const crypto = require('crypto');
    return crypto.createHash('md5').update(String(text)).digest('hex');
  }

  /**
   * 查询语义缓存
   * @param {number[]} embedding 嵌入向量
   * @param {string} text 原始文本
   * @param {string} variant 变体签名（H2：隔离不同压缩/路由配置）
   * @returns {{hit: boolean, response: object|null, similarity: number, text: string}|null}
   */
  lookup(embedding, text, variant = '__default__') {
    const cfg = this.cfg();
    if (!cfg.enabled || !embedding) { this.misses++; return { hit: false, response: null, similarity: 0, text }; }
    const bucket = this._bucket(variant);
    let best = null;
    let bestSim = 0;
    for (const entry of bucket.values()) {
      const sim = SemanticCache.cosine(embedding, entry.embedding);
      if (sim > bestSim) { bestSim = sim; best = entry; }
    }
    if (best && bestSim >= cfg.threshold) {
      this.hits++;
      best.hits++;
      best.lastAccess = Date.now();
      // LRU touch
      bucket.delete(best._key);
      bucket.set(best._key, best);
      return { hit: true, response: best.response, similarity: bestSim, text: best.text };
    }
    this.misses++;
    return { hit: false, response: null, similarity: bestSim, text };
  }

  /**
   * 写入语义缓存
   * @param {number[]} embedding 嵌入向量
   * @param {string} text 原始文本
   * @param {object} response 响应数据
   * @param {string} variant 变体签名（H2：隔离不同压缩/路由配置）
   */
  put(embedding, text, response, variant = '__default__') {
    const cfg = this.cfg();
    if (!cfg.enabled || !embedding || !text || !response) return false;
    const bucket = this._bucket(variant);
    const key = this.hash(text);
    if (bucket.has(key)) return true;
    const entry = { text, embedding, response, hits: 0, lastAccess: Date.now(), _key: key, _variant: variant };
    bucket.set(key, entry);
    // LRU 淘汰：仅对当前 variant 桶内淘汰（不同 variant 互不影响）
    while (bucket.size > (cfg.maxEntries || 2000)) {
      const oldestKey = bucket.keys().next().value;
      if (oldestKey == null) break;
      bucket.delete(oldestKey);
    }
    return true;
  }

  /**
   * 从请求消息提取待嵌入文本
   */
  extractText(messages) {
    const parts = [];
    for (const m of messages || []) {
      if (typeof m?.content === 'string') parts.push(m.content);
    }
    return parts.join('\n').trim();
  }

  stats() {
    const cfg = this.cfg();
    const total = this.hits + this.misses;
    // H2 修复：统计所有 variant 桶的总数
    let totalEntries = 0;
    for (const bucket of this.entries.values()) totalEntries += bucket.size;
    return {
      enabled: cfg.enabled,
      threshold: cfg.threshold,
      maxEntries: cfg.maxEntries,
      entries: totalEntries,
      variants: this.entries.size,
      hits: this.hits,
      misses: this.misses,
      embedErrors: this.embedErrors,
      hitRate: total > 0 ? +((this.hits / total) * 100).toFixed(1) : 0
    };
  }

  clear() {
    this.entries.clear();
    this.hits = 0;
    this.misses = 0;
    this.embedErrors = 0;
  }

  /**
   * H2 修复：清除指定 variant 的缓存（不污染其他 variant）
   * @param {string} variant
   * @returns {boolean} 是否清除了任何条目
   */
  clearVariant(variant) {
    const v = String(variant || '__default__');
    const bucket = this.entries.get(v);
    if (!bucket || bucket.size === 0) return false;
    bucket.clear();
    this.entries.delete(v);
    return true;
  }
}

module.exports = { SemanticCache };
