/**
 * LLM 智能路由核心引擎 v2.0
 * 支持多服务商、多Key轮换、加权路由、熔断保护、配额管理、成本优化、跨模型回退、A/B测试
 */
const { BUILTIN_PRICES } = require('./config');
const { MemoryCache, DEFAULT_MAX_BYTES } = require('./cache');
const { TraceLogger } = require('./trace');
const { ContentGuard } = require('./guard');
const { SemanticCache } = require('./semantic-cache');
const { SloMonitor } = require('./slo');
const { MandatoryGuard } = require('./mandatory-guard');

const KEY_DISABLE_THRESHOLD = 3;   // 连续错误 N 次禁用 Key
const KEY_RECOVER_ERRORS = ['401', '403', '429'];

/**
 * 流式 token 估算（INTERACTION-AUDIT C3 修复）：
 * 不依赖 tiktoken 第三方包（避免新增依赖），用 OpenAI 公开的 cl100k_base 近似公式：
 * - 1 token ≈ 4 个英文字符 / 0.75 个英文单词
 * - 1 个中文字符 ≈ 1.5~2 token（这里取 1.8）
 * 整体误差约 ±15%，对配额/成本报表影响远好于「永远 0」
 */
function estimateTokensFromText(text) {
  if (!text) return 0;
  const s = String(text);
  // 中文字符（CJK 统一表意文字）单独按 1.8 token/字符估算
  const cjkChars = (s.match(/[\u4e00-\u9fff\u3400-\u4dbf\uf900-\ufaff]/g) || []).length;
  // 其余字符按 4 字符/token
  const otherChars = s.length - cjkChars;
  // 单词粗略计数：非 CJK 字符中的连续字母串
  const wordCount = (s.replace(/[\u4e00-\u9fff]/g, ' ').match(/[A-Za-z]+/g) || []).length;
  const otherTokens = Math.ceil(otherChars / 4) + Math.ceil(wordCount * 0.25);
  const cjkTokens = Math.ceil(cjkChars * 1.8);
  return cjkTokens + otherTokens;
}

/**
 * 估算 messages 数组的 token 总数
 */
function estimateMessagesTokens(messages) {
  if (!Array.isArray(messages)) return 0;
  // 每条消息固定 4 token（role 标记 + 边界）
  let total = messages.length * 4;
  for (const m of messages) {
    if (typeof m?.content === 'string') {
      total += estimateTokensFromText(m.content);
    } else if (Array.isArray(m?.content)) {
      // 多模态（文本+图片）：文本部分按文本估算，图片按 765 token/张（OpenAI 公开近似）
      for (const part of m.content) {
        if (part?.type === 'text' && typeof part.text === 'string') {
          total += estimateTokensFromText(part.text);
        } else if (part?.type === 'image_url') {
          total += 765;
        }
      }
    }
  }
  return total;
}

class Router {
  constructor(config, userDataDir) {
    this.config = config;
    this.cache = new MemoryCache({ maxBytes: DEFAULT_MAX_BYTES });
    this.tracer = new TraceLogger(config, userDataDir);
    this.guard = new ContentGuard(config);
    this.semanticCache = new SemanticCache(config);
    this.slo = new SloMonitor(config);
    this.mandatoryGuard = new MandatoryGuard();   // 强制内容拦截（不可关闭）
    this.modelMemory = null;                      // 内置记忆系统（由 main 注入）
    this.localEngine = null;                      // 本地模型引擎（v2.4.0，由 main 注入）
    this.toolRegistry = null;                     // 内置工具集（v2.4.0，由 main 注入）
    this.brain = null;                            // 路由大脑（v2.5.0，由 main 注入）
    this.lastActivityAt = Date.now();             // 最近路由活动时间（v2.6.2 空闲休眠/自动唤醒用）
    this.autoWakeHook = null;                     // 自动唤醒钩子（main 注入：引擎休眠时后台启动）
    this.lkgp = new Map();                        // 最后成功渠道（v2.8.0 借鉴 OmniRoute lkgp）：model -> providerId
    this.promptCacheAffinity = new Map();         // 提示缓存亲和（v2.8.1 借鉴 OmniRoute）：system前缀 -> providerId
    this._affinityLRUCap = 100;                   // M3 修复：LRU 上限，防止 Map 无限膨胀
    this.affinityStats = { hits: 0, total: 0, invalidations: 0 };
    this.videoTasks = new Map();   // 视频生成异步任务表：taskId -> {providerId, model, baseUrl, pathStyle, upstreamId}
    this.compressionStats = { compressedRequests: 0, savedTokens: 0, heuristic: 0, smart: 0 };
    this._inflight = new Map();   // 并发单飞去重：cacheKey -> 进行中的路由任务
    this.stats = {
      totalRequests: 0,
      successCount: 0,
      failCount: 0,
      totalCost: 0,          // 预估总成本（v2.0.4，按各服务商计费方式累计）
      providerStats: {},
      modelStats: {},
      recentRequests: []
    };
    this.onStatsUpdate = null;
  }

  /**
   * 注入内置记忆系统（学习渠道模型与用户习惯）
   */
  setModelMemory(mm) {
    this.modelMemory = mm;
  }

  /**
   * 注入本地引擎与工具集（v2.4.0）
   */
  setLocalEngine(engine, toolRegistry) {
    this.localEngine = engine;
    this.toolRegistry = toolRegistry;
    if (engine) {
      engine.toolExecutor = (name, argsText) => toolRegistry ? toolRegistry.execute(name, argsText) : Promise.resolve({ ok: false, error: '工具集未初始化' });
    }
  }

  /**
   * 工具执行入口（供本地模型工具循环与 UI 面板共用）
   */
  async executeTool(name, argsText) {
    if (!this.toolRegistry) return { ok: false, error: '工具集未初始化' };
    const r = await this.toolRegistry.execute(name, argsText);
    this.track('local_tool', { detail: name, ok: !!r.ok });
    return r;
  }

  /**
   * 不可重试错误检测（v2.7.0，借鉴 OmniRoute nonRetryableUpstream）：
   * 账号封禁/Cloudflare 签名封锁/配额耗尽等——重试无意义，立即禁用该 Key 快速失败
   */
  isHopelessError(error) {
    if (!error) return false;
    const t = String(error.message || error.text || error.body || '');
    const lower = t.toLowerCase();
    return /browser_signature_banned|cloudflare|error 1010|\"error_code\"\s*:\s*1010|insufficient_quota|quota exhausted|quota exceeded|account (suspended|disabled|locked)|permission denied|access denied|forbidden for this key|key (invalid|expired|revoked|disabled)|invalid api key|api key not found/i.test(lower);
  }

  /**
   * 提示缓存亲和键（v2.8.1，借鉴 OmniRoute promptCacheAffinity）：
   * 取 system 消息内容前 300 字符作为前缀指纹——上游 prompt caching 按前缀命中，
   * 相同前缀固定渠道可命中缓存，省 50-90% 输入 tokens 费用
   */
  computeAffinityKey(messages) {
    if (!Array.isArray(messages)) return null;
    const sys = messages.filter(m => m.role === 'system' && typeof m.content === 'string' && m.content.trim());
    if (sys.length === 0) return null;
    return sys.map(m => m.content).join('\n').slice(0, 300);
  }

  /**
   * auto 模型智能选择（v2.10.0，借鉴 OmniRoute taskFitness）：
   * 按 意图+复杂度 从所有渠道的聊天模型中选匹配度最高者（含稳定性加权）
   */
  pickModelByTask(reqIntent, overrides = {}) {
    const { taskFitness } = require('./intent');
    const providers = this.config.getEnabledProviders().filter(p => p.kind !== 'local');
    const candidates = new Map();   // model -> { fitness, support }
    for (const p of providers) {
      for (const m of p.models || []) {
        if (this.inferModelCapability(m) !== 'chat') continue;
        const fit = taskFitness(m, reqIntent.intent, reqIntent.complexity, overrides);
        const cur = candidates.get(m) || { fitness: 0, support: 0 };
        cur.fitness += fit;
        cur.support += 1;
        candidates.set(m, cur);
      }
    }
    let best = null, bestScore = -1;
    for (const [m, c] of candidates) {
      // 综合：平均匹配度 × 渠道支持数（稳定性），简单加权
      const score = (c.fitness / c.support) + Math.min(0.3, c.support * 0.05);
      if (score > bestScore) { bestScore = score; best = m; }
    }
    return best;
  }

  /**
   * 注入路由大脑（v2.5.0）：关键事件（熔断/限流/Key保护）自动唤醒大脑分析
   */
  setBrain(brain) {
    this.brain = brain;
  }

  /**
   * 模型后端选择（v2.5.1）：auto=本地引擎在跑优先用本地，否则云端；cloud/local 强制指定
   * @param {string} cfgPath 如 'quality.judgeBackend'
   * @param {string} [def] 默认 auto
   * @returns {'local'|'cloud'}
   */
  backendFor(cfgPath, def = 'auto') {
    const mode = this.config.get(cfgPath) ?? def;
    if (mode === 'cloud') return 'cloud';
    if (mode === 'local') return this.localEngine?.running ? 'local' : 'cloud';
    // auto：引擎在跑优先本地，否则回落云端
    return this.localEngine?.running ? 'local' : 'cloud';
  }

  /**
   * 路由活动打卡（v2.6.2）：任何请求进入时更新活动时间；引擎休眠时触发自动唤醒
   */
  touchActivity() {
    this.lastActivityAt = Date.now();
    const lc = this.config.get('local') || {};
    if (lc.autoWake !== false && this.localEngine && !this.localEngine.running && !this.localEngine.waking) {
      try {
        if (this.autoWakeHook) this.autoWakeHook();
      } catch (e) { /* 唤醒失败不影响请求 */ }
    }
  }

  /**
   * H6 修复：把 autoWakeHook 注入到 localEngine，让 chat/chatWithTools 入口也能触发唤醒
   * （原实现只挂到 router 顶部，路由走 tryRouteModel → callProvider → localEngine.chat
   *  时直接进入 chat() 内部，从未经过 router 顶部 hook，导致流式请求在空闲后第一个会失败）
   */
  installAutoWakeOnEngine() {
    if (!this.localEngine) return;
    const hook = () => {
      try {
        if (this.autoWakeHook) this.autoWakeHook();
      } catch (e) { /* 唤醒失败不影响请求 */ }
    };
    // 暴露给 localEngine，让它在 chat/chatWithTools/embeddings 等入口前自检
    this.localEngine.routerAutoWakeHook = hook;
  }

  /**
   * M3 修复：promptCacheAffinity LRU 上限控制
   * 命中时把键移到末尾（touch），超出时淘汰最旧的
   * O(N) 简单实现，N 上限 100，可接受
   */
  _enforceAffinityLRU() {
    if (this.promptCacheAffinity.size <= this._affinityLRUCap) return;
    // 简单 FIFO：Map 插入顺序 = 写入顺序；超出后从头部淘汰
    const toRemove = this.promptCacheAffinity.size - this._affinityLRUCap;
    const it = this.promptCacheAffinity.keys();
    for (let i = 0; i < toRemove; i++) {
      const k = it.next().value;
      if (k == null) break;
      this.promptCacheAffinity.delete(k);
    }
  }

  /**
   * 是否达到空闲休眠条件（v2.6.2）：引擎在跑且超过 idleSleepMinutes 无请求
   */
  isEngineIdle(now = Date.now()) {
    const lc = this.config.get('local') || {};
    // 后端=云端渠道模型：无本地进程、不占内存，不做空闲休眠（否则会把云端渠道模型停用）
    if (lc.backend === 'cloud') return false;
    const min = lc.idleSleepMinutes;
    if (!min || min <= 0) return false;                       // 0/未配置 = 关闭自动休眠
    if (!this.localEngine || !this.localEngine.running) return false;
    return (now - (this.lastActivityAt || now)) >= min * 60000;
  }

  /**
   * 本地模型可用的后端能力（UI 展示用）
   */
  localBackendCapabilities() {
    const running = !!this.localEngine?.running;
    return {
      engineRunning: running,
      judge: this.backendFor('quality.judgeBackend'),
      smartCompress: this.backendFor('compression.smartBackend'),
      embed: this.backendFor('semanticCache.embedBackend')
    };
  }

  /**
   * 功能使用埋点（对接记忆系统）
   */
  track(id, opts) {
    try {
      this.modelMemory?.trackFeature(id, opts);
      // 关键事件唤醒路由大脑（熔断/限流/Key保护）
      if (this.brain && (id === 'circuit_break' || id === 'rate_limit_backoff' || id === 'key_guard')) {
        this.brain.notify(id);
      }
    } catch (e) { /* 埋点失败不影响主流程 */ }
  }

  /**
   * 计算服务商 API 基础路径（兼容不同接口前缀）
   * pathStyle: 'v1'  → baseUrl + '/v1'（OpenAI 标准）
   *            'none' → baseUrl 原样（智谱 /api/paas/v4、千帆 /v2、Groq /openai/v1 等）
   */
  apiBase(provider) {
    const base = String(provider?.baseUrl || '').replace(/\/$/, '');
    const style = provider?.pathStyle || 'v1';
    return style === 'none' ? base : base + '/v1';
  }

  /**
   * 模型能力识别（多模态路由用）：image / video / embedding / chat
   */
  inferModelCapability(model) {
    const m = String(model || '').toLowerCase();
    if (/(image|dall-e|dalle|flux|sdxl|stable-diffusion|midjourney|kolors|seedream|janus|gpt-image|nano-banana|sensenova-u1|agnes-image|hunyuan-image|cogview|pixart|wanx|wan2|wan-2|doubao-seed)/.test(m)) return 'image';
    if (/(video|veo|sora|runway|kling|keling|hailuo|seedance|agnes-video|hunyuan-video|minimax-vl|skyreels)/.test(m)) return 'video';
    if (/(embed|text-embed|bge|mxbai|e5|m3$)/.test(m)) return 'embedding';
    return 'chat';
  }

  /**
   * 策略过滤：数据驻留 + SLO 降级（多模态路由复用）
   * @returns {{ allowed: boolean, reason: string|null }}
   * H3 修复：返回具体被拒原因，供 selectProviders 区分"零匹配"和"全过滤"
   */
  providerAllowed(provider) {
    const residency = this.config.get('residency') || {};
    if (residency.enabled && Array.isArray(residency.allowedRegions) && residency.allowedRegions.length > 0) {
      const allowed = residency.allowedRegions.map(r => String(r).toUpperCase());
      if (!allowed.includes(String(provider.region || 'any').toUpperCase())) {
        return { allowed: false, reason: `数据驻留：区域 ${provider.region || 'any'} 不在允许列表 ${JSON.stringify(residency.allowedRegions)}` };
      }
    }
    if (this.slo.degraded && !this.slo.isProviderAllowed(provider)) {
      return { allowed: false, reason: `SLO 降级：${provider.name} 延迟 p95 超阈值` };
    }
    return { allowed: true, reason: null };
  }

  /**
   * 获取所有可用模型（含价格信息）
   */
  getAllModels() {
    const providers = this.config.getEnabledProviders();
    const modelMap = new Map();

    for (const provider of providers) {
      for (const model of provider.models) {
        if (!modelMap.has(model)) {
          modelMap.set(model, { id: model, providers: [] });
        }
        modelMap.get(model).providers.push({
          id: provider.id,
          name: provider.name,
          priority: provider.priority
        });
      }
    }

    const models = Array.from(modelMap.values());
    // 附加价格信息与能力标签（多模态路由用）
    for (const m of models) {
      const price = this.getPrice(m.id);
      if (price) m.price = price;
      m.capability = this.inferModelCapability(m.id);
    }
    return models;
  }

  /**
   * 自动获取服务商的模型列表
   */
  async fetchModels(providerId) {
    const provider = this.config.getProviders().find(p => p.id === providerId);
    if (!provider) throw new Error('服务商不存在');
    if (!provider.keys.length) throw new Error('请先添加 API Key');

    const key = this.getActiveKey(provider);
    const url = `${this.apiBase(provider)}/models`;

    const response = await fetch(url, {
      headers: { 'Authorization': `Bearer ${key}` },
      signal: AbortSignal.timeout(15000)
    });

    if (!response.ok) {
      const text = await response.text();
      throw new Error(`HTTP ${response.status}: ${text}`);
    }

    const data = await response.json();
    const models = (data.data || []).map(m => m.id).sort();

    // 更新服务商的模型列表
    this.config.updateProvider(providerId, { models });

    return models;
  }

  /**
   * 批量获取所有服务商的模型
   */
  async fetchAllModels() {
    const providers = this.config.getEnabledProviders();
    const results = {};

    await Promise.allSettled(
      providers.map(async (p) => {
        try {
          const models = await this.fetchModels(p.id);
          results[p.id] = { success: true, models };
        } catch (e) {
          results[p.id] = { success: false, error: e.message };
        }
      })
    );

    return results;
  }

  /**
   * 价格管理
   */
  getPrice(modelId) {
    const models = this.config.get('prices.models') || {};
    const p = models[modelId];
    if (!p) return null;
    return { input: p.input || 0, output: p.output || 0 };
  }

  setPrice(modelId, input, output) {
    const models = { ...(this.config.get('prices.models') || {}) };
    models[modelId] = { input: Number(input) || 0, output: Number(output) || 0 };
    // 重新添加：从删除列表移除
    const removed = (this.config.get('prices.removed') || []).filter(r => r !== modelId);
    this.config.set('prices.removed', removed);
    this.config.set('prices.models', models);
    return models[modelId];
  }

  removePrice(modelId) {
    const models = { ...(this.config.get('prices.models') || {}) };
    delete models[modelId];
    // 记入删除列表，防止下次启动合并内置表时复活
    const removed = [...(this.config.get('prices.removed') || []), modelId];
    this.config.set('prices.removed', removed);
    this.config.set('prices.models', models);
    return true;
  }

  /**
   * 一键同步上游价格：用内置价格表补齐缺失的模型价格
   * （各服务商价格接口不统一，这里以内置参考价为准，用户可再手动微调）
   * @returns {number} 补齐的数量
   */
  syncPrices() {
    const models = { ...(this.config.get('prices.models') || {}) };
    const removed = this.config.get('prices.removed') || [];
    const removedSet = new Set(removed);
    let synced = 0;

    // 1. 内置价格表中缺失的补上（用户删除过的不补）
    for (const [name, price] of Object.entries(BUILTIN_PRICES)) {
      if (!removedSet.has(name) && !models[name]) {
        models[name] = { ...price };
        synced++;
      }
    }

    // 2. 从服务商已配置的模型中，把内置表里有价格但缺失的也补上（删除过的不补）
    for (const p of this.config.getProviders()) {
      for (const m of p.models || []) {
        if (!removedSet.has(m) && BUILTIN_PRICES[m] && !models[m]) {
          models[m] = { ...BUILTIN_PRICES[m] };
          synced++;
        }
      }
    }

    this.config.set('prices.models', models);
    return synced;
  }

  /**
   * 货币换算（USD <-> CNY），用于界面展示
   */
  convertPrice(usdAmount, targetCurrency) {
    const currency = targetCurrency || this.config.get('currency') || 'USD';
    if (currency === 'CNY') {
      return { amount: +(usdAmount * 7.2).toFixed(4), currency: 'CNY', rate: 7.2 };
    }
    return { amount: +usdAmount.toFixed(4), currency: 'USD', rate: 1 };
  }

  /**
   * 智能路由 - 聊天补全
   */
  async routeChatCompletion({ model, messages, stream, ...rest }) {
    const result = await this.routeWithFallback({
      model, messages, stream, ...rest
    });
    return result.data;
  }

  /**
   * 核心路由 + 跨模型回退 + A/B 分流 + 内存缓存 + 语义缓存 + 影子决策 + Trace
   * @param context { traceId } 调用上下文
   */
  async routeWithFallback({ model, messages, stream, ...rest }, context = {}) {
    this.stats.totalRequests++;
    this.track('chat_req');
    this.touchActivity();
    this.notifyStatsUpdate();
    const traceId = context.traceId || this.tracer.newTraceId();
    const trace = { traceId, model, requestedModel: model, strategy: this.config.get('routing.strategy'), time: new Date().toISOString() };

    // ---- 请求级意图/复杂度识别（v2.10.0，借鉴 OmniRoute intentClassifier）： ----
    // 记录到 trace 供回放分析；复杂/代码请求在回退时优先强模型；支持 model='auto' 智能选模型
    let reqIntent = null;
    let reqModel = model;
    try {
      const { analyzeRequest, taskFitness, modelStrength } = require('./intent');
      const overrides = this.config.get('routing.modelStrength') || {};
      reqIntent = analyzeRequest(messages, overrides);
      trace.intent = reqIntent.intent;
      trace.complexity = reqIntent.complexity;
      trace.tokens = reqIntent.tokens;
      this.stats.intentStats = this.stats.intentStats || {};
      this.stats.intentStats[reqIntent.intent] = (this.stats.intentStats[reqIntent.intent] || 0) + 1;
      // model='auto'：按 意图+复杂度 从所有渠道的聊天模型中选最优
      if ((model === 'auto' || model === 'auto-chat') && (this.config.get('routing.intentRouting') ?? true)) {
        const best = this.pickModelByTask(reqIntent, overrides);
        if (best) { reqModel = best; trace.requestedModel = model; trace.model = best; trace.autoModel = best; }
      }
    } catch (e) { /* 识别失败不影响主流程 */ }

    // ---- 强制内容拦截（不可关闭）：命中直接拒绝，仅返回通用提示 ----
    if (this.mandatoryGuard.checkMessages(messages)) {
      this.stats.failCount++;
      this.stats.mandatoryBlocks = (this.stats.mandatoryBlocks || 0) + 1;
      this.track('content_guard', { ok: false });
      trace.status = 'blocked';
      trace.error = this.mandatoryGuard.genericReason;
      this.tracer.write(trace);
      const err = new Error(this.mandatoryGuard.genericReason);
      err.status = 403;
      err.mandatory = true;
      throw err;
    }

    // ---- 内容护栏：输入敏感词拦截 ----
    const guardCheck = this.guard.checkMessages(messages);
    if (guardCheck.blocked) {
      this.stats.failCount++;
      trace.status = 'blocked';
      trace.error = '敏感词拦截: ' + guardCheck.reasons.join(',');
      this.tracer.write(trace);
      const err = new Error('内容护栏拦截：输入命中敏感词');
      err.status = 403;
      throw err;
    }
    // ---- 内存命中缓存：相同 模型+消息+参数 直接返回，节省上游调用 ----
    const cacheCfg = this.config.get('cache') || {};
    const { noCache, ...forwardRest } = rest;
    // 意图/复杂度识别可能把 model 换成 auto 智能选出的模型（v2.10.0）
    const finalModel = reqModel || model;
    const cacheEnabled = cacheCfg.enabled && !noCache && !!finalModel && Array.isArray(messages) && messages.length > 0;
    let cacheKey = null;
    if (cacheEnabled) {
      this.cache.maxBytes = cacheCfg.maxBytes || DEFAULT_MAX_BYTES;
      cacheKey = this.getCacheKey(finalModel, messages, forwardRest);
      const hit = this.cache.get(cacheKey);
      if (hit) {
        // 命中：不产生任何上游调用/配额消耗
        this.stats.successCount++;
        this.stats.recentRequests.unshift({
          time: new Date().toISOString(),
          model: finalModel,
          provider: '缓存',
          status: 'success',
          latency: 0,
          switched: false,
          cached: true
        });
        if (this.stats.recentRequests.length > 50) this.stats.recentRequests.pop();
        this.notifyStatsUpdate();
        trace.status = 'success';
        trace.provider = '缓存';
        trace.cached = true;
        trace.cacheType = 'exact';
        trace.latency = 0;
        this.tracer.write(trace);
        return {
          success: true,
          data: hit,
          meta: {
            model: finalModel,
            provider: '缓存',
            providerId: 'cache',
            latency: 0,
            switched: false,
            cached: true,
            cacheType: 'exact',
            cacheKey
          }
        };
      }
      this.track('cache_miss');
      // 未命中：继续正常路由（流式响应由代理层完成后通过 cachePut 回写）
    } else {
      // 缓存未启用：跳过
    }

    // ---- 语义缓存：嵌入相似度命中（精确缓存未命中时） ----
    const scCfg = this.config.get('semanticCache') || {};
    let semanticPending = null;
    if (scCfg.enabled && !noCache && !stream && Array.isArray(messages) && messages.length > 0) {
      const text = this.semanticCache.extractText(messages);
      if (text) {
        const emb = await this.embedText(text);
        const sres = this.semanticCache.lookup(emb, text, this.compressionVariant());
        if (sres.hit) {
          this.track('semantic_cache_hit');
          this.stats.successCount++;
          this.stats.recentRequests.unshift({
            time: new Date().toISOString(),
            model,
            provider: '语义缓存',
            status: 'success',
            latency: 0,
            switched: false,
            cached: true
          });
          if (this.stats.recentRequests.length > 50) this.stats.recentRequests.pop();
          this.notifyStatsUpdate();
          trace.status = 'success';
          trace.provider = '语义缓存';
          trace.cached = true;
          trace.cacheType = 'semantic';
          trace.similarity = +sres.similarity.toFixed(4);
          trace.latency = 0;
          this.tracer.write(trace);
          return {
            success: true,
            data: sres.response,
            meta: {
              model,
              provider: '语义缓存',
              providerId: 'semantic-cache',
              latency: 0,
              switched: false,
              cached: true,
              cacheType: 'semantic',
              similarity: +sres.similarity.toFixed(4)
            }
          };
        }
        semanticPending = { emb, text };
        this.track('semantic_cache_miss');
      }
    }

    // ---- Tokens 压缩：长对话在不影响语义的前提下压缩后发上游（缓存命中不触发） ----
    let compressedInfo = null;
    {
      const c = await this.compressMessages(messages);
      if (c.compressed) {
        messages = c.messages;
        compressedInfo = c;
        trace.compressed = true;
        trace.savedTokens = c.savedTokens;
        trace.compressionMode = c.smart ? 'smart' : 'heuristic';
        this.track('compression', { detail: c.smart ? 'smart' : 'heuristic' });
        this.compressionStats.compressedRequests++;
        this.compressionStats.savedTokens += c.savedTokens;
        if (c.smart) this.compressionStats.smart++; else this.compressionStats.heuristic++;

        // 关键修复（INTERACTION-AUDIT C1）：压缩后，cacheKey 必须基于"压缩后文本"，
        // 否则精确缓存写入的是「A 原始请求的压缩回复」，会被 B 的相同原始请求命中，
        // 造成跨用户/跨会话回复错乱。直接用压缩后 messages 重新计算 cacheKey。
        if (cacheKey && cacheEnabled) {
          cacheKey = this.getCacheKey(finalModel, messages, forwardRest);
        }
      }
    }

    // ---- 并发单飞去重：同键请求进行中时，复用第一个请求的结果（防缓存击穿） ----
    if (cacheKey && this._inflight.has(cacheKey)) {
      try {
        const first = await this._inflight.get(cacheKey);
        if (first && first.success) {
          this.stats.successCount++;
          this.stats.recentRequests.unshift({
            time: new Date().toISOString(), model, provider: '缓存', status: 'success', latency: 0, switched: false, cached: true
          });
          if (this.stats.recentRequests.length > 50) this.stats.recentRequests.pop();
          this.notifyStatsUpdate();
          trace.status = 'success';
          trace.provider = '缓存';
          trace.cached = true;
          trace.cacheType = 'inflight';
          trace.latency = 0;
          this.tracer.write(trace);
          return { success: true, data: first.data, meta: { model, provider: '缓存', providerId: 'inflight', latency: 0, switched: false, cached: true, cacheType: 'inflight' } };
        }
      } catch (e) { /* 首个请求失败，继续自己路由 */ }
    }

    // 执行实际路由（AB 分流 / 故障切换 / 跨模型回退），并注册为 in-flight 任务
    const task = this.routeUncached(finalModel, { messages, stream, forwardRest, cacheKey, cacheEnabled, semanticPending }, trace);
    if (cacheKey) {
      this._inflight.set(cacheKey, task);
      task.then(() => { if (this._inflight.get(cacheKey) === task) this._inflight.delete(cacheKey); },
        () => { if (this._inflight.get(cacheKey) === task) this._inflight.delete(cacheKey); });
    }
    return task;
  }

  /**
   * 实际路由执行体（AB 分流 + 目标模型 + 跨模型回退），供并发去重复用
   */
  async routeUncached(model, { messages, stream, forwardRest, cacheKey, cacheEnabled, semanticPending }, trace) {
    // ---- 提示自动修复：对话未以 user 结尾（工具调用循环等）时补一个空 user 消息 ----
    // 适配部分上游（如商汤 SenseNova）要求末尾必须有用户消息的校验；语义中性，仅影响发往上游的消息
    if ((this.config.get('routing.autoRepairPrompt') ?? true) && Array.isArray(messages) && messages.length > 0) {
      const last = messages[messages.length - 1];
      if (last?.role !== 'user') {
        messages = [...messages, { role: 'user', content: '' }];
        trace.promptRepaired = true;
        this.track('prompt_repair');
      }
    }

    // ---- A/B 测试分流：请求的模型属于 AB 分组时，按权重随机选一个分组模型优先路由 ----
    const ab = this.config.get('routing.abTest') || {};
    let abGroup = null;
    if (ab.enabled && Array.isArray(ab.groups) && ab.groups.length >= 2 && ab.groups.some(g => g.model === model)) {
      abGroup = this.weightedPick(ab.groups);
      if (abGroup.model !== model) {
        this.track('ab_test', { detail: abGroup.name });
        const res = await this.tryRouteModel(abGroup.model, { messages, stream, ...forwardRest }, {
          requestedModel: model,
          switched: true,
          abGroup: abGroup.name
        });
        if (res.success) {
          if (cacheEnabled && !stream && cacheKey) this.cachePut(cacheKey, res.data);
          if (semanticPending && !stream) this.semanticCache.put(semanticPending.emb, semanticPending.text, res.data, this.compressionVariant());
          res.meta.switched = true;
          res.meta.requestedModel = model;
          res.meta.abGroup = abGroup.name;
          await this.finishSuccessTrace(trace, model, res, { semanticPending, cacheKey, cacheEnabled, stream, messages, forwardRest });
          return res;
        }
      }
    }

    // 1. 尝试目标模型
    const attempt = await this.tryRouteModel(model, { messages, stream, ...forwardRest }, {
      requestedModel: model,
      switched: false,
      abGroup: abGroup?.name || null
    });
    if (attempt.success) {
      if (cacheEnabled && !stream && cacheKey) this.cachePut(cacheKey, attempt.data);
      if (semanticPending && !stream) this.semanticCache.put(semanticPending.emb, semanticPending.text, attempt.data, this.compressionVariant());
      await this.finishSuccessTrace(trace, model, attempt, { semanticPending, cacheKey, cacheEnabled, stream, messages, forwardRest });
      return attempt;
    }

    // 2. 目标模型全部失败 -> 跨模型回退
    const fallbackEnabled = this.config.get('routing.fallback') !== false;
    if (!fallbackEnabled) throw attempt.error;

    const candidates = this.buildFallbackCandidates(model);
    if (candidates.length === 0) throw attempt.error;
    this.track('fallback', { detail: `${candidates.length} 个候选` });

    // 回退候选按任务匹配重排（v2.10.0）：复杂/代码请求优先回退到强模型
    if ((this.config.get('routing.intentRouting') ?? true) && Array.isArray(messages)) {
      try {
        const { analyzeRequest, taskFitness } = require('./intent');
        const ov = this.config.get('routing.modelStrength') || {};
        const ai = analyzeRequest(messages, ov);
        candidates.sort((a, b) => taskFitness(b, ai.intent, ai.complexity, ov) - taskFitness(a, ai.intent, ai.complexity, ov));
      } catch (e) { /* 排序失败用原顺序 */ }
    }

    let lastError = attempt.error;
    for (const candidate of candidates) {
      // 回退候选快速遍历（v2.6.4）：单次尝试 20s 上限，快速切到可用渠道，避免微信等严格超时通道等满 60s
      const res = await this.tryRouteModel(candidate, { messages, stream, ...forwardRest }, {
        requestedModel: model,
        switched: true,
        abGroup: abGroup?.name || null
      }, { fast: true });
      if (res.success) {
        if (cacheEnabled && !stream && cacheKey) this.cachePut(cacheKey, res.data);
        if (semanticPending && !stream) this.semanticCache.put(semanticPending.emb, semanticPending.text, res.data, this.compressionVariant());
        res.meta.switched = true;
        res.meta.requestedModel = model;
        res.meta.abGroup = abGroup?.name || null;
        await this.finishSuccessTrace(trace, model, res, { semanticPending, cacheKey, cacheEnabled, stream, messages });
        return res;
      }
      lastError = res.error;
    }

    trace.status = 'failed';
    trace.error = (lastError || attempt.error)?.message;
    this.tracer.write(trace);
    throw lastError || attempt.error;
  }

  /**
   * 按权重随机选择一个 AB 分组（权重 0 有效，null/undefined 按 100）
   */
  weightedPick(groups) {
    const total = groups.reduce((s, g) => s + (g.weight ?? 100), 0);
    if (total <= 0) return groups[0];
    let r = Math.random() * total;
    for (const g of groups) {
      r -= (g.weight ?? 100);
      if (r <= 0) return g;
    }
    return groups[groups.length - 1];
  }

  /**
   * 成功路径的 Trace 收尾：质量评分 + 反馈学习 + 影子决策 + 写日志
   */
  async finishSuccessTrace(trace, requestedModel, result, opts = {}) {
    const meta = result.meta || {};
    trace.status = 'success';
    trace.provider = meta.provider;
    trace.providerId = meta.providerId;
    trace.model = meta.model || requestedModel;
    trace.requestedModel = requestedModel;
    trace.switched = !!meta.switched;
    trace.abGroup = meta.abGroup || null;
    trace.cached = !!meta.cached;
    trace.cacheType = meta.cacheType || null;
    trace.latency = meta.latency;
    // 单次请求成本与 tokens（按响应 usage 精确计算，非累计值）
    const provider = this.config.getProviders().find(p => p.id === meta.providerId);
    const usage = result.data?.usage;
    trace.cost = provider && usage ? this.estimateCost(provider, meta.model || requestedModel, usage) : 0;
    trace.usageTokens = usage?.total_tokens || 0;
    trace.strategy = this.config.get('routing.strategy');

    // 意图维度成本归因（v2.11.0）：按请求意图累计成本（体检第 5 项补全）
    try {
      if (trace.intent && trace.cost > 0) {
        this.stats.intentCostStats = this.stats.intentCostStats || {};
        this.stats.intentCostStats[trace.intent] = +((this.stats.intentCostStats[trace.intent] || 0) + trace.cost).toFixed(6);
      }
    } catch (e) {}

    // 影子真实双跑（v2.11.0，借鉴 OmniRoute shadowRouting 真实模式）：
    // 非流式非缓存请求按采样率额外发给"影子目标"（加权策略第一名），对比质量/延迟，零返回影响
    // M2 修复：max_tokens 改用主请求真实值（fallback 128 防止 OpenAI 旧版本拒绝）
    if ((this.config.get('shadow') || {}).realDualRun === true && !trace.cached && !opts.stream && meta.providerId) {
      try {
        const sr = this.config.get('shadow') || {};
        if (Math.random() < (sr.sampleRate ?? 0.1)) {
          const candidates = this.selectProviders(meta.model || requestedModel);
          const weighted = this.weightedOrder([...candidates]);
          const shadowTarget = weighted[0];
          if (shadowTarget && shadowTarget.id !== meta.providerId) {
            const key = this.getActiveKey(shadowTarget);
            if (key) {
              // 用主请求真实 max_tokens（避免影子用 128 把长回复截短，影响一致性指标）
              const shadowMaxTokens = opts.forwardRest?.max_tokens ?? 128;
              const sres = await this.callProvider(shadowTarget, key, meta.model || requestedModel, {
                messages: opts.messages || [],
                stream: false,
                max_tokens: shadowMaxTokens,
                temperature: opts.forwardRest?.temperature,
                top_p: opts.forwardRest?.top_p
              }, 20000).catch(() => null);
              this.stats.shadowDualRun = this.stats.shadowDualRun || { runs: 0, agree: 0, latencySum: 0, costSum: 0 };
              if (sres) {
                const sd = this.stats.shadowDualRun;
                sd.runs++;
                sd.latencySum += sres.latency || 0;
                const scost = this.estimateCost(shadowTarget, meta.model || requestedModel, sres.usage || null);
                sd.costSum = +(sd.costSum + scost).toFixed(6);
                // 简单一致性：长度相近视为一致（完整语义对比成本高，这里用启发式）
                const realText = String(result.data?.choices?.[0]?.message?.content || '');
                const shadowText = String(sres.data?.choices?.[0]?.message?.content || '');
                if (realText && shadowText && Math.abs(realText.length - shadowText.length) / Math.max(realText.length, 1) < 0.3) sd.agree++;
                trace.shadowDualRun = { target: shadowTarget.name, latency: sres.latency, cost: scost, maxTokens: shadowMaxTokens };
              }
            }
          }
        }
      } catch (e) { /* 影子双跑失败不影响主流程 */ }
    }

    // 影子决策：记录"若用加权策略会选谁"（不额外调用，仅决策对比）
    if ((this.config.get('shadow') || {}).enabled !== false) {
      try {
        const candidates = this.selectProviders(meta.model || requestedModel);
        const weighted = this.weightedOrder([...candidates]);
        this.track('shadow_decision');
        trace.shadow = {
          actual: candidates[0]?.name || null,
          weightedFirst: weighted[0]?.name || null,
          same: candidates[0]?.id === weighted[0]?.id
        };
      } catch (e) { trace.shadow = null; }
    }

    // 质量评分（judge 或启发式）+ 反馈学习（写入 provider 权重）
    const content = result.data?.choices?.[0]?.message?.content
      || result.data?.choices?.[0]?.text
      || '';
    if (!opts.stream && content && !meta.cached) {
      const provider = this.config.getProviders().find(p => p.id === meta.providerId);
      if (provider) {
        const score = await this.scoreQuality(provider, meta.model || requestedModel, content);
        trace.qualityScore = score;
        this.applyQualityFeedback(provider, score);
      }
    }

    // 写入日志
    this.tracer.write(trace);
  }

  /**
   * 质量评分：judge 模型（采样）+ 内置启发式评分函数
   * @returns {number} 0-100
   */
  async scoreQuality(provider, model, content) {
    const q = this.config.get('quality') || {};
    const heuristic = this.heuristicScore(content);
    const backend = this.backendFor('quality.judgeBackend');
    if (!q.enabled) return heuristic;
    if (backend !== 'local' && (!q.judgeProviderId || !q.judgeModel)) return heuristic;
    if (Math.random() >= (q.sampleRate || 0.1)) return heuristic;
    const sysMsg = '你是 AI 回复质量评审员。请按 相关性、准确性、完整性、安全性 四个维度评估下面的 AI 回复，只输出一个 0-100 的整数分数，不要输出其他内容。';
    const usrMsg = 'AI 回复内容：\n' + String(content).slice(0, 2000);
    try {
      let text = '';
      if (backend === 'local') {
        // 本地模型做 judge（省云端 token，数据不出本机）
        if (!this.localEngine?.running) return heuristic;
        this.track('quality_judge', { detail: '本地模型' });
        const res = await this.localEngine.chat({ messages: [{ role: 'system', content: sysMsg }, { role: 'user', content: usrMsg }], max_tokens: 16, timeout: 60000 });
        text = res?.data?.choices?.[0]?.message?.content || '';
      } else {
        const judgeProvider = this.config.getProviders().find(p => p.id === q.judgeProviderId) || provider;
        const key = this.getActiveKey(judgeProvider);
        if (!key) return heuristic;
        this.track('quality_judge', { detail: q.judgeModel });
        const res = await this.callProvider(judgeProvider, key, q.judgeModel, {
          messages: [{ role: 'system', content: sysMsg }, { role: 'user', content: usrMsg }]
        }, 15000);
        text = res?.data?.choices?.[0]?.message?.content || '';
      }
      const m = String(text).match(/\b(\d{1,3})\b/);
      if (m) {
        const v = parseInt(m[1], 10);
        if (v >= 0 && v <= 100) return Math.round((heuristic + v) / 2);
      }
    } catch (e) { /* judge 失败不影响主流程 */ }
    return heuristic;
  }

  /**
   * 内置启发式评分函数（无需额外 API）
   */
  heuristicScore(content) {
    if (!content) return 0;
    const s = String(content);
    let score = 80;
    if (s.trim().length < 2) score -= 60;
    if (/^(抱歉|对不起|无法|不能|拒绝|我不|sorry|error|error\s*[:：])/i.test(s.trim()) && s.length < 100) score -= 30;
    if (/(.)\1{20,}/.test(s)) score -= 20;      // 重复字符
    if (s.length > 8000) score -= 10;
    if (/\b(undefined|null|NaN)\b/.test(s)) score -= 15;
    return Math.max(0, Math.min(100, score));
  }

  /**
   * 质量反馈学习：把质量分写入服务商权重（EMA），加权路由自动纳入
   */
  applyQualityFeedback(provider, score) {
    const w = provider.weights || {};
    const prev = w.qualityScore ?? 70;
    w.qualityScore = Math.round(prev * 0.7 + score * 0.3);
    provider.weights = w;
    // 质量历史（漂移检测用）
    const ps = this.stats.providerStats[provider.id] || {};
    if (!ps.qualityHistory) ps.qualityHistory = [];
    ps.qualityHistory.push(score);
    if (ps.qualityHistory.length > 100) ps.qualityHistory.shift();
    this.config.updateProvider(provider.id, { weights: provider.weights });
  }

  /**
   * 文本嵌入（供语义缓存使用）：自动选择可用的 embeddings 服务商
   */
  async embedText(text) {
    try {
      // 本地嵌入（v2.5.1）：引擎在跑且后端模式允许时优先本地（数据不出本机）
      if (this.backendFor('semanticCache.embedBackend') === 'local' && this.localEngine?.running) {
        const emb = await this.localEngine.embeddings(text);
        if (Array.isArray(emb) && emb.length > 0) return emb;
      }
      const sc = this.config.get('semanticCache') || {};
      let provider = null, model = null;
      if (sc.embeddingProviderId) {
        provider = this.config.getProviders().find(p => p.id === sc.embeddingProviderId);
        model = sc.embeddingModel;
      }
      if (!provider) {
        provider = this.config.getEnabledProviders().find(p => (p.models || []).length > 0);
      }
      if (!provider) return null;
      if (!model) {
        model = (provider.models || []).find(m => /embed|text-embed|bge|m3|mxbai|e5/i.test(m)) || (provider.models || [])[0];
      }
      if (!model) return null;
      const key = this.getActiveKey(provider);
      if (!key) return null;
      const url = `${this.apiBase(provider)}/embeddings`;
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${key}` },
        body: JSON.stringify({ model, input: String(text).slice(0, 2000) }),
        signal: AbortSignal.timeout(10000)
      });
      if (!response.ok) {
        this.semanticCache.embedErrors++;
        return null;
      }
      const data = await response.json();
      const emb = data?.data?.[0]?.embedding;
      if (!Array.isArray(emb)) this.semanticCache.embedErrors++;
      return Array.isArray(emb) ? emb : null;
    } catch (e) {
      this.semanticCache.embedErrors++;
      return null;
    }
  }

  /**
   * 尝试在某模型的所有服务商上路由
   * @param routeInfo { requestedModel, switched, abGroup } 路由元信息（用于统计与切换标记）
   * @param opts { fast: true=回退/快速场景，缩短单次超时快速遍历 }（v2.6.4 微信等严格超时通道优化）
   */
  async tryRouteModel(model, { messages, stream, ...forwardRest }, routeInfo = {}, opts = {}) {
    const affinityKey = this.computeAffinityKey(messages);
    const providers = this.selectProviders(model, { affinityKey });
    if (providers.length === 0) {
      // H3 修复：区分"零匹配"和"全过滤"，错误信息带上具体原因
      const reason = this.lastFilterReason;
      const errMsg = reason
        ? `${reason.reason}${reason.details ? '：' + reason.details.map(d => `[${d.provider}] ${d.reason}`).slice(0, 3).join('；') : ''}`
        : `没有可用的服务商提供模型: ${model}`;
      this.stats.failCount++;
      this.stats.recentRequests.unshift({
        time: new Date().toISOString(),
        model,
        status: 'failed',
        error: errMsg,
        filterType: reason?.type || 'zero_match'
      });
      if (this.stats.recentRequests.length > 50) this.stats.recentRequests.pop();
      this.notifyStatsUpdate();
      const err = new Error(errMsg);
      err.filterType = reason?.type || 'zero_match';
      err.filterDetails = reason?.details || null;
      return {
        success: false,
        error: err
      };
    }

    const maxRetries = Math.min(
      this.config.get('routing.maxRetries') || 3,
      providers.length
    );
    // 新增：单渠道 Key 重试上限（默认 null=用完该渠道全部 Key；设 N 则最多试 N 个 Key 后切下一渠道）
    // 场景：3 个 Key，maxKeyRetries=2 → 该渠道最多试 Key#1、Key#2，仍失败才切渠道
    const maxKeyRetries = this.config.get('routing.maxKeyRetries') ?? null;
    const timeout = this.config.get('routing.timeout') || 30000;
    let lastError;

    // 外层：渠道循环（保留原 maxRetries 行为）；内层：同渠道多 Key 循环
    let providerIdx = 0;
    let keysTried = 0;        // 本渠道内已试 Key 数
    let allKeysExhausted = false; // 本渠道全部 Key 已耗尽

    while (providerIdx < maxRetries) {
      const provider = providers[providerIdx];
      if (!provider) break;

      // 本渠道 Key 预算耗尽：跳过该渠道
      if (allKeysExhausted) {
        providerIdx++;
        keysTried = 0;
        allKeysExhausted = false;
        continue;
      }

      // 本渠道内最多试 maxKeyRetries 个 Key（null=全部）
      if (maxKeyRetries != null && keysTried >= maxKeyRetries) {
        providerIdx++;
        keysTried = 0;
        allKeysExhausted = false;
        continue;
      }

      // 本地模型 CPU 推理慢：放宽超时（7B Q4 生成长回复可达数分钟）
      // 快速场景（回退链/微信等严格超时通道）：单次尝试缩短，快速遍历可用渠道（v2.6.4）
      let effTimeout;
      if (provider.kind === 'local') effTimeout = Math.max(timeout, 600000);
      else if (opts.fast) effTimeout = Math.min(timeout, this.config.get('routing.fallbackTimeoutMs') || 20000);
      else effTimeout = timeout;

      // 熔断检查
      if (this.isCircuitOpen(provider)) {
        // 熔断的渠道不可能是 lkgp，清除
        if (this.lkgp.get(model) === provider.id) this.lkgp.delete(model);
        lastError = new Error(`服务商 ${provider.name} 已熔断（冷却中）`);
        providerIdx++;
        keysTried = 0;
        allKeysExhausted = false;
        continue;
      }

      // 配额检查：硬超限跳过；软超限（soft）仍尝试但已排最后（v2.8.0 软降级）
      const quotaCheck = this.checkQuota(provider);
      if (!quotaCheck.ok) {
        lastError = new Error(`服务商 ${provider.name} 配额已用尽: ${quotaCheck.reason}`);
        providerIdx++;
        keysTried = 0;
        allKeysExhausted = false;
        continue;
      }

      const keyResult = this.selectKey(provider);
      if (!keyResult || keyResult.exhausted) {
        lastError = new Error(`服务商 ${provider.name} 没有可用的 Key（全部已禁用）`);
        allKeysExhausted = true;
        providerIdx++;
        keysTried = 0;
        continue;
      }

      const { key, keyIndex } = keyResult;
      keysTried++;

      try {
        const result = await this.callProvider(
          provider, key, model,
          { messages, stream, ...forwardRest },
          effTimeout
        );

        this.recordSuccess(provider, keyIndex, model, result, routeInfo);
        // 配额记账
        this.consumeQuota(provider, result.usage);
        // lkgp（v2.8.0）：记住该模型最后成功的渠道
        if (this.config.get('routing.lkgp') ?? true) this.lkgp.set(model, provider.id);
        // 提示缓存亲和（v2.8.1）：记录该 system 前缀成功渠道
        // M3 修复：加 LRU 上限（100），防止 Map 无限膨胀
        if ((this.config.get('routing.promptCacheAffinity') ?? true) && affinityKey) {
          this.promptCacheAffinity.set(affinityKey, provider.id);
          this._enforceAffinityLRU();
        }

        return {
          success: true,
          data: result.data,
          meta: {
            model,
            provider: provider.name,
            providerId: provider.id,
            keyIndex,
            latency: result.latency,
            switched: !!routeInfo.switched,
            requestedModel: routeInfo.requestedModel || model,
            abGroup: routeInfo.abGroup || null,
            // 记录本次成功所用的 Key 序号（同渠道多 Key 场景下用户能看出换了几次 Key）
            keyRetries: keysTried - 1
          }
        };
      } catch (error) {
        lastError = error;
        // lkgp 失效：该渠道失败，清除"最后成功"标记（下次重新探测）
        if (this.lkgp.get(model) === provider.id) this.lkgp.delete(model);
        // M3 修复：渠道失败时同步清除 promptCacheAffinity 指向它的记录
        // 避免"上轮失败但 affinity 还指向它"导致下一轮同前缀请求再次走它
        if (affinityKey && this.promptCacheAffinity.get(affinityKey) === provider.id) {
          this.promptCacheAffinity.delete(affinityKey);
          this.affinityStats.invalidations = (this.affinityStats.invalidations || 0) + 1;
        }
        this.recordFailure(provider, keyIndex, model, error);

        // 不可重试错误（v2.7.0）：账号封禁/Cloudflare 封锁/配额耗尽等——换 Key 也没用，
        // 立即禁用该 Key + 切下一渠道（不浪费同渠道其他 Key 的重试预算）
        if (this.isHopelessError(error)) {
          this.track('hopeless_error', { detail: `${provider.name} Key#${keyIndex + 1} ${String(error.message || '').slice(0, 60)}` });
          this.disableKey(provider, keyIndex);
          console.log(`[快速失败] ${provider.name} 不可重试错误，立即禁用 Key #${keyIndex + 1}，切下一渠道`);
          this.track('key_retry_skip', { detail: `${provider.name} hopeless → 切渠道` });
          providerIdx++;
          keysTried = 0;
          allKeysExhausted = false;
          continue;
        }

        // 429 限流：临时退避（不禁用 Key）；401/403 连续错满阈值才禁用 Key
        if (error.status === 429) {
          this.applyRateLimitBackoff(provider);
        } else {
          this.handleKeyError(provider, keyIndex, error.status);
        }

        // 上下文长度超限 / 参数错：换 Key 也无意义，直接切下一渠道
        // 4xx 业务错误（除 401/403/429）一般也不重试
        const isNonRetryable = error.status >= 400 && error.status < 500
          && error.status !== 401 && error.status !== 403 && error.status !== 429;
        const isContextError = /context.length|context_length|too long|max.*tokens.*exceed|prompt is too long/i
          .test(String(error.message || error.text || ''));

        if (isNonRetryable || isContextError) {
          this.track('key_retry_skip', { detail: `${provider.name} Key#${keyIndex + 1} ${error.status || 'ctx'} → 不重试` });
          console.log(`[不重试] ${provider.name} Key#${keyIndex + 1} 错误 ${error.status}（${isContextError ? '上下文超限' : '业务错'}），切下一渠道`);
          providerIdx++;
          keysTried = 0;
          allKeysExhausted = false;
          continue;
        }

        // 同渠道换 Key：检查本渠道是否还有可用 Key
        const totalKeys = (provider.keys || []).length;
        const triedDisabled = provider.keyStats?.[keyIndex]?.disabled === true; // 本 Key 刚被禁用
        const stillHasKeys = keysTried < totalKeys;
        // 关键判断：
        //   1) maxKeyRetries=null（默认）：用完该渠道所有 Key 后才切渠道——穷尽模式
        //   2) maxKeyRetries=N：已试 N 个 Key 后切渠道——预算模式
        //   3) 本渠道只有一个 Key：直接切渠道（避免无意义重试）
        //   4) 本 Key 已被禁用（401/403 连续错满）：一定切下一个 Key
        const exhaustedThisKey = triedDisabled; // 本 Key 已被禁用，下一轮 selectKey 必然换 Key
        const canRetrySameProvider = (maxKeyRetries == null ? keysTried < totalKeys : keysTried < maxKeyRetries)
          && totalKeys > 1
          && !allKeysExhausted;

        if (canRetrySameProvider) {
          // 同渠道换 Key 重试（不消耗外层 providerIdx 配额）
          this.track('key_retry', { detail: `${provider.name} Key#${keyIndex + 1} → 下一 Key（已试 ${keysTried}/${totalKeys}）` });
          console.log(`[同渠道换 Key] ${provider.name} Key#${keyIndex + 1} 失败，尝试该渠道其他 Key（已用 ${keysTried}/${totalKeys}）`);
          if (exhaustedThisKey || keysTried >= totalKeys) {
            // 所有 Key 都已试过或本 Key 已禁用
            allKeysExhausted = true;
          }
          continue; // providerIdx 不变，下一轮 selectKey 选下一 Key
        }

        // 故障切换：尝试下一个服务商
        if (this.config.get('routing.failover') !== false) {
          this.track('provider_failover', { detail: `${provider.name} Key#${keyIndex + 1} → 下一渠道` });
          console.log(`[切渠道] 服务商 ${provider.name} 失败，切换到下一个...`);
          providerIdx++;
          keysTried = 0;
          allKeysExhausted = false;
          continue;
        } else {
          break;
        }
      }
    }

    this.stats.failCount++;
    this.stats.recentRequests.unshift({
      time: new Date().toISOString(),
      model,
      status: 'failed',
      error: lastError?.message
    });
    if (this.stats.recentRequests.length > 50) this.stats.recentRequests.pop();
    this.notifyStatsUpdate();

    return { success: false, error: lastError || new Error('所有服务商均请求失败') };
  }

  /**
   * 构建跨模型回退候选列表（按能力过滤：聊天请求只回退到聊天模型，绝不用图片/视频/嵌入模型）
   */
  buildFallbackCandidates(targetModel, capability = 'chat') {
    const costOpt = this.config.get('routing.costOptimization') || {};
    const allModels = this.getAllModels();
    // 能力过滤：候选必须与请求同能力（默认 chat），避免把图片/视频/嵌入模型当聊天模型用
    // 本地模型（路由大脑）不参与对话回答，回退候选同样排除 kind='local' 渠道提供的模型
    const localProviderIds = new Set(this.config.getProviders().filter(p => p.kind === 'local').map(p => p.id));
    const candidates = allModels.filter(m =>
      m.id !== targetModel && m.providers.length > 0 && m.capability === capability &&
      // 至少有一个非本地提供者才保留（纯本地模型=路由大脑，不参与回答回退）
      m.providers.some(p => !localProviderIds.has(p.id))
    );

    if (costOpt.enabled && costOpt.preferCheapest !== false) {
      // 成本优先：按"单次调用预估成本"升序（兼容 tokens / 次数两种计费）
      candidates.sort((a, b) => {
        const pa = this.estimatePerRequestCost(a);
        const pb = this.estimatePerRequestCost(b);
        return (pa - pb) || (b.providers.length - a.providers.length);
      });
    } else {
      // 稳定性优先：被更多服务商支持 > 服务商优先级
      candidates.sort((a, b) => {
        const diff = b.providers.length - a.providers.length;
        if (diff !== 0) return diff;
        const pa = Math.min(...a.providers.map(p => p.priority || 99));
        const pb = Math.min(...b.providers.map(p => p.priority || 99));
        return pa - pb;
      });
    }

    return candidates.slice(0, 5).map(m => m.id);
  }

  /**
   * 估算某模型"单次调用"的成本（取支持它的服务商中的最低值）
   * - 次数计费服务商：直接用固定单价
   * - tokens 计费服务商：按 1000 输入 + 500 输出 tokens 估算
   */
  estimatePerRequestCost(modelEntry) {
    const providers = (modelEntry.providers || []).map(p =>
      this.config.getProviders().find(x => x.id === p.id)
    ).filter(Boolean);
    const price = this.getPrice(modelEntry.id);
    const tokenEstimate = price ? (price.input || 0) * 0.001 + (price.output || 0) * 0.0005 : Infinity;

    let minCost = tokenEstimate;
    for (const p of providers) {
      const billing = p.billing || {};
      if (billing.mode === 'count' && (billing.pricePerCall || 0) > 0) {
        minCost = Math.min(minCost, billing.pricePerCall);
      }
    }
    return minCost;
  }

  /**
   * 按策略选择服务商（含熔断/数据驻留/SLO降级过滤）
   * @param ctx { affinityKey } 提示缓存亲和键（v2.8.1）：命中时对应渠道排第一
   * @returns {Array} 可用渠道列表；为空时通过 selectProviders.lastFilterReason 读取原因
   */
  selectProviders(modelName, ctx = {}) {
    const enabled = this.config.getEnabledProviders()
      .filter(p => p.models.includes(modelName) && p.kind !== 'local')   // 本地模型=路由大脑，不参与对话路由
      .sort((a, b) => (a.priority || 99) - (b.priority || 99));

    // H3 修复：保留"零匹配"和"全过滤"两种空集的区分
    // - lastFilterReason=null：模型在已启用渠道里一个都没找到（零匹配 / 拼写错误 / 模型名不一致）
    // - lastFilterReason='all_filtered' 或具体原因：模型有匹配渠道，但全部被 SLO/驻留/熔断/限流 剔除
    this.lastFilterReason = null;

    const strategy = this.config.get('routing.strategy') || 'priority';
    const circuitCfg = this.config.get('routing.circuitBreaker') || {};

    if (enabled.length === 0) {
      this.lastFilterReason = {
        type: 'zero_match',
        reason: `没有已启用渠道提供模型 ${modelName}（检查服务商「模型列表」是否包含该模型）`
      };
      return [];
    }

    // H3 修复：逐渠道收集过滤原因，区分三类
    // 1) 限流退避  2) 数据驻留/SLO  3) 熔断
    const blockedReasons = [];
    const filtered = enabled.filter(p => {
      if (this.isRateLimited(p)) {
        blockedReasons.push({ provider: p.name, reason: '429 限流退避中' });
        return false;
      }
      const pa = this.providerAllowed(p);
      if (!pa.allowed) {
        blockedReasons.push({ provider: p.name, reason: pa.reason });
        return false;
      }
      return true;
    });

    // 熔断过滤（冷却结束后允许探测请求）
    const available = filtered.filter(p => {
      if (!circuitCfg.enabled) return true;
      if (!p.circuit?.open) return true;
      const cooldownMs = circuitCfg.cooldownMs || 60000;
      if (p.circuit.openedAt && (Date.now() - p.circuit.openedAt) >= cooldownMs) {
        // 冷却结束：半开探测，允许放行一个请求
        p.circuit.open = false;
        p.circuit.failures = 0;
        p.circuit.probing = true;
        return true;
      }
      blockedReasons.push({ provider: p.name, reason: `熔断冷却中（${Math.round((cooldownMs - (Date.now() - (p.circuit.openedAt || 0))) / 1000)}s 后恢复）` });
      return false;
    });

    if (available.length === 0) {
      this.lastFilterReason = {
        type: 'all_filtered',
        reason: `模型 ${modelName} 有 ${enabled.length} 个匹配渠道，但全部被过滤`,
        details: blockedReasons
      };
      return available;
    }

    // ===== v2.9.0 策略扩充（借鉴 OmniRoute 19 策略） =====
    // strict-random：完全随机（不应用亲和/lkgp 软偏好）；random 保留纯随机（同）
    if (strategy === 'strict-random') {
      return this.shuffle([...available]);
    }
    if (strategy === 'random') {
      return this.shuffle([...available]);
    }

    // least-used（最少使用优先）：按历史请求量升序，平衡负载
    if (strategy === 'least-used') {
      return [...available].sort((a, b) =>
        (this.stats.providerStats[a.id]?.requests || 0) - (this.stats.providerStats[b.id]?.requests || 0));
    }

    // p2c（Power of Two Choices，二选一）：随机取 2 个候选，选优先级/权重更优者，
    // 兼顾随机性与质量（负载均衡经典算法）
    if (strategy === 'p2c') {
      const shuffled = this.shuffle([...available]);
      const a = shuffled[0];
      const b = shuffled.length > 1 ? shuffled[1] : shuffled[0];
      const score = (p) => 1 / (p.priority || 99) * Math.max(0.05, p.weights?.successRate || 1);
      const first = score(a) >= score(b) ? a : b;
      const rest = shuffled.filter(p => p !== first);
      return [first, ...rest];
    }

    // cost-optimized（成本优先）：按该模型的单次估算成本升序（渠道级）
    if (strategy === 'cost-optimized') {
      return [...available].sort((a, b) => {
        const pa = this.estimateCost(a, modelName, { prompt_tokens: 1000, completion_tokens: 500 });
        const pb = this.estimateCost(b, modelName, { prompt_tokens: 1000, completion_tokens: 500 });
        return pa - pb;
      });
    }

    // reset-aware（配额重置窗口感知，合并 headroom）：按配额剩余余量降序（余量多的优先），
    // 配额未启用时回退 weighted
    if (strategy === 'reset-aware' || strategy === 'headroom') {
      const quotaCfg = this.config.get('routing.quota') || {};
      if (quotaCfg.enabled) {
        const periodKey = this.quotaPeriodKey(quotaCfg.period || 'day');
        return [...available].sort((a, b) => {
          const limitA = quotaCfg.limits?.[a.id];
          const limitB = quotaCfg.limits?.[b.id];
          const headA = limitA?.requests ? Math.max(0, limitA.requests - (a.quotaUsed?.requests || 0)) : Infinity;
          const headB = limitB?.requests ? Math.max(0, limitB.requests - (b.quotaUsed?.requests || 0)) : Infinity;
          return headB - headA;
        });
      }
      return this.weightedOrder(available);
    }

    // auto（智能自动）：亲和/lkgp 优先（在下方通用段应用），最终按加权排序——零配置模式
    if (strategy === 'auto') {
      // 继续走通用段（亲和/lkgp），最终在 weighted 分支返回
    }

    // 提示缓存亲和（v2.8.1，借鉴 OmniRoute promptCacheAffinity）：
    // 相同 system 前缀上次成功走哪个渠道，本次优先走它（上游缓存按前缀命中省钱）
    if ((this.config.get('routing.promptCacheAffinity') ?? true) && ctx.affinityKey && available.length > 1) {
      const affId = this.promptCacheAffinity.get(ctx.affinityKey);
      if (affId) {
        this.affinityStats.total++;
        const idx = available.findIndex(p => p.id === affId);
        if (idx > 0) {
          const [p] = available.splice(idx, 1);
          available.unshift(p);
          this.affinityStats.hits++;
        }
      }
    }

    // lkgp（v2.8.0，借鉴 OmniRoute）：记住每个模型最后成功的渠道，优先排第一（失败时清除）
    if ((this.config.get('routing.lkgp') ?? true) && this.lkgp.has(modelName) && available.length > 1) {
      const lkgpId = this.lkgp.get(modelName);
      const idx = available.findIndex(p => p.id === lkgpId);
      if (idx > 0) {
        const [p] = available.splice(idx, 1);
        available.unshift(p);
      }
    }

    if (strategy === 'round-robin') {
      // 服务商间轮询
      const idx = (this._providerRR || 0) % available.length;
      this._providerRR = idx + 1;
      return [...available.slice(idx), ...available.slice(0, idx)];
    }

    if (strategy === 'weighted' || strategy === 'auto') {
      return this.weightedOrder(available);
    }

    // priority（默认）
    const ordered = [...available];
    // 配额软降级（v2.8.0，借鉴 OmniRoute quota-soft）：软超限渠道排最后（仍可用，不硬拦截）
    if ((this.config.get('routing.quota') || {}).enabled && ordered.length > 1) {
      const soft = ordered.filter(p => {
        const q = this.checkQuota(p);
        return q.ok && q.soft;
      });
      if (soft.length > 0 && soft.length < ordered.length) {
        const normal = ordered.filter(p => !soft.includes(p));
        return [...normal, ...soft];
      }
    }
    return ordered;
  }

  /**
   * 加权路由：按 优先级 + 延迟 + 成功率 + 质量分 计算权重并排序
   */
  weightedOrder(providers) {
    const scored = providers.map(p => {
      const w = p.weights || { latencyMs: null, successRate: 1, requests: 0, qualityScore: 70 };

      // 优先级权重：priority 越小权重越大
      const priorityScore = 1 / (p.priority || 99);

      // 延迟权重：与全服务商平均延迟比较，越快权重越大
      const latencies = providers
        .map(x => x.weights?.latencyMs)
        .filter(x => x && x > 0);
      const avgLatency = latencies.length
        ? latencies.reduce((a, b) => a + b, 0) / latencies.length
        : 1000;
      const latencyScore = avgLatency / (w.latencyMs || avgLatency);

      // 成功率权重
      const successScore = Math.max(0.05, w.successRate || 1);

      // 质量分权重（反馈学习：评分高者权重更高，70 分为基准 1.0）
      const qualityFactor = Math.max(0.5, (w.qualityScore ?? 70) / 70);

      // 配额软降级（v2.8.0）：软超限渠道权重 ×0.5（仍可被选中但不占优势）
      let quotaFactor = 1;
      if ((this.config.get('routing.quota') || {}).enabled) {
        const q = this.checkQuota(p);
        if (q.ok && q.soft) quotaFactor = 0.5;
      }

      const weight = priorityScore * latencyScore * successScore * qualityFactor * quotaFactor;
      return { provider: p, weight };
    });

    // 按权重降序（加权随机可用 weight 作为随机概率）
    return scored
      .sort((a, b) => b.weight - a.weight)
      .map(s => s.provider);
  }

  weightedRandom(providers) {
    const scored = providers.map(p => {
      const w = p.weights || { latencyMs: null, successRate: 1, requests: 0, qualityScore: 70 };
      const priorityScore = 1 / (p.priority || 99);
      const latencies = providers.map(x => x.weights?.latencyMs).filter(x => x && x > 0);
      const avgLatency = latencies.length ? latencies.reduce((a, b) => a + b, 0) / latencies.length : 1000;
      const latencyScore = avgLatency / (w.latencyMs || avgLatency);
      const successScore = Math.max(0.05, w.successRate || 1);
      const qualityFactor = Math.max(0.5, (w.qualityScore ?? 70) / 70);
      return { provider: p, weight: priorityScore * latencyScore * successScore * qualityFactor };
    });

    const total = scored.reduce((s, x) => s + x.weight, 0);
    let r = Math.random() * total;
    for (const s of scored) {
      r -= s.weight;
      if (r <= 0) return s.provider;
    }
    return scored[scored.length - 1].provider;
  }

  /**
   * 熔断状态检查（单服务商）
   */
  isCircuitOpen(provider) {
    const circuitCfg = this.config.get('routing.circuitBreaker') || {};
    if (!circuitCfg.enabled) return false;
    if (!provider.circuit?.open) return false;
    const cooldownMs = circuitCfg.cooldownMs || 60000;
    // 冷却结束 -> 半开，允许探测
    if (provider.circuit.openedAt && (Date.now() - provider.circuit.openedAt) >= cooldownMs) {
      provider.circuit.open = false;
      provider.circuit.failures = 0;
      return false;
    }
    return true;
  }

  /**
   * 配额管理
   */
  quotaPeriodKey(period) {
    const now = new Date();
    const pad = n => String(n).padStart(2, '0');
    if (period === 'hour') return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())} ${pad(now.getHours())}:00`;
    if (period === 'week') {
      const day = (now.getDay() + 6) % 7; // 周一为一周开始
      const d = new Date(now);
      d.setDate(d.getDate() - day);
      return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
    }
    if (period === 'month') return `${now.getFullYear()}-${pad(now.getMonth() + 1)}`;
    return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`; // day
  }

  checkQuota(provider) {
    const quotaCfg = this.config.get('routing.quota') || {};
    if (!quotaCfg.enabled) return { ok: true };

    const limit = quotaCfg.limits?.[provider.id];
    if (!limit || (!limit.requests && !limit.tokens)) return { ok: true };

    const period = quotaCfg.period || 'day';
    const periodKey = this.quotaPeriodKey(period);
    const used = provider.quotaUsed || {};

    // 周期变化 -> 重置用量
    if (used.periodKey !== periodKey) {
      provider.quotaUsed = { periodKey, requests: 0, tokens: 0 };
    }

    // 配额软降级（v2.8.0，借鉴 OmniRoute quota-soft）：
    // 达到软阈值（90% 上限）标记 soft=true，渠道仍可用但排最后；
    // 超过硬上限（120% 上限）才真正拦截——避免"还有别的渠道却报配额不足"
    const softFactor = quotaCfg.softFactor ?? 0.9;
    const hardFactor = quotaCfg.hardFactor ?? 1.2;
    const reqs = provider.quotaUsed.requests || 0;
    const toks = provider.quotaUsed.tokens || 0;
    const reqSoft = limit.requests ? reqs >= limit.requests * softFactor : false;
    const tokSoft = limit.tokens ? toks >= limit.tokens * softFactor : false;
    const reqHard = limit.requests ? reqs >= limit.requests * hardFactor : false;
    const tokHard = limit.tokens ? toks >= limit.tokens * hardFactor : false;

    if (reqHard || tokHard) {
      return { ok: false, reason: `配额硬超限 请求${reqs}/${limit.requests} tokens${toks}/${limit.tokens}` };
    }
    if (reqSoft || tokSoft) {
      return { ok: true, soft: true, reason: `配额接近上限 请求${reqs}/${limit.requests} tokens${toks}/${limit.tokens}` };
    }
    return { ok: true };
  }

  consumeQuota(provider, usage) {
    const quotaCfg = this.config.get('routing.quota') || {};
    if (!quotaCfg.enabled) return;

    const period = quotaCfg.period || 'day';
    const periodKey = this.quotaPeriodKey(period);
    if (!provider.quotaUsed || provider.quotaUsed.periodKey !== periodKey) {
      provider.quotaUsed = { periodKey, requests: 0, tokens: 0 };
    }
    provider.quotaUsed.requests++;
    if (usage?.total_tokens) {
      provider.quotaUsed.tokens += usage.total_tokens;
    }
    // H5 修复：高频写场景用 debounce，30s 内合并写盘
    this.config.updateProvider(provider.id, { quotaUsed: provider.quotaUsed }, { debounce: true });
  }

  /**
   * 流式响应结束后回填 token 用量 / 成本 / 配额。
   * routeWithFallback 在发起流式请求时（callProvider 对流式返回 usage:null）已通过 recordSuccess
   * 记了 请求数 / 成功率 / 延迟，但 token 用量当时未知（流式 usage 位于 SSE 末帧）。
   * 此处依据代理层从 SSE 重建出的 usage 补足 tokens / cost / quota，
   * 避免流式对话不计入 token 配额与成本报表（原缺陷：流式配额/成本永久失真）。
   *
   * C3 修复：若无 SSE usage（常见情况），用本地估算填充，避免永远 0。
   *
   * @param {string} providerId 服务商 id（来自 meta）
   * @param {number} keyIndex 选中的 Key 序号
   * @param {string} model 实际路由模型
   * @param {Object} usage 上游 SSE 末帧携带的 usage（含 total_tokens）
   * @param {Array} messages 用于 token 估算的原始请求消息（无 usage 时使用）
   */
  applyStreamUsage(providerId, keyIndex, model, usage, messages) {
    const provider = this.config.getProviders().find(p => p.id === providerId);
    if (!provider) return;

    let usedTokens = 0;
    let tokensEstimated = false;

    if (usage?.total_tokens) {
      // 上游有真实 usage，优先用上游数据
      usedTokens = usage.total_tokens;
    } else {
      // C3 修复：SSE 无 usage 时用本地估算（cl100k_base 近似公式）
      tokensEstimated = true;
      const completionText = usage?.choices?.[0]?.message?.content || '';
      usedTokens = estimateMessagesTokens(messages) + estimateTokensFromText(completionText);
    }

    const pid = provider.id;

    if (!this.stats.providerStats[pid]) {
      this.stats.providerStats[pid] = { requests: 0, success: 0, fail: 0, errors: [], cost: 0, tokens: 0 };
    }
    if (!this.stats.modelStats[model]) {
      this.stats.modelStats[model] = { requests: 0, success: 0, fail: 0, cost: 0, tokens: 0 };
    }
    this.stats.providerStats[pid].tokens = (this.stats.providerStats[pid].tokens || 0) + usedTokens;
    this.stats.modelStats[model].tokens = (this.stats.modelStats[model].tokens || 0) + usedTokens;

    // 成本：若无真实 usage，estimateCost 也会走估算路径（tokens 已有值）
    const cost = this.estimateCost(provider, model, { total_tokens: usedTokens, ...usage });
    if (cost > 0) {
      this.stats.providerStats[pid].cost = +((this.stats.providerStats[pid].cost || 0) + cost).toFixed(6);
      this.stats.modelStats[model].cost = +((this.stats.modelStats[model].cost || 0) + cost).toFixed(6);
      this.stats.totalCost = +((this.stats.totalCost || 0) + cost).toFixed(6);
    }

    // 补记配额 token 用量（不重复记请求数——recordSuccess 已通过 consumeQuota 计过请求）
    const quotaCfg = this.config.get('routing.quota') || {};
    if (quotaCfg.enabled && provider.quotaUsed) {
      provider.quotaUsed.tokens = (provider.quotaUsed.tokens || 0) + usedTokens;
      // H5 修复：debounce 落盘
      this.config.updateProvider(provider.id, { quotaUsed: provider.quotaUsed }, { debounce: true });
    }

    // C3 修复：标记是否含估算 token，让 UI 可识别（真实 vs 估算）
    if (tokensEstimated && usedTokens > 0) {
      this.stats.tokensEstimated = (this.stats.tokensEstimated || 0) + usedTokens;
    }

    this.notifyStatsUpdate();
  }

  getQuotaStatus() {
    const quotaCfg = this.config.get('routing.quota') || {};
    if (!quotaCfg.enabled) return { enabled: false, providers: [] };
    const periodKey = this.quotaPeriodKey(quotaCfg.period || 'day');

    return {
      enabled: true,
      period: quotaCfg.period || 'day',
      periodKey,
      providers: this.config.getProviders().map(p => {
        const limit = quotaCfg.limits?.[p.id] || {};
        const used = p.quotaUsed || {};
        return {
          id: p.id,
          name: p.name,
          requests: used.periodKey === periodKey ? used.requests : 0,
          requestLimit: limit.requests || 0,
          tokens: used.periodKey === periodKey ? used.tokens : 0,
          tokenLimit: limit.tokens || 0
        };
      })
    };
  }

  /**
   * 获取可用的 Key（第一个未禁用）
   */
  getActiveKey(provider) {
    if (provider.kind === 'local') return 'local';   // 本地模型无需 Key
    const keys = provider.keys || [];
    for (let i = 0; i < keys.length; i++) {
      const stat = provider.keyStats?.[i];
      if (!stat?.disabled) return keys[i];
    }
    if (keys.length > 0) return keys[0];
    return null;
  }

  /**
   * 选择 Key（priority / round-robin / random）
   */
  selectKey(provider) {
    if (provider.kind === 'local') return { key: 'local', keyIndex: 0 };   // 本地模型无需 Key
    const keys = provider.keys || [];
    if (keys.length === 0) return null;

    // 找到可用的 Key 索引
    let availableIndices = [];
    let allDisabled = true;
    for (let i = 0; i < keys.length; i++) {
      const stat = provider.keyStats?.[i];
      if (!stat?.disabled) {
        availableIndices.push(i);
        allDisabled = false;
      }
    }

    if (availableIndices.length === 0) {
      // 所有 Key 都被禁用 -> 新增：返回 exhausted 标记，不再随意返回一个 disabled key
      // 调用方据此决定是否切到下一渠道，而不是浪费重试预算重复尝试同一个 disabled key
      // 健康检测恢复时会主动调用 resetKeys() 把所有 Key 重新启用，届时 selectKey 恢复正常
      return { exhausted: true };
    }

    const strategy = this.config.get('routing.strategy') || 'priority';
    let selectedIndex;

    if (strategy === 'round-robin' || strategy === 'weighted') {
      // 在「全部 Key」坐标上推进游标并跳过被禁用的 Key，
      // 使轮询在可用 Key 间保持均匀（修复：原 idx = keyIndex % availableIndices.length
      // 在 Key 被禁用/恢复导致 availableIndices 长度变化时产生分布漂移）。
      const total = keys.length;
      let pos = (provider.keyIndex || 0) % total;
      let guard = 0;
      while (provider.keyStats?.[pos]?.disabled && guard < total) {
        pos = (pos + 1) % total;
        guard++;
      }
      selectedIndex = pos;
      this.config.updateProvider(provider.id, { keyIndex: (pos + 1) % total });
    } else if (strategy === 'random') {
      selectedIndex = availableIndices[Math.floor(Math.random() * availableIndices.length)];
    } else {
      // priority - 选第一个可用的
      selectedIndex = availableIndices[0];
    }

    return { key: keys[selectedIndex], keyIndex: selectedIndex };
  }

  /**
   * 调用服务商 API
   */
  async callProvider(provider, key, model, body, timeout) {
    // 本地模型（v2.4.0）：走内置引擎；带 tools 时执行工具循环（本地模型自主调用工具管理路由）
    if (provider.kind === 'local' && this.localEngine) {
      const tools = body.tools && body.tools.length ? body.tools : null;
      if (tools && !body.stream) {
        // 本地工具循环（非流式）：模型可多次调用工具后给出最终答复
        const { result, toolRuns } = await this.localEngine.chatWithTools({
          model, messages: body.messages, tools,
          temperature: body.temperature, max_tokens: body.max_tokens, timeout: timeout || 300000
        });
        if (toolRuns.length) {
          this.track('local_tool_round', { detail: `${toolRuns.length} 次工具调用` });
          return { data: result.data, latency: result.latency, usage: result.usage, toolRuns };
        }
        return result;
      }
      const r = await this.localEngine.chat({
        model, messages: body.messages, stream: !!body.stream, tools,
        temperature: body.temperature, max_tokens: body.max_tokens, timeout: timeout || 300000
      });
      if (r.data?.choices?.[0]?.message?.tool_calls?.length) {
        this.track('local_tool_round', { detail: '工具调用透传' });
      }
      return r;
    }

    const url = `${this.apiBase(provider)}/chat/completions`;
    const startTime = Date.now();

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeout);

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${key}`
        },
        body: JSON.stringify({ model, ...body }),
        signal: controller.signal
      });

      const latency = Date.now() - startTime;

      if (!response.ok) {
        const text = await response.text();
        const error = new Error(`服务商 ${provider.name} 返回错误: ${response.status} ${text.slice(0, 500)}`);
        error.status = response.status;
        error.provider = provider.name;
        throw error;
      }

      if (body.stream) {
        // 流式响应 - 返回可读流
        return {
          data: { stream: response.body, headers: response.headers },
          latency,
          usage: null
        };
      } else {
        const data = await response.json();
        return {
          data,
          latency,
          usage: data.usage || null
        };
      }
    } finally {
      clearTimeout(timeoutId);
    }
  }

  /**
   * 嵌入向量路由（带故障切换 + 缓存）
   */
  async routeEmbedding({ model, input, ...rest }) {
    this.track('embedding_req');
    this.stats.totalRequests++;
    this.touchActivity();

    // 嵌入缓存
    const cacheCfg = this.config.get('cache') || {};
    if (cacheCfg.enabled && cacheCfg.embeddings !== false && model && input != null) {
      this.cache.maxBytes = cacheCfg.maxBytes || DEFAULT_MAX_BYTES;
      const key = MemoryCache.key(model, { input }, {});
      const hit = this.cache.get(key);
      if (hit) {
        this.stats.successCount++;
        this.notifyStatsUpdate();
        return { ...hit, _cached: true };
      }
      const data = await this._routeEmbeddingUncached({ model, input, ...rest });
      this.cachePut(key, data);
      return data;
    }

    return this._routeEmbeddingUncached({ model, input, ...rest });
  }

  async _routeEmbeddingUncached({ model, input, ...rest }) {
    this.stats.totalRequests++;
    const providers = this.selectProviders(model);
    if (providers.length === 0) {
      this.stats.failCount++;
      this.notifyStatsUpdate();
      throw new Error(`没有可用的服务商提供模型: ${model}`);
    }

    const timeout = this.config.get('routing.timeout') || 30000;
    let lastError;

    for (const provider of providers) {
      if (this.isCircuitOpen(provider)) continue;
      const quotaCheck = this.checkQuota(provider);
      if (!quotaCheck.ok) {
        lastError = new Error(`${provider.name} 配额已用尽`);
        continue;
      }

      const keyResult = this.selectKey(provider);
      if (!keyResult || keyResult.exhausted) {
        lastError = new Error(keyResult?.exhausted ? `${provider.name} 全部 Key 已禁用` : `${provider.name} 没有可用 Key`);
        continue;
      }

      try {
        const url = `${this.apiBase(provider)}/embeddings`;
        const startTime = Date.now();
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), timeout);

        const response = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${keyResult.key}`
          },
          body: JSON.stringify({ model, input, ...rest }),
          signal: controller.signal
        });
        clearTimeout(timeoutId);

        const latency = Date.now() - startTime;
        if (!response.ok) {
          const text = await response.text();
          const err = new Error(`${provider.name} 返回错误: ${response.status} ${text.slice(0, 300)}`);
          err.status = response.status;
          throw err;
        }

        const data = await response.json();
        this.recordSuccess(provider, keyResult.keyIndex, model, { latency, data, usage: data.usage || null });
        this.consumeQuota(provider, data.usage);
        return data;
      } catch (error) {
        lastError = error;
        // 所有错误都记账（含 4xx/5xx），便于统计与权重衰减
        this.recordFailure(provider, keyResult.keyIndex, model, error);
        this.handleKeyError(provider, keyResult.keyIndex, error.status);
        if (this.config.get('routing.failover') === false) break;
      }
    }

    this.stats.failCount++;
    this.notifyStatsUpdate();
    throw lastError || new Error('所有服务商均请求失败');
  }

  /**
   * 估算单次调用的成本（v2.0.4 双计费模式）
   * - 按 Tokens：prompt_tokens × 输入单价 + completion_tokens × 输出单价（每百万 tokens 价格表）
   * - 按次数：固定单价/次
   * @returns {number} 预估成本（USD）
   */
  estimateCost(provider, model, usage) {
    const billing = provider?.billing || {};
    if (billing.mode === 'count') {
      return +(billing.pricePerCall || 0);
    }
    const price = this.getPrice(model);
    if (!price || !usage) return 0;
    const inTok = usage.prompt_tokens || 0;
    const outTok = usage.completion_tokens || 0;
    return +((inTok / 1e6) * (price.input || 0) + (outTok / 1e6) * (price.output || 0)).toFixed(6);
  }

  /**
   * 记录成功（更新权重、统计、成本）
   * @param routeInfo { requestedModel, switched, abGroup }
   */
  recordSuccess(provider, keyIndex, model, result, routeInfo = {}) {
    const pid = provider.id;
    if (!this.stats.providerStats[pid]) {
      this.stats.providerStats[pid] = { requests: 0, success: 0, fail: 0, errors: [], cost: 0, tokens: 0 };
    }
    this.stats.providerStats[pid].requests++;
    this.stats.providerStats[pid].success++;
    // 退避等级重置（v2.8.0）：成功一次即解除指数退避
    if (provider.backoffLevel) {
      provider.backoffLevel = 0;
      provider.rateLimitedUntil = null;
    }

    // 模型统计（含成本与 token 用量）
    if (!this.stats.modelStats[model]) {
      this.stats.modelStats[model] = { requests: 0, success: 0, fail: 0, cost: 0, tokens: 0 };
    }
    this.stats.modelStats[model].requests++;
    this.stats.modelStats[model].success++;

    // 成本记账：按服务商计费方式（tokens / 次数）
    const usage = result?.usage;
    const cost = this.estimateCost(provider, model, usage);
    if (cost > 0) {
      this.stats.providerStats[pid].cost = +((this.stats.providerStats[pid].cost || 0) + cost).toFixed(6);
      this.stats.modelStats[model].cost = +((this.stats.modelStats[model].cost || 0) + cost).toFixed(6);
      this.stats.totalCost = +((this.stats.totalCost || 0) + cost).toFixed(6);
    }
    // 记忆系统：记录成功调用（学习习惯与渠道模型画像）
    try {
      this.modelMemory?.recordCall({
        providerId: provider.id, providerName: provider.name, model,
        key: provider.keys?.[keyIndex], ok: true, latency: result?.latency, cost
      });
    } catch (e) { /* 记忆失败不影响主流程 */ }
    const usedTokens = usage?.total_tokens || 0;
    if (usedTokens > 0) {
      this.stats.providerStats[pid].tokens = (this.stats.providerStats[pid].tokens || 0) + usedTokens;
      this.stats.modelStats[model].tokens = (this.stats.modelStats[model].tokens || 0) + usedTokens;
    }

    // Key 统计 + 连续错误清零
    const keyStat = provider.keyStats?.[keyIndex];
    if (keyStat) {
      keyStat.requests++;
      keyStat.lastUsed = new Date().toISOString();
      keyStat.errors = 0;
      keyStat.consecutiveErrors = 0;
    }

    // 熔断成功 -> 复位
    if (provider.circuit) {
      provider.circuit.failures = 0;
      provider.circuit.open = false;
      provider.circuit.openedAt = null;
      provider.circuit.probing = false;
    }
    // 限流退避解除（渠道恢复可用）
    if (provider.rateLimitedUntil) {
      provider.rateLimitedUntil = null;
      this.config.updateProvider(provider.id, { rateLimitedUntil: null });
    }

    // 加权路由权重更新（EMA）
    const latency = result?.latency;
    if (latency != null) {
      const w = provider.weights || {};
      const prev = w.latencyMs || latency;
      w.latencyMs = Math.round(prev * 0.7 + latency * 0.3);  // 指数移动平均
      provider.weights = w;
    }

    this.config.updateProvider(provider.id, {
      keyStats: provider.keyStats,
      circuit: provider.circuit,
      weights: provider.weights
    });

    this.stats.successCount++;
    this.stats.recentRequests.unshift({
      time: new Date().toISOString(),
      model,
      requestedModel: routeInfo.requestedModel || model,
      provider: provider.name,
      status: 'success',
      latency,
      switched: !!routeInfo.switched,
      abGroup: routeInfo.abGroup || null
    });
    if (this.stats.recentRequests.length > 50) this.stats.recentRequests.pop();

    // SLO 采样（延迟滚动窗口，用于 p95 降级判定）
    this.slo.sample(latency);

    this.notifyStatsUpdate();
  }

  /**
   * 记录失败（更新熔断、权重、模型统计）
   */
  recordFailure(provider, keyIndex, model, error) {
    const pid = provider.id;
    if (!this.stats.providerStats[pid]) {
      this.stats.providerStats[pid] = { requests: 0, success: 0, fail: 0, errors: [], cost: 0, tokens: 0 };
    }
    this.stats.providerStats[pid].requests++;
    this.stats.providerStats[pid].fail++;
    this.stats.providerStats[pid].errors.unshift({
      time: new Date().toISOString(),
      message: (error.message || '').slice(0, 200),
      status: error.status
    });
    if (this.stats.providerStats[pid].errors.length > 10) {
      this.stats.providerStats[pid].errors.pop();
    }

    // 模型统计
    if (model) {
      if (!this.stats.modelStats[model]) {
        this.stats.modelStats[model] = { requests: 0, success: 0, fail: 0, cost: 0, tokens: 0 };
      }
      this.stats.modelStats[model].requests++;
      this.stats.modelStats[model].fail++;
    }

    const keyStat = provider.keyStats?.[keyIndex];
    if (keyStat) {
      keyStat.requests++;
      keyStat.errors++;
      keyStat.consecutiveErrors = (keyStat.consecutiveErrors || 0) + 1;
      keyStat.lastUsed = new Date().toISOString();
    }

    // 记忆系统：记录失败调用（学习习惯）
    try {
      this.modelMemory?.recordCall({
        providerId: provider.id, providerName: provider.name, model,
        key: provider.keys?.[keyIndex], ok: false, latency: null, cost: 0
      });
    } catch (e) { /* 记忆失败不影响主流程 */ }

    // 熔断累计：网络错误 / 5xx 才计入熔断计数（4xx 认证类不计，避免误伤）
    const circuitFault = !error.status || error.status >= 500;
    if (circuitFault && provider.circuit) {
      const circuitCfg = this.config.get('routing.circuitBreaker') || {};
      if (provider.circuit.probing) {
        // 半开探测失败：立即重新熔断（标准 half-open 语义）
        provider.circuit.open = true;
        provider.circuit.openedAt = Date.now();
        provider.circuit.failures = 1;
        provider.circuit.probing = false;
        this.track('circuit_break', { ok: false, detail: `${provider.name} 半开探测失败` });
        console.log(`[熔断] 服务商 ${provider.name} 半开探测失败，重新熔断 ${(circuitCfg.cooldownMs || 60000) / 1000}s`);
      } else {
        provider.circuit.failures = (provider.circuit.failures || 0) + 1;
        if (circuitCfg.enabled && provider.circuit.failures >= (circuitCfg.threshold || 5)) {
          provider.circuit.open = true;
          provider.circuit.openedAt = Date.now();
          this.track('circuit_break', { ok: false, detail: `${provider.name} 连续失败 ${provider.circuit.failures} 次` });
          console.log(`[熔断] 服务商 ${provider.name} 连续失败 ${provider.circuit.failures} 次，熔断 ${(circuitCfg.cooldownMs || 60000) / 1000}s`);
        }
      }
    }

    // 成功率权重更新
    const w = provider.weights || {};
    w.requests = (w.requests || 0) + 1;
    const prevRate = w.successRate ?? 1;
    w.successRate = Math.max(0.01, prevRate * 0.85);  // 失败一次按 15% 衰减
    provider.weights = w;

    this.config.updateProvider(provider.id, {
      keyStats: provider.keyStats,
      circuit: provider.circuit,
      weights: provider.weights
    });
  }

  /**
   * 粗略 token 估算（中文约 1 字符≈1 token，按字符/2 保守估算）
   */
  estimateTokens(text) {
    return Math.ceil(String(text || '').length / 2);
  }

  /**
   * LLM 智能摘要压缩：把超长旧历史合成一条摘要
   * @returns {string|null} 摘要文本（失败返回 null，回退启发式）
   */
  async smartCompress(oldMessages) {
    const cfg = this.config.get('compression') || {};
    const historyText = (oldMessages || [])
      .map(m => `${m.role || 'user'}: ${String(m.content || '')}`)
      .join('\n').slice(0, 12000);
    const prompt = '请将下面的对话历史压缩为一份简洁摘要，保留所有关键信息（人物、事件、任务要求、已确认的结论、待办事项），用中文输出，300 字以内，不要输出其他内容：\n\n' + historyText;

    // 本地模型摘要（v2.5.1）：引擎在跑且后端模式允许时优先本地（省云端 token）
    if (this.backendFor('compression.smartBackend') === 'local' && this.localEngine?.running) {
      try {
        this.track('compression', { detail: 'smart-local' });
        const res = await this.localEngine.chat({ messages: [{ role: 'user', content: prompt }], max_tokens: 500, timeout: 180000 });
        const summary = res?.data?.choices?.[0]?.message?.content;
        return summary ? String(summary).trim() : null;
      } catch (e) {
        return null;
      }
    }

    const q = this.config.get('quality') || {};
    let provider = this.config.getProviders().find(p => p.id === cfg.providerId)
      || (q.judgeProviderId ? this.config.getProviders().find(p => p.id === q.judgeProviderId) : null)
      || this.config.getEnabledProviders().find(p => (p.models || []).length > 0);
    if (!provider) return null;
    let model = cfg.model || q.judgeModel;
    if (!model) model = (provider.models || [])[0];
    if (!model) return null;
    const key = this.getActiveKey(provider);
    if (!key) return null;
    try {
      const res = await this.callProvider(provider, key, model, {
        messages: [{ role: 'user', content: prompt }]
      }, 30000);
      const summary = res?.data?.choices?.[0]?.message?.content;
      return summary ? String(summary).trim() : null;
    } catch (e) {
      return null;
    }
  }

  /**
   * 对话 Tokens 压缩（不影响语义）：
   * - system 消息与最近 keepRecent 条消息保持原文
   * - 更早的旧消息：智能摘要（LLM）或启发式截断
   * - 仅在估算 tokens 超过 triggerTokens 时触发
   * @returns {{messages: Array, compressed: boolean, savedTokens: number, smart: boolean}}
   */
  async compressMessages(messages) {
    const cfg = this.config.get('compression') || {};
    if (!cfg.enabled || !Array.isArray(messages) || messages.length === 0) {
      return { messages, compressed: false, savedTokens: 0, smart: false };
    }
    const before = this.estimateTokens(messages.map(m => m.content || '').join('\n'));
    if (before < (cfg.triggerTokens || 12000)) {
      return { messages, compressed: false, savedTokens: 0, smart: false };
    }

    const keepRecent = cfg.keepRecent || 8;
    const system = messages.filter(m => m.role === 'system');
    const rest = messages.filter(m => m.role !== 'system');
    if (rest.length <= keepRecent + 1) {
      return { messages, compressed: false, savedTokens: 0, smart: false };
    }
    const recent = rest.slice(-keepRecent);
    let old = rest.slice(0, rest.length - keepRecent);

    // 消息级去重（v2.7.1，借鉴 OmniRoute session-dedup 阶梯首档）：完全无损
    // 1) system 消息内容完全相同只保留一条（保留最后出现的）
    // 2) 旧消息中相同 role+content 只保留最后一条
    // 3) 相邻完全相同的消息只保留一条（客户端重复追加）
    let dedupSaved = 0;
    if (cfg.dedup !== false && old.length > 0) {
      const beforeLen = old.reduce((s, m) => s + String(m.content || '').length, 0);
      const seen = new Map();
      const deduped = [];
      for (let i = old.length - 1; i >= 0; i--) {
        const m = old[i];
        const key = m.role + '|' + String(m.content || '');
        if (seen.has(key)) continue;   // 已出现过（保留最后一条）
        seen.set(key, true);
        deduped.unshift(m);
      }
      old = deduped;
      const afterLen = old.reduce((s, m) => s + String(m.content || '').length, 0);
      dedupSaved = beforeLen - afterLen;
      if (dedupSaved > 0) {
        this.compressionStats.dedup = (this.compressionStats.dedup || 0) + 1;
        this.compressionStats.dedupSavedChars = (this.compressionStats.dedupSavedChars || 0) + dedupSaved;
        this.track('compression', { detail: `dedup 去重 ${dedupSaved} 字符` });
      }
    }

    // system 消息去重（相同内容只保留最后一条）
    if (cfg.dedup !== false && system.length > 1) {
      const seenSys = new Set();
      const sysDedup = [];
      for (let i = system.length - 1; i >= 0; i--) {
        const k = system[i].role + '|' + String(system[i].content || '');
        if (!seenSys.has(k)) { seenSys.add(k); sysDedup.unshift(system[i]); }
      }
      const sysBefore = system.reduce((s, m) => s + String(m.content || '').length, 0);
      const sysAfter = sysDedup.reduce((s, m) => s + String(m.content || '').length, 0);
      if (sysBefore > sysAfter) {
        dedupSaved += sysBefore - sysAfter;
        system.length = 0; system.push(...sysDedup);
      }
    }
    if (old.length === 0 && system.length === messages.length) {
      return { messages, compressed: false, savedTokens: 0, smart: false };
    }

    let compressedOld = null;
    let smart = false;
    // 智能摘要优先（若启用且可调用压缩模型）
    if (cfg.smart !== false) {
      const summary = await this.smartCompress(old);
      if (summary) {
        compressedOld = [{ role: 'system', content: '【历史对话压缩摘要】' + summary }];
        smart = true;
      }
    }
    // 规则压缩（v2.7.0，借鉴 OmniRoute Caveman）：截断前先无损语义地删客套/填充/冗余（中英文）
    let base = old;
    if (!compressedOld && cfg.prose !== false) {
      const { compressProse, isCodeLikeText, compactStructured, extractiveCompress, filterCommandOutput, sampleTable, conservativePrune } = require('./prose-compress');
      let proseSaved = 0, proseApplied = [];
      const proseOld = old.map(m => {
        if (typeof m?.content !== 'string') return m;
        if (m.content.length < (cfg.minLen || 80)) return m;   // 短消息不值得
        if (isCodeLikeText(m.content)) return m;                // 代码不压缩
        // headroom（v2.8.0）：JSON/表格内容先紧凑化
        let c = m.content;
        const hd = compactStructured(c);
        if (hd.saved > 0) { proseSaved += hd.saved; c = hd.text; }
        // rtk（v2.9.0）：命令输出冗余过滤
        const rtk = filterCommandOutput(c);
        if (rtk.saved > 0) { proseSaved += rtk.saved; proseApplied.push('rtk'); c = rtk.text; }
        // ionizer（v2.9.0）：大表格行采样
        const ion = sampleTable(c);
        if (ion.saved > 0) { proseSaved += ion.saved; proseApplied.push('ionizer'); c = ion.text; }
        const r = compressProse(c);
        if (r.savedChars > 0) { proseSaved += r.savedChars; proseApplied.push(...r.appliedRules); }
        // relevance（v2.8.2）：规则压缩后仍超长时，抽取式删除低信息句（保守上限 40%）
        let finalText = r.text;
        let exSaved = 0;
        if (finalText.length > 250) {
          const ex = extractiveCompress(finalText);
          if (ex.saved > 0) { proseSaved += ex.saved; proseApplied.push('extractive'); exSaved = ex.saved; finalText = ex.text; }
        }
        // ultra 保守剪枝（v2.9.0）：空行压缩 + 重复段落去重（无损）
        const up = conservativePrune(finalText);
        if (up.saved > 0) { proseSaved += up.saved; proseApplied.push('ultra'); finalText = up.text; }
        return (hd.saved > 0 || rtk.saved > 0 || ion.saved > 0 || r.savedChars > 0 || exSaved > 0 || up.saved > 0) ? { ...m, content: finalText } : m;
      });
      if (proseSaved > 0) {
        base = proseOld;
        this.compressionStats.prose = (this.compressionStats.prose || 0) + 1;
        this.compressionStats.proseSavedChars = (this.compressionStats.proseSavedChars || 0) + proseSaved;
        this.track('compression', { detail: `prose ${proseApplied.length} 条规则` });
      }
    }
    // 启发式截断兜底：在（可能已 prose 压缩的）旧消息上再截断超长项
    if (!compressedOld && cfg.heuristic !== false) {
      const minLen = cfg.minLen || 80;
      const maxChars = cfg.maxOldChars || 600;
      compressedOld = base.map(m => {
        // 仅压缩字符串内容；多模态消息（content 为数组）保持原样，避免损坏结构
        if (typeof m?.content !== 'string') return m;
        const c = m.content;
        if (c.length <= minLen) return m;
        return { ...m, content: c.slice(0, maxChars) + (c.length > maxChars ? '…(已压缩)' : '') };
      });
    }
    if (!compressedOld) {
      return { messages, compressed: false, savedTokens: 0, smart: false };
    }

    const out = [...system, ...compressedOld, ...recent];
    const after = this.estimateTokens(out.map(m => m.content || '').join('\n'));
    const saved = before - after;
    if (saved <= 0) {
      return { messages, compressed: false, savedTokens: 0, smart: false };
    }
    return { messages: out, compressed: true, savedTokens: saved, smart };
  }

  /**
   * 构建多模态生成候选（精确匹配请求模型 → 智能选用同能力模型 → 多服务商）
   * @returns {Array<{provider, model}>}
   */
  buildGenCandidates(model, capability) {
    const providers = this.config.getEnabledProviders().filter(p => this.providerAllowed(p) && !this.isRateLimited(p));
    const out = [];
    const pushed = new Set();
    const add = (p, m) => {
      const k = p.id + '|' + m;
      if (!pushed.has(k)) { pushed.add(k); out.push({ provider: p, model: m }); }
    };
    // 1. 精确匹配请求的模型
    for (const p of providers) {
      if ((p.models || []).includes(model)) add(p, model);
    }
    // 2. 目标模型缺失 → 智能调度：自动选用该能力下的其他模型
    if (out.length === 0) {
      for (const p of providers) {
        for (const m of (p.models || [])) {
          if (this.inferModelCapability(m) === capability) add(p, m);
        }
      }
    }
    // 按服务商优先级排序
    return out.sort((a, b) => (a.provider.priority || 99) - (b.provider.priority || 99));
  }

  /**
   * 图片生成路由（OpenAI /v1/images/generations 兼容，带故障切换与智能调度）
   */
  async routeImageGeneration({ model, prompt, n, size, response_format, ...rest }, context = {}) {
    this.track('image_gen');
    this.stats.totalRequests++;
    this.touchActivity();
    const traceId = context.traceId || this.tracer.newTraceId();
    const trace = { traceId, model, requestedModel: model, kind: 'image', time: new Date().toISOString() };

    // 内容护栏
    if (this.mandatoryGuard.check(prompt)) {
      this.stats.failCount++;
      this.stats.mandatoryBlocks = (this.stats.mandatoryBlocks || 0) + 1;
      trace.status = 'blocked';
      trace.error = this.mandatoryGuard.genericReason;
      this.tracer.write(trace);
      const err = new Error(this.mandatoryGuard.genericReason);
      err.status = 403;
      err.mandatory = true;
      throw err;
    }
    const guardCheck = this.guard.checkMessages([{ role: 'user', content: prompt }]);
    if (guardCheck.blocked) {
      this.stats.failCount++;
      trace.status = 'blocked';
      trace.error = '敏感词拦截';
      this.tracer.write(trace);
      const err = new Error('内容护栏拦截：输入命中敏感词');
      err.status = 403;
      throw err;
    }

    const candidates = this.buildGenCandidates(model, 'image');
    if (candidates.length === 0) {
      this.stats.failCount++;
      trace.status = 'failed';
      trace.error = `没有可用的图片生成模型（请求: ${model}）`;
      this.tracer.write(trace);
      const err = new Error(`没有可用的图片生成模型: ${model}`);
      err.status = 404;
      throw err;
    }

    const failover = this.config.get('routing.failover') !== false;
    let lastError;
    for (const { provider, model: m } of candidates) {
      if (this.isCircuitOpen(provider)) continue;
      const quota = this.checkQuota(provider);
      if (!quota.ok) { lastError = new Error(`${provider.name} 配额已用尽`); continue; }
      const keyResult = this.selectKey(provider);
      if (!keyResult || keyResult.exhausted) { lastError = new Error(keyResult?.exhausted ? `${provider.name} 全部 Key 已禁用` : `${provider.name} 没有可用 Key`); continue; }

      const start = Date.now();
      try {
        const body = {
          model: m,
          prompt: String(prompt || ''),
          ...(n != null ? { n } : {}),
          ...(size ? { size } : {}),
          ...(response_format ? { response_format } : {}),
          ...rest
        };
        const url = `${this.apiBase(provider)}/images/generations`;
        const response = await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${keyResult.key}` },
          body: JSON.stringify(body),
          signal: AbortSignal.timeout(120000)
        });
        const latency = Date.now() - start;
        if (!response.ok) {
          const text = await response.text();
          const err = new Error(`${provider.name} 返回错误: ${response.status} ${text.slice(0, 300)}`);
          err.status = response.status;
          throw err;
        }
        const data = await response.json();
        this.recordSuccess(provider, keyResult.keyIndex, m, { latency, data, usage: null });
        this.consumeQuota(provider, null);
        this.slo.sample(latency);

        trace.status = 'success';
        trace.provider = provider.name;
        trace.providerId = provider.id;
        trace.model = m;
        trace.latency = latency;
        trace.switched = m !== model;
        trace.cost = this.estimateCost(provider, m, null);
        this.tracer.write(trace);
        this.notifyStatsUpdate();

        return {
          data,
          meta: { model: m, provider: provider.name, providerId: provider.id, latency, kind: 'image', switched: m !== model }
        };
      } catch (error) {
        lastError = error;
        this.recordFailure(provider, keyResult.keyIndex, m, error);
        if (error.status === 429) {
          this.applyRateLimitBackoff(provider);
        } else {
          this.handleKeyError(provider, keyResult.keyIndex, error.status);
        }
        if (!failover) break;
      }
    }

    this.stats.failCount++;
    trace.status = 'failed';
    trace.error = lastError?.message;
    this.tracer.write(trace);
    this.notifyStatsUpdate();
    throw lastError || new Error('所有图片生成服务均失败');
  }

  /**
   * 视频生成路由（异步任务：提交 /v1/videos/generations，轮询 /v1/videos/generations/:id）
   */
  async routeVideoGeneration({ model, prompt, duration, resolution, ...rest }, context = {}) {
    this.track('video_gen');
    this.stats.totalRequests++;
    this.touchActivity();
    const traceId = context.traceId || this.tracer.newTraceId();
    const trace = { traceId, model, requestedModel: model, kind: 'video', time: new Date().toISOString() };

    if (this.mandatoryGuard.check(prompt)) {
      this.stats.failCount++;
      this.stats.mandatoryBlocks = (this.stats.mandatoryBlocks || 0) + 1;
      trace.status = 'blocked';
      trace.error = this.mandatoryGuard.genericReason;
      this.tracer.write(trace);
      const err = new Error(this.mandatoryGuard.genericReason);
      err.status = 403;
      err.mandatory = true;
      throw err;
    }
    const guardCheck = this.guard.checkMessages([{ role: 'user', content: prompt }]);
    if (guardCheck.blocked) {
      this.stats.failCount++;
      trace.status = 'blocked';
      trace.error = '敏感词拦截';
      this.tracer.write(trace);
      const err = new Error('内容护栏拦截：输入命中敏感词');
      err.status = 403;
      throw err;
    }

    const candidates = this.buildGenCandidates(model, 'video');
    if (candidates.length === 0) {
      this.stats.failCount++;
      trace.status = 'failed';
      trace.error = `没有可用的视频生成模型（请求: ${model}）`;
      this.tracer.write(trace);
      const err = new Error(`没有可用的视频生成模型: ${model}`);
      err.status = 404;
      throw err;
    }

    const failover = this.config.get('routing.failover') !== false;
    let lastError;
    for (const { provider, model: m } of candidates) {
      if (this.isCircuitOpen(provider)) continue;
      const quota = this.checkQuota(provider);
      if (!quota.ok) { lastError = new Error(`${provider.name} 配额已用尽`); continue; }
      const keyResult = this.selectKey(provider);
      if (!keyResult || keyResult.exhausted) { lastError = new Error(keyResult?.exhausted ? `${provider.name} 全部 Key 已禁用` : `${provider.name} 没有可用 Key`); continue; }

      const start = Date.now();
      try {
        const body = {
          model: m,
          prompt: String(prompt || ''),
          ...(duration != null ? { duration } : {}),
          ...(resolution ? { resolution } : {}),
          ...rest
        };
        const url = `${this.apiBase(provider)}/videos/generations`;
        const response = await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${keyResult.key}` },
          body: JSON.stringify(body),
          signal: AbortSignal.timeout(60000)
        });
        const latency = Date.now() - start;
        if (!response.ok) {
          const text = await response.text();
          const err = new Error(`${provider.name} 返回错误: ${response.status} ${text.slice(0, 300)}`);
          err.status = response.status;
          throw err;
        }
        const data = await response.json();
        this.recordSuccess(provider, keyResult.keyIndex, m, { latency, data, usage: null });
        this.consumeQuota(provider, null);
        this.slo.sample(latency);

        // 记录异步任务映射（供轮询查询转发到同一上游）
        const upstreamId = data?.id || traceId;
        this.videoTasks.set(String(upstreamId), {
          providerId: provider.id,
          model: m,
          baseUrl: provider.baseUrl,
          pathStyle: provider.pathStyle || 'v1',
          upstreamId,
          createdAt: Date.now()
        });
        this.cleanupVideoTasks();

        trace.status = 'success';
        trace.provider = provider.name;
        trace.providerId = provider.id;
        trace.model = m;
        trace.latency = latency;
        trace.switched = m !== model;
        trace.cost = this.estimateCost(provider, m, null);
        this.tracer.write(trace);
        this.notifyStatsUpdate();

        return {
          data,
          meta: { model: m, provider: provider.name, providerId: provider.id, latency, kind: 'video', switched: m !== model }
        };
      } catch (error) {
        lastError = error;
        this.recordFailure(provider, keyResult.keyIndex, m, error);
        if (error.status === 429) {
          this.applyRateLimitBackoff(provider);
        } else {
          this.handleKeyError(provider, keyResult.keyIndex, error.status);
        }
        if (!failover) break;
      }
    }

    this.stats.failCount++;
    trace.status = 'failed';
    trace.error = lastError?.message;
    this.tracer.write(trace);
    this.notifyStatsUpdate();
    throw lastError || new Error('所有视频生成服务均失败');
  }

  /**
   * 查询视频生成任务状态（转发到原上游）
   */
  async getVideoTask(taskId) {
    const task = this.videoTasks.get(String(taskId));
    if (!task) {
      const err = new Error('视频任务不存在或已过期');
      err.status = 404;
      throw err;
    }
    const provider = this.config.getProviders().find(p => p.id === task.providerId);
    if (!provider) {
      const err = new Error('任务所属服务商已被删除');
      err.status = 404;
      throw err;
    }
    const key = this.getActiveKey(provider);
    const url = `${this.apiBase({ baseUrl: task.baseUrl, pathStyle: task.pathStyle })}/videos/generations/${encodeURIComponent(task.upstreamId)}`;
    const response = await fetch(url, {
      headers: { 'Authorization': `Bearer ${key || ''}` },
      signal: AbortSignal.timeout(30000)
    });
    if (!response.ok) {
      const text = await response.text();
      const err = new Error(`上游状态查询失败: ${response.status} ${text.slice(0, 200)}`);
      err.status = 502;
      throw err;
    }
    return response.json();
  }

  cleanupVideoTasks() {
    const cutoff = Date.now() - 60 * 60 * 1000; // 保留 1 小时
    for (const [k, v] of this.videoTasks) {
      if (v.createdAt < cutoff) this.videoTasks.delete(k);
    }
  }

  /**
   * 认证类错误的 Key 处理：连续错误满阈值才禁用（仅 401/403）
   * 注: 429 限流不计入 Key 禁用（临时性，走限流退避而不是禁用），避免限流恢复后渠道仍被禁用
   * @returns {boolean} 是否禁用了 Key
   */
  handleKeyError(provider, keyIndex, status) {
    if (status !== 401 && status !== 403) return false;
    const keyStat = provider.keyStats?.[keyIndex];
    if (keyStat && (keyStat.consecutiveErrors || 0) >= KEY_DISABLE_THRESHOLD) {
      this.track('key_guard', { ok: false, detail: `${provider.name} Key#${keyIndex + 1}` });
      this.disableKey(provider, keyIndex);
      return true;
    }
    return false;
  }

  /**
   * 是否处于 429 限流退避期
   */
  isRateLimited(provider) {
    return !!(provider.rateLimitedUntil && provider.rateLimitedUntil > Date.now());
  }

  /**
   * 429 限流退避（v2.8.0 指数退避 + 冷却上限，借鉴 OmniRoute cooldownCap）：
   * 退避时长 = base × 2^level，封顶 maxMs；成功一次即重置等级
   */
  applyRateLimitBackoff(provider) {
    const base = this.config.get('routing.rateLimitBackoffMs') || 60000;
    const maxMs = this.config.get('routing.rateLimitBackoffMaxMs') || 600000;
    const level = provider.backoffLevel || 0;
    const ms = Math.min(base * Math.pow(2, level), maxMs);
    provider.backoffLevel = level + 1;
    provider.rateLimitedUntil = Date.now() + ms;
    this.track('rate_limit_backoff', { detail: `level ${level} ${Math.round(ms / 1000)}s` });
    console.log(`[限流退避] 服务商 ${provider.name} 触发 429，退避 ${Math.round(ms / 1000)}s（level ${level}，封顶 ${Math.round(maxMs / 1000)}s）`);
  }

  /**
   * 禁用 Key
   */
  disableKey(provider, keyIndex) {
    const stats = provider.keyStats || {};
    if (!stats[keyIndex]) stats[keyIndex] = { requests: 0, errors: 0, consecutiveErrors: 0, lastUsed: null, disabled: false };
    stats[keyIndex].disabled = true;
    stats[keyIndex].disabledAt = new Date().toISOString();
    this.config.updateProvider(provider.id, { keyStats: stats });
    console.log(`已禁用服务商 ${provider.name} 的 Key #${keyIndex + 1}`);
  }

  /**
   * 重置所有被禁用的 Key（手动操作 / 健康检测恢复用）
   */
  resetKeys(provider, onlyIndex = null) {
    const stats = { ...(provider.keyStats || {}) };
    provider.keys.forEach((_, i) => {
      if (onlyIndex != null && i !== onlyIndex) return;
      stats[i] = {
        requests: stats[i]?.requests || 0,
        errors: 0,
        consecutiveErrors: 0,
        lastUsed: stats[i]?.lastUsed || null,
        disabled: false
      };
    });
    this.config.updateProvider(provider.id, { keyStats: stats, keyIndex: 0 });
    return stats;
  }

  /**
   * 获取缓存键（与 stream 标志无关，流式/非流式共用）
   */
  getCacheKey(model, messages, rest = {}) {
    const { noCache, ...forwardRest } = rest;
    return MemoryCache.key(model, messages, forwardRest, this.compressionVariant());
  }

  /**
   * 压缩配置签名：将压缩机制（smart/prose/heuristic/开关）以及所有相关参数
   * 折叠为短串，作为缓存键的一部分，使「压缩响应」与「未压缩响应」的缓存条目相互隔离，
   * 避免开启/关闭压缩后串味命中（原缺陷：精确缓存键基于原始 messages，却写入压缩后响应）。
   *
   * H1 修复：加入所有压缩参数（triggerTokens/keepRecent/maxOldChars/minLen/providerId/model），
   * 改任何参数都会让旧缓存条目失配，避免按"旧配置压缩"的回复继续命中。
   */
  compressionVariant() {
    const c = this.config.get('compression') || {};
    // 关键参数快照：任何变更都会改变 variant，旧缓存条目自动失配
    const snap = {
      enabled: !!c.enabled,
      smart: !!c.smart,
      prose: !!c.prose,
      heuristic: !!c.heuristic,
      dedup: !!c.dedup,
      triggerTokens: c.triggerTokens,
      keepRecent: c.keepRecent,
      maxOldChars: c.maxOldChars,
      minLen: c.minLen,
      providerId: c.providerId || null,
      model: c.model || null
    };
    return 'cmp' + JSON.stringify(snap);
  }

  cacheEnabled() {
    return !!((this.config.get('cache') || {}).enabled);
  }

  cachePut(key, data) {
    const cacheCfg = this.config.get('cache') || {};
    if (!cacheCfg.enabled) return false;
    this.cache.maxBytes = cacheCfg.maxBytes || DEFAULT_MAX_BYTES;
    return this.cache.put(key, data);
  }

  cacheGet(key) {
    const cacheCfg = this.config.get('cache') || {};
    if (!cacheCfg.enabled) return null;
    this.cache.maxBytes = cacheCfg.maxBytes || DEFAULT_MAX_BYTES;
    return this.cache.get(key);
  }

  clearCache() {
    this.cache.clear();
    return this.cache.stats();
  }

  getCacheStats() {
    return this.cache.stats();
  }

  /**
   * 获取统计数据（含服务商统计合并，修复服务商统计显示为 0 的问题）
   */
  getStats() {
    const providers = this.config.getProviders().map(p => {
      const ps = this.stats.providerStats[p.id] || { requests: 0, success: 0, fail: 0, errors: [], cost: 0, tokens: 0 };
      const circuit = p.circuit || { open: false };
      return {
        id: p.id,
        name: p.name,
        keyCount: p.keys.length,
        keyStats: p.keyStats,
        modelCount: p.models.length,
        enabled: p.enabled,
        billing: p.billing || { mode: 'tokens', pricePerCall: 0 },
        requests: ps.requests,
        success: ps.success,
        fail: ps.fail,
        errors: ps.errors || [],
        cost: ps.cost || 0,
        tokens: ps.tokens || 0,
        latency: p.weights?.latencyMs || null,
        successRate: ps.requests > 0 ? +(ps.success / ps.requests).toFixed(3) : null,
        qualityScore: p.weights?.qualityScore ?? null,
        circuitOpen: circuit.open === true,
        priority: p.priority
      };
    });

    return {
      ...this.stats,
      providers,
      quota: this.getQuotaStatus(),
      cache: this.getCacheStats(),
      semanticCache: this.semanticCache.stats(),
      slo: this.slo.stats(),
      drift: this.detectDrift(),
      quality: this.config.get('quality') || {},
      compression: { ...this.compressionStats, config: this.config.get('compression') || {} },
      prices: {
        currency: this.config.get('currency') || 'USD',
        models: this.config.get('prices.models') || {}
      },
      abTest: this.getABReport(),
      routing: {
        strategy: this.config.get('routing.strategy'),
        circuitBreaker: this.config.get('routing.circuitBreaker'),
        quota: this.config.get('routing.quota'),
        costOptimization: this.config.get('routing.costOptimization'),
        intentRouting: this.config.get('routing.intentRouting') ?? true,
        intentStats: this.stats.intentStats || {},
        promptCacheAffinity: {
          enabled: this.config.get('routing.promptCacheAffinity') ?? true,
          hits: this.affinityStats.hits,
          total: this.affinityStats.total,
          hitRate: this.affinityStats.total ? +((this.affinityStats.hits / this.affinityStats.total) * 100).toFixed(1) : 0,
          entries: this.promptCacheAffinity.size
        }
      }
    };
  }

  /**
   * A/B 测试报告
   */
  getABReport() {
    const ab = this.config.get('routing.abTest') || {};
    if (!ab.enabled || !Array.isArray(ab.groups) || ab.groups.length === 0) {
      return { enabled: false, groups: [] };
    }

    return {
      enabled: true,
      groups: ab.groups.map(g => {
        const ms = this.stats.modelStats[g.model] || { requests: 0, success: 0, fail: 0, cost: 0, tokens: 0 };
        const successRate = ms.requests > 0 ? +((ms.success / ms.requests) * 100).toFixed(1) : 0;
        // 实际累计成本（按服务商计费方式统计）；无数据时按 tokens 价格估算
        const estCost = ms.cost > 0
          ? ms.cost
          : (() => {
            const price = this.getPrice(g.model);
            return price ? +(ms.requests * (price.input * 0.001 + price.output * 0.0005)).toFixed(4) : null;
          })();
        return {
          name: g.name || g.model,
          model: g.model,
          weight: g.weight ?? 100,
          requests: ms.requests,
          success: ms.success,
          fail: ms.fail,
          successRate,
          tokens: ms.tokens || 0,
          estCost
        };
      })
    };
  }

  /**
   * 智能体检：对照 10 项能力清单逐项自检（落地选型检查清单）
   * status: ok | partial | missing | disabled
   */
  getHealthCheck() {
    const routing = this.config.get('routing') || {};
    const quality = this.config.get('quality') || {};
    const guard = this.config.get('guard') || {};
    const sc = this.config.get('semanticCache') || {};
    const slo = this.config.get('slo') || {};
    const residency = this.config.get('residency') || {};
    const hasEmbeddingModel = this.config.getEnabledProviders().some(p =>
      (p.models || []).some(m => /embed|text-embed|bge|m3|mxbai|e5/i.test(m))
    );

    const items = [
      { id: 1, name: '请求级意图/复杂度识别', desc: '按请求意图动态选路，而非固定规则', status: routing.intentRouting !== false ? 'ok' : 'off', enabled: routing.intentRouting !== false, hint: '六类意图分类 + 复杂度评估 + auto 智能选模型 + 回退按任务匹配（v2.10.0）' },
      { id: 2, name: '动态模型能力画像', desc: '随模型升级/价格变更同步更新', status: 'ok', enabled: true, hint: '一键获取模型列表 + 可编辑价格表 + 一键同步价格' },
      { id: 3, name: '多目标优化（成本/延迟/质量/均衡）', desc: '可按场景切换优化目标', status: 'ok', enabled: true, hint: '优先级/轮询/随机/加权(延迟+成功率+质量分) + 成本优化' },
      { id: 4, name: '多级 fallback 与熔断 + 能力兼容校验', desc: 'failover 时校验能力兼容性', status: 'ok', enabled: true, hint: '多服务商 fallback + 跨模型回退（按能力过滤：对话/图片/视频/嵌入互不串用）+ 熔断半开探测 + 回退快速遍历 + 不可重试快速失败' },
      { id: 5, name: '成本归因（服务商/模型/意图）', desc: '而非只有总账单', status: 'ok', enabled: true, hint: '按服务商+模型（双计费模式）+ 请求意图 三维成本归因' },
      { id: 6, name: 'Trace / Prompt版本 / 调用日志回放', desc: '支持问题回放', status: 'ok', enabled: (this.config.get('logging') || {}).enabled !== false, hint: '磁盘 JSONL 日志 + 过滤/详情/导出（含路由决策与候选排序）' },
      { id: 7, name: '质量评分 + 漂移检测 + 反馈迭代', desc: '反馈用于路由策略迭代', status: quality.enabled ? 'ok' : 'disabled', enabled: !!quality.enabled, hint: quality.enabled ? 'judge 模型评分 + 启发式评分 + 漂移告警 + 评分反哺加权路由' : '未启用：可在「智能」页开启（需配置 judge 模型）' },
      { id: 8, name: '数据驻留 / 内容护栏', desc: '安全与合规能力', status: 'ok', enabled: true, hint: '数据驻留（区域白名单）+ 内容护栏（PII 掩码 + 敏感词拦截）+ 强制内容保护；单机应用无多租户场景' },
      { id: 9, name: '语义缓存 + SLO 智能限流', desc: '降本提速最后一公里', status: (sc.enabled || slo.enabled !== false) ? (sc.enabled && !hasEmbeddingModel ? 'partial' : 'ok') : 'disabled', enabled: true, hint: (sc.enabled ? (hasEmbeddingModel ? `语义缓存已开（相似度阈值 ${sc.threshold}）` : `语义缓存已开但未检测到嵌入模型（本地嵌入会自动尝试，退化时回落云端）`) : '语义缓存未开（需可用 embeddings 服务商）') + `；SLO p95 降级保护${slo.enabled === false ? '未启用' : '已启用'}` },
      { id: 10, name: '影子模式', desc: '上线前先用真实流量验证', status: 'ok', enabled: true, hint: '影子决策（对比加权策略选择，零额外调用）+ 影子真实双跑（采样请求额外发加权首选渠道对比质量/延迟，shadow.realDualRun 开启，默认关）' }
    ];

    const okCount = items.filter(i => i.status === 'ok').length;
    const partialCount = items.filter(i => i.status === 'partial').length;
    return {
      items,
      summary: { ok: okCount, partial: partialCount, missing: items.filter(i => i.status === 'missing').length, disabled: items.filter(i => i.status === 'disabled').length, total: items.length },
      hasEmbeddingModel
    };
  }

  /**
   * 漂移检测：比较服务商质量分的"基线 vs 近期"，下降超过 15 分判定漂移
   */
  detectDrift() {
    const out = { active: false, items: [] };
    for (const [pid, ps] of Object.entries(this.stats.providerStats || {})) {
      const h = ps.qualityHistory || [];
      if (h.length < 20) continue;
      const baseline = h.slice(0, 10).reduce((a, b) => a + b, 0) / 10;
      const recentArr = h.slice(-20);
      const recent = recentArr.reduce((a, b) => a + b, 0) / recentArr.length;
      const drop = baseline - recent;
      if (drop >= 15) {
        const provider = this.config.getProviders().find(x => x.id === pid);
        out.active = true;
        out.items.push({
          provider: provider?.name || pid,
          baseline: Math.round(baseline),
          recent: Math.round(recent),
          drop: Math.round(drop)
        });
      }
    }
    return out;
  }

  resetStats() {
    const mandatoryBlocks = this.stats.mandatoryBlocks || 0;
    this.stats = {
      totalRequests: 0,
      successCount: 0,
      failCount: 0,
      totalCost: 0,
      providerStats: {},
      modelStats: {},
      recentRequests: [],
      mandatoryBlocks
    };
    this.slo.reset();
    this.notifyStatsUpdate();
    return this.stats;
  }

  /**
   * 输出拦截计数（代理层输出命中强制拦截时调用）
   */
  countMandatoryBlock() {
    this.stats.mandatoryBlocks = (this.stats.mandatoryBlocks || 0) + 1;
    return this.stats.mandatoryBlocks;
  }

  notifyStatsUpdate() {
    if (this.onStatsUpdate) {
      this.onStatsUpdate();
    }
  }

  shuffle(arr) {
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }
}

module.exports = { Router, KEY_DISABLE_THRESHOLD, KEY_RECOVER_ERRORS };
