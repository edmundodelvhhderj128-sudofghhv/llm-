/**
 * 路由引擎冒烟测试（不依赖 Electron）
 * 运行: node test-smoke.js
 * 覆盖: 多Key轮换/加权路由/熔断/配额/跨模型回退/成本优化/价格同步/统计合并
 */
const assert = require('assert');
const os = require('os');

// ---- Mock ConfigManager ----
function makeMockConfig(overrides = {}) {
  const state = {
    version: '2.0.0',
    proxyPort: 3456,
    autoStartProxy: true,
    autoStart: false,
    trayMinimize: true,
    currency: 'USD',
    providers: [],
    routing: {
      strategy: 'priority',
      failover: true,
      fallback: true,
      maxRetries: 3,
      timeout: 30000,
      healthCheckInterval: 5,
      circuitBreaker: { enabled: true, threshold: 2, cooldownMs: 5000 },
      quota: { enabled: false, period: 'day', limits: {} },
      costOptimization: { enabled: false, preferCheapest: true },
      abTest: { enabled: false, groups: [] }
    },
    prices: { currency: 'USD', models: { 'gpt-4': { input: 30, output: 60 } } },
    stats: { totalRequests: 0, successCount: 0, failCount: 0, providerStats: {} },
    ...overrides
  };

  return {
    config: state,
    getAll() { return this.config; },
    get(key) { return key.split('.').reduce((o, k) => o?.[k], this.config); },
    set(key, value) {
      const keys = key.split('.');
      const last = keys.pop();
      const target = keys.reduce((o, k) => { if (!o[k]) o[k] = {}; return o[k]; }, this.config);
      target[last] = value;
    },
    persist() {},
    save(data) { this.config = { ...this.config, ...data }; this.persist(); return this.config; },
    addProvider(p) {
      const id = p.id || ('p' + (this.config.providers.length + 1));
      const provider = {
        id, name: p.name, baseUrl: p.baseUrl, keys: p.keys, models: p.models,
        enabled: p.enabled !== false, priority: p.priority || this.config.providers.length + 1,
        keyIndex: 0, keyStats: {},
        weights: p.weights || { latencyMs: null, successRate: 1, requests: 0 },
        billing: p.billing || { mode: 'tokens', pricePerCall: 0 },
        region: p.region || 'any',
        circuit: p.circuit || { failures: 0, open: false, openedAt: null },
        quotaUsed: p.quotaUsed || { periodKey: null, requests: 0, tokens: 0 }
      };
      provider.keys.forEach((k, i) => { provider.keyStats[i] = { requests: 0, errors: 0, consecutiveErrors: 0, lastUsed: null, disabled: false }; });
      this.config.providers.push(provider);
      this.persist();
      return provider;
    },
    updateProvider(id, data) {
      const idx = this.config.providers.findIndex(p => p.id === id);
      if (idx === -1) return null;
      this.config.providers[idx] = { ...this.config.providers[idx], ...data };
      this.persist();
      return this.config.providers[idx];
    },
    removeProvider(id) { this.config.providers = this.config.providers.filter(p => p.id !== id); this.persist(); return true; },
    getProviders() { return this.config.providers; },
    getEnabledProviders() { return this.config.providers.filter(p => p.enabled); }
  };
}

const { Router } = require('./src/router');

let passed = 0;
function test(name, fn) {
  try { fn(); passed++; console.log(`  ok ${name}`); }
  catch (e) { console.log(`  FAIL ${name}: ${e.message}`); process.exitCode = 1; }
}

// ============ 1. 多Key轮换 ============
{
  const config = makeMockConfig();
  config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1', 'k2', 'k3'], models: ['gpt-4'] });
  const router = new Router(config, os.tmpdir());

  test('priority 策略选第一个可用 Key', () => {
    const p = config.getProviders()[0];
    const r = router.selectKey(p);
    assert.strictEqual(r.key, 'k1');
    assert.strictEqual(r.keyIndex, 0);
  });

  test('round-robin 策略轮换 Key', () => {
    config.set('routing.strategy', 'round-robin');
    let fresh = config.getProviders()[0];
    const r1 = router.selectKey(fresh);
    assert.strictEqual(r1.key, 'k1');
    fresh = config.getProviders()[0];
    const r2 = router.selectKey(fresh);
    assert.strictEqual(r2.key, 'k2');
    fresh = config.getProviders()[0];
    const r3 = router.selectKey(fresh);
    assert.strictEqual(r3.key, 'k3');
  });

  test('禁用 Key 后跳过', () => {
    config.set('routing.strategy', 'priority');
    const fresh0 = config.getProviders()[0];
    config.updateProvider(fresh0.id, { keyStats: { ...fresh0.keyStats, 0: { ...fresh0.keyStats[0], disabled: true } } });
    const fresh = config.getProviders()[0];
    const r = router.selectKey(fresh);
    assert.strictEqual(r.key, 'k2');
  });

  test('401 错误禁用 Key', () => {
    const provider = config.getProviders()[0];
    router.disableKey(provider, 1);
    assert.strictEqual(provider.keyStats[1].disabled, true);
  });

  test('resetKeys 恢复指定 Key', () => {
    const provider = config.getProviders()[0];
    router.resetKeys(provider, 1);
    const fresh = config.getProviders()[0];
    assert.strictEqual(fresh.keyStats[1].disabled, false);
  });
}

// ============ 2. 熔断 ============
{
  const config = makeMockConfig();
  config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4'] });
  config.addProvider({ name: 'B', baseUrl: 'https://b.example.com', keys: ['k1'], models: ['gpt-4'], priority: 2 });
  const router = new Router(config, os.tmpdir());

  test('连续失败达到阈值触发熔断', () => {
    const provider = config.getProviders()[0];
    for (let i = 0; i < 2; i++) {
      router.recordFailure(provider, 0, 'gpt-4', Object.assign(new Error('timeout'), { status: 500 }));
    }
    assert.strictEqual(provider.circuit.open, true, '熔断应打开');
  });

  test('熔断后 selectProviders 跳过该服务商', () => {
    const providers = router.selectProviders('gpt-4');
    assert.ok(!providers.some(p => p.name === 'A'), '熔断的服务商不应被选中');
  });

  test('4xx 不计入熔断计数', () => {
    const config2 = makeMockConfig();
    const p2 = config2.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4'] });
    const router2 = new Router(config2, os.tmpdir());
    for (let i = 0; i < 5; i++) {
      router2.recordFailure(p2, 0, 'gpt-4', Object.assign(new Error('401'), { status: 401 }));
    }
    assert.strictEqual(p2.circuit.open, false, '4xx 不应触发熔断');
  });
}

// ============ 3. 配额 ============
{
  const config = makeMockConfig();
  const p = config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4'] });
  const router = new Router(config, os.tmpdir());

  test('配额限制请求数（v2.8.0 软降级：100% 软超限不拒，120% 硬超限拒绝）', () => {
    config.set('routing.quota', { enabled: true, period: 'day', limits: { [p.id]: { requests: 2, tokens: 0 } } });
    router.checkQuota(p);
    assert.strictEqual(router.checkQuota(p).ok, true);
    p.quotaUsed.requests = 2;   // 100% = 软超限（≥90%），仍可用
    const soft = router.checkQuota(p);
    assert.strictEqual(soft.ok, true, '软超限应仍可用');
    assert.strictEqual(soft.soft, true, '应标记 soft');
    p.quotaUsed.requests = 3;   // 150% ≥ 120% = 硬超限
    const hard = router.checkQuota(p);
    assert.strictEqual(hard.ok, false, '硬超限应拒绝');
    assert.ok(hard.reason.includes('硬超限'));
  });

  test('周期切换自动重置', () => {
    p.quotaUsed = { periodKey: '1999-01-01', requests: 999, tokens: 999 };
    const result = router.checkQuota(p);
    assert.strictEqual(result.ok, true, '新周期应重置用量');
  });

  test('禁用配额时不受限', () => {
    config.set('routing.quota', { enabled: false, period: 'day', limits: { [p.id]: { requests: 1, tokens: 0 } } });
    p.quotaUsed.requests = 999;
    assert.strictEqual(router.checkQuota(p).ok, true);
  });
}

// ============ 4. 跨模型回退 ============
{
  const config = makeMockConfig({
    prices: {
      currency: 'USD',
      models: {
        'gpt-4': { input: 30, output: 60 },
        'gpt-3.5-turbo': { input: 0.5, output: 1.5 },
        'gpt-4o-mini': { input: 0.15, output: 0.6 }
      }
    }
  });
  config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4', 'gpt-3.5-turbo'] });
  config.addProvider({ name: 'B', baseUrl: 'https://b.example.com', keys: ['k1'], models: ['gpt-3.5-turbo', 'gpt-4o-mini'], priority: 2 });
  const router = new Router(config, os.tmpdir());

  test('无可用服务商时报错', async () => {
    await assert.rejects(() => router.routeWithFallback({ model: 'nonexistent', messages: [{ role: 'user', content: 'hi' }] }));
  });

  test('回退候选优先选支持面更广的模型', () => {
    const candidates = router.buildFallbackCandidates('gpt-4');
    assert.ok(candidates.includes('gpt-3.5-turbo'), 'gpt-3.5-turbo 应被 2 个服务商支持优先');
    assert.strictEqual(candidates[0], 'gpt-3.5-turbo');
  });

  test('成本优化开启时按价格排序', () => {
    config.set('routing.costOptimization', { enabled: true, preferCheapest: true });
    const candidates = router.buildFallbackCandidates('gpt-4');
    // gpt-4o-mini (0.15+0.6) < gpt-3.5-turbo (0.5+1.5)
    assert.strictEqual(candidates[0], 'gpt-4o-mini');
  });
}

// ============ 5. 价格管理 ============
{
  const config = makeMockConfig();
  config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4'] });
  const router = new Router(config, os.tmpdir());

  test('getPrice 返回内置价格', () => {
    const price = router.getPrice('gpt-4');
    assert.strictEqual(price.input, 30);
    assert.strictEqual(price.output, 60);
  });

  test('setPrice / removePrice', () => {
    router.setPrice('my-model', 1.5, 2.5);
    assert.strictEqual(router.getPrice('my-model').input, 1.5);
    router.removePrice('my-model');
    assert.strictEqual(router.getPrice('my-model'), null);
  });

  test('syncPrices 补齐缺失模型', () => {
    const synced = router.syncPrices();
    assert.ok(synced >= 20, `应补齐至少 20 个内置模型价格, 实际 ${synced}`);
    assert.ok(router.getPrice('deepseek-chat'));
  });

  test('货币换算', () => {
    const cny = router.convertPrice(2.5, 'CNY');
    assert.strictEqual(cny.currency, 'CNY');
    assert.strictEqual(cny.amount, 18);
    const usd = router.convertPrice(2.5, 'USD');
    assert.strictEqual(usd.amount, 2.5);
  });
}

// ============ 6. 统计合并（修复 0 显示 bug） ============
{
  const config = makeMockConfig();
  const p = config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4'] });
  const router = new Router(config, os.tmpdir());

  test('getStats 合并 providerStats 到 providers', () => {
    router.recordSuccess(p, 0, 'gpt-4', { latency: 123, data: {}, usage: null });
    router.recordFailure(p, 0, 'gpt-4', Object.assign(new Error('boom'), { status: 500 }));
    const stats = router.getStats();
    const provider = stats.providers.find(x => x.id === p.id);
    assert.strictEqual(provider.requests, 2, '请求数应为 2');
    assert.strictEqual(provider.success, 1);
    assert.strictEqual(provider.fail, 1);
    assert.ok(provider.latency > 0, '应有延迟数据');
  });

  test('modelStats 记录', () => {
    const stats = router.getStats();
    assert.strictEqual(stats.modelStats['gpt-4'].requests, 2);
  });

  test('失败后成功率衰减', () => {
    const provider = config.getProviders()[0];
    assert.ok(provider.weights.successRate < 1);
  });

  test('recordFailure 计入 modelStats 失败数', () => {
    const stats = router.getStats();
    assert.strictEqual(stats.modelStats['gpt-4'].fail, 1);
  });
}

// ============ 7. 加权路由 ============
{
  const config = makeMockConfig();
  config.addProvider({ name: 'slow', baseUrl: 'https://slow.example.com', keys: ['k1'], models: ['gpt-4'], priority: 1, weights: { latencyMs: 3000, successRate: 0.5, requests: 10 } });
  config.addProvider({ name: 'fast', baseUrl: 'https://fast.example.com', keys: ['k1'], models: ['gpt-4'], priority: 2, weights: { latencyMs: 200, successRate: 0.99, requests: 10 } });
  config.set('routing.strategy', 'weighted');
  const router = new Router(config, os.tmpdir());

  test('加权路由优先选择延迟低成功率高的服务商', () => {
    const providers = router.selectProviders('gpt-4');
    assert.strictEqual(providers[0].name, 'fast');
  });

  test('random 策略返回随机顺序（不抛错）', () => {
    config.set('routing.strategy', 'random');
    const providers = router.selectProviders('gpt-4');
    assert.strictEqual(providers.length, 2);
  });
}

// ============ 8. A/B 报告 ============
{
  const config = makeMockConfig();
  const p = config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4', 'gpt-4o-mini'] });
  config.set('routing.abTest', { enabled: true, groups: [{ name: 'main', model: 'gpt-4', weight: 50 }, { name: 'cheap', model: 'gpt-4o-mini', weight: 50 }] });
  const router = new Router(config, os.tmpdir());
  router.recordSuccess(p, 0, 'gpt-4', { latency: 100, data: {}, usage: null });
  router.recordSuccess(p, 0, 'gpt-4o-mini', { latency: 100, data: {}, usage: null });
  router.recordFailure(p, 0, 'gpt-4', Object.assign(new Error('x'), { status: 500 }));

  test('getABReport 输出分组统计', () => {
    const report = router.getABReport();
    assert.strictEqual(report.enabled, true);
    assert.strictEqual(report.groups.length, 2);
    const g1 = report.groups.find(g => g.name === 'main');
    assert.strictEqual(g1.requests, 2);
    assert.strictEqual(g1.successRate, 50);
    assert.ok(g1.estCost != null);
  });
}

// ============ 9.5 内存命中缓存 ============
{
  const { MemoryCache } = require('./src/cache');

  test('缓存命中/未命中计数', () => {
    const c = new MemoryCache({ maxBytes: 1024 * 1024 });
    const key = 'k1';
    assert.strictEqual(c.get(key), null);
    assert.strictEqual(c.misses, 1);
    c.put(key, { choices: [{ message: { content: 'hello' } }] });
    const hit = c.get(key);
    assert.ok(hit, '应命中');
    assert.strictEqual(hit.choices[0].message.content, 'hello');
    assert.strictEqual(c.hits, 1);
    const s = c.stats();
    assert.strictEqual(s.hitRate, 50);
  });

  test('LRU 按容量淘汰最久未用', () => {
    const c = new MemoryCache({ maxBytes: 3000, maxEntries: 100 });
    // 填充多条（每条约 500+ 字节），触发淘汰
    for (let i = 0; i < 10; i++) {
      c.put('key' + i, { data: 'x'.repeat(100), i });
    }
    assert.ok(c.evictions > 0, '应有淘汰发生');
    assert.ok(c.usedBytes <= c.maxBytes + 2000, `占用应接近上限: ${c.usedBytes}`);
    // 最近写入的应仍在（LRU 末尾），最旧的应被淘汰
    assert.ok(c.get('key9') != null, '最新条目应保留');
    assert.strictEqual(c.get('key0'), null, '最旧条目应被淘汰');
  });

  test('缓存键与 stream 无关、与参数相关', () => {
    const messages = [{ role: 'user', content: 'hi' }];
    const rest = { temperature: 0.7 };
    const k1 = MemoryCache.key('gpt-4', messages, rest);
    const k2 = MemoryCache.key('gpt-4', messages, { temperature: 0.7 });
    const k3 = MemoryCache.key('gpt-4', messages, { temperature: 0.8 });
    const k4 = MemoryCache.key('gpt-4', [{ role: 'user', content: 'hi2' }], rest);
    const k5 = MemoryCache.key('gpt-5', messages, rest);
    assert.strictEqual(k1, k2, '相同参数应同键');
    assert.notStrictEqual(k1, k3, '不同参数应不同键');
    assert.notStrictEqual(k1, k4, '不同消息应不同键');
    assert.notStrictEqual(k1, k5, '不同模型应不同键');
  });

  test('路由层缓存：相同请求第二次命中（上游只调用一次）', async () => {
    const origFetch = global.fetch;
    let calls = 0;
    global.fetch = async (url, opts) => {
      calls++;
      const body = JSON.parse(opts.body);
      return {
        ok: true, status: 200, headers: {}, body: null,
        json: async () => ({ id: 'x', choices: [{ message: { role: 'assistant', content: 'ok:' + body.model } }], usage: null })
      };
    };
    try {
      const config = makeMockConfig();
      config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4'] });
      const router = new Router(config, os.tmpdir());
      const r1 = await router.routeWithFallback({ model: 'gpt-4', messages: [{ role: 'user', content: 'hi' }] });
      assert.strictEqual(r1.meta.cached, undefined, '首次不应命中');
      const r2 = await router.routeWithFallback({ model: 'gpt-4', messages: [{ role: 'user', content: 'hi' }] });
      assert.strictEqual(r2.meta.cached, true, '第二次应命中缓存');
      assert.strictEqual(r2.meta.provider, '缓存');
      assert.strictEqual(calls, 1, '上游应只调用一次');
      const stats = router.getStats();
      assert.ok(stats.cache.hits >= 1);
    } finally {
      global.fetch = origFetch;
    }
  });

  test('noCache 参数绕过缓存；禁用缓存后不命中', async () => {
    const origFetch = global.fetch;
    let calls = 0;
    global.fetch = async () => { calls++; return { ok: true, status: 200, headers: {}, body: null, json: async () => ({ id: 'x', choices: [{ message: { content: 'ok' } }], usage: null }) }; };
    try {
      const config = makeMockConfig();
      config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4'] });
      const router = new Router(config, os.tmpdir());
      await router.routeWithFallback({ model: 'gpt-4', messages: [{ role: 'user', content: 'hi' }] });
      // noCache 请求：即使已有缓存也不命中
      const r = await router.routeWithFallback({ model: 'gpt-4', messages: [{ role: 'user', content: 'hi' }], noCache: true });
      assert.strictEqual(r.meta.cached, undefined, 'noCache 不应命中');
      // 禁用缓存后：第三次也不命中
      config.set('cache', { enabled: false, maxBytes: 1024 * 1024 * 1024, stream: true, embeddings: true });
      const r2 = await router.routeWithFallback({ model: 'gpt-4', messages: [{ role: 'user', content: 'hi' }] });
      assert.strictEqual(r2.meta.cached, undefined, '禁用缓存后不应命中');
      assert.ok(calls >= 3);
    } finally {
      global.fetch = origFetch;
    }
  });

  test('清空缓存后再次未命中', async () => {
    const c = new MemoryCache({ maxBytes: 1024 * 1024 });
    c.put('k', { a: 1 });
    assert.ok(c.get('k'));
    c.clear();
    assert.strictEqual(c.get('k'), null);
    assert.strictEqual(c.hits, 0);
    assert.strictEqual(c.misses, 0);
  });
}

// ============ 9.6 双计费模式（tokens / 次数） ============
{
  test('按 Tokens 计费：根据价格表与用量计算成本', () => {
    const config = makeMockConfig({
      prices: { currency: 'USD', models: { 'gpt-4': { input: 30, output: 60 } } }
    });
    const p = config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4'] });
    const router = new Router(config, os.tmpdir());
    // 1000 输入 + 500 输出 tokens：1000/1e6*30 + 500/1e6*60 = 0.03 + 0.03 = 0.06
    const cost = router.estimateCost(p, 'gpt-4', { prompt_tokens: 1000, completion_tokens: 500, total_tokens: 1500 });
    assert.strictEqual(cost, 0.06);
  });

  test('按次数计费：固定单价/次', () => {
    const config = makeMockConfig();
    const p = config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4'], billing: { mode: 'count', pricePerCall: 0.002 } });
    const router = new Router(config, os.tmpdir());
    const cost = router.estimateCost(p, 'gpt-4', { prompt_tokens: 99999, completion_tokens: 99999, total_tokens: 199998 });
    assert.strictEqual(cost, 0.002, '次数计费与 tokens 用量无关');
  });

  test('统计累计成本与 token 用量（tokens 模式）', () => {
    const config = makeMockConfig({
      prices: { currency: 'USD', models: { 'gpt-4': { input: 30, output: 60 } } }
    });
    const p = config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4'] });
    const router = new Router(config, os.tmpdir());
    router.recordSuccess(p, 0, 'gpt-4', { latency: 10, data: {}, usage: { prompt_tokens: 1000, completion_tokens: 500, total_tokens: 1500 } });
    const stats = router.getStats();
    assert.strictEqual(stats.totalCost, 0.06);
    const provider = stats.providers.find(x => x.id === p.id);
    assert.strictEqual(provider.cost, 0.06);
    assert.strictEqual(provider.tokens, 1500);
    assert.strictEqual(stats.modelStats['gpt-4'].cost, 0.06);
  });

  test('统计累计成本（次数模式：3 次调用 × 0.002）', () => {
    const config = makeMockConfig();
    const p = config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4'], billing: { mode: 'count', pricePerCall: 0.002 } });
    const router = new Router(config, os.tmpdir());
    for (let i = 0; i < 3; i++) {
      router.recordSuccess(p, 0, 'gpt-4', { latency: 10, data: {}, usage: null });
    }
    const stats = router.getStats();
    assert.strictEqual(stats.totalCost, 0.006);
    const provider = stats.providers.find(x => x.id === p.id);
    assert.strictEqual(provider.cost, 0.006);
  });

  test('成本优化按双计费模式排序回退候选', () => {
    const config = makeMockConfig({
      prices: { currency: 'USD', models: { 'gpt-4': { input: 30, output: 60 }, 'gpt-4o-mini': { input: 0.15, output: 0.6 } } }
    });
    config.addProvider({ name: 'Token渠道', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4', 'gpt-4o-mini'] });
    config.addProvider({ name: '按次渠道', baseUrl: 'https://b.example.com', keys: ['k1'], models: ['gpt-4o-mini'], billing: { mode: 'count', pricePerCall: 0.001 } });
    config.set('routing.costOptimization', { enabled: true, preferCheapest: true });
    const router = new Router(config, os.tmpdir());
    // gpt-4o-mini: tokens 0.00045 或 按次 0.001 → 取 min 0.00045；gpt-4: 0.09
    const candidates = router.buildFallbackCandidates('gpt-4');
    assert.strictEqual(candidates[0], 'gpt-4o-mini');
  });
}

// ============ 9.7 智能模块（护栏/语义缓存/SLO/质量/驻留/体检） ============
{
  const { ContentGuard } = require('./src/guard');
  const { SemanticCache } = require('./src/semantic-cache');
  const { SloMonitor } = require('./src/slo');

  test('护栏：PII 掩码（邮箱/手机号/密钥）', () => {
    const config = makeMockConfig();
    config.set('guard', { enabled: true, maskPII: true, blockSensitive: false, sensitiveWords: [] });
    const g = new ContentGuard(config);
    const r = g.mask('联系我 test@example.com 或 13800138000，密钥 sk-abc1234567890');
    assert.strictEqual(r.masked, true);
    assert.ok(!r.text.includes('test@example.com'), '邮箱应被掩码');
    assert.ok(!r.text.includes('13800138000'), '手机号应被掩码');
    assert.ok(!r.text.includes('sk-abc1234567890'), '密钥应被掩码');
  });

  test('护栏：敏感词拦截', () => {
    const config = makeMockConfig();
    config.set('guard', { enabled: true, maskPII: false, blockSensitive: true, sensitiveWords: ['暴恐', '违禁词'] });
    const g = new ContentGuard(config);
    const ok = g.checkMessages([{ role: 'user', content: '你好' }]);
    assert.strictEqual(ok.blocked, false);
    const bad = g.checkMessages([{ role: 'user', content: '今天聊点违禁词' }]);
    assert.strictEqual(bad.blocked, true);
  });

  test('语义缓存：余弦相似度 + 阈值命中', () => {
    const config = makeMockConfig();
    config.set('semanticCache', { enabled: true, threshold: 0.95, maxEntries: 100 });
    const sc = new SemanticCache(config);
    const emb = [1, 0, 0];
    sc.put(emb, '你好世界', { choices: [{ message: { content: '回复' } }] });
    // 完全相同的向量 -> 相似度 1.0 -> 命中
    const hit = sc.lookup([1, 0, 0], '你好世界');
    assert.strictEqual(hit.hit, true);
    assert.ok(hit.similarity >= 0.95);
    // 不相似的向量 -> 未命中
    const miss = sc.lookup([0, 1, 0], '完全无关');
    assert.strictEqual(miss.hit, false);
    // 余弦：正交为 0，相同为 1（浮点容差）
    assert.strictEqual(SemanticCache.cosine([1, 0], [0, 1]), 0);
    assert.ok(Math.abs(SemanticCache.cosine([1, 2], [1, 2]) - 1) < 1e-9);
  });

  test('SLO：p95 计算与降级触发/恢复', () => {
    const config = makeMockConfig();
    config.set('slo', { enabled: true, p95ThresholdMs: 100, windowSize: 200 });
    const slo = new SloMonitor(config);
    for (let i = 0; i < 100; i++) slo.sample(50);   // 低延迟
    assert.strictEqual(slo.degraded, false);
    assert.ok(slo.p95() <= 100);
    for (let i = 0; i < 60; i++) slo.sample(5000);  // 高延迟触发降级
    assert.strictEqual(slo.degraded, true, '应进入降级模式');
    assert.ok(slo.p95() > 100);
    for (let i = 0; i < 200; i++) slo.sample(30);   // 恢复
    assert.strictEqual(slo.degraded, false, '应解除降级');
  });

  test('质量评分：启发式函数', () => {
    const config = makeMockConfig();
    const router = new Router(config, os.tmpdir());
    assert.strictEqual(router.heuristicScore(''), 0, '空回复 0 分');
    assert.strictEqual(router.heuristicScore('抱歉，我无法回答这个问题。'), 50, '拒绝语应扣分');
    assert.strictEqual(router.heuristicScore('这是一个正常的完整回答，内容充实。'), 80);
  });

  test('质量反馈学习：评分写入服务商权重', () => {
    const config = makeMockConfig();
    const p = config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4'] });
    const router = new Router(config, os.tmpdir());
    router.applyQualityFeedback(p, 90);
    router.applyQualityFeedback(p, 90);
    const fresh = config.getProviders()[0];
    assert.ok(fresh.weights.qualityScore > 70, '质量分应提升权重');
    // 加权路由优先质量高的服务商
    const p2 = config.addProvider({ name: 'B', baseUrl: 'https://b.example.com', keys: ['k1'], models: ['gpt-4'], priority: 1, weights: { latencyMs: 100, successRate: 0.9, requests: 10, qualityScore: 40 } });
    config.set('routing.strategy', 'weighted');
    const order = router.weightedOrder([config.getProviders()[0], config.getProviders()[1]]);
    assert.strictEqual(order[0].name, 'A', '质量分高的 A 应优先');
  });

  test('数据驻留：区域白名单过滤', () => {
    const config = makeMockConfig();
    config.addProvider({ name: 'CN渠道', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4'], region: 'CN' });
    config.addProvider({ name: '海外渠道', baseUrl: 'https://b.example.com', keys: ['k1'], models: ['gpt-4'], region: 'US', priority: 2 });
    config.set('residency', { enabled: true, allowedRegions: ['CN'] });
    const router = new Router(config, os.tmpdir());
    const providers = router.selectProviders('gpt-4');
    assert.strictEqual(providers.length, 1);
    assert.strictEqual(providers[0].name, 'CN渠道');
    // 关闭驻留后全部可用
    config.set('residency', { enabled: false, allowedRegions: ['CN'] });
    assert.strictEqual(router.selectProviders('gpt-4').length, 2);
  });

  test('智能体检：10 项清单', () => {
    const config = makeMockConfig();
    const router = new Router(config, os.tmpdir());
    const hc = router.getHealthCheck();
    assert.strictEqual(hc.items.length, 10);
    assert.strictEqual(hc.summary.total, 10);
    const traceItem = hc.items.find(i => i.id === 6);
    assert.strictEqual(traceItem.status, 'ok');
  });

  test('Trace 日志：写入与查询', () => {
    const config = makeMockConfig();
    const router = new Router(config, os.tmpdir());
    const tid = router.tracer.newTraceId();
    router.tracer.write({ traceId: tid, model: 'gpt-4', provider: 'A', status: 'success', latency: 12 });
    const logs = router.tracer.recent(10, {});
    assert.ok(logs.some(l => l.traceId === tid));
    const filtered = router.tracer.recent(10, { model: 'gpt-4' });
    assert.ok(filtered.length >= 1);
    router.tracer.clear();
  });
}

// ============ 9.8 预设渠道商 ============
{
  const { PROVIDER_PRESETS } = require('./src/config');

  test('预设渠道商：数量与结构完整', () => {
    assert.ok(PROVIDER_PRESETS.length >= 16, `预设应不少于 16 个，实际 ${PROVIDER_PRESETS.length}`);
    for (const p of PROVIDER_PRESETS) {
      assert.ok(p.name && p.name.trim(), '必须有名称');
      assert.ok(/^https?:\/\//.test(p.baseUrl), `${p.name} 的 Base URL 格式错误: ${p.baseUrl}`);
      assert.ok(['CN', 'US', 'EU', 'any'].includes(p.region), `${p.name} 区域非法`);
      assert.ok(Array.isArray(p.models), `${p.name} 模型列表必须是数组`);
      assert.ok(['v1', 'none'].includes(p.pathStyle || 'v1'), `${p.name} pathStyle 非法`);
      // URL 正确性：不出现 /v1/v1、/v2/v1、/v4/v1 等重复拼接
      const base = p.baseUrl.replace(/\/$/, '');
      const url = ((p.pathStyle || 'v1') === 'none' ? base : base + '/v1') + '/chat/completions';
      assert.ok(!url.includes('/v1/v1') && !url.includes('/v2/v1') && !url.includes('/v4/v1'), `${p.name} 接口路径重复拼接: ${url}`);
    }
  });

  test('预设渠道商：包含商汤日日新与 Agnes 双节点', () => {
    const sn = PROVIDER_PRESETS.find(p => p.name.includes('商汤'));
    assert.ok(sn, '应包含商汤日日新预设');
    assert.strictEqual(sn.baseUrl, 'https://token.sensenova.cn');
    assert.ok(sn.models.includes('sensenova-6.7-flash-lite'), '应含 sensenova-6.7-flash-lite');
    const cn = PROVIDER_PRESETS.find(p => p.baseUrl.includes('agnes-ai.cn'));
    const intl = PROVIDER_PRESETS.find(p => p.baseUrl.includes('agnes-ai.com'));
    assert.ok(cn && intl, '应包含 Agnes 国内外两个节点');
    assert.strictEqual(cn.baseUrl, 'https://apihub.agnes-ai.cn');
    assert.strictEqual(intl.baseUrl, 'https://apihub.agnes-ai.com');
  });

  test('apiBase 兼容不同接口前缀', () => {
    const config = makeMockConfig();
    const router = new Router(config, os.tmpdir());
    assert.strictEqual(router.apiBase({ baseUrl: 'https://api.deepseek.com' }), 'https://api.deepseek.com/v1');
    assert.strictEqual(router.apiBase({ baseUrl: 'https://open.bigmodel.cn/api/paas/v4', pathStyle: 'none' }), 'https://open.bigmodel.cn/api/paas/v4');
    assert.strictEqual(router.apiBase({ baseUrl: 'https://api.groq.com/openai/v1', pathStyle: 'none' }), 'https://api.groq.com/openai/v1');
    assert.strictEqual(router.apiBase({ baseUrl: 'https://qianfan.baidubce.com/v2', pathStyle: 'none' }), 'https://qianfan.baidubce.com/v2');
    assert.strictEqual(router.apiBase({ baseUrl: 'https://token.sensenova.cn' }), 'https://token.sensenova.cn/v1');
  });

  test('预设渠道商：名称唯一', () => {
    const names = PROVIDER_PRESETS.map(p => p.name);
    assert.strictEqual(new Set(names).size, names.length, '预设名称应唯一');
  });
}

// ============ 9.9 边界用例（熔断半开/配额与缓存/缓存边界/SLO/Trace成本） ============
{
  const { MemoryCache } = require('./src/cache');
  const { SemanticCache } = require('./src/semantic-cache');
  const { SloMonitor } = require('./src/slo');
  const { ContentGuard } = require('./src/guard');

  test('熔断冷却结束后半开探测放行', () => {
    const config = makeMockConfig();
    const p = config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4'] });
    p.circuit = { failures: 5, open: true, openedAt: Date.now() - 100000 }; // 冷却已过
    const router = new Router(config, os.tmpdir());
    const providers = router.selectProviders('gpt-4');
    assert.strictEqual(providers.length, 1, '冷却结束后应放行探测');
  });

  test('缓存命中不消耗配额', async () => {
    const origFetch = global.fetch;
    let calls = 0;
    global.fetch = async () => { calls++; return { ok: true, status: 200, headers: {}, body: null, json: async () => ({ id: 'x', choices: [{ message: { content: 'ok' } }], usage: { total_tokens: 5 } }) }; };
    try {
      const config = makeMockConfig();
      const p = config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4'] });
      config.set('routing.quota', { enabled: true, period: 'day', limits: { [p.id]: { requests: 2, tokens: 0 } } });
      const router = new Router(config, os.tmpdir());
      await router.routeWithFallback({ model: 'gpt-4', messages: [{ role: 'user', content: '配额与缓存' }] });
      const used1 = config.getProviders()[0].quotaUsed.requests;
      assert.strictEqual(used1, 1, '首次调用应消耗 1 次配额');
      await router.routeWithFallback({ model: 'gpt-4', messages: [{ role: 'user', content: '配额与缓存' }] });
      const used2 = config.getProviders()[0].quotaUsed.requests;
      assert.strictEqual(used2, 1, '缓存命中不应再消耗配额');
      assert.strictEqual(calls, 1, '上游应只调用一次');
    } finally {
      global.fetch = origFetch;
    }
  });

  test('缓存：单条超大响应不缓存', () => {
    const c = new MemoryCache({ maxBytes: 2000 });
    const big = { data: 'x'.repeat(5000) };
    assert.strictEqual(c.put('big', big), false, '超过上限的单条不应缓存');
    assert.strictEqual(c.get('big'), null);
  });

  test('语义缓存：LRU 淘汰超出条数', () => {
    const config = makeMockConfig();
    config.set('semanticCache', { enabled: true, threshold: 0.95, maxEntries: 3 });
    const sc = new SemanticCache(config);
    sc.put([1, 0], 'a', { r: 1 });
    sc.put([0, 1], 'b', { r: 2 });
    sc.put([1, 1], 'c', { r: 3 });
    sc.put([1, -1], 'd', { r: 4 });
    assert.strictEqual(sc.entries.size, 3, '超出 maxEntries 应淘汰');
  });

  test('SLO：降级时拦截慢速服务商', () => {
    const config = makeMockConfig();
    config.set('slo', { enabled: true, p95ThresholdMs: 1000 });
    const slo = new SloMonitor(config);
    slo.degraded = true;
    assert.strictEqual(slo.isProviderAllowed({ weights: { latencyMs: 5000 } }), false, '慢速应被拦截');
    assert.strictEqual(slo.isProviderAllowed({ weights: { latencyMs: 200 } }), true, '快速应放行');
    assert.strictEqual(slo.isProviderAllowed({ weights: {} }), true, '无数据不拦截');
  });

  test('护栏：URL 掩码', () => {
    const config = makeMockConfig();
    config.set('guard', { enabled: true, maskPII: true, blockSensitive: false, sensitiveWords: [] });
    const g = new ContentGuard(config);
    const r = g.mask('参考文档 https://example.com/docs/1 说明');
    assert.strictEqual(r.masked, true);
    assert.ok(!r.text.includes('https://example.com'), 'URL 应被掩码');
  });

  test('Trace：单次成本按 usage 精确计算（非累计）', async () => {
    const origFetch = global.fetch;
    global.fetch = async () => ({ ok: true, status: 200, headers: {}, body: null, json: async () => ({ id: 'x', choices: [{ message: { content: 'ok' } }], usage: { prompt_tokens: 1000, completion_tokens: 500, total_tokens: 1500 } }) });
    try {
      const config = makeMockConfig({ prices: { currency: 'USD', models: { 'gpt-4': { input: 30, output: 60 } } } });
      config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4'] });
      const router = new Router(config, os.tmpdir());
      await router.routeWithFallback({ model: 'gpt-4', messages: [{ role: 'user', content: '成本测试' }] });
      await router.routeWithFallback({ model: 'gpt-4', messages: [{ role: 'user', content: '成本测试2' }] });
      const logs = router.tracer.recent(10, {});
      const last = logs.find(l => l.status === 'success');
      assert.strictEqual(last.cost, 0.06, '单次成本应为 0.06（1000*30/1e6 + 500*60/1e6）');
      assert.strictEqual(last.usageTokens, 1500);
    } finally {
      global.fetch = origFetch;
    }
  });
}

// ============ 9.10 多模态（能力识别 / 图片 / 视频生成） ============
{
  test('模型能力识别', () => {
    const config = makeMockConfig();
    const router = new Router(config, os.tmpdir());
    assert.strictEqual(router.inferModelCapability('dall-e-3'), 'image');
    assert.strictEqual(router.inferModelCapability('agnes-image-2.1-flash'), 'image');
    assert.strictEqual(router.inferModelCapability('sensenova-u1-fast'), 'image');
    assert.strictEqual(router.inferModelCapability('agnes-video-2.5'), 'video');
    assert.strictEqual(router.inferModelCapability('hailuo-02'), 'video');
    assert.strictEqual(router.inferModelCapability('text-embedding-3-small'), 'embedding');
    assert.strictEqual(router.inferModelCapability('bge-m3'), 'embedding');
    assert.strictEqual(router.inferModelCapability('gpt-4o'), 'chat');
    assert.strictEqual(router.inferModelCapability('agnes-2.5-flash'), 'chat');
  });

  test('图片候选：精确匹配优先，缺失时自动选用同能力模型', () => {
    const config = makeMockConfig();
    config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4o', 'dall-e-3'] });
    config.addProvider({ name: 'B', baseUrl: 'https://b.example.com', keys: ['k1'], models: ['agnes-image-2.1-flash'], priority: 2 });
    const router = new Router(config, os.tmpdir());
    // 精确匹配
    let c = router.buildGenCandidates('dall-e-3', 'image');
    assert.strictEqual(c.length, 1);
    assert.strictEqual(c[0].model, 'dall-e-3');
    // 精确缺失 → 智能选用同能力模型
    c = router.buildGenCandidates('unknown-image-model', 'image');
    assert.strictEqual(c.length, 2, '应自动选用全部图片模型');
    assert.ok(c.some(x => x.model === 'dall-e-3'));
    assert.ok(c.some(x => x.model === 'agnes-image-2.1-flash'));
    // 视频候选：无视频模型则为空
    c = router.buildGenCandidates('any-video', 'video');
    assert.strictEqual(c.length, 0);
  });

  test('图片生成：成功 + 自动选模型 + 故障切换', async () => {
    const origFetch = global.fetch;
    let calls = [];
    global.fetch = async (url, opts) => {
      calls.push({ url, model: JSON.parse(opts.body).model });
      const body = JSON.parse(opts.body);
      if (body.model === 'dall-e-3' && url.includes('a.example.com')) {
        return { ok: false, status: 500, text: async () => 'err', headers: {}, body: null };
      }
      return { ok: true, status: 200, headers: {}, body: null, json: async () => ({ created: 1, data: [{ b64_json: 'AAAA' }] }) };
    };
    try {
      const config = makeMockConfig();
      config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4o', 'dall-e-3'] });
      config.addProvider({ name: 'B', baseUrl: 'https://b.example.com', keys: ['k1'], models: ['agnes-image-2.1-flash'], priority: 2 });
      const router = new Router(config, os.tmpdir());
      // 请求的模型缺失 → 自动调度到 A 的 dall-e-3 → 失败 → 切换 B 的 agnes-image
      const result = await router.routeImageGeneration({ model: 'my-image', prompt: '一只猫' });
      assert.ok(result.data.data[0].b64_json);
      assert.strictEqual(result.meta.model, 'agnes-image-2.1-flash');
      assert.strictEqual(result.meta.switched, true);
      assert.ok(calls.some(c => c.model === 'dall-e-3'), '先尝试 dall-e-3');
      assert.ok(calls.some(c => c.model === 'agnes-image-2.1-flash'), '再尝试 agnes-image');
    } finally {
      global.fetch = origFetch;
    }
  });

  test('视频生成：提交任务 + 轮询状态转发到原上游', async () => {
    const origFetch = global.fetch;
    global.fetch = async (url) => {
      if (url.endsWith('/videos/generations')) {
        return { ok: true, status: 200, headers: {}, body: null, json: async () => ({ id: 'task-1', status: 'queued' }) };
      }
      if (url.includes('/videos/generations/task-1')) {
        return { ok: true, status: 200, headers: {}, body: null, json: async () => ({ id: 'task-1', status: 'completed', url: 'http://cdn/video.mp4' }) };
      }
      return { ok: true, status: 200, headers: {}, body: null, json: async () => ({}) };
    };
    try {
      const config = makeMockConfig();
      config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['agnes-video-2.5'] });
      const router = new Router(config, os.tmpdir());
      const result = await router.routeVideoGeneration({ model: 'agnes-video-2.5', prompt: '海浪' });
      assert.strictEqual(result.data.status, 'queued');
      assert.ok(router.videoTasks.has('task-1'));
      const status = await router.getVideoTask('task-1');
      assert.strictEqual(status.status, 'completed');
      assert.strictEqual(status.url, 'http://cdn/video.mp4');
      // 不存在的任务 → 404
      await assert.rejects(() => router.getVideoTask('nope'), (e) => e.status === 404);
    } finally {
      global.fetch = origFetch;
    }
  });

  test('图片生成：护栏拦截返回 403', async () => {
    const config = makeMockConfig();
    config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['dall-e-3'] });
    config.set('guard', { enabled: true, maskPII: false, blockSensitive: true, sensitiveWords: ['违禁'] });
    const router = new Router(config, os.tmpdir());
    await assert.rejects(() => router.routeImageGeneration({ model: 'dall-e-3', prompt: '包含违禁的内容' }), (e) => e.status === 403);
  });
}

// ============ 9.11 Tokens 压缩 ============
{
  test('压缩：短对话不触发，长对话启发式截断且保留关键消息', async () => {
    const config = makeMockConfig();
    config.set('compression', { enabled: true, heuristic: true, smart: false, keepRecent: 3, maxOldChars: 120, minLen: 60, triggerTokens: 100 });
    const router = new Router(config, os.tmpdir());
    // 短对话：不触发
    let r = await router.compressMessages([{ role: 'user', content: '你好' }]);
    assert.strictEqual(r.compressed, false);
    // 长对话：system + 最近 3 条保留，更早的超长消息被截断
    const system = { role: 'system', content: '你是助手' };
    const oldLong = { role: 'user', content: 'x'.repeat(300) + '关键信息ABC' };
    const recent = [
      { role: 'user', content: '最近问题1' },
      { role: 'assistant', content: '最近回答1' },
      { role: 'user', content: '最近问题2' }
    ];
    const msgs = [system, oldLong, ...recent];
    r = await router.compressMessages(msgs);
    assert.strictEqual(r.compressed, true);
    assert.ok(r.savedTokens > 0);
    // system 与最近消息必须原样保留
    assert.ok(r.messages.some(m => m.content === '你是助手'));
    assert.ok(r.messages.some(m => m.content === '最近问题2'));
    // 旧消息被截断
    const oldOut = r.messages.find(m => m.content.includes('已压缩'));
    assert.ok(oldOut, '旧消息应带压缩标记');
    assert.ok(oldOut.content.includes('关键信息ABC'), '截断应保留头部关键信息');
    assert.ok(oldOut.content.length <= 130, '压缩后长度受限');
  });

  test('压缩：禁用时不生效；keepRecent 覆盖全部消息时不压缩', async () => {
    const config = makeMockConfig();
    const router = new Router(config, os.tmpdir());
    let r = await router.compressMessages([{ role: 'user', content: 'x'.repeat(500) }]);
    assert.strictEqual(r.compressed, false, '默认禁用');
    config.set('compression', { enabled: true, heuristic: true, smart: false, keepRecent: 20, triggerTokens: 10 });
    r = await router.compressMessages([{ role: 'user', content: 'x'.repeat(500) }]);
    assert.strictEqual(r.compressed, false, '消息数不足时不压缩');
  });

  test('压缩：LLM 智能摘要模式合成摘要消息', async () => {
    const origFetch = global.fetch;
    global.fetch = async (url, opts) => {
      const body = JSON.parse(opts.body);
      if (body.messages?.[0]?.content?.includes('压缩为一份简洁摘要')) {
        return { ok: true, status: 200, headers: {}, body: null, json: async () => ({ choices: [{ message: { content: '这是摘要：用户询问了 A 和 B' } }], usage: null }) };
      }
      return { ok: true, status: 200, headers: {}, body: null, json: async () => ({ choices: [{ message: { content: 'ok' } }], usage: null }) };
    };
    try {
      const config = makeMockConfig();
      config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['compress-model'] });
      config.set('compression', { enabled: true, heuristic: true, smart: true, providerId: null, model: 'compress-model', keepRecent: 2, triggerTokens: 50 });
      const router = new Router(config, os.tmpdir());
      const old = [];
      for (let i = 0; i < 5; i++) old.push({ role: 'user', content: '很长的历史问题内容' + 'y'.repeat(100) + i });
      const recent = [{ role: 'user', content: '当前问题' }, { role: 'assistant', content: '当前回答' }];
      const r = await router.compressMessages([...old, ...recent]);
      assert.strictEqual(r.compressed, true);
      assert.strictEqual(r.smart, true, '应使用智能摘要');
      assert.ok(r.messages.some(m => m.content.includes('历史对话压缩摘要')), '应包含摘要消息');
      assert.ok(r.messages.some(m => m.content === '当前问题'), '最近消息应保留');
    } finally {
      global.fetch = origFetch;
    }
  });

  test('路由集成：压缩后发送上游，统计生效', async () => {
    const origFetch = global.fetch;
    let received = null;
    global.fetch = async (url, opts) => {
      received = JSON.parse(opts.body);
      return { ok: true, status: 200, headers: {}, body: null, json: async () => ({ id: 'x', choices: [{ message: { content: 'ok' } }], usage: null }) };
    };
    try {
      const config = makeMockConfig();
      config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4'] });
      config.set('compression', { enabled: true, heuristic: true, smart: false, keepRecent: 2, maxOldChars: 100, minLen: 50, triggerTokens: 100 });
      const router = new Router(config, os.tmpdir());
      const messages = [];
      for (let i = 0; i < 6; i++) messages.push({ role: 'user', content: '长历史内容' + 'z'.repeat(200) + i });
      messages.push({ role: 'user', content: '最终问题' });
      await router.routeWithFallback({ model: 'gpt-4', messages });
      assert.ok(received.messages.some(m => String(m.content).includes('已压缩')), '上游应收到压缩后的消息');
      assert.ok(received.messages.some(m => m.content === '最终问题'), '最近消息原文保留');
      const stats = router.getStats();
      assert.ok(stats.compression.compressedRequests >= 1, '压缩统计应记录');
      assert.ok(stats.compression.savedTokens > 0, '节省 tokens 应大于 0');
    } finally {
      global.fetch = origFetch;
    }
  });
}

// ============ 9.12 工具调用消息（content=null + tool_calls）+ 上游400自动切换 ============
{
  test('工具调用消息通过校验；上游 400 自动故障切换', async () => {
    const origFetch = global.fetch;
    const calls = [];
    global.fetch = async (url, opts) => {
      const body = JSON.parse(opts.body);
      calls.push({ url, model: body.model, hasToolCall: body.messages.some(m => m.tool_calls), contentNull: body.messages.some(m => m.content === null) });
      if (url.includes('a.example.com')) {
        return { ok: false, status: 400, text: async () => '{"error":{"message":"tool_calls not supported"}}', headers: {}, body: null };
      }
      return { ok: true, status: 200, headers: {}, body: null, json: async () => ({ id: 'x', choices: [{ message: { role: 'assistant', content: '渠道B回答' } }], usage: null }) };
    };
    try {
      const config = makeMockConfig();
      config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['glm-5.2'], priority: 1 });
      config.addProvider({ name: 'B', baseUrl: 'https://b.example.com', keys: ['k1'], models: ['glm-5.2'], priority: 2 });
      const router = new Router(config, os.tmpdir());
      const messages = [
        { role: 'user', content: '帮我搜索渠县今天的天气' },
        { role: 'assistant', content: null, tool_calls: [{ id: 'c1', type: 'function', function: { name: 'search', arguments: '{}' } }] },
        { role: 'tool', tool_call_id: 'c1', content: '晴 25℃' }
      ];
      const result = await router.routeWithFallback({ model: 'glm-5.2', messages });
      assert.strictEqual(result.success, true);
      assert.strictEqual(result.meta.provider, 'B', 'A 返回 400 后应切换到 B');
      assert.ok(calls[0].hasToolCall && calls[0].contentNull, '上游应收到含 tool_calls 与 content=null 的消息');
    } finally {
      global.fetch = origFetch;
    }
  });
}

// ============ 9.13 跨模型回退按能力过滤（chat 请求绝不回退到图片/视频模型） ============
{
  test('chat 回退只选聊天模型，不调用图片模型', async () => {
    const origFetch = global.fetch;
    const calls = [];
    global.fetch = async (url, opts) => {
      const body = JSON.parse(opts.body);
      calls.push({ url, model: body.model });
      if (body.model === 'glm-5.2') return { ok: false, status: 500, text: async () => 'err', headers: {}, body: null };
      return { ok: true, status: 200, headers: {}, body: null, json: async () => ({ id: 'x', choices: [{ message: { content: 'ok:' + body.model } }], usage: null }) };
    };
    try {
      const config = makeMockConfig();
      config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['glm-5.2', 'agnes-image-2.0-flash', 'agnes-video-2.5'] });
      config.addProvider({ name: 'B', baseUrl: 'https://b.example.com', keys: ['k1'], models: ['deepseek-chat'], priority: 2 });
      const router = new Router(config, os.tmpdir());
      const result = await router.routeWithFallback({ model: 'glm-5.2', messages: [{ role: 'user', content: 'hi' }] });
      assert.strictEqual(result.meta.model, 'deepseek-chat', '应回退到聊天模型');
      assert.ok(calls.every(c => c.model !== 'agnes-image-2.0-flash'), '绝不应调用图片模型');
      assert.ok(calls.every(c => c.model !== 'agnes-video-2.5'), '绝不应调用视频模型');
      // 图片模型只应通过 /images/generations 调用（本测试未触发）
      assert.ok(!calls.some(c => c.url.includes('/images/generations')));
    } finally {
      global.fetch = origFetch;
    }
  });

  test('无聊天回退候选时直接失败，绝不拿图片模型顶替', async () => {
    const origFetch = global.fetch;
    const calls = [];
    global.fetch = async (url, opts) => {
      const body = JSON.parse(opts.body);
      calls.push({ model: body.model });
      return { ok: false, status: 500, text: async () => 'err', headers: {}, body: null };
    };
    try {
      const config = makeMockConfig();
      config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['glm-5.2', 'agnes-image-2.0-flash'] });
      const router = new Router(config, os.tmpdir());
      await assert.rejects(() => router.routeWithFallback({ model: 'glm-5.2', messages: [{ role: 'user', content: 'hi' }] }));
      assert.ok(calls.every(c => c.model !== 'agnes-image-2.0-flash'), '失败也不应调用图片模型');
    } finally {
      global.fetch = origFetch;
    }
  });

  test('buildFallbackCandidates 能力过滤（chat / image）', () => {
    const config = makeMockConfig();
    config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4o', 'dall-e-3', 'text-embedding-3-small'] });
    const router = new Router(config, os.tmpdir());
    const chat = router.buildFallbackCandidates('gpt-3.5-turbo', 'chat');
    assert.ok(chat.includes('gpt-4o'));
    assert.ok(!chat.includes('dall-e-3'), '图片模型不应出现在 chat 回退候选');
    assert.ok(!chat.includes('text-embedding-3-small'), '嵌入模型不应出现在 chat 回退候选');
    const img = router.buildFallbackCandidates('xxx', 'image');
    assert.ok(img.includes('dall-e-3'));
  });
}

// ============ 9.14 429 限流退避（不禁用 Key，临时跳过渠道） ============
{
  test('429 连续多次不禁用 Key（限流是临时的）', () => {
    const config = makeMockConfig();
    const p = config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4'] });
    const router = new Router(config, os.tmpdir());
    for (let i = 0; i < 5; i++) {
      router.recordFailure(p, 0, 'gpt-4', Object.assign(new Error('429'), { status: 429 }));
      router.handleKeyError(p, 0, 429);
    }
    assert.strictEqual(p.keyStats[0].disabled, false, '429 不应禁用 Key');
  });

  test('401 连续 3 次仍会禁用 Key（回归）', () => {
    const config = makeMockConfig();
    const p = config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4'] });
    const router = new Router(config, os.tmpdir());
    for (let i = 0; i < 3; i++) {
      router.recordFailure(p, 0, 'gpt-4', Object.assign(new Error('401'), { status: 401 }));
    }
    assert.strictEqual(router.handleKeyError(p, 0, 401), true, '401 连续 3 次应禁用');
  });

  test('429 触发限流退避：selectProviders 跳过，成功后解除', () => {
    const config = makeMockConfig();
    config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4'] });
    const router = new Router(config, os.tmpdir());
    const p = config.getProviders()[0];
    router.applyRateLimitBackoff(p);
    assert.ok(p.rateLimitedUntil > Date.now(), '应设置退避时间');
    assert.strictEqual(router.isRateLimited(p), true);
    assert.strictEqual(router.selectProviders('gpt-4').length, 0, '退避期间应跳过该渠道');
    // 成功 → 解除退避
    p.rateLimitedUntil = null;
    assert.strictEqual(router.selectProviders('gpt-4').length, 1);
    // 退避过期 → 自动恢复
    router.applyRateLimitBackoff(p);
    p.rateLimitedUntil = Date.now() - 1000;
    assert.strictEqual(router.isRateLimited(p), false, '退避过期应恢复');
    assert.strictEqual(router.selectProviders('gpt-4').length, 1);
  });

  test('限流退避时自动走其他渠道（A 限流 → B 成功）', async () => {
    const origFetch = global.fetch;
    const calls = [];
    global.fetch = async (url, opts) => {
      const body = JSON.parse(opts.body);
      calls.push(body.model);
      if (url.includes('a.example.com')) {
        return { ok: false, status: 429, text: async () => 'tpm exhausted', headers: {}, body: null };
      }
      return { ok: true, status: 200, headers: {}, body: null, json: async () => ({ id: 'x', choices: [{ message: { content: 'ok' } }], usage: null }) };
    };
    try {
      const config = makeMockConfig();
      config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4'], priority: 1 });
      config.addProvider({ name: 'B', baseUrl: 'https://b.example.com', keys: ['k1'], models: ['gpt-4'], priority: 2 });
      const router = new Router(config, os.tmpdir());
      const r1 = await router.routeWithFallback({ model: 'gpt-4', messages: [{ role: 'user', content: 'hi' }] });
      assert.strictEqual(r1.meta.provider, 'B', 'A 限流后应切到 B');
      // 第二次请求：A 仍在退避期 → 直接走 B（不再请求 A）
      const callsBefore = calls.length;
      const r2 = await router.routeWithFallback({ model: 'gpt-4', messages: [{ role: 'user', content: 'hi' }] });
      assert.strictEqual(r2.meta.provider, 'B');
      assert.ok(calls.length - callsBefore <= 1, '退避期内不应再请求 A');
    } finally {
      global.fetch = origFetch;
    }
  });
}

// ============ 9.15 提示自动修复（末尾非 user 消息补空 user） ============
{
  test('对话末尾非 user 时自动补空 user 消息发上游', async () => {
    const origFetch = global.fetch;
    let received = null;
    global.fetch = async (url, opts) => {
      received = JSON.parse(opts.body);
      return { ok: true, status: 200, headers: {}, body: null, json: async () => ({ id: 'x', choices: [{ message: { content: 'ok' } }], usage: null }) };
    };
    try {
      const config = makeMockConfig();
      config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4'] });
      const router = new Router(config, os.tmpdir());
      const messages = [
        { role: 'user', content: '帮我查天气' },
        { role: 'assistant', content: null, tool_calls: [{ id: 'c1', type: 'function', function: { name: 'search', arguments: '{}' } }] },
        { role: 'tool', tool_call_id: 'c1', content: '晴 25℃' }
      ];
      await router.routeWithFallback({ model: 'gpt-4', messages });
      const last = received.messages[received.messages.length - 1];
      assert.strictEqual(last.role, 'user', '末尾应为补上的 user 消息');
      assert.strictEqual(last.content, '', '补上的内容应为空（语义中性）');
      assert.strictEqual(received.messages.length, 4, '应新增一条');
      const logs = router.tracer.recent(5, {});
      assert.ok(logs.some(l => l.promptRepaired === true), 'Trace 应标记已修复');
    } finally {
      global.fetch = origFetch;
    }
  });

  test('末尾已是 user 消息时不修复；关闭开关时不修复', async () => {
    const origFetch = global.fetch;
    let received = null;
    global.fetch = async (url, opts) => {
      received = JSON.parse(opts.body);
      return { ok: true, status: 200, headers: {}, body: null, json: async () => ({ id: 'x', choices: [{ message: { content: 'ok' } }], usage: null }) };
    };
    try {
      const config = makeMockConfig();
      config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4'] });
      const router = new Router(config, os.tmpdir());
      await router.routeWithFallback({ model: 'gpt-4', messages: [{ role: 'user', content: '正常提问' }] });
      assert.strictEqual(received.messages.length, 1, '末尾是 user 不应修复');
      // 关闭开关
      config.set('routing.autoRepairPrompt', false);
      await router.routeWithFallback({ model: 'gpt-4', messages: [{ role: 'assistant', content: '只有助手消息' }] });
      assert.strictEqual(received.messages.length, 1, '关闭后不应修复');
    } finally {
      global.fetch = origFetch;
    }
  });
}

// ============ 9. 跨模型回退标记 / A/B 分流 / Key 阈值 ============
(async () => {
  let passedHere = 0;
  const testAsync = async (name, fn) => {
    try { await fn(); passedHere++; passed++; console.log(`  ok ${name}`); }
    catch (e) { console.log(`  FAIL ${name}: ${e.message}`); process.exitCode = 1; }
  };

  // 伪造 fetch：gpt-4 全部失败，gpt-4o-mini / gpt-3.5-turbo 成功
  const withFakeFetch = async (fn) => {
    const origFetch = global.fetch;
    global.fetch = async (url, opts) => {
      const body = JSON.parse(opts.body);
      if (body.model === 'gpt-4') {
        return { ok: false, status: 500, text: async () => 'upstream error', headers: {}, body: null };
      }
      return {
        ok: true, status: 200, headers: {}, body: null,
        json: async () => ({ id: 'x', choices: [{ message: { role: 'assistant', content: 'ok:' + body.model } }], usage: { total_tokens: 5 } })
      };
    };
    try { await fn(); }
    finally { global.fetch = origFetch; }
  };

  await testAsync('跨模型回退写入 switched 标记与响应元信息', () => withFakeFetch(async () => {
    const config = makeMockConfig({
      prices: { currency: 'USD', models: { 'gpt-4': { input: 30, output: 60 }, 'gpt-4o-mini': { input: 0.15, output: 0.6 } } }
    });
    config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4', 'gpt-4o-mini'] });
    const router = new Router(config, os.tmpdir());
    const result = await router.routeWithFallback({ model: 'gpt-4', messages: [{ role: 'user', content: 'hi' }] });
    assert.strictEqual(result.meta.switched, true, 'meta.switched 应为 true');
    assert.strictEqual(result.meta.model, 'gpt-4o-mini');
    assert.strictEqual(result.meta.requestedModel, 'gpt-4');
    const stats = router.getStats();
    assert.strictEqual(stats.recentRequests[0].switched, true, '统计应记录 switched');
  }));

  await testAsync('A/B 分流按权重选择分组模型', () => withFakeFetch(async () => {
    const config = makeMockConfig();
    config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4', 'gpt-4o-mini'] });
    config.set('routing.abTest', {
      enabled: true,
      groups: [{ name: 'main', model: 'gpt-4', weight: 0 }, { name: 'cheap', model: 'gpt-4o-mini', weight: 100 }]
    });
    const router = new Router(config, os.tmpdir());
    // stub Math.random 保证权重选择确定（r=50 → 必选 cheap）
    const origRandom = Math.random;
    Math.random = () => 0.5;
    try {
      const result = await router.routeWithFallback({ model: 'gpt-4', messages: [{ role: 'user', content: 'hi' }] });
      assert.strictEqual(result.meta.model, 'gpt-4o-mini', '权重 100 的分组应被选中');
      assert.strictEqual(result.meta.abGroup, 'cheap');
      assert.strictEqual(result.meta.switched, true);
      const stats = router.getStats();
      assert.strictEqual(stats.recentRequests[0].abGroup, 'cheap');
    } finally {
      Math.random = origRandom;
    }
  }));

  await testAsync('A/B 未启用时不影响正常路由', () => withFakeFetch(async () => {
    const config = makeMockConfig();
    config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4', 'gpt-4o-mini'] });
    const router = new Router(config, os.tmpdir());
    const result = await router.routeWithFallback({ model: 'gpt-4o-mini', messages: [{ role: 'user', content: 'hi' }] });
    assert.strictEqual(result.meta.model, 'gpt-4o-mini');
    assert.strictEqual(result.meta.switched, false);
    assert.strictEqual(result.meta.abGroup, null);
  }));

  await testAsync('Key 连续 3 次认证错误才禁用（阈值前不误伤）', async () => {
    const config = makeMockConfig();
    const p = config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4'] });
    const router = new Router(config, os.tmpdir());
    router.recordFailure(p, 0, 'gpt-4', Object.assign(new Error('401'), { status: 401 }));
    assert.strictEqual(router.handleKeyError(p, 0, 401), false, '第 1 次不应禁用');
    assert.strictEqual(p.keyStats[0].disabled, false);
    router.recordFailure(p, 0, 'gpt-4', Object.assign(new Error('401'), { status: 401 }));
    assert.strictEqual(router.handleKeyError(p, 0, 401), false, '第 2 次不应禁用');
    router.recordFailure(p, 0, 'gpt-4', Object.assign(new Error('401'), { status: 401 }));
    assert.strictEqual(router.handleKeyError(p, 0, 401), true, '第 3 次应禁用');
    assert.strictEqual(p.keyStats[0].disabled, true);
  });

  await testAsync('Key 成功一次后连续计数清零，不会误禁', async () => {
    const config = makeMockConfig();
    const p = config.addProvider({ name: 'A', baseUrl: 'https://a.example.com', keys: ['k1'], models: ['gpt-4'] });
    const router = new Router(config, os.tmpdir());
    router.recordFailure(p, 0, 'gpt-4', Object.assign(new Error('429'), { status: 429 }));
    router.recordFailure(p, 0, 'gpt-4', Object.assign(new Error('429'), { status: 429 }));
    router.recordSuccess(p, 0, 'gpt-4', { latency: 50, data: {}, usage: null });
    assert.strictEqual(p.keyStats[0].consecutiveErrors, 0, '成功后应清零');
    assert.strictEqual(router.handleKeyError(p, 0, 429), false);
    assert.strictEqual(p.keyStats[0].disabled, false);
  });

  console.log(`\n通过 ${passed} 项测试`);
  process.exit(process.exitCode || 0);
})();

console.log(`\n通过 ${passed} 项测试`);
