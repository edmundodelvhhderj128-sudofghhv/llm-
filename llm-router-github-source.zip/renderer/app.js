// ===== 全局状态 =====
const state = {
  currentPage: 'providers',
  config: null,
  healthStatus: {},
  stats: {},
  proxyStatus: {},
  editingProvider: null,
  currency: 'USD',
  smart: null
};

// 货币换算（与主进程一致）
const CNY_RATE = 7.2;

function fmtPrice(usd, currency) {
  const cur = currency || state.currency || 'USD';
  if (cur === 'CNY') {
    return '¥' + (usd * CNY_RATE).toFixed(2);
  }
  return '$' + usd.toFixed(4);
}

// ===== 工具函数 =====
function toast(message, type = 'info') {
  const container = document.getElementById('toastContainer');
  const el = document.createElement('div');
  el.className = `toast toast-${type}`;
  const icons = { success: '✓', error: '✕', info: 'ℹ' };
  el.innerHTML = `<span>${icons[type] || ''}</span><span>${message}</span>`;
  container.appendChild(el);
  setTimeout(() => {
    el.style.animation = 'slideIn 0.3s reverse';
    setTimeout(() => el.remove(), 300);
  }, 3000);
}

function maskKey(key) {
  if (!key || key.length < 12) return key || '';
  return key.substring(0, 8) + '****' + key.substring(key.length - 4);
}

function formatTime(iso) {
  if (!iso) return '--';
  const d = new Date(iso);
  return d.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text || '';
  return div.innerHTML;
}

// 属性值安全转义（含引号，用于 onclick / value 等属性上下文）
function escapeAttr(text) {
  return String(text || '')
    .replace(/&/g, '&amp;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

// 模型能力识别（与主进程 inferModelCapability 一致，用于 UI 标签）
function inferCapability(model) {
  const m = String(model || '').toLowerCase();
  if (/(image|dall-e|dalle|flux|sdxl|stable-diffusion|midjourney|kolors|seedream|janus|gpt-image|nano-banana|sensenova-u1|agnes-image|hunyuan-image|cogview|pixart|wanx|wan2|wan-2|doubao-seed)/.test(m)) return 'image';
  if (/(video|veo|sora|runway|kling|keling|hailuo|seedance|agnes-video|hunyuan-video|minimax-vl|skyreels)/.test(m)) return 'video';
  if (/(embed|text-embed|bge|mxbai|e5|m3$)/.test(m)) return 'embedding';
  return 'chat';
}

const CAPABILITY_TAGS = {
  chat: '<span class="key-tag" title="对话模型">💬 对话</span>',
  image: '<span class="key-tag" style="color: var(--yellow);" title="图片生成模型">🖼️ 图片</span>',
  video: '<span class="key-tag" style="color: var(--red);" title="视频生成模型">🎬 视频</span>',
  embedding: '<span class="key-tag" style="color: var(--blue-sky);" title="嵌入模型">🧲 嵌入</span>'
};

async function copyToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
    toast('已复制到剪贴板', 'success');
  } catch (e) {
    toast('复制失败', 'error');
  }
}

// ===== 导航 =====
function setupNavigation() {
  document.querySelectorAll('.nav-item').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      state.currentPage = btn.dataset.page;
      renderPage();
    });
  });

  document.getElementById('btnMinimize').addEventListener('click', () => api.minimizeWindow());
  document.getElementById('btnMaximize').addEventListener('click', () => api.maximizeWindow());
  document.getElementById('btnClose').addEventListener('click', () => api.closeWindow());
}

// ===== 页面渲染 =====
function renderPage() {
  const content = document.getElementById('content');
  const pages = {
    providers: renderProviders,
    models: renderModels,
    routing: renderRouting,
    health: renderHealth,
    test: renderTest,
    stats: renderStats,
    smart: renderSmart,
    memory: renderMemory,
    local: renderLocal,
    logs: renderLogs,
    settings: renderSettings
  };
  content.innerHTML = pages[state.currentPage]();
  attachPageHandlers();
}

// ===== 服务商页面 =====
function renderProviders() {
  const providers = state.config?.providers || [];

  if (providers.length === 0) {
    return `
      <div class="glass-card">
        <div class="stripe-title">🌐 服务商管理</div>
        <div class="empty-state">
          <div class="empty-state-icon">🌐</div>
          <div class="empty-state-text">还没有添加任何服务商<br>可以从 18 个内置预设渠道商中一键添加，或手动添加</div>
          <div style="display: flex; gap: 8px; justify-content: center; flex-wrap: wrap;">
            <button class="btn btn-primary" onclick="openPresetsModal()">📋 从预设添加</button>
            <button class="btn" onclick="openProviderModal()">+ 手动添加服务商</button>
          </div>
        </div>
      </div>
    `;
  }

  return `
    <div class="glass-card">
      <div class="stripe-title">🌐 服务商管理</div>
      <div style="display: flex; gap: 8px; margin-bottom: 16px; flex-wrap: wrap;">
        <button class="btn btn-primary" onclick="openProviderModal()">+ 添加服务商</button>
        <button class="btn btn-yellow" onclick="fetchAllModels()">⚡ 一键获取所有模型</button>
        <button class="btn" onclick="openPresetsModal()">📋 从预设添加</button>
      </div>
      ${providers.map(p => {
        const circuitOpen = p.circuit?.open;
        return `
        <div class="table-row" style="flex-wrap: wrap;">
          <div style="display: flex; align-items: center; gap: 12px; flex: 1; min-width: 200px;">
            <div class="health-icon ${p.enabled ? 'healthy' : 'unhealthy'}" style="width: 40px; height: 40px; font-size: 18px;">
              ${p.enabled ? '✓' : '✕'}
            </div>
            <div>
              <div style="font-size: 15px; font-weight: 600; color: var(--text-main);">${escapeHtml(p.name)}</div>
              <div style="font-size: 11px; color: rgba(31, 41, 55, 0.85); font-family: monospace;">${escapeHtml(p.baseUrl)}</div>
            </div>
          </div>
          <div style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">
            <span class="key-tag">🔑 ${p.keys.length} 个Key</span>
            <span class="key-tag">🤖 ${p.models.length} 个模型</span>
            <span class="badge ${p.enabled ? 'badge-healthy' : 'badge-disabled'}">${p.enabled ? '启用' : '禁用'}</span>
            ${circuitOpen ? '<span class="badge badge-circuit">⛔ 熔断中</span>' : ''}
            <button class="btn btn-sm" onclick="fetchModels('${p.id}')">获取模型</button>
            <button class="btn btn-sm" onclick="openProviderModal('${p.id}')">编辑</button>
            <button class="btn btn-sm btn-danger" onclick="removeProvider('${p.id}')">删除</button>
          </div>
        </div>
      `}).join('')}
    </div>
  `;
}

// ===== 模型页面 =====
function renderModels() {
  const providers = state.config?.providers || [];
  const allModels = new Map();

  for (const p of providers) {
    if (!p.enabled) continue;
    for (const m of p.models) {
      if (!allModels.has(m)) {
        allModels.set(m, []);
      }
      allModels.get(m).push(p);
    }
  }

  if (allModels.size === 0) {
    return `
      <div class="glass-card">
        <div class="stripe-title">🤖 模型列表</div>
        <div class="empty-state">
          <div class="empty-state-icon">🤖</div>
          <div class="empty-state-text">暂无模型<br>请在服务商页面添加服务商并获取模型</div>
        </div>
      </div>
    `;
  }

  const models = Array.from(allModels.entries()).sort();
  const priceModels = state.config?.prices?.models || {};

  return `
    <div class="glass-card">
      <div class="stripe-title">🤖 模型列表 (${models.length})</div>
      <div style="display: flex; gap: 8px; margin-bottom: 16px;">
        <input class="input" id="modelSearch" placeholder="搜索模型..." oninput="filterModels()" style="flex: 1;">
        <button class="btn btn-yellow" onclick="fetchAllModels()">⚡ 刷新所有模型</button>
      </div>
      <div id="modelList">
        ${models.map(([name, providers]) => {
          const price = priceModels[name];
          return `
          <div class="table-row model-row" data-name="${escapeAttr(name.toLowerCase())}">
            <div style="flex: 1;">
              <div style="font-size: 14px; font-weight: 500; color: var(--text-main); font-family: monospace;">${escapeHtml(name)} ${CAPABILITY_TAGS[inferCapability(name)] || ''}</div>
              <div style="font-size: 11px; color: rgba(31, 41, 55, 0.85); margin-top: 2px;">
                ${providers.map(p => `<span class="key-tag" style="margin-right: 4px;">${escapeHtml(p.name)}</span>`).join('')}
              </div>
            </div>
            ${price ? `<span class="key-tag" title="输入/输出价格（每百万 tokens）">💲 ${fmtPrice(price.input || 0, state.currency)} / ${fmtPrice(price.output || 0, state.currency)}</span>` : ''}
            <span class="badge badge-healthy">${providers.length} 个服务商</span>
            <button class="btn btn-sm" onclick="copyToClipboard('${escapeAttr(name)}')">复制</button>
          </div>
        `}).join('')}
      </div>
    </div>
  `;
}

function filterModels() {
  const q = document.getElementById('modelSearch').value.toLowerCase();
  document.querySelectorAll('.model-row').forEach(row => {
    row.style.display = row.dataset.name.includes(q) ? '' : 'none';
  });
}

// ===== 路由配置页面 =====
function renderRouting() {
  const r = state.config?.routing || {};
  const cb = r.circuitBreaker || {};
  const quota = r.quota || {};
  const cost = r.costOptimization || {};
  const ab = r.abTest || {};
  const providers = state.config?.providers || [];

  return `
    <div class="glass-card">
      <div class="stripe-title">🛤️ 路由配置</div>
      <div class="form-group">
        <label class="label">路由策略</label>
        <select class="select" id="routingStrategy">
          <option value="auto" ${r.strategy === 'auto' ? 'selected' : ''}>智能自动 ⭐（零配置：记住成功渠道+加权优选）</option>
          <option value="priority" ${r.strategy === 'priority' ? 'selected' : ''}>优先级（按服务商优先级顺序）</option>
          <option value="weighted" ${r.strategy === 'weighted' ? 'selected' : ''}>加权 ⭐（按延迟+成功率动态优选）</option>
          <option value="round-robin" ${r.strategy === 'round-robin' ? 'selected' : ''}>轮询（服务商/Key 轮换使用）</option>
          <option value="random" ${r.strategy === 'random' ? 'selected' : ''}>随机（完全随机选择）</option>
          <option value="strict-random" ${r.strategy === 'strict-random' ? 'selected' : ''}>严格随机（不受记忆偏好影响）</option>
          <option value="p2c" ${r.strategy === 'p2c' ? 'selected' : ''}>二选一 p2c（随机取 2 个选更优，负载均衡）</option>
          <option value="least-used" ${r.strategy === 'least-used' ? 'selected' : ''}>最少使用（优先用请求量少的渠道）</option>
          <option value="cost-optimized" ${r.strategy === 'cost-optimized' ? 'selected' : ''}>成本优先（按单次估算成本升序）</option>
          <option value="reset-aware" ${r.strategy === 'reset-aware' ? 'selected' : ''}>配额余量（剩余配额多的优先）</option>
        </select>
        <p style="color: rgba(31, 41, 55, 0.85); font-size: 12px; margin-top: 4px;">共 10 种策略（v3.0.2 借鉴 OmniRoute 19 策略中的主流：lkgp 记忆已内置于加权/优先级/智能自动）</p>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="label">最大重试次数</label>
          <input class="input" type="number" id="maxRetries" value="${r.maxRetries || 3}" min="1" max="10">
        </div>
        <div class="form-group">
          <label class="label">请求超时（秒）</label>
          <input class="input" type="number" id="timeout" value="${(r.timeout || 30000) / 1000}" min="5" max="300">
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="label">健康检测间隔（分钟）</label>
          <input class="input" type="number" id="healthInterval" value="${r.healthCheckInterval || 5}" min="1" max="60">
        </div>
        <div class="form-group">
          <label class="label">自动故障切换</label>
          <div style="padding-top: 8px;">
            <div class="toggle ${r.failover !== false ? 'active' : ''}" id="failoverToggle" onclick="this.classList.toggle('active')">
              <div class="toggle-knob"></div>
            </div>
          </div>
        </div>
      </div>
      <div class="toggle-row">
        <div>
          跨模型回退 <span class="hint">目标模型全败时自动回退到其他可用模型</span>
        </div>
        <div class="toggle ${r.fallback !== false ? 'active' : ''}" id="fallbackToggle" onclick="this.classList.toggle('active')">
          <div class="toggle-knob"></div>
        </div>
      </div>
      <div class="divider"></div>
      <div class="section-title">⛔ 熔断保护</div>
      <div class="toggle-row">
        <div>
          启用熔断 <span class="hint">连续失败 N 次后自动熔断，防止雪崩</span>
        </div>
        <div class="toggle ${cb.enabled ? 'active' : ''}" id="cbEnabled" onclick="this.classList.toggle('active')">
          <div class="toggle-knob"></div>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="label">熔断阈值（连续失败次数）</label>
          <input class="input" type="number" id="cbThreshold" value="${cb.threshold || 5}" min="1" max="50">
        </div>
        <div class="form-group">
          <label class="label">熔断冷却（秒）</label>
          <input class="input" type="number" id="cbCooldown" value="${Math.round((cb.cooldownMs || 60000) / 1000)}" min="5" max="3600">
        </div>
      </div>
      <div class="divider"></div>
      <div class="section-title">💰 配额管理</div>
      <div class="toggle-row">
        <div>
          启用配额 <span class="hint">限制各服务商周期调用量</span>
        </div>
        <div class="toggle ${quota.enabled ? 'active' : ''}" id="quotaEnabled" onclick="this.classList.toggle('active')">
          <div class="toggle-knob"></div>
        </div>
      </div>
      <div class="form-group">
        <label class="label">配额周期</label>
        <select class="select" id="quotaPeriod" style="max-width: 200px;">
          <option value="hour" ${quota.period === 'hour' ? 'selected' : ''}>每小时</option>
          <option value="day" ${!quota.period || quota.period === 'day' ? 'selected' : ''}>每天</option>
          <option value="week" ${quota.period === 'week' ? 'selected' : ''}>每周</option>
          <option value="month" ${quota.period === 'month' ? 'selected' : ''}>每月</option>
        </select>
      </div>
      <div id="quotaLimitsBox">
        ${providers.length > 0 ? `
          <div class="section-title" style="margin-top: 4px;">各服务商限额（0 = 不限）</div>
          ${providers.map(p => {
            const limit = quota.limits?.[p.id] || {};
            return `
            <div class="table-row" style="padding: 8px 0;">
              <div style="flex: 1; color: var(--text-main); font-size: 13px;">${escapeHtml(p.name)}</div>
              <div style="display: flex; gap: 8px; align-items: center;">
                <span style="font-size: 11px; color: rgba(31, 41, 55, 0.88);">请求数</span>
                <input class="input-sm" type="number" min="0" data-quota-provider="${p.id}" data-quota-type="requests" value="${limit.requests || 0}">
                <span style="font-size: 11px; color: rgba(31, 41, 55, 0.88);">Tokens(百万)</span>
                <input class="input-sm" type="number" min="0" step="0.1" data-quota-provider="${p.id}" data-quota-type="tokens" value="${limit.tokens ? limit.tokens / 1000000 : 0}">
              </div>
            </div>`;
          }).join('')}
        ` : '<p style="color: rgba(31, 41, 55, 0.85); font-size: 12px;">暂无服务商</p>'}
      </div>
      <div class="divider"></div>
      <div class="section-title">💡 成本优化</div>
      <div class="toggle-row">
        <div>
          启用成本优化 <span class="hint">跨模型回退时按性价比选模型</span>
        </div>
        <div class="toggle ${cost.enabled ? 'active' : ''}" id="costEnabled" onclick="this.classList.toggle('active')">
          <div class="toggle-knob"></div>
        </div>
      </div>
      <div class="toggle-row">
        <div>
          优先最便宜模型 <span class="hint">关闭则优先最贵（质量优先）</span>
        </div>
        <div class="toggle ${cost.preferCheapest !== false ? 'active' : ''}" id="costPreferCheapest" onclick="this.classList.toggle('active')">
          <div class="toggle-knob"></div>
        </div>
      </div>
      <div class="divider"></div>
      <div class="section-title">🧪 A/B 测试</div>
      <div class="toggle-row">
        <div>
          启用 A/B 测试 <span class="hint">分流对比不同模型效果，自动生成报告</span>
        </div>
        <div class="toggle ${ab.enabled ? 'active' : ''}" id="abEnabled" onclick="this.classList.toggle('active')">
          <div class="toggle-knob"></div>
        </div>
      </div>
      <div class="form-group">
        <label class="label">分组配置（每行一个，格式：分组名=模型:权重）</label>
        <textarea class="textarea" id="abGroups" placeholder="主力=gpt-4o:50&#10;备用=claude-3-5-sonnet:30&#10;经济=deepseek-chat:20" style="min-height: 80px; font-family: monospace;">${(ab.groups || []).map(g => `${g.name}=${g.model}:${g.weight || 100}`).join('\n')}</textarea>
      </div>
      <div class="divider"></div>
      <div style="display: flex; gap: 8px;">
        <button class="btn btn-primary" onclick="saveRouting()">💾 保存配置</button>
        <button class="btn" onclick="runHealthCheckNow()">💓 立即检测</button>
      </div>
    </div>

    <div class="glass-card" style="margin-top: 16px;">
      <div class="stripe-title">📋 服务商优先级</div>
      <p style="color: rgba(31, 41, 55, 0.88); font-size: 12px; margin-bottom: 12px;">拖动行可调整优先级顺序（数字越小优先级越高）</p>
      ${(state.config?.providers || []).map((p, i) => `
        <div class="table-row">
          <span style="font-size: 20px; color: var(--yellow); font-weight: 700;">${i + 1}</span>
          <div style="flex: 1;">
            <div style="color: var(--text-main); font-weight: 500;">${escapeHtml(p.name)}</div>
            <div style="font-size: 11px; color: rgba(31, 41, 55, 0.85);">${p.models.length} 个模型 · ${p.keys.length} 个Key ${p.weights?.latencyMs ? `· 均延迟 ${p.weights.latencyMs}ms` : ''} ${p.weights?.successRate != null && p.weights?.successRate < 1 ? `· 成功率 ${(p.weights.successRate * 100).toFixed(0)}%` : ''}</div>
          </div>
          ${i > 0 ? `<button class="btn btn-sm" onclick="moveProvider('${p.id}', -1)">↑ 上移</button>` : ''}
          ${i < (state.config?.providers || []).length - 1 ? `<button class="btn btn-sm" onclick="moveProvider('${p.id}', 1)">↓ 下移</button>` : ''}
        </div>
      `).join('') || '<div class="empty-state-text">暂无服务商</div>'}
    </div>
  `;
}

// ===== 健康检测页面 =====
function renderHealth() {
  const statuses = Object.entries(state.healthStatus || {});
  const providers = state.config?.providers || [];

  if (providers.length === 0) {
    return `
      <div class="glass-card">
        <div class="stripe-title">💓 健康检测</div>
        <div class="empty-state">
          <div class="empty-state-icon">💓</div>
          <div class="empty-state-text">暂无服务商数据</div>
        </div>
      </div>
    `;
  }

  return `
    <div class="glass-card">
      <div class="stripe-title">💓 健康检测</div>
      <div style="display: flex; gap: 8px; margin-bottom: 16px;">
        <button class="btn btn-primary" onclick="runHealthCheckNow()">
          <span id="healthCheckSpinner"></span> 立即检测全部
        </button>
      </div>

      ${providers.map(p => {
        const status = state.healthStatus[p.id] || {};
        const keyStatus = status.keyStatus || [];
        return `
          <div class="health-card">
            <div class="health-icon ${status.healthy ? 'healthy' : 'unhealthy'}">
              ${status.healthy ? '✓' : '✕'}
            </div>
            <div class="health-info">
              <div class="health-name">${escapeHtml(p.name)}</div>
              <div class="health-detail">
                ${escapeHtml(p.baseUrl)} ·
                最后检测: ${formatTime(status.lastCheck)} ·
                ${status.error ? `<span style="color: var(--red);">${escapeHtml(status.error)}</span>` : '正常'}
              </div>
              ${keyStatus.length > 0 ? `
                <div style="margin-top: 8px; display: flex; gap: 6px; flex-wrap: wrap;">
                  ${keyStatus.map(k => `
                    <span class="badge ${k.disabled ? 'badge-disabled' : k.healthy ? 'badge-healthy' : 'badge-unhealthy'}">
                      Key ${k.index + 1}: ${k.disabled ? '已禁用' : k.healthy ? '正常' : escapeHtml(k.error || '异常')}
                      ${k.latency ? ` (${k.latency}ms)` : ''}
                      ${k.recovered ? ' ↺ 已自动恢复' : ''}
                    </span>
                  `).join('')}
                </div>
              ` : ''}
              ${status.modelStatus && status.modelStatus.length > 0 ? `
                <div style="margin-top: 6px; font-size: 11px; color: rgba(31, 41, 55, 0.88);">
                  模型可用性: ${status.modelStatus.filter(m => m.available).length}/${status.modelStatus.length} 可用
                  ${status.modelStatus.filter(m => !m.available).map(m => `<span style="color: var(--red);">${escapeHtml(m.name)}</span>`).join(', ')}
                </div>
              ` : ''}
            </div>
            <div class="health-latency">
              ${status.latency ? `${status.latency}ms` : '--'}
              <div style="font-size: 11px; color: rgba(31, 41, 55, 0.85); margin-top: 2px;">延迟</div>
            </div>
            <button class="btn btn-sm" onclick="checkSingleProvider('${p.id}')">检测</button>
          </div>
        `;
      }).join('')}
    </div>
  `;
}

// ===== 测试控制台 =====
function renderTest() {
  const models = (state.config?.providers || [])
    .filter(p => p.enabled)
    .flatMap(p => p.models);
  const uniqueModels = [...new Set(models)].sort();

  return `
    <div class="glass-card" style="height: calc(100vh - 130px); display: flex; flex-direction: column;">
      <div class="stripe-title">🧪 测试控制台（多模态）</div>
      <div style="display: flex; gap: 12px; margin-bottom: 12px; align-items: center; flex-wrap: wrap;">
        <select class="select" id="testMode" style="max-width: 130px;" onchange="onTestModeChange()">
          <option value="chat">💬 对话</option>
          <option value="image">🖼️ 图片生成</option>
          <option value="video">🎬 视频生成</option>
        </select>
        <select class="select" id="testModel" style="max-width: 300px;">
          <option value="">选择模型...</option>
          ${uniqueModels.map(m => `<option value="${escapeAttr(m)}">${escapeHtml(m)}</option>`).join('')}
        </select>
        <button class="btn btn-primary" onclick="sendTestMessage()" id="testSendBtn">发送</button>
        <button class="btn btn-danger btn-sm" onclick="clearChat()">清空</button>
        <label style="color: rgba(31, 41, 55, 0.92); font-size: 12px; display: flex; align-items: center; gap: 4px;" id="testStreamLabel">
          <input type="checkbox" id="testStream" checked> 流式输出
        </label>
        <span id="testModeHint" style="font-size: 11px; color: rgba(31, 41, 55, 0.75);">图片/视频：选择对应能力的模型，自动智能调度</span>
      </div>
      <div class="chat-messages" id="chatMessages">
        <div class="chat-msg system">选择模型并发送消息进行测试。请求将通过智能路由转发（含熔断/配额/回退）。</div>
      </div>
      <div class="chat-input-area">
        <input class="input" id="chatInput" placeholder="输入提示词..." onkeypress="if(event.key==='Enter')sendTestMessage()" autofocus>
        <button class="btn btn-primary" onclick="sendTestMessage()" id="testSendBtn2">发送</button>
      </div>
    </div>
  `;
}

function onTestModeChange() {
  const mode = document.getElementById('testMode')?.value || 'chat';
  const streamLabel = document.getElementById('testStreamLabel');
  const hint = document.getElementById('testModeHint');
  const input = document.getElementById('chatInput');
  if (streamLabel) streamLabel.style.display = mode === 'chat' ? '' : 'none';
  if (hint) {
    hint.textContent = mode === 'image'
      ? '图片：选择图片模型（如 dall-e-3 / agnes-image），未找到精确模型时自动选用其他图片模型'
      : mode === 'video'
        ? '视频：选择视频模型（如 agnes-video-2.5 / hailuo），提交后自动轮询任务状态'
        : '图片/视频：选择对应能力的模型，自动智能调度';
  }
  if (input) input.placeholder = mode === 'chat' ? '输入消息...' : '输入生成提示词...';
}

// ===== 统计页面 =====
function renderStats() {
  const s = state.stats || {};
  const total = s.totalRequests || 0;
  const success = s.successCount || 0;
  const fail = s.failCount || 0;
  const successRate = total > 0 ? ((success / total) * 100).toFixed(1) : 0;

  const providerStats = s.providers || [];
  const recent = s.recentRequests || [];
  const modelStats = Object.entries(s.modelStats || {});
  const quota = s.quota || { enabled: false };
  const ab = s.abTest || { enabled: false, groups: [] };
  const cache = s.cache || { hits: 0, misses: 0, hitRate: 0, entries: 0 };
  const cacheTotal = (cache.hits || 0) + (cache.misses || 0);
  const drift = s.drift || { active: false, items: [] };
  const driftActive = drift.active;
  const driftItems = drift.items || [];

  return `
    ${driftActive ? `
    <div class="glass-card" style="margin-bottom: 12px; border-color: var(--red);">
      <div class="stripe-title" style="color: var(--red);">⚠️ 质量漂移告警</div>
      ${driftItems.map(d => `<div style="font-size: 13px; margin-bottom: 4px;"><b>${escapeHtml(d.provider)}</b> 质量分 ${d.baseline} → ${d.recent}（下降 ${d.drop} 分）</div>`).join('')}
    </div>` : ''}

    <div class="stat-grid">
      <div class="stat-card">
        <div class="stat-icon">📊</div>
        <div class="stat-value">${total}</div>
        <div class="stat-label">总请求数</div>
      </div>
      <div class="stat-card">
        <div class="stat-icon">✓</div>
        <div class="stat-value" style="color: var(--green);">${success}</div>
        <div class="stat-label">成功请求</div>
      </div>
      <div class="stat-card">
        <div class="stat-icon">✕</div>
        <div class="stat-value" style="color: var(--red);">${fail}</div>
        <div class="stat-label">失败请求</div>
      </div>
      <div class="stat-card">
        <div class="stat-icon">%</div>
        <div class="stat-value" style="color: var(--yellow);">${successRate}%</div>
        <div class="stat-label">成功率</div>
        <div class="progress-bar">
          <div class="progress-fill ${successRate > 80 ? 'green' : successRate > 50 ? 'yellow' : 'red'}" style="width: ${successRate}%"></div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon">💾</div>
        <div class="stat-value" style="color: var(--blue-sky);">${cacheTotal > 0 ? cache.hitRate + '%' : '--'}</div>
        <div class="stat-label">缓存命中率（${cache.hits || 0} 次命中）</div>
        <div class="progress-bar">
          <div class="progress-fill blue" style="width: ${cacheTotal > 0 ? cache.hitRate : 0}%"></div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon">💲</div>
        <div class="stat-value" style="color: var(--green);">${fmtPrice(s.totalCost || 0, state.currency)}</div>
        <div class="stat-label">预估总成本（按计费方式累计）</div>
      </div>
    </div>

    <div class="glass-card" style="margin-bottom: 16px;">
      <div class="stripe-title">📈 服务商统计</div>
      ${providerStats.length > 0 ? providerStats.map(p => {
        const total = (p.requests || 0);
        const rate = total > 0 ? ((p.success / total) * 100).toFixed(0) : 0;
        const billingTag = p.billing?.mode === 'count'
          ? `<span class="key-tag" title="按次数计费 ${fmtPrice(p.billing.pricePerCall || 0, state.currency)}/次">🔢 按次数</span>`
          : '<span class="key-tag" title="按 Tokens 计费（价格表见设置页）">🔤 按Tokens</span>';
        return `
          <div class="table-row">
            <div style="flex: 1;">
              <div style="color: var(--text-main); font-weight: 500;">${escapeHtml(p.name)} ${p.circuitOpen ? '<span class="badge badge-circuit">熔断中</span>' : ''}</div>
              <div style="font-size: 11px; color: rgba(31, 41, 55, 0.85);">
                ${p.keyCount} 个Key · ${p.modelCount} 个模型 ${p.latency ? `· 均延迟 ${p.latency}ms` : ''} ${billingTag}
              </div>
            </div>
            <div style="text-align: center; min-width: 80px;">
              <div style="color: var(--text-main); font-weight: 600;">${total}</div>
              <div style="font-size: 10px; color: rgba(31, 41, 55, 0.85);">请求</div>
            </div>
            <div style="text-align: center; min-width: 80px;">
              <div style="color: var(--green); font-weight: 600;">${p.success || 0}</div>
              <div style="font-size: 10px; color: rgba(31, 41, 55, 0.85);">成功</div>
            </div>
            <div style="text-align: center; min-width: 80px;">
              <div style="color: var(--red); font-weight: 600;">${p.fail || 0}</div>
              <div style="font-size: 10px; color: rgba(31, 41, 55, 0.85);">失败</div>
            </div>
            <div style="text-align: center; min-width: 100px;">
              <div style="color: var(--green); font-weight: 700;">${fmtPrice(p.cost || 0, state.currency)}</div>
              <div style="font-size: 10px; color: rgba(31, 41, 55, 0.85);">费用</div>
            </div>
            <div style="min-width: 120px;">
              <div style="font-size: 12px; color: var(--yellow);">${rate}%</div>
              <div class="progress-bar" style="width: 100px;">
                <div class="progress-fill ${rate > 80 ? 'green' : rate > 50 ? 'yellow' : 'red'}" style="width: ${rate}%"></div>
              </div>
            </div>
          </div>
        `;
      }).join('') : '<div class="empty-state-text">暂无统计数据</div>'}
    </div>

    ${quota.enabled ? `
    <div class="glass-card" style="margin-bottom: 16px;">
      <div class="stripe-title">💰 配额用量（${quota.period || 'day'} · ${escapeHtml(quota.periodKey || '')}）</div>
      ${quota.providers.length > 0 ? quota.providers.map(p => {
        const reqPct = p.requestLimit > 0 ? Math.min(100, Math.round(p.requests / p.requestLimit * 100)) : 0;
        const tokPct = p.tokenLimit > 0 ? Math.min(100, Math.round(p.tokens / p.tokenLimit * 100)) : 0;
        return `
          <div style="padding: 8px 0;">
            <div style="color: var(--text-main); font-size: 13px; margin-bottom: 4px;">${escapeHtml(p.name)}</div>
            ${p.requestLimit > 0 ? `
              <div class="quota-bar">
                <span style="min-width: 48px;">请求</span>
                <div class="quota-track"><div class="quota-fill ${reqPct > 80 ? 'warn' : ''}" style="width: ${reqPct}%"></div></div>
                <span>${p.requests}/${p.requestLimit}</span>
              </div>` : ''}
            ${p.tokenLimit > 0 ? `
              <div class="quota-bar">
                <span style="min-width: 48px;">Tokens</span>
                <div class="quota-track"><div class="quota-fill ${tokPct > 80 ? 'warn' : ''}" style="width: ${tokPct}%"></div></div>
                <span>${(p.tokens / 1000000).toFixed(2)}M/${p.tokenLimit / 1000000}M</span>
              </div>` : ''}
          </div>
        `;
      }).join('') : '<div class="empty-state-text">暂无配额数据</div>'}
    </div>
    ` : ''}

    ${modelStats.length > 0 ? `
    <div class="glass-card" style="margin-bottom: 16px;">
      <div class="stripe-title">🤖 模型调用统计</div>
      ${modelStats.sort((a, b) => (b[1].requests || 0) - (a[1].requests || 0)).map(([name, ms]) => {
        const rate = ms.requests > 0 ? ((ms.success / ms.requests) * 100).toFixed(0) : 0;
        return `
          <div class="table-row">
            <div style="flex: 1; font-family: monospace; font-size: 13px; color: var(--text-main);">${escapeHtml(name)}</div>
            <div style="min-width: 70px; text-align: center; color: var(--text-main);">${ms.requests || 0} 次</div>
            <div style="min-width: 70px; text-align: center; color: var(--green);">${ms.success || 0} ✓</div>
            <div style="min-width: 70px; text-align: center; color: var(--red);">${ms.fail || 0} ✕</div>
            ${ms.tokens ? `<div style="min-width: 90px; text-align: center; color: rgba(31, 41, 55, 0.88);">${(ms.tokens / 1000).toFixed(1)}k tokens</div>` : ''}
            <div style="min-width: 90px; text-align: center; color: var(--green); font-weight: 600;">${fmtPrice(ms.cost || 0, state.currency)}</div>
            <div style="min-width: 80px; text-align: center; color: var(--yellow);">${rate}%</div>
          </div>
        `;
      }).join('')}
    </div>
    ` : ''}

    ${ab.enabled && ab.groups.length > 0 ? `
    <div class="glass-card" style="margin-bottom: 16px;">
      <div class="stripe-title">🧪 A/B 测试报告</div>
      <p style="color: rgba(31, 41, 55, 0.88); font-size: 12px; margin-bottom: 12px;">分流权重: ${ab.groups.map(g => `${escapeHtml(g.name)} ${g.weight}%`).join(' · ')}</p>
      ${ab.groups.map(g => `
        <div class="ab-card">
          <div class="ab-head">
            <div>
              <span class="ab-name">${escapeHtml(g.name)}</span>
              <span class="ab-model">${escapeHtml(g.model)}</span>
            </div>
            <span class="badge badge-healthy">权重 ${g.weight || 100}%</span>
          </div>
          <div class="ab-stats">
            <span>请求 <span class="v">${g.requests}</span></span>
            <span>成功 <span class="v green">${g.success}</span></span>
            <span>失败 <span class="v red">${g.fail}</span></span>
            <span>成功率 <span class="v ${g.successRate >= 80 ? 'green' : g.successRate >= 50 ? 'yellow' : 'red'}">${g.successRate}%</span></span>
            ${g.estCost != null ? `<span>成本 <span class="v yellow">${fmtPrice(g.estCost, state.currency)}</span></span>` : ''}
            ${g.tokens ? `<span>Tokens <span class="v">${(g.tokens / 1000).toFixed(1)}k</span></span>` : ''}
          </div>
        </div>
      `).join('')}
    </div>
    ` : ''}

    <div class="glass-card">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
        <div class="stripe-title" style="margin-bottom: 0;">📝 最近请求</div>
        <button class="btn btn-sm btn-danger" onclick="resetStats()">重置统计</button>
      </div>
      ${recent.length > 0 ? recent.map(r => `
        <div class="log-entry">
          <span class="log-time">${formatTime(r.time)}</span>
          <span class="log-status ${r.status}">${r.status === 'success' ? '✓' : '✕'} ${r.status}</span>
          <span style="color: rgba(31, 41, 55, 0.95);">${escapeHtml(r.model || '--')}</span>
          ${r.provider ? `<span style="color: var(--blue-sky);">→ ${escapeHtml(r.provider)}</span>` : ''}
          ${r.switched ? '<span class="badge badge-switched">⚡ 已切换</span>' : ''}
          ${r.cached ? '<span class="badge badge-healthy">💾 缓存</span>' : ''}
          ${r.abGroup ? `<span class="badge badge-warning">A/B: ${escapeHtml(r.abGroup)}</span>` : ''}
          ${r.latency ? `<span style="color: var(--yellow);">${r.latency}ms</span>` : ''}
          ${r.error ? `<span style="color: var(--red);">${escapeHtml(r.error)}</span>` : ''}
        </div>
      `).join('') : '<div class="empty-state-text">暂无请求记录</div>'}
    </div>
  `;
}

// ===== 设置页面 =====
function renderSettings() {
  const port = state.config?.proxyPort || 3456;
  const currency = state.config?.currency || 'USD';
  const autoStart = state.config?.autoStart;
  const trayMinimize = state.config?.trayMinimize !== false;
  // 价格表：只显示已添加渠道服务商的模型（内置默认价格不显示，但仍保留用于成本计算）
  const priceConfig = state.config?.prices || {};
  const removedSet = new Set(priceConfig.removed || []);
  const priceMap = new Map(Object.entries(priceConfig.models || {}));
  const providerModels = new Set();
  for (const p of state.config?.providers || []) {
    for (const m of p.models || []) providerModels.add(m);
  }
  const priceModels = [];
  for (const m of providerModels) {
    if (removedSet.has(m)) continue;
    priceModels.push([m, priceMap.get(m) || { input: 0, output: 0 }]);
  }
  priceModels.sort((a, b) => a[0].localeCompare(b[0]));

  return `
    <div class="glass-card">
      <div class="stripe-title">⚙️ 设置</div>

      <div class="section-title">🌐 代理服务器</div>
      <div class="form-group">
        <label class="label">代理服务器端口</label>
        <div style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">
          <input class="input" type="number" id="proxyPort" value="${port}" min="1024" max="65535" style="max-width: 120px;">
          <button class="btn btn-primary" onclick="changeProxyPort()">应用</button>
          <button class="btn" onclick="restartProxy()">重启代理</button>
        </div>
        <p style="color: rgba(31, 41, 55, 0.85); font-size: 12px; margin-top: 4px;">
          代理地址: <span style="font-family: monospace; color: var(--red); font-weight: 700;" id="proxyUrlDisplay">http://localhost:${port}</span>
        </p>
      </div>

      <div class="divider"></div>

      <div class="section-title">🚀 系统</div>
      <div class="toggle-row">
        <div>
          开机自启 <span class="hint">系统启动时自动运行本应用</span>
        </div>
        <div class="toggle ${autoStart ? 'active' : ''}" id="autoStartToggle" onclick="toggleAutoStart()">
          <div class="toggle-knob"></div>
        </div>
      </div>
      <div class="toggle-row">
        <div>
          最小化到托盘 <span class="hint">点击最小化隐藏到系统托盘，双击托盘恢复</span>
        </div>
        <div class="toggle ${trayMinimize ? 'active' : ''}" id="trayToggle" onclick="toggleTrayMinimize()">
          <div class="toggle-knob"></div>
        </div>
      </div>
      <div class="toggle-row">
        <div>
          强制保活 <span class="hint">每 30 秒检查窗口和代理状态，异常自动恢复</span>
        </div>
        <div class="toggle active" style="pointer-events: none; opacity: 0.6;">
          <div class="toggle-knob"></div>
        </div>
      </div>

      <div class="divider"></div>

      <div class="section-title">💾 内存缓存（降低成本）</div>
      <div class="toggle-row">
        <div>
          启用缓存 <span class="hint">相同请求直接返回内存缓存，不重复调用上游（默认 1GB 空间）</span>
        </div>
        <div class="toggle active" id="cacheEnabledToggle" onclick="this.classList.toggle('active')">
          <div class="toggle-knob"></div>
        </div>
      </div>
      <div class="toggle-row">
        <div>
          缓存流式请求 <span class="hint">流式完成后自动回写缓存，命中时直接重放 SSE</span>
        </div>
        <div class="toggle active" id="cacheStreamToggle" onclick="this.classList.toggle('active')">
          <div class="toggle-knob"></div>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="label">缓存上限（MB，默认 1024）</label>
          <input class="input" type="number" id="cacheMaxMB" value="1024" min="16" max="8192">
        </div>
        <div class="form-group" style="display: flex; align-items: flex-end; gap: 8px;">
          <button class="btn btn-primary" onclick="saveCacheSettings()">💾 应用</button>
          <button class="btn btn-danger" onclick="clearCacheNow()">清空缓存</button>
        </div>
      </div>
      <div id="cacheStatsBox" style="background: rgba(15,23,42,0.05); padding: 12px 14px; border-radius: 8px; font-size: 12px; border: 1px solid rgba(15,23,42,0.15); line-height: 1.9; color: rgba(31, 41, 55, 0.92);">
        加载中...
      </div>

      <div class="divider"></div>

      <div class="section-title">📊 数据与日志（v3.0.2 长期运行自清理）</div>
      <p style="font-size: 12px; color: rgba(31, 41, 55, 0.85); margin-bottom: 8px;">
        Trace 日志按天分文件、超过保留天数自动删除；记忆/统计有结构上限；本地模型 4.4GB 固定不增长；
        应用启动时自动清理 blob 残留与超大下载日志。下方可查看当前占用并手动清理。
      </p>
      <div class="form-row">
        <div class="form-group">
          <label class="label">Trace 日志保留天数（默认 7）</label>
          <div style="display: flex; gap: 8px; align-items: center;">
            <input class="input" type="number" id="logDays" value="${state.config?.logging?.days ?? 7}" min="1" max="90" style="max-width: 100px;">
            <button class="btn btn-primary" onclick="saveLogDays()">保存</button>
          </div>
        </div>
        <div class="form-group" style="display: flex; align-items: flex-end; gap: 8px;">
          <button class="btn" onclick="cleanupDataNow()">🧹 立即清理临时文件</button>
          <button class="btn" onclick="clearAllLogsNow()">清空全部日志</button>
          <button class="btn" onclick="clearMemoryNow()">清空记忆</button>
        </div>
      </div>
      <div id="dataUsageBox" style="background: rgba(15,23,42,0.05); padding: 12px 14px; border-radius: 8px; font-size: 12px; border: 1px solid rgba(15,23,42,0.15); line-height: 1.9; color: rgba(31, 41, 55, 0.92);">
        加载中...
      </div>

      <div class="divider"></div>

      <div class="section-title">🌐 远程访问与迁移（v3.0.2）</div>
      <p style="font-size: 12px; color: rgba(31, 41, 55, 0.85); margin-bottom: 8px;">
        在云服务器/公网机器上启用后，可用<b>域名绑定 IP + Nginx 反代 + 自动续期证书</b>访问；
        其他电脑新装本软件后，输入 IP/域名+端口+账号密码，即可<b>一键迁移全部配置（渠道及 Key）</b>。
      </p>
      <div id="remoteBox" style="background: rgba(15,23,42,0.05); padding: 12px 14px; border-radius: 8px; font-size: 13px; border: 1px solid rgba(15,23,42,0.15); line-height: 2;">
        加载中...
      </div>

      <div class="divider"></div>

      <div class="section-title">💲 价格管理</div>
      <div class="form-group">
        <label class="label">显示货币</label>
        <div style="display: flex; gap: 8px; align-items: center;">
          <select class="select" id="currencySelect" style="max-width: 140px;">
            <option value="USD" ${currency === 'USD' ? 'selected' : ''}>USD $</option>
            <option value="CNY" ${currency === 'CNY' ? 'selected' : ''}>CNY ¥</option>
          </select>
          <button class="btn btn-yellow" onclick="changeCurrency()">切换</button>
          <button class="btn" onclick="syncPrices()">🔄 一键同步价格</button>
        </div>
        <p style="color: rgba(31, 41, 55, 0.85); font-size: 11px; margin-top: 4px;">价格单位: 每百万 tokens（输入/输出）。同步会用内置参考价补齐缺失模型，可再手动微调。</p>
      </div>
      <div class="form-group">
        <label class="label">渠道模型价格表（仅显示已添加服务商的模型，每百万 tokens）</label>
        <p style="color: rgba(31, 41, 55, 0.85); font-size: 12px; margin-bottom: 6px;">内置默认价格不在此显示，但仍用于成本计算；渠道模型的默认参考价可直接在此微调。</p>
        <div style="max-height: 260px; overflow-y: auto; background: rgba(15,23,42,0.04); border-radius: 8px; padding: 8px; border: 1px solid rgba(15,23,42,0.15);">
          <table class="price-table">
            <thead>
              <tr>
                <th>模型</th>
                <th>输入价格</th>
                <th>输出价格</th>
                <th style="width: 90px;"></th>
              </tr>
            </thead>
            <tbody>
              ${priceModels.length === 0 ? '<tr><td colspan="4" style="color: var(--text-muted); text-align: center; padding: 16px;">暂无渠道模型——添加服务商并获取模型后，其价格将显示在这里</td></tr>' : ''}
              ${priceModels.sort((a, b) => a[0].localeCompare(b[0])).map(([name, price]) => `
                <tr>
                  <td class="model-cell">${escapeHtml(name)}</td>
                  <td><input class="input" type="number" step="0.01" min="0" data-price-model="${escapeAttr(name)}" data-price-kind="input" value="${price.input || 0}"></td>
                  <td><input class="input" type="number" step="0.01" min="0" data-price-model="${escapeAttr(name)}" data-price-kind="output" value="${price.output || 0}"></td>
                  <td style="text-align: right;">
                    <button class="btn btn-sm" onclick="savePriceRow('${escapeAttr(name)}')">保存</button>
                    <button class="btn btn-sm btn-danger" onclick="removePriceRow('${escapeAttr(name)}')">删</button>
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
        <div style="display: flex; gap: 8px; margin-top: 8px;">
          <input class="input" id="newPriceModel" placeholder="新模型名（需先添加到渠道模型列表才会显示）" style="flex: 1; font-family: monospace; font-size: 12px;">
          <button class="btn" onclick="addPriceRow()">+ 添加价格</button>
        </div>
      </div>

      <div class="divider"></div>

      <div class="section-title">📖 代理 API 使用说明</div>
      <div class="form-group">
        <div style="background: rgba(15,23,42,0.05); padding: 16px; border-radius: 8px; font-family: monospace; font-size: 13px; border: 1px solid rgba(15,23,42,0.15); color: rgba(31, 41, 55, 0.95); line-height: 1.8;">
          <div># OpenAI 兼容 API</div>
          <div>Base URL: <span style="color: var(--yellow);">http://localhost:${port}/v1</span></div>
          <div>API Key: <span style="color: var(--yellow);">任意值（代理不需要认证）</span></div>
          <div style="margin-top: 8px;"># 可用接口:</div>
          <div>GET  /v1/models - 获取所有模型（含价格）</div>
          <div>POST /v1/chat/completions - 聊天补全（支持流式）</div>
          <div>POST /v1/completions - 文本补全</div>
          <div>POST /v1/embeddings - 嵌入向量</div>
          <div style="margin-top: 8px;"># 响应头（路由信息）:</div>
          <div>X-Router-Model - 实际使用的模型</div>
          <div>X-Router-Provider - 实际使用的服务商</div>
          <div>X-Router-Switched - 是否发生模型切换 (1)</div>
          <div style="margin-top: 8px;"># 示例 (curl):</div>
          <div style="color: var(--green);">curl http://localhost:${port}/v1/chat/completions \\</div>
          <div style="color: var(--green);">  -H "Content-Type: application/json" \\</div>
          <div style="color: var(--green);">  -H "Authorization: Bearer any" \\</div>
          <div style="color: var(--green);">  -d '{"model":"gpt-4","messages":[{"role":"user","content":"hello"}]}'</div>
        </div>
      </div>

      <div class="divider"></div>

      <div class="section-title">🗂️ 数据管理</div>
      <div class="form-group">
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
          <button class="btn" onclick="exportConfig()">导出配置</button>
          <button class="btn" onclick="document.getElementById('importConfigFile').click()">导入配置</button>
          <input type="file" id="importConfigFile" accept=".json" style="display: none;" onchange="importConfig(event)">
          <button class="btn btn-danger" onclick="resetConfig()">重置所有配置</button>
        </div>
      </div>

      <div class="divider"></div>

      <div style="text-align: center; color: rgba(31, 41, 55, 0.78); font-size: 12px; padding: 12px;">
        子沐智能中转路由 v3.0.2 · 动漫主题版
      </div>
    </div>
  `;
}

// ===== 智能页面（可观测性闭环 / 安全合规 / 语义缓存 / SLO / 体检） =====
function renderSmart() {
  const providers = state.config?.providers || [];
  const providerOpts = providers.map(p => `<option value="${p.id}">${escapeHtml(p.name)}</option>`).join('');
  const quality = state.smart?.quality || {};
  const cmp = state.smart?.stats?.compression?.config || state.smart?.compression?.config || {};
  const cmpStats = state.smart?.stats?.compression || {};
  const guard = state.smart?.guard || {};
  const sc = state.smart?.semanticCache || {};
  const slo = state.smart?.slo || {};
  const residency = state.smart?.residency || {};
  const shadow = state.smart?.shadow || {};
  const stats = state.smart?.stats || {};
  const drift = stats.drift || { active: false, items: [] };
  const hc = state.smart?.healthcheck || { items: [], summary: {}, hasEmbeddingModel: false };
  const statusBadge = (s) => {
    const map = { ok: ['badge-healthy', '✅ 已具备'], partial: ['badge-warning', '🟡 部分'], missing: ['badge-disabled', '❌ 缺失'], disabled: ['badge-disabled', '⏸ 未启用'] };
    const [cls, label] = map[s] || map.missing;
    return `<span class="badge ${cls}">${label}</span>`;
  };

  return `
    ${drift.active ? `
    <div class="glass-card" style="margin-bottom: 12px; border-color: var(--red);">
      <div class="stripe-title" style="color: var(--red);">⚠️ 质量漂移告警</div>
      ${drift.items.map(d => `
        <div style="font-size: 13px; color: rgba(31, 41, 55, 0.95); margin-bottom: 6px;">
          <b>${escapeHtml(d.provider)}</b>：质量分从 <b style="color: var(--yellow);">${d.baseline}</b> 降至 <b style="color: var(--red);">${d.recent}</b>（下降 ${d.drop} 分）
        </div>`).join('')}
      <p style="font-size: 12px; color: rgba(31, 41, 55, 0.75);">建议：检查该服务商模型是否降级/超载，或在加权路由中其权重已自动下降。</p>
    </div>` : ''}

    ${stats.slo?.degraded ? `
    <div class="glass-card" style="margin-bottom: 12px; border-color: var(--yellow);">
      <div class="stripe-title" style="color: var(--yellow);">🐢 SLO 降级模式运行中</div>
      <p style="font-size: 13px;">延迟 p95 ${stats.slo.p95Ms}ms 超过阈值 ${stats.slo.thresholdMs}ms，已自动跳过慢速服务商，延迟恢复后自动解除。</p>
    </div>` : ''}

    <div class="glass-card" style="margin-bottom: 12px;">
      <div class="stripe-title">📊 智能模块状态</div>
      <div style="display: flex; gap: 10px; flex-wrap: wrap;">
        <span class="key-tag">质量评分 ${quality.enabled ? '✅' : '⏸'}</span>
        <span class="key-tag">内容护栏 ${guard.enabled ? '✅' : '⏸'}</span>
        <span class="key-tag">语义缓存 ${sc.enabled ? '✅' : '⏸'}（命中率 ${sc.hitRate || 0}%）</span>
        <span class="key-tag">SLO 降级保护 ${slo.enabled !== false ? '✅' : '⏸'}（p95 ${stats.slo?.p95Ms || 0}ms）</span>
        <span class="key-tag">数据驻留 ${residency.enabled ? '✅' : '⏸'}</span>
        <span class="key-tag">影子决策 ${shadow.enabled !== false ? '✅' : '⏸'}</span>
        <span class="key-tag">Trace 日志 ${state.smart?.logging?.enabled !== false ? '✅' : '⏸'}</span>
      </div>
    </div>

    <div class="glass-card" style="margin-bottom: 12px;">
      <div class="stripe-title">⭐ 质量评分与反馈学习</div>
      <div class="toggle-row">
        <div>启用质量评分 <span class="hint">judge 模型打分（采样）或内置启发式评分；分数反哺加权路由权重</span></div>
        <div class="toggle ${quality.enabled ? 'active' : ''}" id="qEnabled" onclick="this.classList.toggle('active')"><div class="toggle-knob"></div></div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="label">Judge 服务商</label>
          <select class="select" id="qJudgeProvider">
            <option value="">自动（用当前服务商）</option>
            ${providerOpts}
          </select>
        </div>
        <div class="form-group">
          <label class="label">Judge 模型（建议便宜的）</label>
          <input class="input" id="qJudgeModel" value="${escapeAttr(quality.judgeModel || '')}" placeholder="例如 gpt-4o-mini / deepseek-chat">
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="label">采样率（0-1，默认 0.1）</label>
          <input class="input" type="number" id="qSampleRate" step="0.05" min="0" max="1" value="${quality.sampleRate ?? 0.1}">
        </div>
        <div class="form-group">
          <label class="label">评分后端（v3.0.2）</label>
          <select class="select" id="qJudgeBackend">
            <option value="auto" ${(quality.judgeBackend || 'auto') === 'auto' ? 'selected' : ''}>自动（本地引擎在跑优先用本地）</option>
            <option value="local" ${quality.judgeBackend === 'local' ? 'selected' : ''}>本地模型（Qwen2.5，省云端 token）</option>
            <option value="cloud" ${quality.judgeBackend === 'cloud' ? 'selected' : ''}>云端 Judge 模型</option>
          </select>
        </div>
        <div class="form-group">
          <label class="label">内置启发式评分</label>
          <div style="padding-top: 8px;">
            <div class="toggle ${quality.heuristic !== false ? 'active' : ''}" id="qHeuristic" onclick="this.classList.toggle('active')"><div class="toggle-knob"></div></div>
          </div>
        </div>
      </div>
      <button class="btn btn-primary" onclick="saveSmartSection('quality')">💾 保存质量评分</button>
    </div>

    <div class="glass-card" style="margin-bottom: 12px;">
      <div class="stripe-title">🗜️ Tokens 压缩（长对话节省成本）</div>
      <p style="font-size: 12px; color: rgba(31, 41, 55, 0.8); margin-bottom: 8px;">
        对话超过阈值时，路由会在<b>不影响语义</b>的前提下压缩长历史后再发上游：system 与最近 ${cmp.keepRecent || 8} 条保持原文，更早的旧消息用启发式截断或 LLM 摘要。
        当前：已压缩 <b style="color: var(--yellow);">${cmpStats.compressedRequests || 0}</b> 次，累计节省 <b style="color: var(--green);">${(cmpStats.savedTokens || 0).toLocaleString()}</b> tokens（启发式 ${cmpStats.heuristic || 0} / 智能 ${cmpStats.smart || 0}）
      </p>
      <div class="toggle-row">
        <div>启用压缩</div>
        <div class="toggle ${cmp.enabled ? 'active' : ''}" id="cmpEnabled" onclick="this.classList.toggle('active')"><div class="toggle-knob"></div></div>
      </div>
      <div class="toggle-row">
        <div>启发式截断（免费） <span class="hint">超长旧消息截断为 ${cmp.maxOldChars || 600} 字符</span></div>
        <div class="toggle ${cmp.heuristic !== false ? 'active' : ''}" id="cmpHeuristic" onclick="this.classList.toggle('active')"><div class="toggle-knob"></div></div>
      </div>
      <div class="toggle-row">
        <div>LLM 智能摘要 <span class="hint">用压缩模型把旧历史合成摘要（更省 tokens）</span></div>
        <div class="toggle ${cmp.smart ? 'active' : ''}" id="cmpSmart" onclick="this.classList.toggle('active')"><div class="toggle-knob"></div></div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="label">摘要后端（v3.0.2）</label>
          <select class="select" id="cmpSmartBackend">
            <option value="auto" ${(cmp.smartBackend || 'auto') === 'auto' ? 'selected' : ''}>自动（本地引擎在跑优先用本地）</option>
            <option value="local" ${cmp.smartBackend === 'local' ? 'selected' : ''}>本地模型（Qwen2.5，免费）</option>
            <option value="cloud" ${cmp.smartBackend === 'cloud' ? 'selected' : ''}>云端压缩模型</option>
          </select>
        </div>
        <div class="form-group">
          <label class="label">压缩服务商（留空自动）</label>
          <select class="select" id="cmpProvider">
            <option value="">自动（复用 judge 或首个可用）</option>
            ${providerOpts}
          </select>
        </div>
        <div class="form-group">
          <label class="label">压缩模型（留空自动）</label>
          <input class="input" id="cmpModel" value="${escapeAttr(cmp.model || '')}" placeholder="例如 deepseek-chat">
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="label">保留最近消息条数</label>
          <input class="input" type="number" id="cmpKeepRecent" min="2" max="50" value="${cmp.keepRecent ?? 8}">
        </div>
        <div class="form-group">
          <label class="label">触发阈值（估算 tokens）</label>
          <input class="input" type="number" id="cmpTrigger" min="500" max="200000" step="500" value="${cmp.triggerTokens ?? 12000}">
        </div>
      </div>
      <button class="btn btn-primary" onclick="saveSmartSection('compression')">💾 保存压缩设置</button>
    </div>

    <div class="glass-card" style="margin-bottom: 12px;">
      <div class="stripe-title">🛡️ 内容护栏（安全合规）</div>
      <div class="toggle-row">
        <div>启用护栏</div>
        <div class="toggle ${guard.enabled ? 'active' : ''}" id="gEnabled" onclick="this.classList.toggle('active')"><div class="toggle-knob"></div></div>
      </div>
      <div class="toggle-row">
        <div>输出 PII 掩码 <span class="hint">邮箱/手机号/身份证/IP/密钥/URL 自动打码（非流式输出）</span></div>
        <div class="toggle ${guard.maskPII !== false ? 'active' : ''}" id="gMaskPII" onclick="this.classList.toggle('active')"><div class="toggle-knob"></div></div>
      </div>
      <div class="toggle-row">
        <div>输入敏感词拦截 <span class="hint">命中直接拒绝请求（403）</span></div>
        <div class="toggle ${guard.blockSensitive ? 'active' : ''}" id="gBlockSensitive" onclick="this.classList.toggle('active')"><div class="toggle-knob"></div></div>
      </div>
      <div class="form-group">
        <label class="label">敏感词黑名单（逗号或换行分隔）</label>
        <textarea class="textarea" id="gWords" style="min-height: 60px;">${escapeHtml((guard.sensitiveWords || []).join(', '))}</textarea>
      </div>
      <button class="btn btn-primary" onclick="saveSmartSection('guard')">💾 保存护栏</button>
    </div>

    <div class="glass-card" style="margin-bottom: 12px;">
      <div class="stripe-title">🧲 语义缓存（降本提速最后一公里）</div>
      <p style="font-size: 12px; color: rgba(31, 41, 55, 0.75); margin-bottom: 8px;">
        ${hc.hasEmbeddingModel ? '已检测到支持嵌入的服务商 ✅' : '⚠️ 未检测到嵌入模型（如 text-embedding / bge），开启后可能无法生成向量，需先在有嵌入模型的服务商上使用'}
        语义缓存用嵌入相似度匹配「语义等价」的请求，命中即返回（零成本）。当前：命中 ${sc.hits || 0} 次 / 未命中 ${sc.misses || 0} 次 / 命中率 ${sc.hitRate || 0}%
      </p>
      <div class="toggle-row">
        <div>启用语义缓存</div>
        <div class="toggle ${sc.enabled ? 'active' : ''}" id="scEnabled" onclick="this.classList.toggle('active')"><div class="toggle-knob"></div></div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="label">嵌入后端（v3.0.2）</label>
          <select class="select" id="scEmbedBackend">
            <option value="auto" ${(sc.embedBackend || 'auto') === 'auto' ? 'selected' : ''}>自动（本地引擎在跑优先用本地）</option>
            <option value="local" ${sc.embedBackend === 'local' ? 'selected' : ''}>本地模型（Qwen2.5，数据不出本机）</option>
            <option value="cloud" ${sc.embedBackend === 'cloud' ? 'selected' : ''}>云端嵌入模型</option>
          </select>
        </div>
        <div class="form-group">
          <label class="label">相似度阈值（0.9-0.99，越高越严格）</label>
          <input class="input" type="number" id="scThreshold" step="0.01" min="0.5" max="1" value="${sc.threshold ?? 0.95}">
        </div>
        <div class="form-group">
          <label class="label">最大条目数</label>
          <input class="input" type="number" id="scMaxEntries" min="100" max="20000" value="${sc.maxEntries ?? 2000}">
        </div>
      </div>
      <button class="btn btn-primary" onclick="saveSmartSection('semanticCache')">💾 保存语义缓存</button>
    </div>

    <div class="glass-card" style="margin-bottom: 12px;">
      <div class="stripe-title">🐢 SLO 智能限流（延迟 p95 降级保护）</div>
      <div class="toggle-row">
        <div>启用 SLO 保护 <span class="hint">p95 延迟超阈值自动跳过慢速服务商，恢复后自动解除</span></div>
        <div class="toggle ${slo.enabled !== false ? 'active' : ''}" id="sloEnabled" onclick="this.classList.toggle('active')"><div class="toggle-knob"></div></div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="label">p95 阈值（ms，默认 4000）</label>
          <input class="input" type="number" id="sloThreshold" min="500" max="60000" value="${slo.p95ThresholdMs ?? 4000}">
        </div>
        <div class="form-group">
          <label class="label">当前状态</label>
          <p style="padding-top: 8px;">${stats.slo?.degraded ? '<span class="badge badge-unhealthy">降级中</span>' : '<span class="badge badge-healthy">正常</span>'} p95=${stats.slo?.p95Ms || 0}ms · 降级 ${stats.slo?.degradedCount || 0} 次</p>
        </div>
      </div>
      <button class="btn btn-primary" onclick="saveSmartSection('slo')">💾 保存 SLO</button>
    </div>

    <div class="glass-card" style="margin-bottom: 12px;">
      <div class="stripe-title">🌍 数据驻留 + 影子模式</div>
      <div class="toggle-row">
        <div>启用数据驻留 <span class="hint">只走允许区域的服务商（服务商需在编辑时填写区域，如 CN/US/EU）</span></div>
        <div class="toggle ${residency.enabled ? 'active' : ''}" id="resEnabled" onclick="this.classList.toggle('active')"><div class="toggle-knob"></div></div>
      </div>
      <div class="form-group">
        <label class="label">允许区域（逗号分隔，如 CN,US）</label>
        <input class="input" id="resRegions" value="${escapeAttr((residency.allowedRegions || []).join(','))}" placeholder="CN,US">
      </div>
      <div class="toggle-row">
        <div>影子决策记录 <span class="hint">每条请求记录"若用加权策略会选谁"，用于对比验证，不额外调用</span></div>
        <div class="toggle ${shadow.enabled !== false ? 'active' : ''}" id="shadowEnabled" onclick="this.classList.toggle('active')"><div class="toggle-knob"></div></div>
      </div>
      <div style="display: flex; gap: 8px; margin-top: 4px;">
        <button class="btn btn-primary" onclick="saveResidencyShadow()">💾 保存</button>
      </div>
    </div>

    <div class="glass-card">
      <div class="stripe-title">📋 智能体检（10 项能力清单）</div>
      <p style="font-size: 12px; color: rgba(31, 41, 55, 0.75); margin-bottom: 12px;">
        通过 ${hc.summary.ok || 0} / ${hc.summary.total || 10} 项 · 部分 ${hc.summary.partial || 0} 项 · 缺失 ${hc.summary.missing || 0} 项
      </p>
      ${(hc.items || []).map(it => `
        <div class="table-row" style="padding: 10px 14px;">
          <span style="color: var(--yellow); font-weight: 700; min-width: 28px;">${it.id}</span>
          <div style="flex: 1;">
            <div style="color: var(--text-main); font-weight: 600; font-size: 14px;">${escapeHtml(it.name)} ${statusBadge(it.status)}</div>
            <div style="font-size: 11px; color: rgba(31, 41, 55, 0.75); margin-top: 2px;">${escapeHtml(it.desc)}</div>
            <div style="font-size: 11px; color: rgba(31, 41, 55, 0.6); margin-top: 2px;">${escapeHtml(it.hint || '')}</div>
          </div>
        </div>
      `).join('')}
    </div>
  `;
}

async function saveSmartSection(section) {
  const data = {};
  if (section === 'quality') {
    data.enabled = document.getElementById('qEnabled').classList.contains('active');
    data.judgeProviderId = document.getElementById('qJudgeProvider').value || null;
    data.judgeModel = document.getElementById('qJudgeModel').value.trim() || null;
    data.sampleRate = parseFloat(document.getElementById('qSampleRate').value) || 0.1;
    data.heuristic = document.getElementById('qHeuristic').classList.contains('active');
    data.judgeBackend = document.getElementById('qJudgeBackend')?.value || 'auto';
  } else if (section === 'guard') {
    data.enabled = document.getElementById('gEnabled').classList.contains('active');
    data.maskPII = document.getElementById('gMaskPII').classList.contains('active');
    data.blockSensitive = document.getElementById('gBlockSensitive').classList.contains('active');
    data.sensitiveWords = document.getElementById('gWords').value.split(/[,，\n]/).map(w => w.trim()).filter(Boolean);
  } else if (section === 'semanticCache') {
    data.enabled = document.getElementById('scEnabled').classList.contains('active');
    data.threshold = parseFloat(document.getElementById('scThreshold').value) || 0.95;
    data.maxEntries = parseInt(document.getElementById('scMaxEntries').value) || 2000;
    data.embedBackend = document.getElementById('scEmbedBackend')?.value || 'auto';
  } else if (section === 'slo') {
    data.enabled = document.getElementById('sloEnabled').classList.contains('active');
    data.p95ThresholdMs = parseInt(document.getElementById('sloThreshold').value) || 4000;
  } else if (section === 'compression') {
    data.enabled = document.getElementById('cmpEnabled').classList.contains('active');
    data.heuristic = document.getElementById('cmpHeuristic').classList.contains('active');
    data.smart = document.getElementById('cmpSmart').classList.contains('active');
    data.smartBackend = document.getElementById('cmpSmartBackend')?.value || 'auto';
    data.providerId = document.getElementById('cmpProvider').value || null;
    data.model = document.getElementById('cmpModel').value.trim() || null;
    data.keepRecent = parseInt(document.getElementById('cmpKeepRecent').value) || 8;
    data.triggerTokens = parseInt(document.getElementById('cmpTrigger').value) || 12000;
  }
  try {
    await api.setSmart(section, data);
    toast('已保存', 'success');
    await refreshSmartPage();
  } catch (e) {
    toast('保存失败: ' + e.message, 'error');
  }
}

async function saveResidencyShadow() {
  try {
    await api.setSmart('residency', {
      enabled: document.getElementById('resEnabled').classList.contains('active'),
      allowedRegions: document.getElementById('resRegions').value.split(/[,，]/).map(r => r.trim().toUpperCase()).filter(Boolean)
    });
    await api.setSmart('shadow', {
      enabled: document.getElementById('shadowEnabled').classList.contains('active')
    });
    toast('已保存', 'success');
    await refreshSmartPage();
  } catch (e) {
    toast('保存失败: ' + e.message, 'error');
  }
}

async function refreshSmart() {
  try {
    state.smart = await api.getSmart();
  } catch (e) {
    console.error('刷新智能状态失败:', e);
  }
}

// 保存后刷新数据并重渲染一次（避免与 attachPageHandlers 形成无限循环）
async function refreshSmartPage() {
  await refreshSmart();
  if (state.currentPage === 'smart') renderPage();
}

// ===== 记忆页面（渠道模型画像 + 用户习惯 + 推荐） =====
let memoryReport = null;

const CAP_LABEL = { chat: '💬 对话', image: '🖼️ 图片', video: '🎬 视频', embedding: '🧲 嵌入', audio: '🔊 音频' };

const FEATURE_LABEL = {
  chat_req: '💬 对话请求', image_gen: '🖼️ 图片生成', video_gen: '🎬 视频生成', embedding_req: '🧲 嵌入请求',
  cache_hit: '📦 缓存命中', cache_miss: '📦 缓存未命中', semantic_cache_hit: '🧠 语义缓存命中',
  compression: '✂️ 消息压缩', prompt_repair: '🔧 提示词修复', fallback: '🔀 跨模型回退',
  rate_limit_backoff: '⏳ 限流退避', circuit_break: '🛡️ 熔断', key_guard: '🔑 Key 保护',
  quality_judge: '⭐ 质量评分', shadow_decision: '👻 影子决策', slo_degrade: '🐢 SLO 降级', slo_recover: '🚀 SLO 恢复',
  health_check: '❤️ 健康检测', provider_manage: '🏢 渠道管理', config_change: '⚙️ 配置修改',
  stats_reset: '📊 统计重置', cache_manage: '🧹 缓存管理', test_page: '🧪 测试调用',
  logs_export: '📜 日志导出', memory_probe: '🔍 记忆探测', memory_sync: '↗ 记忆同步', ab_test: '🧪 A/B 分流',
  local_engine_download: '⬇ 本地引擎下载', local_model_download: '⬇ 本地模型下载', local_start: '▶ 本地引擎启动',
  local_tool: '🔧 本地工具调用', local_tool_round: '🔄 工具调用回合'
};

function renderMemory() {
  const m = memoryReport;
  const cfg = state.config?.memory || {};
  return `
    <div class="glass-card" style="margin-bottom: 12px;">
      <div class="stripe-title">📚 内置记忆（自动学习）</div>
      <p style="font-size: 13px; color: var(--text-3); margin-bottom: 10px;">
        自动学习每个渠道有哪些模型、每个 Key 能访问哪些模型（同渠道多 Key 权限可能不同）、多模态能力分类，以及你的使用习惯（常用模型/各能力默认选择/分时段使用）。
        全软件功能使用（缓存/压缩/熔断/回退/健康检测/渠道管理等）也自动记录并分析。
        ${m ? `累计学习 <b style="color: var(--blue-primary);">${m.totalCalls || 0}</b> 次调用 · ${(m.channels || []).length} 个渠道 · 共 ${(m.channels || []).reduce((s, c) => s + c.modelCount, 0)} 个模型 · ${(m.featureStats || []).length} 项功能` : ''}
      </p>
      <div style="display: flex; gap: 8px; flex-wrap: wrap;">
        <div class="toggle-row" style="width: 100%;">
          <div>自动学习 ${cfg.enabled !== false ? '✅' : '⏸'} · 自动并入渠道列表 ${cfg.autoAddModels !== false ? '✅' : '⏸'}</div>
          <div style="display: flex; gap: 8px;">
            <button class="btn btn-primary" onclick="probeMemoryNow()">🔍 立即探测所有渠道</button>
            <button class="btn" onclick="syncMemoryModelsNow()">↗ 同步到渠道列表</button>
            <button class="btn btn-danger" onclick="clearMemoryNow()">清空记忆</button>
          </div>
        </div>
      </div>
    </div>

    ${m ? `
    <div class="glass-card" style="margin-bottom: 12px;">
      <div class="stripe-title">⭐ 模型推荐（综合成功率/延迟/成本）</div>
      <div style="display: flex; gap: 10px; flex-wrap: wrap;">
        ${['chat', 'image', 'video', 'embedding'].map(cap => {
          const rec = m.recommendations?.[cap];
          return `
            <div class="ab-card" style="min-width: 220px;">
              <div class="ab-head"><span class="ab-name">${CAP_LABEL[cap] || cap}</span></div>
              ${rec ? `
                <div style="font-family: monospace; font-size: 14px; color: var(--text-main); font-weight: 700;">${escapeHtml(rec.model)}</div>
                <div class="ab-stats" style="margin-top: 6px;">
                  <span>调用 <span class="v">${rec.calls}</span></span>
                  <span>成功率 <span class="v ${rec.successRate >= 80 ? 'green' : rec.successRate >= 50 ? 'yellow' : 'red'}">${rec.successRate}%</span></span>
                  ${rec.avgLatency ? `<span>延迟 <span class="v">${rec.avgLatency}ms</span></span>` : ''}
                </div>` : '<div style="color: var(--text-muted); font-size: 12px;">暂无使用记录</div>'}
            </div>`;
        }).join('')}
      </div>
    </div>

    <div class="glass-card" style="margin-bottom: 12px;">
      <div class="stripe-title">🕐 我的习惯</div>
      <div class="table-row">
        <div style="flex: 1;">
          <div style="font-size: 13px; color: var(--text-3); margin-bottom: 6px;">各能力最近使用的模型（默认偏好）</div>
          <div style="display: flex; gap: 8px; flex-wrap: wrap;">
            ${Object.entries(m.lastUsedByCapability || {}).map(([cap, model]) => `<span class="key-tag">${CAP_LABEL[cap] || cap}: <b>${escapeHtml(model)}</b></span>`).join('') || '<span style="color: var(--text-muted); font-size: 12px;">暂无记录</span>'}
          </div>
        </div>
      </div>
      ${(m.topModels || []).length > 0 ? `
      <div style="margin-top: 10px; font-size: 13px; color: var(--text-3); margin-bottom: 6px;">常用模型 Top 10</div>
      ${m.topModels.map((t, i) => `
        <div class="log-entry">
          <span style="color: var(--yellow); font-weight: 700; min-width: 24px;">${i + 1}</span>
          <span style="flex: 1; font-family: monospace; color: var(--text-main);">${escapeHtml(t.name)}</span>
          <span>${CAP_LABEL[t.capability] || t.capability}</span>
          <span>${t.calls} 次</span>
          <span style="color: var(--green);">${t.successRate}%</span>
        </div>`).join('')}
      ` : ''}
      ${(m.usageByHour || []).length > 0 ? `
      <div style="margin-top: 10px; font-size: 13px; color: var(--text-3); margin-bottom: 6px;">分时段使用</div>
      <div style="display: flex; gap: 6px; flex-wrap: wrap;">
        ${m.usageByHour.map(h => `
          <span class="key-tag" title="${h.top.map(t => escapeHtml(t.model) + ' x' + t.count).join('\n')}">${h.hour}:00时 ${h.top.length ? escapeHtml(h.top[0].model) : ''}</span>`).join('')}
      </div>
      ` : ''}
    </div>

    <div class="glass-card" style="margin-bottom: 12px;">
      <div class="stripe-title">⚙️ 功能使用分析（全软件接入）</div>
      ${(m.featureInsights || []).length ? `
      <div style="display: flex; flex-direction: column; gap: 6px; margin-bottom: 10px;">
        ${m.featureInsights.map(i => `
          <div class="log-entry" style="background: ${i.level === 'good' ? 'rgba(16,185,129,0.10)' : i.level === 'warn' ? 'rgba(245,158,11,0.12)' : 'rgba(59,130,246,0.08)'};">
            <span style="font-size: 15px;">${i.level === 'good' ? '✅' : i.level === 'warn' ? '⚠️' : '💡'}</span>
            <span style="flex: 1; font-size: 13px; color: var(--text-main);">${escapeHtml(i.text)}</span>
          </div>`).join('')}
      </div>` : ''}
      ${(m.featureStats || []).length > 0 ? `
      <div style="margin-bottom: 6px; font-size: 13px; color: var(--text-3);">功能使用排行（累计）</div>
      ${m.featureStats.slice(0, 12).map(f => {
        const max = m.featureStats[0].count || 1;
        return `
        <div class="log-entry" style="gap: 8px;">
          <span style="min-width: 130px; font-size: 13px;">${FEATURE_LABEL[f.id] || escapeHtml(f.id)}</span>
          <div style="flex: 1; height: 8px; background: #e5e7eb; border-radius: 4px; overflow: hidden;">
            <div style="width: ${Math.max(2, Math.round(f.count / max * 100))}%; height: 100%; background: linear-gradient(90deg, var(--blue-primary), #60a5fa); border-radius: 4px;"></div>
          </div>
          <span style="font-family: monospace; font-size: 12px; min-width: 55px; text-align: right;">${f.count} 次${f.errorCount ? ` <span style="color: var(--red);">(${f.errorCount} 异常)</span>` : ''}</span>
        </div>`;
      }).join('')}
      ` : '<div class="empty-state-text">暂无功能使用数据——正常使用软件（测试页/路由/渠道管理/健康检测等）后这里会生成完整画像与建议</div>'}
      ${(m.recentEvents || []).length > 0 ? `
      <div style="margin-top: 10px; margin-bottom: 6px; font-size: 13px; color: var(--text-3);">最近功能事件</div>
      <div style="max-height: 180px; overflow-y: auto;">
        ${m.recentEvents.slice(0, 15).map(e => `
          <div class="log-entry" style="gap: 8px; font-size: 12px;">
            <span style="color: var(--text-muted); min-width: 42px;">${formatTime(e.t)}</span>
            <span>${FEATURE_LABEL[e.id] || escapeHtml(e.id)}</span>
            <span style="color: ${e.ok ? 'var(--green)' : 'var(--red)'};">${e.ok ? '✓' : '✗'}</span>
            ${e.detail ? `<span style="color: var(--text-muted); flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${escapeHtml(e.detail)}</span>` : ''}
          </div>`).join('')}
      </div>
      ` : ''}
    </div>

    <div class="glass-card">
      <div class="stripe-title">🏢 渠道模型清单（按渠道分组 · 按能力分类）</div>
      ${(m.channels || []).length === 0 ? '<div class="empty-state-text">暂无数据——使用一段时间或点击「立即探测」后这里会显示各渠道的模型画像</div>' : ''}
      ${(m.channels || []).map(ch => `
        <div style="margin-bottom: 14px;">
          <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 6px;">
            <b style="font-size: 15px;">${escapeHtml(ch.name || ch.id)}</b>
            <span class="key-tag">${ch.modelCount} 个模型</span>
            <span style="font-size: 11px; color: var(--text-muted); font-family: monospace;">${escapeHtml(ch.baseUrl || '')}</span>
            <span style="font-size: 11px; color: var(--text-muted);">${ch.lastProbedAt ? '探测于 ' + formatTime(ch.lastProbedAt) : '未探测'}</span>
          </div>
          <div style="display: flex; flex-wrap: wrap; gap: 6px;">
            ${ch.models.slice(0, 100).map(mm => `
              <span class="key-tag" style="font-size: 12px;" title="
                ${CAP_LABEL[mm.capability] || mm.capability} · Key 覆盖 ${mm.keyCount} 个 · 调用 ${mm.calls} 次
                成功率 ${mm.successRate ?? '--'}% · 延迟 ${mm.avgLatency ?? '--'}ms${mm.avgCost != null ? ' · 均成本 ' + fmtPrice(mm.avgCost, state.currency) : ''}
                最近 ${mm.lastUsed ? formatTime(mm.lastUsed) : '--'}">
                ${escapeHtml(mm.name)} ${CAP_LABEL[mm.capability] || ''}
              </span>`).join('')}
            ${ch.models.length > 100 ? `<span class="key-tag" style="font-size: 12px; color: var(--text-muted);">+${ch.models.length - 100} 更多</span>` : ''}
          </div>
        </div>`).join('')}
    </div>
    ` : '<div class="glass-card"><div class="empty-state-text">加载中...</div></div>'}
  `;
}

async function refreshMemory() {
  try {
    memoryReport = await api.getMemory();
  } catch (e) {
    console.error('加载记忆失败:', e);
  }
}

async function probeMemoryNow() {
  toast('正在探测所有渠道模型...', 'info');
  try {
    const r = await api.probeMemory();
    memoryReport = r.report;
    toast('探测完成，模型画像已更新', 'success');
    renderPage();
  } catch (e) {
    toast('探测失败: ' + e.message, 'error');
  }
}

async function syncMemoryModelsNow() {
  try {
    const r = await api.syncMemoryModels();
    memoryReport = r.report;
    await refreshConfig();
    toast(`已并入 ${r.added || 0} 个新模型到渠道列表`, 'success');
    renderPage();
  } catch (e) {
    toast('同步失败: ' + e.message, 'error');
  }
}

async function clearMemoryNow() {
  if (!confirm('确定清空全部记忆？（渠道模型画像与使用习惯）')) return;
  try {
    memoryReport = await api.clearMemory();
    toast('记忆已清空', 'success');
    renderPage();
  } catch (e) {
    toast('清空失败: ' + e.message, 'error');
  }
}

// ===== 本地模型页面（v3.0.2 内置 Qwen2.5-7B-Instruct） =====
let localStatus = null;
let localTools = null;
let localEngineLogs = [];
let brainStatus = null;

function fmtBytes(n) {
  if (!n) return '0 B';
  const u = ['B', 'KB', 'MB', 'GB'];
  let i = 0;
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
  return n.toFixed(1) + ' ' + u[i];
}

function fmtSpeed(bps) {
  if (!bps) return '';
  return fmtBytes(bps) + '/s';
}

function renderLocal() {
  const s = localStatus;
  // 已添加渠道（含模型）列表——供本地模型引擎的「云端渠道模型」下拉使用
  const channelProviders = (state.config?.providers || []).filter(p => (p.models || []).length > 0);
  const b = brainStatus || { enabled: true, autoRunning: false, engineRunning: false, intervalMin: 15, wakeOnEvents: true, decisionCount: 0, history: [] };
  if (!s) return '<div class="glass-card"><div class="empty-state-text">加载中...</div></div>';
  const progress = s.progress;
  const progressBar = progress ? `
    <div style="margin-top: 8px;">
      <div style="font-size: 12px; color: var(--text-3); margin-bottom: 4px;">
        ${progress.kind === 'engine' ? '下载 llama.cpp 引擎' : '下载 Qwen2.5-7B-Instruct GGUF'}：${progress.percent}% · ${fmtBytes(progress.received)} / ${fmtBytes(progress.total)} · ${fmtSpeed(progress.speedBps)}
      </div>
      <div style="flex: 1; height: 10px; background: #e5e7eb; border-radius: 5px; overflow: hidden;">
        <div style="width: ${progress.percent}%; height: 100%; background: linear-gradient(90deg, var(--blue-primary), #60a5fa); border-radius: 5px; transition: width .3s;"></div>
      </div>
    </div>` : '';
  const modelReady = s.modelExists;
  const engineReady = s.engineExists;
  const running = s.running;
  const isCloud = s.backend === 'cloud';
  // 云端渠道模型下拉（后端=cloud 时使用）：值格式 providerId||model
  const cloudChannelOpts = channelProviders.flatMap(p => (p.models || []).map(m => {
    const val = p.id + '||' + m;
    return `<option value="${escapeAttr(val)}" ${val === (s.cloudChannel || '') ? 'selected' : ''}>${escapeHtml(p.name)} / ${escapeHtml(m)}</option>`;
  })).join('');

  return `
    <div class="glass-card" style="margin-bottom: 12px;">
      <div class="stripe-title">🤖 本地模型引擎（内置 Qwen2.5-7B-Instruct · 路由大脑底座）</div>
      <p style="font-size: 13px; color: var(--text-3); margin-bottom: 10px;">
        应用内置本地推理引擎（llama.cpp），不依赖任何外部服务。下载一次后完全离线可用；
        本地模型作为<b style="color: var(--blue-primary);">路由器大脑</b>运行——观察路由状态并调用工具优化路由（不参与对话回答）。
      </p>
      <div style="display: flex; gap: 6px; flex-wrap: wrap; align-items: center;">
        <span class="key-tag">后端: <b>${isCloud ? '☁️ 云端渠道模型' : s.backend === 'ollama' ? 'Ollama（外部）' : '内置 llama.cpp'}</b></span>
        <span class="key-tag">状态: <b style="color: ${isCloud ? (running ? 'var(--green)' : s.cloudReady ? 'var(--text-muted)' : 'var(--red)') : (running ? 'var(--green)' : s.state === 'error' ? 'var(--red)' : 'var(--text-muted)')};">${isCloud ? (running ? '🟢 已启用' : s.cloudReady ? '😴 未启用' : '⚠️ 待选模型') : (running ? '🟢 运行中' : s.waking ? '⏳ 唤醒中' : s.state === 'downloading-engine' ? '⏳ 下载引擎中' : s.state === 'downloading-model' ? '⏳ 下载模型中' : s.state === 'error' ? '🔴 异常' : '😴 已休眠（请求进来自动唤醒）')}</b></span>
        ${isCloud
          ? `<span class="key-tag">模型: ${s.cloudReady ? '☁️ ' + escapeHtml(s.cloudProviderName) + ' / ' + escapeHtml(s.cloudModel) : '❌ 未选择'}</span>`
          : `<span class="key-tag">模型: ${modelReady ? '✅ ' + fmtBytes(s.modelSize) + '（约 ' + fmtBytes(s.modelApprox) + '）' : '❌ 未下载'}</span><span class="key-tag">引擎: ${engineReady ? '✅' : '❌ 未下载'}</span>`}
        ${s.backend === 'llama' ? `<span class="key-tag">端口 ${s.port}</span>` : ''}
      </div>
      ${s.lastError ? `<div style="color: var(--red); font-size: 12px; margin-top: 6px;">⚠ ${escapeHtml(s.lastError)}</div>` : ''}
      ${progressBar}
      <div style="display: flex; gap: 8px; margin-top: 10px; flex-wrap: wrap;">
        ${isCloud
          ? `${!running && s.cloudReady ? `<button class="btn btn-primary" onclick="startLocal()">▶ 启用云端渠道模型</button>` : ''}
             ${running ? `<button class="btn" onclick="stopLocal()">⏹ 停用</button>` : ''}
             ${!s.cloudReady ? `<span style="color: var(--red); font-size: 12px;">⚠ 请先在下方选择云端渠道模型</span>` : ''}`
          : `${s.backend === 'llama' && !engineReady ? `<button class="btn btn-primary" onclick="downloadLocalEngine()">⬇ 下载引擎（约 50MB）</button>` : ''}
             ${!modelReady ? `<button class="btn btn-primary" onclick="downloadLocalModel()">⬇ 下载模型 Q4_K_M（约 4.6GB）</button>` : ''}
             ${!running && engineReady && modelReady ? `<button class="btn btn-primary" onclick="startLocal()">▶ 启动本地引擎</button>` : ''}
             ${running ? `<button class="btn" onclick="stopLocal()">⏹ 停止</button>` : ''}
             ${running ? `<button class="btn" onclick="probeLocalChat()">🧪 引擎自检对话</button>` : ''}`}
      </div>
      <div style="display: flex; gap: 8px; margin-top: 10px; flex-wrap: wrap; align-items: center;">
        <label style="font-size: 13px;">后端
          <select onchange="setLocalBackend(this.value)" style="font-size: 14px; padding: 4px 8px; border-radius: 6px; border: 1px solid #d1d5db;">
            <option value="llama" ${!isCloud && s.backend !== 'ollama' ? 'selected' : ''}>内置 llama.cpp（推荐）</option>
            <option value="ollama" ${s.backend === 'ollama' ? 'selected' : ''}>Ollama（外部）</option>
            <option value="cloud" ${isCloud ? 'selected' : ''}>云端渠道模型</option>
          </select>
        </label>
        <label id="cloudChannelLabel" style="font-size: 13px; ${isCloud ? '' : 'display: none;'}">云端渠道模型
          <select id="cloudChannelSel" onchange="saveCloudChannel(this.value)" style="font-size: 13px; padding: 4px 8px; border-radius: 6px; border: 1px solid #d1d5db;">
            <option value="">选择云端渠道模型...</option>
            ${cloudChannelOpts || '<option value="" disabled>（暂无已添加渠道模型，请先在服务商页添加并获取模型）</option>'}
          </select>
        </label>
        <label style="font-size: 13px; ${isCloud ? 'display: none;' : ''}">线程
          <input type="number" id="localThreads" value="${s.threads || 4}" min="1" max="32" style="width: 60px; font-size: 14px; padding: 4px 8px; border-radius: 6px; border: 1px solid #d1d5db;" />
        </label>
        <label style="font-size: 13px; ${isCloud ? 'display: none;' : ''}">上下文
          <input type="number" id="localCtx" value="${s.ctxSize || 8192}" min="512" step="512" style="width: 80px; font-size: 14px; padding: 4px 8px; border-radius: 6px; border: 1px solid #d1d5db;" />
        </label>
        <button class="btn" onclick="saveLocalTuning()">保存（重启生效）</button>
      </div>
      <div style="display: flex; gap: 10px; margin-top: 10px; flex-wrap: wrap; align-items: center;">
        <span style="font-size: 13px; font-weight: 700;">😴 自动休眠</span>
        <input type="number" id="idleSleepMin" value="${(state.config?.local?.idleSleepMinutes ?? 15)}" min="0" max="1440" style="width: 70px; font-size: 14px; padding: 4px 8px; border-radius: 6px; border: 1px solid #d1d5db;" /> 分钟无请求自动停引擎（0=关闭）
        <label style="font-size: 13px;">请求自动唤醒
          <input type="checkbox" id="autoWakeChk" ${(state.config?.local?.autoWake !== false) ? 'checked' : ''} style="width: 16px; height: 16px; vertical-align: middle;" />
        </label>
        <button class="btn btn-primary" onclick="saveIdleSleep()">保存</button>
        <span style="font-size: 12px; color: var(--text-muted);">休眠后释放约 5-6GB 内存；路由器收到请求时后台自动唤醒（当前请求仍由云端处理，不阻塞）</span>
      </div>
    </div>

      <div class="stripe-title">🧠 路由大脑（本地模型 · 不参与对话回答）</div>
      <p style="font-size: 13px; color: var(--text-3); margin-bottom: 8px;">
        Qwen2.5-7B-Instruct 的定位是<b style="color: var(--blue-primary);">路由器大脑</b>：它定时/事件触发地观察路由状态（渠道健康/熔断/限流、统计、记忆画像、日志），
        诊断问题后<b style="color: var(--blue-primary);">自主调用工具优化路由</b>（切换策略、启停渠道、清缓存、触发探测），输出决策日志。
        它<b>不会</b>出现在对话路由/回退候选里——回答请求永远走云端渠道，本地模型只做路由管理。
      </p>
      <div style="display: flex; gap: 6px; flex-wrap: wrap; align-items: center; margin-bottom: 8px;">
        <span class="key-tag">大脑: <b style="color: ${b.enabled ? 'var(--green)' : 'var(--text-muted)'};">${b.enabled ? '✅ 启用' : '⏸ 停用'}</b></span>
        <span class="key-tag">定时巡检: <b>${b.autoRunning ? '🟢 运行中（每 ' + b.intervalMin + ' 分钟）' : '⚪ 未运行'}</b></span>
        <span class="key-tag">事件唤醒: <b>${b.wakeOnEvents ? '✅' : '❌'}</b></span>
        <span class="key-tag">决策次数: <b>${b.decisionCount}</b></span>
        ${b.lastRunAt ? `<span class="key-tag">上次决策: ${formatTime(b.lastRunAt)}</span>` : ''}
      </div>
      <div style="display: flex; gap: 8px; flex-wrap: wrap; align-items: center;">
        <button class="btn btn-primary" onclick="runBrainNow()" ${b.engineRunning ? '' : 'disabled title="请先启动本地引擎"'}>
          🧠 立即分析并优化${b.engineRunning ? '' : '（需先启动引擎）'}
        </button>
        <label style="font-size: 13px;">自动巡检
          <input type="number" id="brainInterval" value="${b.intervalMin || 15}" min="1" max="1440" style="width: 70px; font-size: 14px; padding: 4px 8px; border-radius: 6px; border: 1px solid #d1d5db;" /> 分钟
        </label>
        <button class="btn" onclick="saveBrainSettings()">保存并应用</button>
        <button class="btn" onclick="toggleBrainEnabled()">${b.enabled ? '停用大脑' : '启用大脑'}</button>
      </div>
      ${(b.history || []).length > 0 ? `
      <div style="margin-top: 10px;">
        <div style="font-size: 13px; color: var(--text-3); margin-bottom: 6px;">决策日志（最近 ${Math.min(b.history.length, 10)} 条 · 含成效追踪）</div>
        <div style="max-height: 260px; overflow-y: auto;">
          ${b.history.slice(0, 10).map(h => {
            const eff = h.effect || 'pending';
            const effLabel = { good: '✅改善', bad: '📉恶化', neutral: '➖持平', insufficient: '⏳样本不足', pending: '⏳待评估' }[eff] || eff;
            const effColor = eff === 'good' ? 'var(--green)' : eff === 'bad' ? 'var(--red)' : 'var(--text-muted)';
            return `
          <div class="log-entry" style="align-items: flex-start; gap: 8px;">
            <div style="min-width: 105px; font-size: 11px; color: var(--text-muted);">${formatTime(h.time)}</div>
            <div style="flex: 1;">
              <div style="font-size: 12px; color: var(--text-3);">触发：${escapeHtml(h.reason)}${h.durationMs ? ' · 用时 ' + Math.round(h.durationMs / 1000) + 's' : ''} <span style="color: ${effColor}; font-weight: 700;">${effLabel}${h.effectDetail ? '（' + escapeHtml(h.effectDetail) + '）' : ''}</span></div>
              ${(h.tools || []).length ? `<div style="font-size: 12px; color: var(--blue-primary); margin: 2px 0;">🔧 ${h.tools.map(t => escapeHtml(t.name) + (t.ok ? '' : ' ✗')).join('，')}</div>` : ''}
              <div style="font-size: 12px; color: var(--text-main); white-space: pre-wrap;">${escapeHtml(h.summary || '').slice(0, 400)}</div>
            </div>
          </div>`;
          }).join('')}
        </div>
      </div>` : '<div style="font-size: 12px; color: var(--text-muted); margin-top: 6px;">暂无决策记录——点击「立即分析并优化」，或等熔断/限流/Key 异常事件自动唤醒</div>'}
      ${(b.lessons || []).length > 0 ? `
      <div style="margin-top: 10px;">
        <div style="font-size: 13px; color: var(--text-3); margin-bottom: 6px;">🧠 积累的经验（自学习沉淀 · 下次决策自动参考）</div>
        ${b.lessons.slice(0, 8).map(l => `
        <div class="log-entry" style="gap: 8px; font-size: 12px;">
          <span>💡</span>
          <span style="font-family: monospace; color: var(--blue-primary);">${escapeHtml(l.action)}</span>
          <span style="flex: 1; color: var(--text-main);">${escapeHtml(l.detail || l.reason || '')}</span>
          <span style="color: var(--text-muted);">×${l.times || 1}</span>
        </div>`).join('')}
      </div>` : ''}
    </div>

    <div class="glass-card" style="margin-bottom: 12px;">
      <div class="stripe-title">🔌 本地模型作为后端（v3.0.2：记忆/智能板块的模型任务可切换用本地）</div>
      <p style="font-size: 13px; color: var(--text-3); margin-bottom: 8px;">
        「智能/记忆」板块里需要模型的三个功能，都可以改用本地 Qwen2.5-7B-Instruct 执行（<b>省云端 token、数据不出本机</b>）。
        ${s.running ? '<b style="color: var(--green);">🟢 本地引擎运行中</b>' : '<b style="color: var(--yellow);">⚪ 本地引擎未运行（auto 模式将自动使用云端）</b>'}
      </p>
      <div class="table-row" style="font-weight: 700; font-size: 13px;">
        <span style="flex: 1;">功能</span>
        <span style="width: 110px;">当前生效</span>
        <span style="width: 200px;">模式</span>
      </div>
      ${['judge', 'smartCompress', 'embed'].map(k => {
        const label = { judge: ['⭐ 质量评分（judge）', 'quality', 'judgeBackend'], smartCompress: ['🗜️ LLM 智能摘要', 'compression', 'smartBackend'], embed: ['🧲 语义缓存嵌入', 'semanticCache', 'embedBackend'] }[k];
        const mode = state.config?.[label[1]]?.[label[2]] || 'auto';
        const eff = mode === 'cloud' ? 'cloud' : (s.running ? 'local' : 'cloud');
        return `
        <div class="table-row" style="font-size: 13px;">
          <span style="flex: 1;">${label[0]}</span>
          <span style="width: 110px; color: ${eff === 'local' ? 'var(--green)' : 'var(--blue-primary)'};">${eff === 'local' ? '🟢 本地 Qwen' : '☁️ 云端'}</span>
          <span style="width: 200px;">
            <select class="select backend-sel" data-sec="${label[1]}" data-key="${label[2]}" style="font-size: 13px; padding: 4px 6px;">
              <option value="auto" ${mode === 'auto' ? 'selected' : ''}>自动</option>
              <option value="local" ${mode === 'local' ? 'selected' : ''}>本地</option>
              <option value="cloud" ${mode === 'cloud' ? 'selected' : ''}>云端</option>
            </select>
          </span>
        </div>`;
      }).join('')}
      <div style="display: flex; gap: 8px; margin-top: 8px; align-items: center;">
        <button class="btn btn-primary" onclick="saveBackendModes()">💾 保存后端模式</button>
        <span style="font-size: 12px; color: var(--text-muted);">自动 = 引擎在跑用本地，关引擎自动回云端（智能页对应设置里也有同样的下拉）</span>
      </div>
    </div>

    <div class="glass-card" style="margin-bottom: 12px;">
      <div class="stripe-title">⚙️ 内置工具集（大脑调路由的“手”）</div>
      <p style="font-size: 13px; color: var(--text-3); margin-bottom: 8px;">
        Qwen2.5-7B-Instruct 原生支持函数调用。对话中模型可自主决定调用这些工具（查看渠道状态/统计/记忆、切换策略、启停渠道、清缓存、触发探测、查日志/成本等），执行结果回填后继续推理——相当于<b style="color: var(--blue-primary);">给模型装上了管理智能路由的“手”</b>。
      </p>
      ${localTools && localTools.tools ? `
      <div style="display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 10px;">
        ${localTools.tools.map(t => `<span class="key-tag" style="font-size: 12px;">🔧 ${escapeHtml(t.function.name)}</span>`).join('')}
      </div>` : ''}
      <div style="display: flex; gap: 8px; flex-wrap: wrap; align-items: center;">
        <select id="toolSelect" style="font-size: 14px; padding: 6px 8px; border-radius: 6px; border: 1px solid #d1d5db;">
          ${localTools && localTools.tools ? localTools.tools.map(t => `<option value="${escapeHtml(t.function.name)}">${escapeHtml(t.function.name)}</option>`).join('') : '<option>（工具集未加载）</option>'}
        </select>
        <input id="toolArgs" placeholder='参数 JSON，如 {"strategy":"weighted"}' style="flex: 1; min-width: 200px; font-size: 14px; padding: 6px 8px; border-radius: 6px; border: 1px solid #d1d5db;" />
        <button class="btn btn-primary" onclick="runLocalTool()">▶ 执行</button>
      </div>
      <pre id="toolResult" style="margin-top: 8px; background: #f8fafc; color: #1f2937; border-radius: 8px; padding: 10px; font-size: 12px; max-height: 260px; overflow: auto; white-space: pre-wrap;">选择工具并填入参数后点击执行，结果在这里显示。</pre>
    </div>

    <div class="glass-card" style="margin-bottom: 12px;">
      <div class="stripe-title">📊 大脑运行情况</div>
      <div id="localCompareTable"></div>
    </div>

    <div class="glass-card">
      <div class="stripe-title">🖥 引擎日志</div>
      <div id="localEngineLog" style="max-height: 200px; overflow-y: auto; font-family: monospace; font-size: 11px; color: var(--text-muted); white-space: pre-wrap;">${escapeHtml(localEngineLogs.slice(-30).join('\n')) || '（启动引擎后这里显示 llama.cpp 输出）'}</div>
    </div>
  `;
}

async function refreshLocal() {
  try {
    localStatus = await api.getLocalStatus();
    localTools = await api.getLocalTools();
    brainStatus = await api.getBrainStatus();
    if (state.currentPage === 'local') renderLocalCompare();
  } catch (e) { console.error('加载本地模型状态失败:', e); }
}

async function runBrainNow() {
  toast('🧠 路由大脑分析中（本地推理约需 1-3 分钟）...', 'info');
  const r = await api.runBrain('手动触发');
  if (r && r.ok) {
    toast('✅ 大脑决策完成：' + (r.summary || '').slice(0, 50), 'success');
  } else {
    toast('大脑运行失败: ' + (r?.error || '未知错误'), 'error');
  }
  refreshLocal();
  renderPage();
}

async function saveBrainSettings() {
  const interval = parseInt(document.getElementById('brainInterval')?.value || '15', 10);
  await api.setBrainConfig({ brainIntervalMin: Math.max(1, interval) });
  toast('巡检间隔已保存并应用', 'success');
  refreshLocal();
  renderPage();
}

async function toggleBrainEnabled() {
  const cur = brainStatus || {};
  await api.setBrainConfig({ brainEnabled: !(cur.enabled !== false) });
  refreshLocal();
  renderPage();
}

// 保存三个功能的模型后端模式（质量评分/摘要/嵌入）
async function saveBackendModes() {
  try {
    const picks = {};
    document.querySelectorAll('.backend-sel').forEach(sel => {
      const sec = sel.dataset.sec;
      const key = sel.dataset.key;
      if (!picks[sec]) picks[sec] = {};
      picks[sec][key] = sel.value;
    });
    for (const [sec, kv] of Object.entries(picks)) {
      await api.setSmart(sec, kv);
    }
    await refreshConfig();
    toast('后端模式已保存（引擎在跑时自动用本地）', 'success');
    renderPage();
  } catch (e) {
    toast('保存失败: ' + e.message, 'error');
  }
}

async function renderLocalCompare() {
  try {
    const b = brainStatus || {};
    const h = b.history || [];
    const toolsUsed = {};
    for (const e of h) { for (const t of e.tools || []) { toolsUsed[t.name] = (toolsUsed[t.name] || 0) + 1; } }
    const el = document.getElementById('localCompareTable');
    if (!el) return;
    const totalTools = Object.values(toolsUsed).reduce((a, b) => a + b, 0);
    el.innerHTML = `
      <div class="table-row" style="font-size: 13px;">
        <span style="flex: 1;">大脑决策 ${b.decisionCount || 0} 次</span>
        <span style="width: 130px;">工具调用 ${totalTools} 次</span>
        <span style="width: 130px;">自动巡检 ${b.autoRunning ? '运行中' : '关闭'}</span>
        <span style="width: 130px;">引擎 ${b.engineRunning ? '🟢' : '⚪'}</span>
      </div>
      ${Object.entries(toolsUsed).length ? `<div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">常用工具：${Object.entries(toolsUsed).map(([n, c]) => `${n}×${c}`).join('，')}</div>` : '<div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">大脑尚未调用过工具</div>'}
      <div style="font-size: 11px; color: var(--text-muted); margin-top: 6px;">说明：本地模型不参与对话回答，只作为路由大脑管理路由；回答请求全部走云端渠道。</div>
    `;
  } catch (e) {
    const el = document.getElementById('localCompareTable');
    if (el) el.innerHTML = '<div class="empty-state-text">加载失败</div>';
  }
}

async function downloadLocalEngine() {
  toast('开始下载 llama.cpp 引擎...', 'info');
  const r = await api.downloadLocalEngine();
  toast(r.ok ? '引擎下载完成 ✅' : '引擎下载失败: ' + r.error, r.ok ? 'success' : 'error');
  refreshLocal();
  renderPage();
}

async function downloadLocalModel() {
  if (!confirm('将下载 Qwen2.5-7B-Instruct Q4_K_M（约 4.6GB）到本机，断点续传。确定开始？')) return;
  toast('开始下载模型（可后台进行）...', 'info');
  const r = await api.downloadLocalModel();
  toast(r.ok ? '模型下载完成 ✅ 可以启动了' : '模型下载失败: ' + r.error, r.ok ? 'success' : 'error');
  refreshLocal();
  renderPage();
}

async function startLocal() {
  toast('正在启动本地引擎（7B 模型加载约需 10-30 秒）...', 'info');
  const r = await api.startLocal();
  toast(r.ok ? '本地引擎已就绪 🟢' : '启动失败: ' + (r.error || '未知错误'), r.ok ? 'success' : 'error');
  refreshLocal();
  renderPage();
}

async function stopLocal() {
  await api.stopLocal();
  toast('本地引擎已停止', 'info');
  refreshLocal();
  renderPage();
}

async function probeLocalChat() {
  try {
    const port = localStatus?.port || 11435;
    const r = await fetch('http://localhost:' + port + '/v1/chat/completions', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: 'qwen', messages: [{ role: 'user', content: '你好，用一句话介绍你自己' }], max_tokens: 64 })
    });
    if (!r.ok) { toast('引擎响应异常 HTTP ' + r.status, 'error'); return; }
    const d = await r.json();
    toast('✅ ' + (d.choices?.[0]?.message?.content || '').slice(0, 60), 'success');
  } catch (e) { toast('测试失败: ' + e.message, 'error'); }
}

async function setLocalBackend(v) {
  const payload = { backend: v };
  const sel = document.getElementById('cloudChannelSel');
  if (v === 'cloud' && sel) payload.cloudChannel = sel.value || null;
  await api.setLocalConfig(payload);
  await refreshConfig();
  refreshLocal();
  renderPage();
  if (v === 'cloud' && !payload.cloudChannel) {
    toast('已切换到云端渠道模型，请选择具体渠道与模型', 'info');
  }
}

/** 选择/清除「云端渠道模型」（值格式 providerId||model） */
async function saveCloudChannel(v) {
  await api.setLocalConfig({ cloudChannel: v || null });
  await refreshConfig();
  refreshLocal();
  renderPage();
  toast(v ? '已选择云端渠道模型' : '已清除云端渠道模型', 'success');
}

async function saveLocalTuning() {
  const threads = parseInt(document.getElementById('localThreads')?.value || '4', 10);
  const ctx = parseInt(document.getElementById('localCtx')?.value || '8192', 10);
  await api.setLocalConfig({ threads, ctxSize: ctx });
  toast('已保存，下次启动生效', 'success');
  refreshLocal();
}

async function saveIdleSleep() {
  const min = parseInt(document.getElementById('idleSleepMin')?.value || '15', 10);
  const autoWake = document.getElementById('autoWakeChk')?.checked !== false;
  await api.setLocalConfig({ idleSleepMinutes: Math.max(0, min), autoWake });
  await refreshConfig();
  toast(min > 0 ? `已保存：空闲 ${min} 分钟自动休眠，请求自动唤醒` : '已保存：关闭自动休眠', 'success');
  refreshLocal();
  renderPage();
}

async function runLocalTool() {
  const name = document.getElementById('toolSelect')?.value;
  const args = document.getElementById('toolArgs')?.value || '';
  if (!name) { toast('请选择工具', 'error'); return; }
  const el = document.getElementById('toolResult');
  el.textContent = '执行中...';
  const r = await api.runLocalTool(name, args);
  el.textContent = JSON.stringify(r, null, 2);
}

// ===== 日志页面（Trace 回放） =====
let logFilter = {};

function renderLogs() {
  return `
    <div class="glass-card" style="margin-bottom: 12px;">
      <div class="stripe-title">📜 Trace 调用日志（可观测性）</div>
      <div style="display: flex; gap: 8px; flex-wrap: wrap; align-items: center;">
        <input class="input" id="logFilterModel" placeholder="模型过滤" value="${escapeAttr(logFilter.model || '')}" style="max-width: 140px;">
        <input class="input" id="logFilterProvider" placeholder="服务商过滤" value="${escapeAttr(logFilter.provider || '')}" style="max-width: 140px;">
        <select class="select" id="logFilterStatus" style="max-width: 110px;">
          <option value="">全部状态</option>
          <option value="success" ${logFilter.status === 'success' ? 'selected' : ''}>成功</option>
          <option value="failed" ${logFilter.status === 'failed' ? 'selected' : ''}>失败</option>
          <option value="blocked" ${logFilter.status === 'blocked' ? 'selected' : ''}>被拦截</option>
        </select>
        <select class="select" id="logFilterCached" style="max-width: 120px;">
          <option value="">全部缓存</option>
          <option value="1" ${logFilter.cached === '1' ? 'selected' : ''}>仅缓存命中</option>
          <option value="0" ${logFilter.cached === '0' ? 'selected' : ''}>仅真实调用</option>
        </select>
        <label style="color: rgba(31, 41, 55, 0.85); font-size: 12px; display: flex; align-items: center; gap: 4px;">
          <input type="checkbox" id="logFilterQualityLow" ${logFilter.qualityLow ? 'checked' : ''}> 仅低质量(&lt;60)
        </label>
        <button class="btn btn-primary" onclick="applyLogFilter()">查询</button>
        <button class="btn" onclick="resetLogFilter()">重置</button>
        <button class="btn btn-yellow" onclick="exportLogs()">⬇ 导出</button>
        <button class="btn btn-danger" onclick="clearLogsNow()">清空</button>
      </div>
    </div>
    <div id="logListBox"><div class="glass-card"><div class="empty-state-text">加载中...</div></div></div>
  `;
}

async function loadLogs() {
  const box = document.getElementById('logListBox');
  if (!box) return;
  try {
    const logs = await api.getLogs({ ...logFilter, limit: 300 });
    if (logs.length === 0) {
      box.innerHTML = '<div class="glass-card"><div class="empty-state-text">暂无日志（有请求后自动记录）</div></div>';
      return;
    }
    box.innerHTML = `
      <div class="glass-card">
        <div style="font-size: 12px; color: rgba(31, 41, 55, 0.75); margin-bottom: 8px;">共 ${logs.length} 条（最近 ${logFilter.limit || 300} 条内）</div>
        ${logs.map(l => `
          <div class="log-entry" style="cursor: pointer;" onclick="showLogDetail('${l.traceId}')">
            <span class="log-time">${formatTime(l.time)}</span>
            <span class="log-status ${l.status === 'success' ? 'success' : 'failed'}">${l.status === 'success' ? '✓' : l.status === 'blocked' ? '⛔' : '✕'} ${l.status}</span>
            <span style="color: rgba(31, 41, 55, 0.92); font-family: monospace;">${escapeHtml(l.model || '--')}</span>
            <span style="color: var(--blue-sky);">→ ${escapeHtml(l.provider || '--')}</span>
            ${l.switched ? '<span class="badge badge-switched">⚡切换</span>' : ''}
            ${l.cached ? `<span class="badge badge-healthy">💾${l.cacheType === 'semantic' ? '语义' : '缓存'}</span>` : ''}
            ${l.qualityScore != null ? `<span style="color: ${l.qualityScore >= 60 ? 'var(--green)' : 'var(--red)'};">质量 ${l.qualityScore}</span>` : ''}
            ${l.cost ? `<span style="color: var(--yellow);">${fmtPrice(l.cost, state.currency)}</span>` : ''}
            ${l.latency ? `<span style="color: rgba(31, 41, 55, 0.75);">${l.latency}ms</span>` : ''}
            ${l.error ? `<span style="color: var(--red);">${escapeHtml(String(l.error).slice(0, 60))}</span>` : ''}
          </div>
        `).join('')}
      </div>
    `;
  } catch (e) {
    box.innerHTML = '<div class="glass-card"><div class="empty-state-text">加载失败: ' + escapeHtml(e.message) + '</div></div>';
  }
}

function applyLogFilter() {
  logFilter = {
    model: document.getElementById('logFilterModel').value.trim(),
    provider: document.getElementById('logFilterProvider').value.trim(),
    status: document.getElementById('logFilterStatus').value,
    cached: document.getElementById('logFilterCached').value,
    qualityLow: document.getElementById('logFilterQualityLow').checked
  };
  loadLogs();
}

function resetLogFilter() {
  logFilter = {};
  renderPage();
}

async function exportLogs() {
  try {
    const logs = await api.exportLogs();
    const blob = new Blob([JSON.stringify(logs, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `trace-logs-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast(`已导出 ${logs.length} 条日志`, 'success');
  } catch (e) {
    toast('导出失败: ' + e.message, 'error');
  }
}

async function clearLogsNow() {
  if (!confirm('确定清空全部 Trace 日志？')) return;
  try {
    await api.clearLogs();
    toast('日志已清空', 'success');
    loadLogs();
  } catch (e) {
    toast('清空失败: ' + e.message, 'error');
  }
}

async function showLogDetail(traceId) {
  try {
    const logs = await api.getLogs({ limit: 1000 });
    const l = logs.find(x => x.traceId === traceId);
    if (!l) { toast('未找到该日志', 'error'); return; }
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.innerHTML = `
      <div class="modal" style="width: 640px;">
        <div class="modal-title">📜 Trace 详情 <span style="font-size: 12px; color: rgba(31, 41, 55, 0.65); font-family: monospace;">${l.traceId}</span></div>
        <div style="font-size: 13px; line-height: 2; color: rgba(31, 41, 55, 0.95); word-break: break-all;">
          <div>⏰ 时间: ${escapeHtml(l.time || '--')}</div>
          <div>🎯 请求模型: ${escapeHtml(l.requestedModel || l.model || '--')} ${l.model !== l.requestedModel ? `→ 实际: <b style="color: var(--yellow);">${escapeHtml(l.model)}</b>` : ''}</div>
          <div>🏢 服务商: ${escapeHtml(l.provider || '--')} ${l.providerId ? `<span style="font-size: 11px; color: rgba(31, 41, 55, 0.55);">(${escapeHtml(l.providerId)})</span>` : ''}</div>
          <div>🛤️ 策略: ${escapeHtml(l.strategy || '--')} ${l.abGroup ? `· A/B 分组: <b>${escapeHtml(l.abGroup)}</b>` : ''}</div>
          <div>📶 状态: ${l.status} ${l.switched ? '· ⚡ 已切换' : ''} ${l.cached ? `· 💾 缓存(${escapeHtml(l.cacheType || 'exact')})` : ''}</div>
          ${l.similarity != null ? `<div>🧲 语义相似度: ${l.similarity}</div>` : ''}
          <div>⏱️ 延迟: ${l.latency != null ? l.latency + 'ms' : '--'} · 💲 成本: ${fmtPrice(l.cost || 0, state.currency)} · 🔤 Tokens: ${l.usageTokens || 0}</div>
          ${l.compressed ? `<div>🗜️ 已压缩：节省 <b style="color: var(--green);">${l.savedTokens || 0}</b> tokens（${escapeHtml(l.compressionMode || 'heuristic')}）</div>` : ''}
          ${l.qualityScore != null ? `<div>⭐ 质量分: <b style="color: ${l.qualityScore >= 60 ? 'var(--green)' : 'var(--red)'};">${l.qualityScore}</b></div>` : ''}
          ${l.shadow ? `<div>👻 影子对比: 实际=${escapeHtml(l.shadow.actual || '--')} / 加权首选=${escapeHtml(l.shadow.weightedFirst || '--')} ${l.shadow.same ? '<span style="color: var(--green);">(一致)</span>' : '<span style="color: var(--yellow);">(不一致，可考虑调策略)</span>'}</div>` : ''}
          ${l.error ? `<div style="color: var(--red);">❌ 错误: ${escapeHtml(l.error)}</div>` : ''}
        </div>
        <div class="modal-actions">
          <button class="btn" onclick="this.closest('.modal-overlay').remove()">关闭</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
    modal.addEventListener('click', (e) => { if (e.target === modal) modal.remove(); });
  } catch (e) {
    toast('加载详情失败: ' + e.message, 'error');
  }
}

// ===== 预设渠道商（一键添加主流模型商） =====
let providerPresets = [];

async function loadPresets() {
  try {
    providerPresets = await api.getPresets();
  } catch (e) {
    providerPresets = [];
    console.error('加载预设失败:', e);
  }
}

async function openPresetsModal() {
  if (providerPresets.length === 0) await loadPresets();
  const modal = document.createElement('div');
  modal.className = 'modal-overlay';
  modal.id = 'presetsModal';
  const regionBadge = (r) => {
    const map = { CN: ['badge-warning', '🇨🇳 国内'], US: ['badge-healthy', '🇺🇸 海外'], EU: ['badge-healthy', '🇪🇺 欧洲'], any: ['badge-disabled', '🌐 本地/不限'] };
    const [cls, label] = map[r] || map.any;
    return `<span class="badge ${cls}">${label}</span>`;
  };
  modal.innerHTML = `
    <div class="modal" style="width: 680px;">
      <div class="modal-title">📋 预设渠道商（一键添加，再填入 API Key 即可）</div>
      <p style="font-size: 12px; color: rgba(31, 41, 55, 0.75); margin-bottom: 12px;">已添加的预设会自动填充 Base URL / 模型列表 / 数据驻留区域；每个渠道只需填入对应服务商的 API Key。</p>
      <div style="max-height: 55vh; overflow-y: auto;">
        ${providerPresets.map(p => `
          <div class="table-row" style="flex-wrap: wrap;">
            <div style="flex: 1; min-width: 200px;">
              <div style="color: var(--text-main); font-weight: 600; font-size: 14px;">${escapeHtml(p.name)} ${regionBadge(p.region)}</div>
              <div style="font-size: 11px; color: rgba(31, 41, 55, 0.75); font-family: monospace;">${escapeHtml(p.baseUrl)}</div>
              <div style="font-size: 11px; color: rgba(31, 41, 55, 0.6); margin-top: 2px;">${escapeHtml(p.note || '')}${p.models.length ? ` · 预设 ${p.models.length} 个模型` : ' · 模型留空（添加后一键获取）'}</div>
            </div>
            <button class="btn btn-primary btn-sm" onclick="addFromPreset('${escapeAttr(p.name)}')">+ 添加</button>
          </div>
        `).join('')}
      </div>
      <div class="modal-actions">
        <button class="btn" onclick="closePresetsModal()">关闭</button>
      </div>
    </div>
  `;
  document.body.appendChild(modal);
  modal.addEventListener('click', (e) => { if (e.target === modal) closePresetsModal(); });
}

function closePresetsModal() {
  const modal = document.getElementById('presetsModal');
  if (modal) modal.remove();
}

async function addFromPreset(name) {
  const preset = providerPresets.find(p => p.name === name);
  if (!preset) return;
  try {
    await api.addProvider({
      name: preset.name,
      baseUrl: preset.baseUrl,
      keys: [],
      models: [...(preset.models || [])],
      enabled: true,
      region: preset.region || 'any'
    });
    toast(`已添加「${preset.name}」，请点击编辑填入 API Key`, 'success');
    await refreshConfig();
    renderPage();
  } catch (e) {
    toast('添加失败: ' + e.message, 'error');
  }
}

// ===== 模态框 =====
function openProviderModal(providerId = null) {
  const provider = providerId ? state.config.providers.find(p => p.id === providerId) : null;
  state.editingProvider = providerId;

  const modal = document.createElement('div');
  modal.className = 'modal-overlay';
  modal.id = 'providerModal';
  modal.innerHTML = `
    <div class="modal">
      <div class="modal-title">${provider ? '编辑服务商' : '添加服务商'}</div>
      <div class="form-group">
        <label class="label">服务商名称</label>
        <input class="input" id="pName" value="${provider?.name || ''}" placeholder="例如：OpenAI / DeepSeek / 本地Ollama">
      </div>
      <div class="form-group">
        <label class="label">Base URL（基础地址）</label>
        <input class="input" id="pUrl" value="${provider?.baseUrl || ''}" placeholder="例如：https://api.openai.com">
        <p style="color: rgba(31, 41, 55, 0.85); font-size: 11px; margin-top: 4px;">
          不需要加 /v1 后缀，系统会自动拼接
        </p>
      </div>
      <div class="form-group">
        <label class="label">API Keys（每行一个，支持同URL多Key）</label>
        <textarea class="textarea" id="pKeys" placeholder="sk-xxxxxxxxxxxxx&#10;sk-yyyyyyyyyyyyy" style="min-height: 100px; font-family: monospace;">${provider?.keys?.join('\n') || ''}</textarea>
        <p style="color: rgba(31, 41, 55, 0.85); font-size: 11px; margin-top: 4px;">
          支持输入多个 Key，每行一个。系统会自动轮换使用，连续出错 3 次自动禁用，健康检测通过后自动恢复。
        </p>
      </div>
      <div class="form-group">
        <label class="label">模型列表（每行一个，可留空后自动获取）</label>
        <textarea class="textarea" id="pModels" placeholder="gpt-4&#10;gpt-3.5-turbo" style="min-height: 80px; font-family: monospace;">${provider?.models?.join('\n') || ''}</textarea>
        <button class="btn btn-yellow" id="btnFetchModels" style="margin-top: 8px; width: 100%; justify-content: center;" onclick="fetchModelsInModal()">
          <span>⚡</span>
          <span>一键获取模型</span>
        </button>
      </div>
      <div class="form-group">
        <label class="label">启用状态</label>
        <div class="toggle ${(!provider || provider.enabled !== false) ? 'active' : ''}" id="pEnabled" onclick="this.classList.toggle('active')">
          <div class="toggle-knob"></div>
        </div>
      </div>
      <div class="form-group">
        <label class="label">计费方式（不同模型商计费方式不同）</label>
        <select class="select" id="pBillingMode" onchange="toggleBillingFields()">
          <option value="tokens" ${(!provider?.billing || provider.billing.mode !== 'count') ? 'selected' : ''}>按 Tokens 计费（配合设置页价格表）</option>
          <option value="count" ${provider?.billing?.mode === 'count' ? 'selected' : ''}>按调用次数计费（固定单价/次）</option>
        </select>
      </div>
      <div class="form-group" id="pPricePerCallGroup" style="${provider?.billing?.mode === 'count' ? '' : 'display:none;'}">
        <label class="label">单次调用价格（USD，每成功一次调用计费一次）</label>
        <input class="input" id="pPricePerCall" type="number" step="0.0001" min="0" value="${provider?.billing?.pricePerCall || ''}" placeholder="例如 0.002">
      </div>
      <div class="form-group">
        <label class="label">数据驻留区域（配合「智能」页区域白名单，如 CN/US/EU，any=不限）</label>
        <input class="input" id="pRegion" value="${escapeAttr(provider?.region || 'any')}" placeholder="any / CN / US / EU">
      </div>
      <div class="form-group">
        <label class="label">接口路径模式（预设已自动填好，手动添加时注意）</label>
        <select class="select" id="pPathStyle">
          <option value="v1" ${(!provider?.pathStyle || provider.pathStyle !== 'none') ? 'selected' : ''}>标准：自动拼接 /v1（OpenAI/DeepSeek/Agnes 等）</option>
          <option value="none" ${provider?.pathStyle === 'none' ? 'selected' : ''}>完整路径：Base URL 已含前缀（智谱 /api/paas/v4、千帆 /v2、Groq /openai/v1、Gemini /v1beta/openai）</option>
        </select>
      </div>
      <div class="form-group">
        <label class="label">渠道类型（v3.0.2）</label>
        <select class="select" id="pKind" onchange="toggleLocalKind()">
          <option value="remote" ${provider?.kind !== 'local' ? 'selected' : ''}>云端渠道（OpenAI 兼容 API，需 Base URL + Key）</option>
          <option value="local" ${provider?.kind === 'local' ? 'selected' : ''}>本地模型（内置 Qwen2.5-7B-Instruct 引擎，无需 Key）</option>
        </select>
      </div>
      <div class="form-group" id="pLocalModelsGroup" style="${provider?.kind === 'local' ? '' : 'display:none;'}">
        <label class="label">本地模型名（路由/测试页使用，默认 Qwen2.5-7B-Instruct）</label>
        <input class="input" id="pLocalModels" value="${escapeAttr((provider?.kind === 'local' && provider.models) ? provider.models.join(',') : 'Qwen2.5-7B-Instruct')}" placeholder="Qwen2.5-7B-Instruct">
      </div>
      <div class="modal-actions">
        <button class="btn" onclick="closeProviderModal()">取消</button>
        ${provider ? `<button class="btn btn-yellow" onclick="saveProviderAndFetch()">保存并获取模型</button>` : ''}
        <button class="btn btn-primary" onclick="saveProvider()">保存</button>
      </div>
    </div>
  `;
  document.body.appendChild(modal);
  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeProviderModal();
  });
}

function closeProviderModal() {
  const modal = document.getElementById('providerModal');
  if (modal) modal.remove();
  state.editingProvider = null;
}

// 计费方式切换：显示/隐藏"单次调用价格"输入
function toggleBillingFields() {
  const mode = document.getElementById('pBillingMode')?.value;
  const group = document.getElementById('pPricePerCallGroup');
  if (group && mode) {
    group.style.display = mode === 'count' ? '' : 'none';
  }
}

async function saveProvider(andFetch = false) {
  const name = document.getElementById('pName').value.trim();
  const baseUrl = document.getElementById('pUrl').value.trim();
  const keys = document.getElementById('pKeys').value.split('\n').map(k => k.trim()).filter(k => k);
  const models = document.getElementById('pModels').value.split('\n').map(m => m.trim()).filter(m => m);
  const enabled = document.getElementById('pEnabled').classList.contains('active');
  const billingMode = document.getElementById('pBillingMode')?.value || 'tokens';
  const pricePerCall = parseFloat(document.getElementById('pPricePerCall')?.value) || 0;
  const billing = billingMode === 'count'
    ? { mode: 'count', pricePerCall }
    : { mode: 'tokens', pricePerCall: 0 };
  const region = document.getElementById('pRegion')?.value.trim().toUpperCase() || 'any';
  const pathStyle = document.getElementById('pPathStyle')?.value || 'v1';
  const kind = document.getElementById('pKind')?.value || 'remote';
  let modelsFinal = models;
  if (kind === 'local') {
    // 本地渠道：用本地模型名列表，无需 Key/Base URL
    const localModels = (document.getElementById('pLocalModels')?.value || 'Qwen2.5-7B-Instruct').split(',').map(m => m.trim()).filter(m => m);
    modelsFinal = localModels;
  }

  if (!name) { toast('请输入服务商名称', 'error'); return; }
  if (kind !== 'local' && !baseUrl) { toast('请输入 Base URL', 'error'); return; }
  if (billing.mode === 'count' && pricePerCall <= 0) { toast('按次数计费请填写单次调用价格', 'error'); return; }

  const data = { name, baseUrl, keys, models: modelsFinal, enabled, billing, region, pathStyle, kind };

  try {
    if (state.editingProvider) {
      await api.updateProvider(state.editingProvider, data);
      toast('服务商已更新', 'success');
    } else {
      await api.addProvider(data);
      toast('服务商已添加', 'success');
    }

    if (andFetch && state.editingProvider) {
      closeProviderModal();
      await refreshConfig();
      await fetchModels(state.editingProvider);
      return;
    }

    closeProviderModal();
    await refreshConfig();
    renderPage();
  } catch (e) {
    toast('保存失败: ' + e.message, 'error');
  }
}

function saveProviderAndFetch() {
  saveProvider(true);
}

// 渠道类型切换：本地渠道显示本地模型名输入，隐藏云端字段提示
function toggleLocalKind() {
  const kind = document.getElementById('pKind')?.value;
  const group = document.getElementById('pLocalModelsGroup');
  if (group) group.style.display = kind === 'local' ? '' : 'none';
  const urlGroup = document.getElementById('pUrl')?.closest('.form-group');
  const keysGroup = document.getElementById('pKeys')?.closest('.form-group');
  if (kind === 'local') {
    if (urlGroup) urlGroup.style.display = 'none';
    if (keysGroup) keysGroup.style.display = 'none';
  } else {
    if (urlGroup) urlGroup.style.display = '';
    if (keysGroup) keysGroup.style.display = '';
  }
}

// 一键添加本地渠道已移除（v3.0.2：本地模型定位为路由大脑，不参与对话路由）

// 在弹窗内一键获取模型（先保存，再拉取，填入文本框）
async function fetchModelsInModal() {
  const name = document.getElementById('pName').value.trim();
  const baseUrl = document.getElementById('pUrl').value.trim();
  if (!name) { toast('请先输入服务商名称', 'error'); return; }
  if (!baseUrl) { toast('请先输入 Base URL', 'error'); return; }

  const btn = document.getElementById('btnFetchModels');
  if (btn) {
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span><span>正在获取...</span>';
  }

  try {
    const keys = document.getElementById('pKeys').value.split('\n').map(k => k.trim()).filter(k => k);
    const models = document.getElementById('pModels').value.split('\n').map(m => m.trim()).filter(m => m);
    const enabled = document.getElementById('pEnabled').classList.contains('active');
    const billingMode = document.getElementById('pBillingMode')?.value || 'tokens';
    const pricePerCall = parseFloat(document.getElementById('pPricePerCall')?.value) || 0;
    const billing = billingMode === 'count'
      ? { mode: 'count', pricePerCall }
      : { mode: 'tokens', pricePerCall: 0 };
    const region = document.getElementById('pRegion')?.value.trim().toUpperCase() || 'any';
    const pathStyle = document.getElementById('pPathStyle')?.value || 'v1';
    const kind = document.getElementById('pKind')?.value || 'remote';
    let modelsFinal = models;
    if (kind === 'local') {
      const localModels = (document.getElementById('pLocalModels')?.value || 'Qwen2.5-7B-Instruct').split(',').map(m => m.trim()).filter(m => m);
      modelsFinal = localModels;
    }
    const data = { name, baseUrl, keys, models: modelsFinal, enabled, billing, region, pathStyle, kind };

    let providerId = state.editingProvider;
    if (providerId) {
      await api.updateProvider(providerId, data);
    } else {
      const p = await api.addProvider(data);
      providerId = p.id;
      state.editingProvider = providerId;
    }

    toast('正在获取模型列表...', 'info');
    const fetchedModels = await api.fetchModels(providerId);

    if (fetchedModels && fetchedModels.length > 0) {
      document.getElementById('pModels').value = fetchedModels.join('\n');
      toast(`成功获取 ${fetchedModels.length} 个模型`, 'success');
    } else {
      toast('未获取到模型，请检查 URL 和 Key', 'error');
    }

    await refreshConfig();
  } catch (e) {
    toast('获取失败: ' + e.message, 'error');
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.innerHTML = '<span>⚡</span><span>一键获取模型</span>';
    }
  }
}

// ===== 操作函数 =====
async function removeProvider(id) {
  if (!confirm('确定删除此服务商？')) return;
  try {
    await api.removeProvider(id);
    toast('服务商已删除', 'success');
    await refreshConfig();
    renderPage();
  } catch (e) {
    toast('删除失败: ' + e.message, 'error');
  }
}

async function fetchModels(providerId) {
  toast('正在获取模型列表...', 'info');
  try {
    const models = await api.fetchModels(providerId);
    toast(`成功获取 ${models.length} 个模型`, 'success');
    await refreshConfig();
    renderPage();
  } catch (e) {
    toast('获取模型失败: ' + e.message, 'error');
  }
}

async function fetchAllModels() {
  toast('正在批量获取模型...', 'info');
  try {
    const results = await api.fetchAllModels();
    const success = Object.values(results).filter(r => r.success).length;
    const fail = Object.values(results).filter(r => !r.success).length;
    toast(`获取完成: ${success} 成功, ${fail} 失败`, success > 0 ? 'success' : 'error');
    await refreshConfig();
    renderPage();
  } catch (e) {
    toast('批量获取失败: ' + e.message, 'error');
  }
}

async function saveRouting() {
  const routing = {
    strategy: document.getElementById('routingStrategy').value,
    maxRetries: parseInt(document.getElementById('maxRetries').value) || 3,
    timeout: (parseInt(document.getElementById('timeout').value) || 30) * 1000,
    healthCheckInterval: parseInt(document.getElementById('healthInterval').value) || 5,
    failover: document.getElementById('failoverToggle').classList.contains('active'),
    fallback: document.getElementById('fallbackToggle').classList.contains('active'),
    circuitBreaker: {
      enabled: document.getElementById('cbEnabled').classList.contains('active'),
      threshold: parseInt(document.getElementById('cbThreshold').value) || 5,
      cooldownMs: (parseInt(document.getElementById('cbCooldown').value) || 60) * 1000
    },
    quota: {
      enabled: document.getElementById('quotaEnabled').classList.contains('active'),
      period: document.getElementById('quotaPeriod').value,
      limits: {}
    },
    costOptimization: {
      enabled: document.getElementById('costEnabled').classList.contains('active'),
      preferCheapest: document.getElementById('costPreferCheapest').classList.contains('active')
    },
    abTest: {
      enabled: document.getElementById('abEnabled').classList.contains('active'),
      groups: []
    }
  };

  // 配额限额
  document.querySelectorAll('[data-quota-provider]').forEach(input => {
    const pid = input.dataset.quotaProvider;
    const type = input.dataset.quotaType;
    let val = parseFloat(input.value) || 0;
    if (type === 'tokens') val = Math.round(val * 1000000); // 存为 tokens 数
    if (!routing.quota.limits[pid]) routing.quota.limits[pid] = {};
    routing.quota.limits[pid][type] = val;
  });

  // A/B 分组
  const abText = document.getElementById('abGroups').value;
  abText.split('\n').map(l => l.trim()).filter(l => l).forEach(line => {
    const [head, weightStr] = line.split(':');
    const eqIdx = head.indexOf('=');
    if (eqIdx === -1) return;
    const name = head.substring(0, eqIdx).trim();
    const model = head.substring(eqIdx + 1).trim();
    if (!name || !model) return;
    const w = parseInt(weightStr);
    routing.abTest.groups.push({ name, model, weight: Number.isFinite(w) ? w : 100 });
  });

  try {
    const config = await api.getConfig();
    const oldInterval = config.routing?.healthCheckInterval;
    config.routing = routing;
    await api.saveConfig(config);
    state.config = config;
    toast('路由配置已保存', 'success');
    if (routing.healthCheckInterval !== oldInterval) {
      await api.restartHealthChecker();
      toast('健康检测间隔已更新', 'success');
    }
  } catch (e) {
    toast('保存失败: ' + e.message, 'error');
  }
}

async function moveProvider(id, direction) {
  const providers = state.config.providers;
  const idx = providers.findIndex(p => p.id === id);
  const newIdx = idx + direction;
  if (newIdx < 0 || newIdx >= providers.length) return;

  const tmp = providers[idx].priority;
  providers[idx].priority = providers[newIdx].priority;
  providers[newIdx].priority = tmp;

  providers.sort((a, b) => (a.priority || 0) - (b.priority || 0));

  const config = { ...state.config, providers };
  await api.saveConfig(config);
  state.config = config;
  renderPage();
  toast('优先级已调整', 'success');
}

async function runHealthCheckNow() {
  const spinner = document.getElementById('healthCheckSpinner');
  if (spinner) spinner.innerHTML = '<span class="spinner"></span>';
  toast('正在执行健康检测...', 'info');
  try {
    state.healthStatus = await api.runHealthCheck();
    toast('健康检测完成', 'success');
    renderPage();
  } catch (e) {
    toast('检测失败: ' + e.message, 'error');
  }
}

async function checkSingleProvider(id) {
  toast('正在检测...', 'info');
  try {
    const result = await api.checkProvider(id);
    state.healthStatus[id] = result;
    renderPage();
  } catch (e) {
    toast('检测失败: ' + e.message, 'error');
  }
}

// ===== 测试控制台 =====
let chatHistory = [];

async function sendTestMessage() {
  api.trackFeature('test_page', { detail: 'chat' }).catch(() => {});
  const mode = document.getElementById('testMode')?.value || 'chat';
  if (mode === 'image') return sendImageGeneration();
  if (mode === 'video') return sendVideoGeneration();

  const input = document.getElementById('chatInput');
  const modelSelect = document.getElementById('testModel');
  const streamCheckbox = document.getElementById('testStream');
  const message = input.value.trim();

  if (!message) return;
  if (!modelSelect.value) {
    toast('请先选择模型', 'error');
    return;
  }

  const model = modelSelect.value;
  const stream = streamCheckbox.checked;

  addChatMessage('user', message);
  input.value = '';

  const assistantEl = addChatMessage('assistant', '<span class="spinner"></span> 思考中...');

  const messages = [...chatHistory, { role: 'user', content: message }];
  chatHistory.push({ role: 'user', content: message });

  try {
    const sendBtn = document.getElementById('testSendBtn');
    const sendBtn2 = document.getElementById('testSendBtn2');
    if (sendBtn) sendBtn.disabled = true;
    if (sendBtn2) sendBtn2.disabled = true;

    if (stream) {
      // 流式输出 - 通过代理服务器（可读取 X-Router-* 头）
      const port = state.config?.proxyPort || 3456;
      const response = await fetch(`http://localhost:${port}/v1/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer any'
        },
        body: JSON.stringify({ model, messages, stream: true })
      });

      if (!response.ok) {
        const err = await response.text();
        throw new Error(err);
      }

      // 切换提示（流式）
      const switched = response.headers.get('X-Router-Switched');
      const cacheHit = ['HIT', 'SEMANTIC-HIT'].includes(response.headers.get('X-Router-Cache'));
      const decode = (v) => { try { return v ? decodeURIComponent(v) : null; } catch { return v; } };
      const actualModel = decode(response.headers.get('X-Router-Model'));
      const provider = decode(response.headers.get('X-Router-Provider'));
      if (cacheHit) {
        toast('💾 缓存命中（未调用上游 API）', 'success');
        assistantEl.insertAdjacentHTML('beforebegin', '<div class="chat-msg system"><span class="switch-note" style="color: var(--green); border-color: var(--green);">💾 缓存命中（零成本）</span></div>');
      }
      if (switched === '1' || (switched && switched !== '0')) {
        toast(`⚡ 自动切换: ${model} → ${actualModel} (服务商: ${provider})`, 'info');
        assistantEl.insertAdjacentHTML('beforebegin', `<div class="chat-msg system"><span class="switch-note">⚡ 自动切换: ${escapeHtml(model)} → ${escapeHtml(actualModel)} (服务商: ${escapeHtml(provider)})</span></div>`);
      } else if (actualModel && actualModel !== model) {
        assistantEl.insertAdjacentHTML('beforebegin', `<div class="chat-msg system"><span class="switch-note">⚡ 自动切换: ${escapeHtml(model)} → ${escapeHtml(actualModel)} (服务商: ${escapeHtml(provider)})</span></div>`);
      }

      assistantEl.innerHTML = '';
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let fullText = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const text = decoder.decode(value);
        const lines = text.split('\n').filter(l => l.startsWith('data: '));

        for (const line of lines) {
          const data = line.substring(6).trim();
          if (data === '[DONE]') continue;
          try {
            const json = JSON.parse(data);
            const delta = json.choices?.[0]?.delta?.content || '';
            if (delta) {
              fullText += delta;
              assistantEl.innerHTML = escapeHtml(fullText);
              scrollChatToBottom();
            }
          } catch (e) { /* skip */ }
        }
      }

      chatHistory.push({ role: 'assistant', content: fullText });

    } else {
      // 非流式（IPC 返回 { data, meta }）
      const result = await api.testRoute(model, messages, false);
      const data = result?.data || result;
      const meta = result?.meta;
      const content = data.choices?.[0]?.message?.content || '无响应';

      if (meta?.cached) {
        toast(`💾 ${meta.cacheType === 'semantic' ? '语义缓存命中' : '缓存命中'}（未调用上游 API）`, 'success');
        assistantEl.insertAdjacentHTML('beforebegin', `<div class="chat-msg system"><span class="switch-note" style="color: var(--green); border-color: var(--green);">💾 ${meta.cacheType === 'semantic' ? `语义缓存命中（相似度 ${(meta.similarity || 0).toFixed(2)}）` : '缓存命中（零成本）'}</span></div>`);
      } else if (meta?.switched || (meta?.model && meta.model !== model)) {
        toast(`⚡ 自动切换: ${model} → ${meta.model} (服务商: ${meta.provider})`, 'info');
        assistantEl.insertAdjacentHTML('beforebegin', `<div class="chat-msg system"><span class="switch-note">⚡ 自动切换: ${escapeHtml(model)} → ${escapeHtml(meta.model)} (服务商: ${escapeHtml(meta.provider)}${meta.latency ? ` · ${meta.latency}ms` : ''})</span></div>`);
      } else if (meta?.provider) {
        assistantEl.insertAdjacentHTML('beforebegin', `<div class="chat-msg system"><span class="switch-note">服务商: ${escapeHtml(meta.provider)}${meta.latency ? ` · ${meta.latency}ms` : ''}</span></div>`);
      }

      assistantEl.innerHTML = escapeHtml(content);
      chatHistory.push({ role: 'assistant', content });
    }

  } catch (e) {
    assistantEl.innerHTML = `<span style="color: var(--red);">✕ ${escapeHtml(e.message)}</span>`;
  } finally {
    const sendBtn = document.getElementById('testSendBtn');
    const sendBtn2 = document.getElementById('testSendBtn2');
    if (sendBtn) sendBtn.disabled = false;
    if (sendBtn2) sendBtn2.disabled = false;
    scrollChatToBottom();
  }
}

function addChatMessage(role, content) {
  const container = document.getElementById('chatMessages');
  const el = document.createElement('div');
  el.className = `chat-msg ${role}`;
  el.innerHTML = content;
  container.appendChild(el);
  scrollChatToBottom();
  return el;
}

function scrollChatToBottom() {
  const container = document.getElementById('chatMessages');
  if (container) container.scrollTop = container.scrollHeight;
}

// ===== 多模态生成（图片/视频） =====
async function sendImageGeneration() {
  api.trackFeature('test_page', { detail: 'image' }).catch(() => {});
  const input = document.getElementById('chatInput');
  const modelSelect = document.getElementById('testModel');
  const prompt = input.value.trim();
  if (!prompt) { toast('请输入图片提示词', 'error'); return; }
  if (!modelSelect.value) { toast('请先选择图片模型', 'error'); return; }

  addChatMessage('user', '🖼️ 生成图片: ' + escapeHtml(prompt));
  input.value = '';
  const el = addChatMessage('assistant', '<span class="spinner"></span> 正在生成图片...');
  const port = state.config?.proxyPort || 3456;
  try {
    const response = await fetch(`http://localhost:${port}/v1/images/generations`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': '***' },
      body: JSON.stringify({ model: modelSelect.value, prompt, n: 1, response_format: 'b64_json' })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data?.error?.message || ('HTTP ' + response.status));
    const item = data.data?.[0];
    const actualModel = decodeURIComponent(response.headers.get('X-Router-Model') || '');
    const provider = decodeURIComponent(response.headers.get('X-Router-Provider') || '');
    if (item?.b64_json) {
      el.innerHTML = `<div style="margin-bottom: 6px;">✅ 已生成（${escapeHtml(actualModel || modelSelect.value)} · ${escapeHtml(provider || '')}）</div><img src="data:image/png;base64,${item.b64_json}" style="max-width: 100%; max-height: 420px; border-radius: 10px;">`;
    } else if (item?.url) {
      el.innerHTML = `<div style="margin-bottom: 6px;">✅ 已生成（${escapeHtml(actualModel || modelSelect.value)} · ${escapeHtml(provider || '')}）</div><img src="${escapeAttr(item.url)}" style="max-width: 100%; max-height: 420px; border-radius: 10px;">`;
    } else {
      el.innerHTML = '生成完成，但响应格式异常: ' + escapeHtml(JSON.stringify(data).slice(0, 200));
    }
  } catch (e) {
    el.innerHTML = `<span style="color: var(--red);">✕ ${escapeHtml(e.message)}</span>`;
  }
  scrollChatToBottom();
}

let videoPollTimer = null;
async function sendVideoGeneration() {
  api.trackFeature('test_page', { detail: 'video' }).catch(() => {});
  const input = document.getElementById('chatInput');
  const modelSelect = document.getElementById('testModel');
  const prompt = input.value.trim();
  if (!prompt) { toast('请输入视频提示词', 'error'); return; }
  if (!modelSelect.value) { toast('请先选择视频模型', 'error'); return; }

  addChatMessage('user', '🎬 生成视频: ' + escapeHtml(prompt));
  input.value = '';
  const el = addChatMessage('assistant', '<span class="spinner"></span> 正在提交视频任务...');
  const port = state.config?.proxyPort || 3456;
  try {
    const response = await fetch(`http://localhost:${port}/v1/videos/generations`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': '***' },
      body: JSON.stringify({ model: modelSelect.value, prompt })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data?.error?.message || ('HTTP ' + response.status));
    const taskId = data.id;
    const actualModel = decodeURIComponent(response.headers.get('X-Router-Model') || '');
    const provider = decodeURIComponent(response.headers.get('X-Router-Provider') || '');
    el.innerHTML = `🎬 任务已提交（${escapeHtml(actualModel || modelSelect.value)} · ${escapeHtml(provider || '')}）<br><span style="font-family: monospace;">任务ID: ${escapeHtml(taskId || '')}</span><br><span class="spinner"></span> 等待生成...`;
    // 轮询任务状态
    const poll = async () => {
      try {
        const r = await fetch(`http://localhost:${port}/v1/videos/generations/${taskId}`);
        const d = await r.json();
        if (d.status === 'completed' || d.status === 'succeeded' || d.status === 'success') {
          clearInterval(videoPollTimer);
          const url = d.url || d.video_url || d.data?.url || d.output?.url;
          if (url) {
            el.innerHTML = `🎬 视频已生成！<br><video src="${escapeAttr(url)}" controls style="max-width: 100%; max-height: 380px; border-radius: 10px;"></video>`;
          } else {
            el.innerHTML = '🎬 视频已生成: ' + escapeHtml(JSON.stringify(d).slice(0, 300));
          }
        } else if (d.status === 'failed' || d.status === 'error') {
          clearInterval(videoPollTimer);
          el.innerHTML = `<span style="color: var(--red);">✕ 视频生成失败: ${escapeHtml(d.error?.message || d.message || '未知错误')}</span>`;
        } else {
          el.innerHTML = `🎬 生成中...（${escapeHtml(d.status || 'processing')}）<br><span class="spinner"></span>`;
        }
      } catch (e) {
        clearInterval(videoPollTimer);
        el.innerHTML = `<span style="color: var(--red);">✕ 状态查询失败: ${escapeHtml(e.message)}</span>`;
      }
    };
    clearInterval(videoPollTimer);
    videoPollTimer = setInterval(poll, 3000);
    poll();
  } catch (e) {
    el.innerHTML = `<span style="color: var(--red);">✕ ${escapeHtml(e.message)}</span>`;
  }
  scrollChatToBottom();
}

function clearChat() {
  chatHistory = [];
  if (videoPollTimer) { clearInterval(videoPollTimer); videoPollTimer = null; }
  const container = document.getElementById('chatMessages');
  if (container) {
    container.innerHTML = '<div class="chat-msg system">对话已清空</div>';
  }
}

// ===== 设置 =====
async function refreshCacheUI() {
  try {
    const { config: cacheCfg, stats } = await api.getCache();
    const enabledToggle = document.getElementById('cacheEnabledToggle');
    const streamToggle = document.getElementById('cacheStreamToggle');
    const maxInput = document.getElementById('cacheMaxMB');
    const box = document.getElementById('cacheStatsBox');
    if (enabledToggle) enabledToggle.classList.toggle('active', cacheCfg.enabled !== false);
    if (streamToggle) streamToggle.classList.toggle('active', cacheCfg.stream !== false);
    if (maxInput) maxInput.value = Math.round((cacheCfg.maxBytes || 1073741824) / 1048576);
    if (box) {
      const usedMB = (stats.sizeBytes / 1048576).toFixed(1);
      const limitMB = Math.round((stats.maxBytes || 1073741824) / 1048576);
      const total = stats.hits + stats.misses;
      box.innerHTML = `
        <div>💾 已用 <b style="color: var(--yellow);">${usedMB} MB</b> / ${limitMB} MB · 条目 ${stats.entries} 条 · 淘汰 ${stats.evictions} 次</div>
        <div>🎯 命中 <b style="color: var(--green);">${stats.hits}</b> 次 · 未命中 ${stats.misses} 次 · 命中率 <b style="color: var(--yellow);">${stats.hitRate}%</b></div>
        <div style="color: rgba(31, 41, 55, 0.75); font-size: 11px;">提示：命中缓存不消耗上游调用，可大幅降低 API 成本；命中数据仅存于内存，重启后清空。</div>
      `;
    }
    loadDataUsage();
    loadRemoteBox();
  } catch (e) {
    console.error('加载缓存状态失败:', e);
  }
}

// 远程访问与迁移面板（v3.0.2）
let remoteState = null;
let remoteNginx = null;

async function loadRemoteBox() {
  const box = document.getElementById('remoteBox');
  if (!box) return;
  try {
    remoteState = await api.getRemote();
    box.innerHTML = renderRemoteBox();
  } catch (e) {
    box.innerHTML = '<div>加载远程状态失败</div>';
  }
}

function renderRemoteBox() {
  const r = remoteState || {};
  const enabled = !!r.enabled;
  const hasPwd = !!r.hasPassword;
  return `
    <div style="display: flex; gap: 10px; flex-wrap: wrap; align-items: center; margin-bottom: 8px;">
      <label style="font-size: 13px; font-weight: 700;">远程访问
        <input type="checkbox" id="remoteEnabled" ${enabled ? 'checked' : ''} style="width: 16px; height: 16px; vertical-align: middle;" onchange="toggleRemote()" />
      </label>
      <label style="font-size: 13px;">端口
        <input type="number" id="remotePort" value="${r.port || 3457}" min="1024" max="65535" style="width: 80px; font-size: 14px; padding: 4px 8px; border-radius: 6px; border: 1px solid #d1d5db;" />
      </label>
      <label style="font-size: 13px;">账号
        <input type="text" id="remoteUser" value="${escapeAttr(r.username || 'admin')}" style="width: 110px; font-size: 14px; padding: 4px 8px; border-radius: 6px; border: 1px solid #d1d5db;" />
      </label>
      <label style="font-size: 13px;">密码
        <input type="password" id="remotePwd" placeholder="${hasPwd ? '已设置（留空不改）' : '未设置！'}" style="width: 130px; font-size: 14px; padding: 4px 8px; border-radius: 6px; border: 1px solid #d1d5db;" />
      </label>
      <button class="btn btn-primary" onclick="saveRemoteSettings()">保存</button>
    </div>
    <div style="font-size: 12px; color: rgba(31,41,55,0.85); margin-bottom: 6px;">
      ${enabled ? (r.listening ? '<b style="color: var(--green);">🟢 远程已开启</b>' : '<b style="color: var(--yellow);">设置密码并保存后生效</b>') : '<b style="color: var(--text-muted);">⚪ 远程关闭（仅本机可访问）</b>'}
      · 远程地址：<code>http://服务器IP:${r.port || 3457}</code> · 迁移接口：<code>/remote/export</code>
    </div>
    <div style="display: flex; gap: 8px; flex-wrap: wrap; align-items: center; margin-bottom: 8px; background: rgba(15,23,42,0.04); border-radius: 8px; padding: 8px 10px;">
      <span style="font-size: 13px; font-weight: 700;">🔑 远程 Key（免登录直连）：</span>
      <code id="remoteKeyText" style="font-size: 12px; word-break: break-all; flex: 1;">${r.hasApiKey ? escapeHtml(r.apiKey) : '（启用后自动生成）'}</code>
      <button class="btn" onclick="copyRemoteKey()" ${r.hasApiKey ? '' : 'disabled'}>复制</button>
      <button class="btn" onclick="regenRemoteKey()">重新生成</button>
    </div>
    <div style="font-size: 11px; color: rgba(31,41,55,0.75); margin-bottom: 8px;">远程 Key 可直接作为 <code>Authorization: Bearer &lt;Key&gt;</code> 或请求头 <code>X-Router-Remote-Key</code> 使用（curl/客户端/B 电脑迁移都可用）；泄漏可立即「重新生成」吊销旧 Key。</div>
    <div style="font-size: 12px; background: rgba(22,163,74,0.08); border: 1px solid rgba(22,163,74,0.25); border-radius: 8px; padding: 8px 10px; margin-bottom: 8px;">
      💡 <b>远程调用模型（当渠道用）</b>：任何 OpenAI 兼容客户端（LobsterAI/OpenWebUI/curl 等）可直接配置——<br>
      Base URL：<code>http://服务器IP:${r.port || 3457}/v1</code> &nbsp;·&nbsp; API Key：<code>${r.hasApiKey ? escapeHtml(r.apiKey) : '（启用后自动生成）'}</code>
    </div>
    <div style="display: flex; gap: 8px; flex-wrap: wrap; align-items: center; margin: 8px 0;">
      <input type="text" id="nginxDomain" placeholder="输入域名，如 router.example.com" style="flex: 1; min-width: 200px; font-size: 14px; padding: 6px 8px; border-radius: 6px; border: 1px solid #d1d5db;" />
      <button class="btn" onclick="genNginxNow()">🔐 生成 Nginx 反代 + 证书命令</button>
    </div>
    ${remoteNginx ? `<pre style="background: #f8fafc; color: #1f2937; border-radius: 8px; padding: 10px; font-size: 11px; max-height: 220px; overflow: auto; white-space: pre-wrap; margin: 6px 0;">${escapeHtml(remoteNginx.nginxConf)}</pre>
    <pre style="background: #f8fafc; color: #1f2937; border-radius: 8px; padding: 10px; font-size: 11px; max-height: 160px; overflow: auto; white-space: pre-wrap; margin: 6px 0;">${escapeHtml(remoteNginx.certbotCmd)}\n\n${escapeHtml(remoteNginx.renewCmd)}</pre>
    <div style="font-size: 11px; color: rgba(31,41,55,0.75);">${remoteNginx.tips.map(t => escapeHtml(t)).join('<br>')}</div>` : ''}
    <div class="divider" style="margin: 10px 0;"></div>
    <div style="font-size: 13px; font-weight: 700; margin-bottom: 6px;">🖥️ B 电脑迁移（新装机连接 A 电脑，像渠道一样填 地址+Key）</div>
    <div style="display: flex; gap: 8px; flex-wrap: wrap; align-items: center;">
      <input type="text" id="migHost" placeholder="地址，如 http://1.2.3.4:3457 或 域名" style="width: 220px; font-size: 14px; padding: 6px 8px; border-radius: 6px; border: 1px solid #d1d5db;" />
      <input type="text" id="migKey" placeholder="远程 Key" style="width: 220px; font-size: 14px; padding: 6px 8px; border-radius: 6px; border: 1px solid #d1d5db;" />
      <button class="btn" onclick="testRemoteNow()">连接测试</button>
      <button class="btn btn-primary" onclick="migrateNow()">🚚 一键迁移数据</button>
    </div>
    <div style="margin-top: 6px;">
      <span style="font-size: 12px; color: var(--blue-primary); cursor: pointer;" onclick="toggleMigPwd()">🔒 或用账号密码登录（展开）</span>
      <div id="migPwdRow" style="display: none; gap: 8px; flex-wrap: wrap; align-items: center; margin-top: 6px;">
        <input type="text" id="migUser" placeholder="账号" style="width: 100px; font-size: 14px; padding: 6px 8px; border-radius: 6px; border: 1px solid #d1d5db;" />
        <input type="password" id="migPwd" placeholder="密码" style="width: 120px; font-size: 14px; padding: 6px 8px; border-radius: 6px; border: 1px solid #d1d5db;" />
      </div>
    </div>
    <div id="migResult" style="font-size: 12px; margin-top: 6px;"></div>
  `;
}

function toggleMigPwd() {
  const row = document.getElementById('migPwdRow');
  if (row) row.style.display = row.style.display === 'none' ? 'flex' : 'none';
}

async function toggleRemote() {
  const enabled = document.getElementById('remoteEnabled')?.checked === true;
  const pwd = document.getElementById('remotePwd')?.value || '';
  if (enabled && !remoteState?.hasPassword && !pwd) {
    toast('启用远程必须先设置账号密码', 'error');
    document.getElementById('remoteEnabled').checked = false;
    return;
  }
  await saveRemoteSettings();
}

async function saveRemoteSettings() {
  try {
    const enabled = document.getElementById('remoteEnabled')?.checked === true;
    const port = parseInt(document.getElementById('remotePort')?.value || '3457', 10);
    const user = document.getElementById('remoteUser')?.value.trim() || 'admin';
    const pwd = document.getElementById('remotePwd')?.value || '';
    await api.setRemote({ enabled, port, username: user });
    if (pwd) {
      const r = await api.setRemotePassword(pwd);
      if (!r.ok) { toast(r.error || '密码设置失败', 'error'); return; }
    }
    if (enabled && !remoteState?.hasPassword && !pwd) {
      toast('请先设置账号密码再启用远程', 'error');
    }
    await loadRemoteBox();
    toast(enabled ? '远程访问已保存（监听 0.0.0.0）' : '远程访问已关闭', 'success');
  } catch (e) { toast('保存失败: ' + e.message, 'error'); }
}

async function genNginxNow() {
  const domain = document.getElementById('nginxDomain')?.value.trim();
  if (!domain) { toast('请输入域名', 'error'); return; }
  remoteNginx = await api.genRemoteNginx(domain);
  loadRemoteBox();
}

async function copyRemoteKey() {
  const el = document.getElementById('remoteKeyText');
  if (!el) return;
  try { await navigator.clipboard.writeText(el.textContent.trim()); toast('远程 Key 已复制', 'success'); }
  catch (e) { toast('复制失败（可手动选择复制）', 'error'); }
}

async function regenRemoteKey() {
  if (!confirm('重新生成远程 Key？旧 Key 立即失效（已连接的客户端需更新）。')) return;
  const r = await api.regenerateRemoteKey();
  if (r.ok) { toast('新远程 Key 已生成', 'success'); await loadRemoteBox(); }
  else toast('生成失败: ' + (r.error || ''), 'error');
}

async function testRemoteNow() {
  const host = document.getElementById('migHost')?.value.trim();
  if (!host) { toast('请输入 A 电脑 IP 或域名', 'error'); return; }
  const apiKey = document.getElementById('migKey')?.value.trim() || null;
  const r = await api.testRemote({
    host: host.startsWith('http') ? host : 'http://' + host,
    port: document.getElementById('migPort')?.value || '3457',
    username: document.getElementById('migUser')?.value || 'admin',
    password: document.getElementById('migPwd')?.value || '',
    apiKey
  });
  const el = document.getElementById('migResult');
  el.innerHTML = r.ok
    ? `<span style="color: var(--green);">✅ 连接成功：${escapeHtml(r.remote?.app || '')} v${escapeHtml(r.remote?.version || '')}</span>`
    : `<span style="color: var(--red);">❌ ${escapeHtml(r.error || '连接失败')}</span>`;
}

async function migrateNow() {
  const host = document.getElementById('migHost')?.value.trim();
  if (!host) { toast('请输入 A 电脑 IP 或域名', 'error'); return; }
  if (!confirm('将从远程导入全部配置（渠道/Key/价格/路由/记忆），覆盖本机当前配置？本机配置会先备份。')) return;
  const el = document.getElementById('migResult');
  el.innerHTML = '⏳ 迁移中...';
  const apiKey = document.getElementById('migKey')?.value.trim() || null;
  const r = await api.migrateRemote({
    host: host.startsWith('http') ? host : 'http://' + host,
    port: document.getElementById('migPort')?.value || '3457',
    username: document.getElementById('migUser')?.value || 'admin',
    password: document.getElementById('migPwd')?.value || '',
    apiKey
  });
  if (r.ok) {
    el.innerHTML = `<span style="color: var(--green);">✅ 迁移完成：${r.providers} 个渠道 / ${r.models} 个模型（源 v${escapeHtml(r.version)}）${escapeHtml(r.note)}</span>`;
    toast('迁移完成，重启后生效', 'success');
    await refreshConfig();
  } else {
    el.innerHTML = `<span style="color: var(--red);">❌ ${escapeHtml(r.error || '迁移失败')}</span>`;
  }
}

// 数据占用统计与清理（v3.0.2）
function fmtMB(n) {
  if (!n) return '0 MB';
  if (n >= 1073741824) return (n / 1073741824).toFixed(2) + ' GB';
  if (n >= 1048576) return (n / 1048576).toFixed(1) + ' MB';
  return (n / 1024).toFixed(0) + ' KB';
}

async function loadDataUsage() {
  const box = document.getElementById('dataUsageBox');
  if (!box) return;
  try {
    const u = await api.getDataUsage();
    box.innerHTML = `
      <div>🗂 Trace 日志 <b>${fmtMB(u.logs)}</b> · 记忆 <b>${fmtMB(u.memory)}</b> · 配置 <b>${fmtMB(u.config)}</b></div>
      <div>🤖 本地引擎+模型 <b>${fmtMB(u.local)}</b>（固定大小，不增长）· 浏览器缓存 <b>${fmtMB(u.cache)}</b>（系统自管理）· blob 残留 <b>${fmtMB(u.blob)}</b></div>
      <div style="color: rgba(31, 41, 55, 0.75); font-size: 11px;">日志按保留天数自动轮转删除；记忆有结构上限；内存缓存重启即清。长期运行不会无限制增长。</div>
    `;
  } catch (e) {
    box.innerHTML = '<div>加载占用数据失败</div>';
  }
}

async function saveLogDays() {
  const days = parseInt(document.getElementById('logDays')?.value || '7', 10);
  if (days < 1 || days > 90) { toast('保留天数范围: 1-90', 'error'); return; }
  try {
    const cfg = state.config || {};
    cfg.logging = { ...(cfg.logging || {}), days };
    await api.saveConfig(cfg);
    await refreshConfig();
    toast(`日志保留天数已设为 ${days} 天`, 'success');
  } catch (e) { toast('保存失败: ' + e.message, 'error'); }
}

async function cleanupDataNow() {
  try {
    await api.cleanupData();
    await loadDataUsage();
    toast('临时文件清理完成', 'success');
  } catch (e) { toast('清理失败: ' + e.message, 'error'); }
}

async function clearAllLogsNow() {
  if (!confirm('确定清空全部 Trace 日志？')) return;
  try {
    await api.clearLogs();
    toast('日志已清空', 'success');
  } catch (e) { toast('清空失败: ' + e.message, 'error'); }
}

async function saveCacheSettings() {
  const enabled = document.getElementById('cacheEnabledToggle').classList.contains('active');
  const stream = document.getElementById('cacheStreamToggle').classList.contains('active');
  const mb = parseInt(document.getElementById('cacheMaxMB').value) || 1024;
  try {
    await api.setCache({ enabled, stream, maxBytes: mb * 1024 * 1024 });
    toast(`缓存设置已保存（上限 ${mb} MB）`, 'success');
    await refreshCacheUI();
  } catch (e) {
    toast('保存失败: ' + e.message, 'error');
  }
}

async function clearCacheNow() {
  if (!confirm('确定清空全部内存缓存？')) return;
  try {
    await api.clearCache();
    toast('缓存已清空', 'success');
    await refreshCacheUI();
  } catch (e) {
    toast('清空失败: ' + e.message, 'error');
  }
}

async function changeProxyPort() {
  const port = parseInt(document.getElementById('proxyPort').value);
  if (port < 1024 || port > 65535) {
    toast('端口范围: 1024-65535', 'error');
    return;
  }
  try {
    await api.setProxyPort(port);
    state.config.proxyPort = port;
    updateProxyDisplay();
    // 刷新设置页中所有引用端口的展示（代理地址/API 示例）
    renderPage();
    toast(`代理端口已改为 ${port}`, 'success');
  } catch (e) {
    toast('修改端口失败: ' + e.message, 'error');
  }
}

async function restartProxy() {
  try {
    await api.restartProxy();
    toast('代理服务器已重启', 'success');
    await updateProxyStatus();
  } catch (e) {
    toast('重启失败: ' + e.message, 'error');
  }
}

async function toggleAutoStart() {
  const el = document.getElementById('autoStartToggle');
  const enabled = !el.classList.contains('active');
  try {
    const result = await api.setAutoStart(enabled);
    el.classList.toggle('active', result);
    state.config.autoStart = result;
    toast(result ? '已开启开机自启' : '已关闭开机自启', 'success');
  } catch (e) {
    toast('设置失败: ' + e.message, 'error');
  }
}

async function toggleTrayMinimize() {
  const el = document.getElementById('trayToggle');
  const enabled = !el.classList.contains('active');
  try {
    await api.setTrayMinimize(enabled);
    el.classList.toggle('active', enabled);
    state.config.trayMinimize = enabled;
    toast(enabled ? '最小化将隐藏到托盘' : '最小化将直接收起', 'success');
  } catch (e) {
    toast('设置失败: ' + e.message, 'error');
  }
}

async function changeCurrency() {
  const currency = document.getElementById('currencySelect').value;
  try {
    await api.setCurrency(currency);
    state.config.currency = currency;
    state.currency = currency;
    toast(`货币已切换为 ${currency === 'CNY' ? '人民币 ¥' : '美元 $'}`, 'success');
    renderPage();
  } catch (e) {
    toast('切换失败: ' + e.message, 'error');
  }
}

async function syncPrices() {
  toast('正在同步价格...', 'info');
  try {
    const result = await api.syncPrices();
    toast(`价格同步完成，补齐 ${result.synced} 个模型`, 'success');
    state.config.prices.models = result.models;
    renderPage();
  } catch (e) {
    toast('同步失败: ' + e.message, 'error');
  }
}

async function savePriceRow(modelId) {
  const inputVal = document.querySelector(`input[data-price-model="${modelId}"][data-price-kind="input"]`);
  const outputVal = document.querySelector(`input[data-price-model="${modelId}"][data-price-kind="output"]`);
  if (!inputVal || !outputVal) return;
  try {
    await api.setPrice(modelId, parseFloat(inputVal.value) || 0, parseFloat(outputVal.value) || 0);
    await refreshConfig();
    toast('价格已保存', 'success');
  } catch (e) {
    toast('保存失败: ' + e.message, 'error');
  }
}

async function removePriceRow(modelId) {
  if (!confirm(`删除模型 ${modelId} 的价格记录？`)) return;
  try {
    await api.removePrice(modelId);
    await refreshConfig();
    renderPage();
    toast('已删除', 'success');
  } catch (e) {
    toast('删除失败: ' + e.message, 'error');
  }
}

async function addPriceRow() {
  const input = document.getElementById('newPriceModel');
  const modelId = input.value.trim();
  if (!modelId) { toast('请输入模型名', 'error'); return; }
  try {
    await api.setPrice(modelId, 0, 0);
    await refreshConfig();
    renderPage();
    toast('已添加，请填写价格', 'success');
  } catch (e) {
    toast('添加失败: ' + e.message, 'error');
  }
}

function exportConfig() {
  const config = JSON.stringify(state.config, null, 2);
  const blob = new Blob([config], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `llm-router-config-${Date.now()}.json`;
  a.click();
  URL.revokeObjectURL(url);
  toast('配置已导出', 'success');
}

async function importConfig(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = async (e) => {
    try {
      const config = JSON.parse(e.target.result);
      await api.saveConfig(config);
      state.config = await api.getConfig();
      renderPage();
      toast('配置已导入', 'success');
    } catch (err) {
      toast('导入失败: ' + err.message, 'error');
    }
  };
  reader.readAsText(file);
}

async function resetConfig() {
  if (!confirm('确定重置所有配置？此操作不可恢复！')) return;
  try {
    state.config = await api.resetConfig();
    renderPage();
    toast('配置已重置', 'success');
  } catch (e) {
    toast('重置失败: ' + e.message, 'error');
  }
}

async function resetStats() {
  try {
    state.stats = await api.resetStats();
    renderPage();
    toast('统计已重置', 'success');
  } catch (e) {
    toast('重置失败', 'error');
  }
}

// ===== 数据刷新 =====
async function refreshConfig() {
  state.config = await api.getConfig();
  state.currency = state.config?.currency || 'USD';
}

async function updateProxyStatus() {
  try {
    state.proxyStatus = await api.getProxyStatus();
    updateProxyDisplay();
  } catch (e) {
    console.error('获取代理状态失败:', e);
  }
}

function updateProxyDisplay() {
  const badge = document.getElementById('proxyBadge');
  const proxyInfo = document.getElementById('proxyInfo');
  const proxyUrlEl = document.getElementById('proxyUrlText');
  if (!badge) return;

  const running = state.proxyStatus?.running;
  const port = state.proxyStatus?.port;
  const fullUrl = running ? `http://localhost:${port}` : '';

  if (running) {
    badge.innerHTML = '<span class="status-dot healthy"></span><span class="status-text">代理运行中 :' + port + '</span>';
  } else {
    badge.innerHTML = '<span class="status-dot unhealthy"></span><span class="status-text">代理未启动</span>';
  }

  if (proxyInfo) {
    if (proxyUrlEl) {
      proxyUrlEl.textContent = running ? `localhost:${port}` : '--';
      // 红色高亮（v2.0）
      proxyUrlEl.classList.add('warn-red');
      proxyUrlEl.onclick = async () => {
        if (!running || !port) return;
        try {
          await api.copyText(fullUrl);
          toast('已复制: ' + fullUrl, 'success');
        } catch (e) {
          toast('复制失败', 'error');
        }
      };
    }
  }
}

// ===== 事件绑定 =====
function attachPageHandlers() {
  // 设置页进入时异步刷新缓存状态
  if (state.currentPage === 'settings') {
    refreshCacheUI();
  }
  // 智能页/日志页数据刷新
  if (state.currentPage === 'smart') {
    refreshSmart();
  }
  if (state.currentPage === 'memory') {
    refreshMemory();
  }
  if (state.currentPage === 'local') {
    refreshLocal();
  }
  if (state.currentPage === 'logs') {
    loadLogs();
  }
}

// ===== 事件监听 =====
function setupEventListeners() {
  api.onHealthUpdate((data) => {
    state.healthStatus = data;
    if (state.currentPage === 'health') renderPage();
  });

  api.onStatsUpdate((data) => {
    state.stats = data;
    if (state.currentPage === 'stats') renderPage();
  });
}

// ===== 背景图管理 =====
async function loadCustomBg() {
  try {
    const dataUrl = await api.loadBgImage();
    const bgEl = document.querySelector('.bg-anime');
    const resetBtn = document.getElementById('btnResetBg');
    if (dataUrl && bgEl) {
      bgEl.style.backgroundImage = `url("${dataUrl}")`;
      if (resetBtn) resetBtn.style.display = 'flex';
    } else {
      if (resetBtn) resetBtn.style.display = 'none';
    }
  } catch (e) {
    console.error('加载背景图失败:', e);
  }
}

function setupBgChange() {
  const btn = document.getElementById('btnChangeBg');
  const input = document.getElementById('bgFileInput');
  const resetBtn = document.getElementById('btnResetBg');

  if (btn && input) {
    btn.addEventListener('click', () => input.click());
    input.addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      if (file.size > 10 * 1024 * 1024) {
        toast('图片不能超过 10MB', 'error');
        return;
      }
      const reader = new FileReader();
      reader.onload = async () => {
        try {
          await api.saveBgImage(reader.result);
          await loadCustomBg();
          toast('背景图已更换', 'success');
        } catch (e) {
          toast('保存失败: ' + e.message, 'error');
        }
      };
      reader.readAsDataURL(file);
      input.value = '';
    });
  }

  if (resetBtn) {
    resetBtn.addEventListener('click', async () => {
      try {
        await api.resetBgImage();
        const bgEl = document.querySelector('.bg-anime');
        if (bgEl) bgEl.style.backgroundImage = "url('assets/anime-bg.png')";
        resetBtn.style.display = 'none';
        toast('已恢复默认背景', 'success');
      } catch (e) {
        toast('恢复失败', 'error');
      }
    });
  }
}

// ===== 初始化 =====
async function init() {
  try {
    state.config = await api.getConfig();
    state.healthStatus = await api.getHealthStatus();
    state.stats = await api.getStats();
    state.currency = state.config?.currency || 'USD';
    state.smart = await api.getSmart();
    try { memoryReport = await api.getMemory(); } catch (e) {}
    try { localStatus = await api.getLocalStatus(); } catch (e) {}
    try { localTools = await api.getLocalTools(); } catch (e) {}
    try { brainStatus = await api.getBrainStatus(); } catch (e) {}
    if (api.onLocalEvent) {
      api.onLocalEvent((ev) => {
        if (ev.type === 'engine-log') {
          localEngineLogs.push(ev.line);
          if (localEngineLogs.length > 60) localEngineLogs.splice(0, localEngineLogs.length - 60);
        }
        if (ev.type === 'progress' && localStatus) {
          localStatus.progress = ev.progress;
          localStatus.state = ev.progress.kind === 'engine' ? 'downloading-engine' : 'downloading-model';
        }
        if (ev.type === 'state' && localStatus) {
          localStatus.state = ev.state;
          if (ev.state === 'running') localStatus.running = true;
          if (ev.state === 'ready' || ev.state === 'idle' || ev.state === 'error') localStatus.running = false;
        }
        if (state.currentPage === 'local' && (ev.type === 'progress' || ev.type === 'state' || ev.type === 'engine-log')) {
          renderPage();
        }
      });
    }
    if (api.onBrainEvent) {
      api.onBrainEvent((ev) => {
        if (ev.type === 'decision' || ev.type === 'auto' || ev.type === 'error') {
          refreshLocal();
          if (state.currentPage === 'local') renderPage();
        }
      });
    }
    await loadPresets();
  } catch (e) {
    console.error('初始化失败:', e);
  }

  setupNavigation();
  setupEventListeners();
  setupBgChange();
  await loadCustomBg();
  renderPage();
  updateProxyStatus();

  // 定时刷新代理状态
  setInterval(updateProxyStatus, 10000);
}

// 启动
init();
