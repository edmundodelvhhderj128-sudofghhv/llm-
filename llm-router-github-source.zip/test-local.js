/**
 * 本地模型 + 工具集测试（v2.4.0）
 * 运行: node test-local.js
 * 说明：不真实下载/推理，用 mock 引擎验证路由接入、工具执行、状态机
 */
const assert = require('assert');
const os = require('os');
const fs = require('fs');
const path = require('path');

const Module = require('module');
const origLoad = Module._load;
const userDataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'llm-local-'));
Module._load = function (request, parent, isMain) {
  if (request === 'electron') return { app: { getPath: () => userDataDir }, ipcMain: { handle: () => {} } };
  return origLoad.apply(this, arguments);
};

const { Router } = require('./src/router');
const { ToolRegistry } = require('./src/tools');
const { LocalEngine } = require('./src/local-engine');

let passed = 0, failed = 0;
function ok(name) { passed++; console.log(`  ok ${name}`); }
function fail(name, detail) { failed++; console.log(`  FAIL ${name}: ${detail || ''}`); }

function mockConfig() {
  const state = {
    providers: [], routing: { failover: true, maxRetries: 2, timeout: 5000, strategy: 'priority', circuitBreaker: { enabled: true, threshold: 5, cooldownMs: 60000 } },
    guard: {}, quality: {}, compression: {}, semanticCache: {}, slo: {}, residency: {}, shadow: {},
    cache: { enabled: false }, logging: { enabled: true }, local: { backend: 'llama', llamaPort: 11435, tools: true, maxToolRounds: 5 },
    prices: { models: {} }, memory: { enabled: true, autoAddModels: true, learnFeatures: true }
  };
  return {
    config: state,
    get(key) { return key.split('.').reduce((o, k) => o?.[k], this.config); },
    set(key, v) { const ks = key.split('.'); const last = ks.pop(); const t = ks.reduce((o, k) => { if (!o[k]) o[k] = {}; return o[k]; }, this.config); t[last] = v; },
    getAll() { return this.config; },
    persist() {},
    addProvider(p) {
      const prov = { id: p.id || 'p' + this.config.providers.length, name: p.name, baseUrl: p.baseUrl || '', keys: p.keys || ['k1'], models: p.models || [], enabled: true, priority: 1, keyIndex: 0, keyStats: {}, region: 'any', pathStyle: 'v1', kind: p.kind || 'remote', billing: { mode: 'tokens', pricePerCall: 0 }, weights: { latencyMs: null, successRate: 1, requests: 0 }, circuit: { failures: 0, open: false, openedAt: null }, quotaUsed: {} };
      prov.keys.forEach((_, i) => { prov.keyStats[i] = { disabled: false }; });
      this.config.providers.push(prov); return prov;
    },
    updateProvider(id, d) { const i = this.config.providers.findIndex(p => p.id === id); this.config.providers[i] = { ...this.config.providers[i], ...d }; return this.config.providers[i]; },
    getProviders() { return this.config.providers; },
    getEnabledProviders() { return this.config.providers.filter(p => p.enabled); }
  };
}

(async () => {
  // ============ 工具集：定义完整 + 执行 ============
  {
    try {
      const config = mockConfig();
      config.addProvider({ id: 'p1', name: '商汤', keys: ['k1'], models: ['glm-5.2'] });
      const router = new Router(config, os.tmpdir());
      const memory = { getReport: () => ({ totalCalls: 3, recommendations: { chat: { model: 'glm-5.2', successRate: 90 } }, lastUsedByCapability: { chat: 'glm-5.2' }, topModels: [{ name: 'glm-5.2', calls: 3, successRate: 90 }] }) };
      const tracer = { recent: (n) => [{ model: 'glm-5.2', status: 'success', latency: 100 }] };
      const tools = new ToolRegistry({ config, router, memory, tracer });
      const payload = tools.toolsPayload();
      assert.strictEqual(payload.length, 12, '应有 12 个工具');
      assert.ok(payload.every(t => t.type === 'function' && t.function.name && t.function.description), '工具格式应为 OpenAI function');
      const names = payload.map(t => t.function.name);
      for (const n of ['get_status', 'get_stats', 'get_memory', 'list_providers', 'list_models', 'get_recommendation', 'get_logs', 'estimate_cost', 'switch_strategy', 'set_provider_enabled', 'flush_cache', 'probe_providers']) {
        assert.ok(names.includes(n), '缺少工具 ' + n);
      }
      ok('工具集：12 个工具定义完整（OpenAI function 格式）');
    } catch (e) { fail('工具集定义', e.message); }
  }

  // ============ 工具执行：只读 + 配置操作 ============
  {
    try {
      const config = mockConfig();
      config.addProvider({ id: 'p1', name: '商汤', keys: ['k1'], models: ['glm-5.2'] });
      const router = new Router(config, os.tmpdir());
      const memory = { getReport: () => ({ totalCalls: 3, recommendations: { chat: { model: 'glm-5.2', successRate: 90 } }, lastUsedByCapability: { chat: 'glm-5.2' }, topModels: [{ name: 'glm-5.2', calls: 3, successRate: 90 }] }) };
      const tracer = { recent: (n) => [{ model: 'glm-5.2', status: 'success', latency: 100, time: new Date().toISOString() }] };
      const tools = new ToolRegistry({ config, router, memory, tracer });

      const r1 = await tools.execute('list_providers');
      assert.ok(r1.ok && r1.providers.length === 1 && r1.providers[0].name === '商汤');
      const r2 = await tools.execute('switch_strategy', '{"strategy":"weighted"}');
      assert.ok(r2.ok && config.get('routing.strategy') === 'weighted', '策略应被切换');
      const r3 = await tools.execute('set_provider_enabled', '{"providerId":"p1","enabled":false}');
      assert.ok(r3.ok && config.getProviders()[0].enabled === false, '渠道应被停用');
      const r4 = await tools.execute('set_provider_enabled', '{"providerId":"nope","enabled":true}');
      assert.ok(!r4.ok, '不存在的渠道应报错');
      const r5 = await tools.execute('get_recommendation', '{"capability":"chat"}');
      assert.ok(r5.ok && r5.recommended.model === 'glm-5.2');
      const r6 = await tools.execute('get_logs', '{"limit":5}');
      assert.ok(r6.ok && r6.logs.length === 1);
      const r7 = await tools.execute('estimate_cost', '{"model":"glm-5.2"}');
      assert.ok(r7.ok, '成本估算应可执行');
      const r8 = await tools.execute('flush_cache');
      assert.ok(r8.ok);
      const bad = await tools.execute('switch_strategy', 'not-json');
      assert.ok(!bad.ok, '非法 JSON 应报错');
      const unknown = await tools.execute('no_such_tool');
      assert.ok(!unknown.ok, '未知工具应报错');
      ok('工具执行：只读/切策略/启停渠道/查日志/成本/清缓存/异常处理');
    } catch (e) { fail('工具执行', e.message); }
  }

  // ============ 路由接入本地渠道（大脑直连引擎，不经对话路由） ============
  {
    try {
      const config = mockConfig();
      const localProvider = config.addProvider({ id: 'local1', name: '本地 Qwen', keys: ['local'], models: ['Qwen2.5-7B-Instruct'], kind: 'local' });
      const router = new Router(config, os.tmpdir());
      // mock 本地引擎
      const calls = [];
      const fakeEngine = {
        running: true,
        chat: async (opts) => {
          calls.push(opts);
          return { data: { id: 'x', choices: [{ message: { role: 'assistant', content: '本地回答' } }], usage: { total_tokens: 10 } }, latency: 500, usage: { total_tokens: 10 } };
        },
        chatWithTools: async () => ({ result: { data: { choices: [{ message: { content: '带工具回答' } }] }, latency: 800, usage: null }, toolRuns: [{ name: 'get_stats', ok: true }] }),
        toolExecutor: null
      };
      router.setLocalEngine(fakeEngine, null);
      const key = router.getActiveKey(localProvider);
      assert.strictEqual(key, 'local', '本地渠道 Key 应为占位');
      const keyResult = router.selectKey(localProvider);
      assert.strictEqual(keyResult.key, 'local');
      // 对话路由应排除本地渠道（大脑不参与回答）
      const sp = router.selectProviders('Qwen2.5-7B-Instruct');
      assert.strictEqual(sp.length, 0, 'selectProviders 应排除本地渠道');
      // 直接调用 callProvider 验证引擎分支（大脑路径）
      const r = await router.callProvider(localProvider, 'local', 'Qwen2.5-7B-Instruct', { messages: [{ role: 'user', content: '你好' }] }, 60000);
      assert.strictEqual(calls.length, 1, '应调用本地引擎');
      assert.strictEqual(r.data.choices[0].message.content, '本地回答');
      ok('路由接入：kind=local 走引擎（无需 Key，且对话路由排除）');
    } catch (e) { fail('路由接入本地渠道', e.message); }
  }

  // ============ 本地工具循环（大脑带 tools 请求自动执行工具并回填） ============
  {
    try {
      const config = mockConfig();
      const localProvider = config.addProvider({ id: 'local1', name: '本地 Qwen', keys: ['local'], models: ['Qwen2.5-7B-Instruct'], kind: 'local' });
      const router = new Router(config, os.tmpdir());
      const toolRunsLog = [];
      const fakeEngine = {
        running: true,
        chat: async () => ({ data: { choices: [{ message: { content: 'ok' } }] }, latency: 1, usage: null }),
        chatWithTools: async (opts) => {
          toolRunsLog.push(opts.messages.length);
          return { result: { data: { choices: [{ message: { content: '最终答复：已切换策略' } }] }, latency: 900, usage: null }, toolRuns: [{ name: 'switch_strategy', ok: true }] };
        },
        toolExecutor: null
      };
      router.setLocalEngine(fakeEngine, null);
      const r = await router.callProvider(localProvider, 'local', 'Qwen2.5-7B-Instruct', {
        messages: [{ role: 'user', content: '帮我把路由策略切到加权' }],
        tools: [{ type: 'function', function: { name: 'switch_strategy', parameters: { type: 'object' } } }]
      }, 60000);
      assert.strictEqual(r.data.choices[0].message.content, '最终答复：已切换策略');
      assert.strictEqual(toolRunsLog.length, 1, '应进入工具循环');
      assert.ok(r.toolRuns && r.toolRuns.length === 1, '应返回工具执行记录');
      ok('本地工具循环：带 tools 请求自动执行工具并回填');
    } catch (e) { fail('本地工具循环', e.message); }
  }

  // ============ LocalEngine 状态机（不真实下载/启动） ============
  {
    try {
      const config = mockConfig();
      const engine = new LocalEngine(config, userDataDir);
      const st = engine.status();
      assert.strictEqual(st.backend, 'llama');
      assert.strictEqual(st.engineExists, false);
      assert.strictEqual(st.modelExists, false);
      // 缺文件时 start 应报错
      const r1 = await engine.start();
      assert.ok(!r1.ok, '缺引擎/模型时启动应失败');
      assert.ok(r1.error.includes('引擎未下载') || r1.error.includes('模型未下载'));
      // ollama 后端下载引擎应跳过
      config.set('local', { backend: 'ollama' });
      const r2 = await engine.downloadEngine();
      assert.ok(r2.ok && r2.note.includes('Ollama'), 'ollama 后端无需下载引擎');
      ok('LocalEngine 状态机：缺文件启动失败/ollama 后端跳过下载');
    } catch (e) { fail('LocalEngine 状态机', e.message); }
  }

  // ============ 本地成本对比（免费） ============
  {
    try {
      const config = mockConfig();
      config.addProvider({ id: 'local1', name: '本地', keys: ['local'], models: ['Qwen2.5-7B-Instruct'], kind: 'local' });
      config.addProvider({ id: 'p1', name: '云端', keys: ['k'], models: ['gpt-4o'] });
      config.set('prices', { models: { 'gpt-4o': { input: 2.5, output: 10 } } });
      const router = new Router(config, os.tmpdir());
      const localCost = router.estimateCost(config.getProviders()[0], 'Qwen2.5-7B-Instruct', { prompt_tokens: 1000, completion_tokens: 500 });
      const cloudCost = router.estimateCost(config.getProviders()[1], 'gpt-4o', { prompt_tokens: 1000, completion_tokens: 500 });
      assert.strictEqual(localCost, 0, '本地成本应为 0');
      assert.ok(cloudCost > 0, '云端成本应 > 0');
      ok('成本对比：本地免费 vs 云端计费（可对比）');
    } catch (e) { fail('成本对比', e.message); }
  }

  // ============ 自动休眠/唤醒（v2.6.2） ============
  {
    try {
      const config = mockConfig();
      config.addProvider({ id: 'p1', name: '云端', keys: ['k'], models: ['glm-5.2'] });
      const router = new Router(config, os.tmpdir());
      const fakeEngine = { running: false, waking: false };
      router.setLocalEngine(fakeEngine, null);
      config.set('local', { idleSleepMinutes: 15, autoWake: true });

      assert.strictEqual(router.isEngineIdle(Date.now()), false, '引擎未运行不算空闲');
      fakeEngine.running = true;
      router.lastActivityAt = Date.now() - 20 * 60000;
      assert.ok(router.isEngineIdle(Date.now()), '超过 15 分钟无活动应判定空闲');
      router.lastActivityAt = Date.now() - 5 * 60000;
      assert.strictEqual(router.isEngineIdle(Date.now()), false, '5 分钟内不算空闲');
      config.set('local', { idleSleepMinutes: 0 });
      assert.strictEqual(router.isEngineIdle(Date.now()), false, '配置 0 关闭自动休眠');

      config.set('local', { idleSleepMinutes: 15, autoWake: true });
      let wakes = 0;
      router.autoWakeHook = () => { wakes++; fakeEngine.waking = true; };   // 模拟 start() 会置 waking
      fakeEngine.running = false; fakeEngine.waking = false;
      router.lastActivityAt = Date.now() - 60 * 60000;
      router.touchActivity();
      assert.ok(router.lastActivityAt > Date.now() - 5000, 'touchActivity 应更新活动时间');
      assert.strictEqual(wakes, 1, '引擎休眠时请求应触发自动唤醒');
      router.touchActivity();
      assert.strictEqual(wakes, 1, '唤醒中不应重复触发');
      fakeEngine.waking = true;
      router.touchActivity();
      assert.strictEqual(wakes, 1, 'waking 期间不重复触发');
      fakeEngine.waking = false;
      config.set('local', { autoWake: false });
      router.touchActivity();
      assert.strictEqual(wakes, 1, '关闭 autoWake 后不触发');
      ok('自动休眠判定 + 活动打卡 + 自动唤醒（并发去重/开关）');
    } catch (e) { fail('自动休眠/唤醒', e.message); }
  }

  console.log(`\n通过 ${passed} 项, 失败 ${failed} 项`);
  process.exit(failed > 0 ? 1 : 0);
})().catch(e => { console.error('测试崩溃:', e); process.exit(1); });
