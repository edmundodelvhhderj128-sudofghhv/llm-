// 提升 app.js 内联白色文字透明度（仅 color: 声明）
const fs = require('fs');
const path = require('path');

const file = path.join(__dirname, 'renderer', 'app.js');
let src = fs.readFileSync(file, 'utf8');

const MAP = { '3': '0.72', '4': '0.8', '5': '0.86', '6': '0.9', '7': '0.95' };

const before = (src.match(/color:\s*rgba\(255,\s*255,\s*255,\s*0\.\d\)/g) || []).length;

src = src.replace(/color:\s*rgba\(255,\s*255,\s*255,\s*0\.(\d)\)/g, (m, d) => {
  const repl = MAP[d];
  if (!repl) return m;
  return m.replace(new RegExp('0\\.' + d + '\\)$'), repl + ')');
});

const after = (src.match(/color:\s*rgba\(255,\s*255,\s*255,\s*0\.\d\)/g) || []).length;
const left = (src.match(/color:\s*rgba\(255,\s*255,\s*255,\s*0\.[0-7]\)/g) || []).length;

fs.writeFileSync(file, src, 'utf8');
console.log(`替换前 ${before} 处 -> 替换后剩余 ${after} 处（低亮度残留 ${left} 处）`);
