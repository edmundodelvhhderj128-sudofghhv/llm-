# OmniRoute 对标分析（v2.7.x）

分析对象：[diegosouzapw/OmniRoute](https://github.com/diegosouzapw/OmniRoute)（MIT 协议，340+ 服务商、1200+ 模型的 AI 网关，450+ 贡献者）
分析方式：GitHub Contents API 拉取核心源码（`open-sse/` 目录），逐文件研读。

## 已落地到子沐智能中转路由的能力

| OmniRoute 机制 | 位置 | 子沐实现 | 版本 |
|---|---|---|---|
| Caveman 规则压缩（30+ 正则规则、代码保护、cleanup、recapitalize） | `services/compression/caveman.ts` + `cavemanRules.ts` | `src/prose-compress.js`（中英文 25 条规则 + 占位符保护代码/URL/JSON + 残留清理 + 句首复原 + 代码为主文本跳过） | v2.7.0 |
| 不可重试错误检测（Cloudflare 1010 / browser_signature_banned / retryable:false） | `services/accountFallback/nonRetryableUpstream.ts` | `router.isHopelessError()`：封禁/CF 封锁/配额耗尽/Key 失效 → 立即禁用该 Key，不浪费回退时间 | v2.7.0 |
| session-dedup（无损跨轮去重，压缩阶梯首档） | `services/compression/adaptiveCompression/ladder.ts`（DEFAULT_LADDER[0]） | `compressMessages()` 消息级去重：重复 system / 相同 role+content 旧消息只保留最后一条 | v2.7.1 |
| 回退候选快速遍历 | （对应其 fallback/combo 链设计） | `tryRouteModel(..., {fast})` + `routing.fallbackTimeoutMs`（20s） | v2.6.4 |

## 研读过的机制（未落地或部分对应）

1. **自适应压缩阶梯**（7 档：session-dedup → rtk → headroom → lite → caveman → aggressive → ultra）
   - 子沐对应：dedup（1 档）+ prose（≈lite/caveman）+ 启发式截断（≈aggressive 简化版）+ LLM 智能摘要（≈llm 档，可选）
   - 未落地：headroom（表格 JSON 压缩）、rtk（命令输出过滤）——价值中等，中文场景收益有限
2. **配额评分路由**（`services/combo/quotaScoring.ts`，16KB）：按配额余量/消耗速度打分选路
   - 子沐对应：简单配额计数 + 上限拦截（routing.quota）；未做评分排序——如需可在 weightedOrder 加配额因子
3. **账号级回退**（`accountFallback/`）：指数退避冷却上限（cooldownCap）、模型锁定驱逐（lockoutEviction）
   - 子沐对应：固定 60s 限流退避（无指数增长）；未做锁定驱逐——当前 429 退避已够用
4. **影子路由**（`services/combo/shadowRouting.ts`）：影子决策对比
   - 子沐对应：智能页「影子决策」已有（v2.1.0）
5. **340+ 服务商注册表**（`config/providers/registry/*`）：按供应商维护模型/头/错误规则
   - 子沐对应：18 个内置预设 + 用户自建渠道；未做自动化注册表——用户渠道有限，手动足够

## 后续可选方向（按价值排序）

1. headroom 表格/JSON 压缩（对 JSON 型对话历史省 tokens 明显）
2. 配额评分路由（若用户启用配额功能）
3. 指数退避 + 冷却上限（替代固定 60s 限流退避）

源码存档：`D:\新建文件夹\.cowork-temp\omniroute-src\`（12 个核心文件）
