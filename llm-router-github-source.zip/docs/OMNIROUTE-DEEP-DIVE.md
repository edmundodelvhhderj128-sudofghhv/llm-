# OmniRoute 深度研究报告（v2.7.x 对标）

> 研究日期：2026-08-23
> 对象：[diegosouzapw/OmniRoute](https://github.com/diegosouzapw/OmniRoute)（MIT，450+ 贡献者，约 1.51B 免费 tokens/月）
> 方法：GitHub API 拉取文件树（12601 文件）+ 26 个核心源码文件精读（存档于 `D:\新建文件夹\.cowork-temp\omniroute-src\`）
> 目的：理解其架构与功能，与本路由逐项对比，提炼可借鉴点

## 一、项目架构

```
OmniRoute (monorepo)
├── open-sse/          核心网关（本报告重点）
│   ├── config/        349 个服务商注册表（providers/registry/*）+ 模型目录 + 错误规则 + OAuth 凭据加载
│   ├── translator/    协议转换层（OpenAI↔Anthropic↔Gemini 请求/响应互转）
│   ├── handlers/      chatCore（主对话链路）/ imageGeneration / videoGeneration / search
│   ├── executors/     各上游执行器（default/claude-web/grok-web/codex/cursor/ninerouter…）
│   └── services/      核心服务：
│       ├── combo/         旗舰「组合路由」（19 策略 + 配额感知 + 韧性）
│       ├── autoCombo/     零配置 auto：按任务复杂度/模型族自动组合
│       ├── compression/   12 引擎压缩栈（session-dedup→rtk→headroom→lite→caveman→aggressive→ultra）
│       ├── accountFallback/ 账号级回退（指数退避冷却上限、锁定驱逐、Cloudflare 不可重试检测）
│       ├── tokenRefresh/  15 个 OAuth provider 的 token 自动刷新
│       ├── sessionPool/   匿名浏览器会话池（免费层核心：多指纹轮询/429 冷却/5xx 判死自愈）
│       ├── usage/         各家配额用量抓取（claude/codex/gemini/glm…）
│       └── rateLimitManager/ 并发准入控制
├── electron/          桌面壳（登录管理、托盘、进程树）
├── bin/cli/           真 CLI + 远程模式
├── src/               Web UI（Next.js，1468 文件）
└── tests/             单测 3788 + 集成 124 + e2e 42

核心链路：请求 → translator（协议归一）→ combo（选渠道/策略/配额评分）→ executor（转发+错误分类）→ compression（响应压缩）→ 回退链（accountFallback 3 层韧性）
```

## 二、功能全景对比

| 维度 | OmniRoute | 子沐智能中转路由 | 对比结论 |
|---|---|---|---|
| 服务商覆盖 | 349 家（90+ 免费），注册表+插件机制 | 18 预设 + 手动渠道 | 生态差距大（450 人 vs 单机），但对本机用户影响小 |
| 路由策略 | **19 种**：auto / priority / weighted / round-robin / random / strict-random / fill-first / **lkgp（记住最后成功渠道）** / **p2c（二选一随机）** / **least-used（最少使用优先）** / cost-optimized / **reset-aware（配额重置窗口感知）** / reset-window / context-optimized / headroom / quota-share / context-relay 等 | 5 种：priority / weighted / random / round-robin + 跨模型回退 | **lkgp / p2c / least-used / reset-aware 值得借鉴** |
| 韧性体系 | 3 层：combo 内回退 + accountFallback（指数退避、冷却绝对上限、模型锁定驱逐、不可重试错误识别）+ 熔断 | 熔断 + 429 固定 60s 退避 + 跨渠道/跨模型回退 + 快速失败（v2.7） | 我们的已可用；**指数退避+冷却上限**可补 |
| Token 压缩 | **12 引擎栈** + 自适应档位 + 档位阶梯（预期压缩率建模），省 15-95% | 消息去重 + 规则压缩（25 中英文规则）+ 启发式截断 + LLM 摘要 | 已落地其 3 档核心；**headroom（表格/JSON 压缩）**可补 |
| 配额管理 | 配额评分路由 + **软降级**（超配额渠道 ×0.7 降权而非硬拦）+ 重置窗口感知 + quota-share 并发共享 | 计数 + 硬拦截（超限跳过） | **软降级策略值得学**（体验更平滑） |
| 自适应记忆 | **lkgp**（每 combo 记住最后成功渠道，系统级即时）+ prompt-cache affinity（相同前缀请求固定渠道，利用上游提示缓存省钱） | 大脑经验（LLM 级，决策沉淀）+ 权重 EMA + 记忆画像 | **lkgp 是简化版大脑经验，实现成本极低价值高** |
| 认证管理 | OAuth token 自动刷新（15 家）+ 外部凭据文件覆盖（60s TTL） | API Key 池（轮询/连续错误禁用/健康检测自动恢复）+ 配置加密存储 | 各场景自洽，无需学 |
| 免费层 | 浏览器会话池（多指纹匿名会话，429 冷却/5xx 判死/自动补位） | 无 | **不适用**（依赖厂商匿名配额，风险高，不推荐） |
| Agent 控制 | MCP/A2A：Claude Code 等 agent 可通过 MCP 工具集控制网关（选模型/查池/压缩） | 内置 12 工具集 + 路由大脑自主调度 | 概念一致，我们走本地大脑路线 |
| 多模态 | 图片/视频生成 handler + 搜索 | 图片/视频/嵌入生成 + 测试页 | 相当 |
| 可观测性 | 完整 trace/统计/UI | Trace 回放/统计/记忆画像/功能分析/决策日志 | 相当（我们还有大脑） |
| 本地模型 | 无（纯网关） | **内置 Qwen2.5-7B 本地引擎 + 路由大脑** | 差异化优势 |

## 三、值得借鉴的实现细节（已精读源码）

1. **lkgp（Last Known Good Provider）**：`applyStrategyOrdering.ts`——每个模型组合记住上次成功的 (provider, connection)，下次路由时优先排第一；失败即失效。实现 ~30 行，效果立竿见影。
2. **配额软降级**：`autoStrategy.ts`——`QUOTA_SOFT_DEPRIORITIZE_FACTOR=0.7`、`STATUS_SOFT_DEPRIORITIZE_FACTOR=0.5`：配额软超/状态异常（credits_exhausted/rate_limited/banned/expired）的候选**不硬拦截**，分数乘系数降权排在健康渠道之后——避免"明明还有别的渠道却报 429"。
3. **prompt-cache affinity**：相同 system 前缀的请求固定路由到同一渠道，最大化上游 prompt caching 命中（省 50-90% 输入 tokens 费用）。
4. **指数退避 + 冷却上限**：`cooldownCap.ts`——`baseCooldownMs × 2^level` 但封顶 `maxCooldownMs`，防止长时间黑名单。
5. **headroom 压缩**：表格/JSON 型内容的紧凑化（列折叠、缩进压缩），对工具调用类对话历史省 tokens 明显。
6. **fallback hint 协议**：executor 用响应头（如 `X-Omni-Fallback-Hint: connection_cooldown`）告知回退层"这是 5s 冷却，别触发熔断"——错误分级更细。

## 四、已落地清单（v2.7.0 / v2.7.1）

| 借鉴项 | 来源 | 落地 |
|---|---|---|
| 规则式散文压缩（25 中英文规则+代码保护） | caveman.ts / cavemanRules.ts | src/prose-compress.js |
| 不可重试错误快速失败（Key 立即禁用） | nonRetryableUpstream.ts | router.isHopelessError() |
| 消息级去重 | adaptiveCompression ladder 首档 session-dedup | compressMessages() dedup |
| 回退候选快速遍历（20s 上限） | combo fallback 链设计 | tryRouteModel fast + fallbackTimeoutMs |

## 五、下一步可落地清单（按性价比排序）

1. **lkgp 策略**（~1 小时）：加权路由里把"最后成功渠道"权重乘 2，失败即回退——微信场景立减首跳延迟
2. **配额软降级**（~1 小时）：checkQuota 超限时改为降权而非硬跳过
3. **prompt-cache 亲和**（~2 小时）：同 system 前缀的请求固定渠道（配缓存命中统计）
4. **指数退避+冷却上限**（~1 小时）：429 退避 60s → 60s×2^level，封顶 10 分钟
5. **headroom 表格压缩**（~2 小时）：JSON/表格内容紧凑化规则

## 六、结论

OmniRoute 的规模优势（349 服务商/免费层/协议转换）对本机单用户场景价值有限；其**路由策略与韧性设计**（lkgp、配额软降级、指数退避、压缩阶梯）是真正的精华，且大部分可以低成本移植。子沐的差异化优势在**内置本地模型 + 路由大脑**（OmniRoute 没有）——两者结合后，本路由在"单机智能路由"定位上已形成自己的完整闭环。
