# ADR-001: 内置本地模型引擎选型（Qwen2.5-7B-Instruct）

**Status:** Accepted
**Date:** 2026-08-22
**Deciders:** 用户 + 开发者

## Context

用户要求把 Qwen2.5-7B-Instruct（Q4_K_M ≈ 4.6GB，中文能力强）内置进「子沐智能中转路由」，作为独立渠道与云端渠道同台对比（不覆盖旧版本），并给本地模型配工具集，让它能调用工具管理智能路由。

约束：应用是 Electron 打包分发（150MB 级）；不能强制用户安装额外运行时；本地模型需要支持 OpenAI 兼容接口与 function calling；模型文件 4.6GB 不可能随安装包分发，需首次启动下载；离线可用。

## Decision

在 v2.4.0 中内置 **llama.cpp server 子进程引擎**（应用内自动下载 `llama-server.exe` + GGUF 模型），并通过 `provider.kind='local'` 把本地模型注册为普通渠道接入现有路由系统；同时提供 Ollama 作为可选后端。

## Options Considered

### Option A: node-llama-cpp（npm 原生绑定，主进程内嵌）
| Dimension | Assessment |
|-----------|------------|
| Complexity | 高（native 模块打包/asar 处理/多平台二进制） |
| 构建环境 | 本机 npm 源无法保证 prebuild 下载 |
| 崩溃隔离 | 差（推理崩溃 = 应用崩溃） |
| 工具调用 | 支持（grammar/json schema） |

**Pros:** 无子进程管理；API 直接。
**Cons:** 打包复杂、构建环境风险高、崩溃无隔离、多版本 A/B 对比难做。

### Option B: llama.cpp server 子进程（OpenAI 兼容 HTTP）（✅ 选定）
| Dimension | Assessment |
|-----------|------------|
| Complexity | 中（进程管理 + 下载器） |
| Cost | 应用内下载 ~50MB 引擎 + 4.6GB 模型，断点续传 |
| Scalability | 子进程独立，可随时启停/重启，崩溃不影响应用 |
| Team familiarity | llama.cpp 生态成熟，OpenAI 兼容层稳定 |

**Pros:** 与现有 `callProvider` 完全同构（返回 `{data,latency,usage}`，流式 SSE 透传）；`--jinja` 支持 chat template 与 tools；引擎/模型可单独管理（状态机+进度 UI）；天然支持"本地 vs 云端"对比（本地渠道成本恒 0）；工具循环在应用内执行（ToolRegistry 12 个管理工具）。
**Cons:** 需管理子进程生命周期；首次下载体积大；CPU 推理速度有限（7B Q4 约 5-15 token/s，可用）。

### Option C: 依赖外部 Ollama
| Dimension | Assessment |
|-----------|------------|
| Complexity | 低 |
| Cost | 用户需自行安装 Ollama + 拉模型 |
| Scalability | 外部依赖 |

**Pros:** 零打包成本。
**Cons:** 不算"内置"；用户多一步安装；Ollama 严格校验模型名。
**处理：** 保留为可选后端（`local.backend='ollama'`），默认仍走 B。

## Trade-off Analysis

B 与 C 共用同一 OpenAI 兼容调用层，引擎抽象（LocalEngine）一次实现双后端，用户可随时切换。A 的风险（打包/崩溃隔离）对桌面分发软件不可接受。B 的下载问题通过多源（ModelScope 默认 + HuggingFace 备选）+ 断点续传 + 进度 UI 缓解。

## Consequences

- 更容易：本地模型作为普通渠道参与路由/回退/统计/记忆；工具循环（chatWithTools）让模型自主管理路由；成本对比清晰（本地 0 成本）。
- 更难：首次使用需下载 4.6GB 模型（引导 UI 已做）；CPU 推理慢；llama.cpp 版本（llamaTag）需随上游演进更新。
- 需 revisit：模型升级（Qwen3 等）、GPU 加速（llama.cpp Vulkan/CUDA 后端）、工具集扩充。

## Action Items

1. [x] src/local-engine.js（双后端 + 下载器 + 状态机）
2. [x] src/tools.js（12 个管理工具 + OpenAI function 格式）
3. [x] router 接入 kind='local' + 本地工具循环
4. [x] 「🤖 本地模型」页 + 渠道页本地渠道支持
5. [ ] 用户真实下载/推理验证（需要联网下载 4.6GB）
