# 子沐智能中转路由 v3.0.2 — 功能间交互漏洞审计

> 审计时间：2026-09-04
> 范围：`src/router.js` (2747行)、`src/local-engine.js`、`src/cache.js`、`src/semantic-cache.js`、`src/slo.js`、`src/model-memory.js`、`src/brain.js`、`src/proxy.js`、`main.js`
> 重点：模块间数据流、状态共享、并发安全、生命周期交互
>
> 与 [SECURITY-AUDIT.md](./SECURITY-AUDIT.md) 互补：
> 上一篇是「单点安全漏洞」；这一篇聚焦「模块边界、数据一致性、竞态条件、级联失效」。

---

## 严重程度等级

| 等级 | 含义 | 数量 |
|------|------|------|
| 🔴 严重 | 可导致系统状态错乱/资金错算/静默数据丢失 | 4 |
| 🟠 高危 | 在特定路径下触发，但日常使用可能命中 | 6 |
| 🟡 中危 | 边界场景，性能或行为偏差 | 5 |
| 🔵 低危 | 设计/最佳实践改进 | 3 |

---

## 🔴 严重（Critical）

### C1 — 压缩后回写缓存的"串味"——响应内容与缓存键不匹配

**位置**：`src/router.js` 第 459-466 行（`getCacheKey`）+ 第 558-573 行（`compressMessages`）+ 第 635-636 行（cachePut）

**漏洞路径**：
```js
// 1. 用【原始】消息生成 cacheKey
cacheKey = this.getCacheKey(finalModel, messages, forwardRest);

// 2. 内存缓存 miss → 继续路由

// 3. 压缩消息（messages 变量被改写）
const c = await this.compressMessages(messages);
if (c.compressed) {
  messages = c.messages;  // ← 引用变更
}

// 4. 实际发给上游的是【压缩后】的 messages

// 5. 成功时用【基于原始】的 cacheKey 回写【压缩后响应】
if (cacheEnabled && !stream && cacheKey) this.cachePut(cacheKey, res.data);
```

**问题**：
- 缓存键基于原始 50 条消息的 sha1
- 但实际发给上游的是压缩后的 5 条摘要
- 第二个相同原始请求来时，命中这条缓存，**拿到的响应是另一个不同原始请求压缩后产生的回复**

**后果**：
- 跨用户/跨会话串味：如果 A 问"今天天气"，B 问"明天天气"，压缩摘要近似 → B 命中 A 的回复
- `compressionVariant()` 只区分"压缩/未压缩"模式，**不区分压缩前内容**
- 与 H1 联动：连模式参数变更都无法彻底隔离

**修复建议**：
- 方案 A（最简单）：压缩时把 `cacheKey` 改成基于"压缩后文本"
- 方案 B：在 cacheKey 中加入 `compressedMessages` 的 sha1 前 8 位
- 方案 C：直接在 compressMessages 之前做缓存查询

---

### C2 — 路由大脑（Brain）可永久修改全局配置，且无审计/回滚机制

**位置**：`src/tools.js` 第 217-231 行（`switch_strategy` / `set_provider_enabled`）+ `src/brain.js` 整体 + `main.js` 远程访问与迁移无审计

**漏洞描述**：
- BrainEngine 通过本地 Qwen2.5-7B 模型自主调用工具
- `set_provider_enabled` 工具**永久修改** `config.updateProvider(p.id, { enabled: !!enabled })`
- `switch_strategy` 修改 `config.set('routing.strategy', strategy)`
- 这些操作**没有审计日志**，没有"两阶段确认"（dry-run），没有"撤销栈"
- 大脑定时 15 分钟自动跑一次，事件触发不限次

**触发风险**：
1. 本地模型因 prompt 注入/幻觉调用了 `set_provider_enabled(providerId='xxx', enabled=false)`，用户主渠道被静默停用
2. 用户察觉不到（前端没有"配置变更通知"），下次请求静默切换到次优渠道
3. 即使发现，恢复需手动改 UI；config.json 不会自动恢复

**影响**：
- 静默降级（实际可用渠道被关，掉到低成本模型，聊天质量下降）
- 配合远程访问：远程调用方通过 Brain 间接修改服务端配置
- 没有"重大操作确认"门槛

**修复建议**：
1. 重大配置变更（停用渠道/切换策略）需要用户二次确认（UI 弹窗）
2. 增加 dry-run 模式：Brain 给出建议但不立即执行
3. 保留配置变更历史，支持一键回滚到上一版本
4. 远程访问模式下，Brain 自动修改默认禁用

---

### C3 — 流式 SSE usage 不可靠，导致 token 配额/成本永久失真

**位置**：`src/proxy.js` 第 113-139 行（`reconstructFromChatSse`）+ `src/router.js` 第 1432-1463 行（`applyStreamUsage`）

**漏洞描述**：
- 大部分上游**流式 SSE 末帧不携带 `usage`**（OpenAI、DeepSeek、智谱等部分 model）
- 重建逻辑只能累积 content，**但 usage 在协议上是可选的**
- `reconstructFromChatSse` 第 127-128 行：`if (json.usage) usage = json.usage;`
- `applyStreamUsage` 第 1433 行：`if (!usage || !usage.total_tokens) return;` → **整个 token 计量直接被跳过**

**后果**：
- 流式 token 配额永久少计（用户实际用 1000 tokens，配额只计 0）
- 成本估算偏低（按 tokens 计算的渠道）
- 与非流式对账时出现明显差异，财务对账时无法解释

**具体场景**：
- 用户开启 `quota.enabled = true` + 配额按 `tokens` 限制
- 用户用流式调用 DeepSeek-R1 烧了 100 万 tokens
- 实际配额只计了 0 tokens → 配额永远用不完

**修复建议**：
1. 流式时用 tiktoken 估算（即使 SSE 没带 usage）回填到 `providerStats.tokens` 与 `quotaUsed.tokens`
2. 在 stats 字段里明确标 `tokensEstimated: true` 让用户识别估算 vs 实测
3. 当上游确实发 usage 时优先用上游数据

---

### C4 — `cloudChat` 路径会二次触发整条路由管道（配额翻倍/双重 judge/双重 shadow）

**位置**：`src/local-engine.js` 第 460-483 行（`cloudChat`）+ `main.js` 第 751-762 行（`localEngine.cloudCaller`）

**漏洞路径**：
1. 用户配置本地后端 = `cloud` 模式（用云端渠道模型代替本地引擎）
2. 路由请求来 → `router.callProvider` 检测到 `kind='local'`
3. 进入 `localEngine.chat()` → 进入 `cloudChat()` → 调用 `cloudCaller`
4. `cloudCaller` 调 `router.callProvider(provider, key, model, body)` —— **这里是普通云端渠道**
5. **router 仍走完整管道**（cacheKey 复用、压缩、AB、quota、shadow runner、judge、quality feedback 都会重新触发）

**问题**：
- 配额**只记一次**（`callProvider` 自己会做），但...
- **judge 评分会评 cloud 路径的响应**（语义 OK，但延迟至少翻倍）
- **shadow runner 会再发一次相同请求**给加权首选渠道
- 语义缓存会再回写一次（与精确缓存都再写一次）

**实际后果**：
- 延迟至少 +1 个 judge 调用（采样命中时）+1 个 shadow 双跑
- 上游被打多余请求（如果开了 shadow real dual run）
- 内存缓存命中率虚高

**修复建议**：
- 在 main.js 的 cloudCaller 中走一个简化路径：直接 fetch，不再走 router 全栈（不计入 quota、不触发 judge/shadow）
- 或者在 `callProvider` 检测到 `body._isCloudCall: true` 时跳过 judge/shadow

---

## 🟠 高危（High）

### H1 — 缓存键的"压缩变体"无法区分不同的压缩算法/参数

**位置**：`src/router.js` 第 2508-2517 行（`compressionVariant`）

```js
compressionVariant() {
  const c = this.config.get('compression') || {};
  const flags = [
    c.enabled ? '1' : '0',
    c.smart !== false ? '1' : '0',
    c.prose !== false ? '1' : '0',
    c.heuristic !== false ? '1' : '0'
  ].join('');
  return 'cmp' + flags;
}
```

**漏洞**：
- 只记录了"启用了哪些压缩"开/关
- **不包含** `triggerTokens`/`keepRecent`/`maxOldChars`/`minLen` 等参数
- 用户改了 `triggerTokens` 从 12000 改为 5000，cache key 不变
- 用户改了 `providerId`（压缩用模型），cache key 也不变

**影响**：
- 旧缓存条目（triggerTokens=12000 时产生的）继续命中请求，**响应是按 5000 triggerTokens 配置压缩后的回复**
- 串味依旧

**修复建议**：把所有压缩相关字段 hash 后加入 cache key：
```js
return 'cmp' + JSON.stringify({
  enabled: c.enabled,
  smart: c.smart,
  prose: c.prose,
  heuristic: c.heuristic,
  triggerTokens: c.triggerTokens,
  keepRecent: c.keepRecent,
  maxOldChars: c.maxOldChars,
  providerId: c.providerId,
  model: c.model
});
```

---

### H2 — 语义缓存条目无"压缩变体"隔离，与精确缓存行为不一致

**位置**：`src/router.js` 第 509-555 行（语义缓存 lookup/put 逻辑）

**对比**：
- 精确缓存：用 `cacheKey` 含 `compressionVariant()` 隔离（第 2500 行）
- 语义缓存：直接用 `semanticCache.put(emb, text, data)`，**没有 variant 参数**

**影响**：
- 用户开了压缩后，语义缓存可能命中压缩前"另一种"回复（"近似但不同文本"的回复被误判为相同语义）
- 行为不可预测：相同问题开/关压缩后，回答可能突然变化（因为命中/未命中语义缓存的旧条目）

**修复建议**：`semanticCache.put(emb, text, data, variant)` 加上 variant 参数；`SemanticCache` 内部用 `Map<embHash+variant, entry>` 隔离。

---

### H3 — SLO 降级 + 数据驻留 + 熔断 三层过滤的"全过滤完没可用渠道"路径未做兜底

**位置**：`src/router.js` 第 225-233 行（`providerAllowed`） + `selectProviders`

**问题**：
- `providerAllowed` 返回 false 时，`selectProviders` 静默剔除该渠道
- 若所有渠道都因为 SLO/熔断/驻留被剔除，调用方得到"没有可用的服务商"（错误消息含糊）
- 用户看到错误无法判断是 SLO 降级还是驻留误配

**具体表现**：
- 用户设了 `residency.allowedRegions: ['CN']`
- 但添加的所有渠道 `region` 字段都没设（默认 `any`）
- 上游压力大时 SLO 全部降级，所有渠道被剔除
- 用户只看到"无可用渠道"，不知道是哪里配错了

**修复建议**：
1. `providerAllowed` 返回 false 时给 trace 标记原因，错误信息带上具体原因（SLO 降级 / 区域不匹配 / 熔断）
2. `selectProviders` 如果过滤后为空，明确区分"零个匹配" vs "全部被过滤"

---

### H4 — Brain 工具调用可被本地 prompt 注入操纵

**位置**：`src/brain.js` 整体 + `src/local-engine.js` `chatWithTools` + `src/tools.js` 第 222-231 行

**漏洞描述**：
- Brain 的 System Prompt 写在 `src/brain.js` 第 15-36 行，是字符串硬编码
- 本地模型 Qwen2.5-7B 可能在某些输入模式下不严格遵守 system prompt
- 工具 `set_provider_enabled` 接收 `providerId: { type: 'string' }` 完全没有校验
- `tools.js` 第 223-225 行：**"先按 id 精确匹配，再按渠道名匹配"** —— 模型如果传一个**模糊匹配字符串**进来，会匹配到错误渠道
- 大脑对**所有**工具调用结果都没二次校验（"这个操作合理吗？"）

**具体攻击/误用场景**：
1. 用户请求内容被路由快照带到 Brain 输入时（"我的问题 X 解决不了"），Brain 可能过度反应
2. 本地模型幻觉：把 `providerId` 设成 `name` 而不是真实 UUID
3. 没有最小变更原则：Brain 可以一次性停用 5 个渠道，没有"先停 1 个看效果"机制

**修复建议**：
1. 工具调用前加"白名单/沙箱"层：只允许 Brain 调用 `probe_providers` / `get_status` 这类只读工具
2. 写操作（`set_provider_enabled`、`switch_strategy`）需要"建议 → 等待确认 → 执行"两阶段
3. 增加"撤销栈"，最近 5 次操作可一键回滚

---

### H5 — `consumeQuota` 频繁写盘（每次成功请求一次 config.json 同步写入）

**位置**：`src/router.js` 第 1418 行 + `src/config.js` 第 313-321 行（`persist`）

**问题**：
- 每次成功请求 → `updateProvider` → `persist` → `fs.writeFileSync` 同步写盘
- 高并发场景（如 100 QPS）下，IO 抖动 + 同一文件并发写可能损坏
- 配置写入是单条 JSON 序列化（**无原子写**：直接 writeFileSync 而非"先写临时再 rename"）—— **断电时 config.json 可能截断/损坏**

**影响**：
- 高频请求下磁盘 IO 抖动
- 断电场景下配置可能损坏
- 同一文件并发写时序无保证（虽然 Node 单线程，但 fs.writeFileSync 异步排队，仍可能交叠）

**修复建议**：
- 配额用量改为内存累加，**定时（如 30s）落盘**
- `persist` 改为：先写 `config.json.tmp`，再 `rename` 覆盖（原子写）
- `consumeQuota` 走 debounce 写盘

---

### H6 — 本地引擎自动休眠 + 自动唤醒 的边界条件

**位置**：`main.js` 第 801-809 行（idle sleep timer）+ `src/router.js` 第 150-200 行（autoWakeHook）

**问题**：
- 30s 检查一次空闲，空闲 15 分钟自动 `localEngine.stop()`
- 路由有请求进来 → 触发 `autoWakeHook` → 重新启动引擎（下载/初始化 60s 超时）
- **问题 1**：如果用户连发多个请求，第二个/第三个会撞上第一个的唤醒过程（`this.waking = true` 守卫，但 promise 共享有问题）
- **问题 2**：流式请求进入 `routeWithFallback` → 调 `localEngine.chat` → chat 内部不触发 autoWakeHook（hook 只在 router 顶部），所以流式不能唤醒

**影响**：
- 长时间空闲后第一个请求会卡 60s 等引擎启动
- 流式请求在空闲后第一个会失败（503）

**修复建议**：
- autoWakeHook 在 `localEngine.chat` 入口处也调用一次
- 增加"提前唤醒"：监控最后一次活动时间，距离 idle 阈值还差 1 分钟时主动启动引擎

---

## 🟡 中危（Medium）

### M1 — 健康检测 + 自动恢复 Key 可能与并发请求产生竞态

**位置**：`src/healthcheck.js` 第 100-126 行（`checkKey` + 恢复逻辑）

**问题**：
- 健康检测周期（如 5 分钟）触发 → 遍历所有 Key
- 检测通过 → `this.router.resetKeys(provider, i)` 立即重新启用
- 但**正在执行中**的请求可能刚刚把同一个 Key 标记为 disabled（`disableKey`），健康检测又把它启用 → 后续请求继续用这个本来要熔断的 Key → 失败率短期上升

**修复建议**：
- `resetKeys` 与 `disableKey` 加乐观锁（用 provider.configVersion 之类的版本号）
- 健康检测恢复 Key 时给一个"灰度"标记，前 N 次只走非灰度 Key

---

### M2 — 影子双跑（Shadow Runner）使用 max_tokens=128，可能错过长回复的质量对比

**位置**：`src/router.js` 第 760-764 行

```js
const sres = await this.callProvider(shadowTarget, key, meta.model || requestedModel, {
  messages: opts.messages || [],
  stream: false,
  max_tokens: 128
}, 20000).catch(() => null);
```

**问题**：
- 影子只发 128 tokens 的回复
- 与主请求（可能 2000 tokens）做"长度相近"对比完全失真
- 第 775 行：`Math.abs(realText.length - shadowText.length) / Math.max(realText.length, 1) < 0.3` → 主请求 2000 字 / 影子 100 字 = 95% 差距，永远不一致
- 导致 `agree` 永远接近 0，"影子一致性"指标失效

**修复建议**：
- shadow runner 与主请求 `max_tokens` 一致
- 或用其他一致性指标（如首句相同、首 token 相同、embedding 相似度）

---

### M3 — `lkgp` / `promptCacheAffinity` 缓存无 TTL，可能永远粘在失败渠道

**位置**：`src/router.js` 第 31-33 行

```js
this.lkgp = new Map();  // model -> providerId
this.promptCacheAffinity = new Map();  // system前缀 -> providerId
```

**问题**：
- `lkgp` 在 success 时 set、failure 时 delete（合理）
- `promptCacheAffinity` 在 success 时 set，**失败时不会 delete**（第 1009-1011 行只 set 不清理）
- 一旦绑定的渠道后来熔断，所有相同 system 前缀的请求都会集中到熔断渠道 → 雪崩

**修复建议**：
- `promptCacheAffinity` 也应该在失败时 delete
- 给两个 Map 加 LRU 上限（如 1000 条），防止长期累积

---

### M4 — `remote:migrate` 导出含明文 API Key 完整配置，后端无审计

**位置**：`main.js` 第 427-482 行（`remote:migrate`）

**问题**：
- 迁移接口导出**含明文 API Key** 的完整配置（`config: config.getAll()`）
- 没有"谁/何时/在哪"操作审计日志
- A 电脑误触"B 电脑迁移"按钮 → 完整配置泄露给 B
- B 电脑被植入恶意软件后，可伪装为"远程客户端"反复拉取最新配置
- 与 C2 联动：Brain 远程模式下能通过迁移获取的 API Key 进一步操纵系统

**修复建议**：
- 迁移操作写一条 `audit.log`（含时间、来源 IP、操作类型）
- 限制迁移频率：单 IP 每小时 ≤ 1 次
- 提供"只导出指定渠道"选项（避免一次性导出全部 Key）
- 迁移后立即轮换所有渠道 Key（防御"配置被截获"）

---

### M5 — `tracer.write` 写入失败时不影响主流程，但可能丢审计数据

**位置**：`src/router.js` 多处 `this.tracer.write(trace)`

**问题**：
- tracer 写入失败被 try/catch 静默吃掉
- 若磁盘满/权限丢失，所有 trace 静默丢失
- 出问题排查时（"为什么昨天 spike 失败那么多？"）看不到日志

**修复建议**：
- tracer.write 失败时降级到 console 输出（开发期可见）
- 在 IPC handler 暴露 `getTracerStatus`，前端可见"日志是否健康"

---

## 🔵 低危（Low）

### L1 — `getAllModels` 没考虑去重，多渠道同名模型会被合并

**位置**：`src/router.js` 第 238-263 行

**说明**：同名模型（不同渠道）会被合并到同一 entry，UI 上无法区分实际可用渠道。这不是安全漏洞，但前端展示 "GPT-4 由 5 个渠道提供" 时无法判断每个渠道的真实状态。

**建议**：在 entry 上加 `availableProviders: [live providers]`（去重时只保留当前可达的）。

---

### L2 — 知识缓存的 `extractedText` 截断 2000 字符（`embedText` 第 916 行），超长对话摘要不完整

**位置**：`src/router.js` 第 916 行 + `src/local-engine.js` 第 498 行

**说明**：`input: String(text).slice(0, 2000)` —— 超出 2000 字符的对话被截断后嵌入。长对话（10000+ 字符）的语义匹配准确度下降。

**建议**：分段嵌入后取平均，或对摘要前/中/末三段分别嵌入后合并。

---

### L3 — 路由大脑（Brain）的 `lessons` 数组无去重

**位置**：`src/brain.js` `persistLessons` + `model-memory.js`

**说明**：每次 `persistLessons` 都把 lessons 数组写盘，无去重逻辑。Brain 多次重复同类操作可能产生几十条相似 lesson，污染记忆。

**建议**：lesson 写入前做相似度去重（同模式操作的 lesson 不重复添加）。

---

## 与 SECURITY-AUDIT 的差异

| 维度 | SECURITY-AUDIT | INTERACTION-AUDIT（本报告） |
|------|---------------|--------------------------|
| 关注点 | 单点安全漏洞（认证/注入/敏感信息） | 模块边界、数据流、竞态、一致性 |
| 风险类型 | 攻击者利用 | 系统自身缺陷/状态污染 |
| 触发条件 | 外部输入 | 内部模块组合 + 时序 |
| 修复成本 | 中-高（涉及架构/协议） | 低-中（局部代码改动） |
| 用户感知 | 明确（被攻击/泄露） | 隐晦（行为偏差/性能下降） |

---

## 优先修复建议

| 优先级 | 动作 | 预期效果 | 修复成本 | 状态 |
|--------|------|---------|---------|------|
| **P0** | C1: 压缩时让 cacheKey 基于压缩后文本（或加摘要 hash） | 解决跨会话串味 | 0.5 天 | ✅ 已修 |
| **P0** | C2: Brain 写操作两阶段确认 + 撤销栈 | 防止静默降级 | 1.5 天 | ✅ 已修 |
| **P0** | C3: 流式时用 tiktoken 估算 tokens 回填 | 解决配额/成本失真 | 1 天 | ✅ 已修 |
| **P1** | C4: cloudChat 走简化路径（跳过 judge/shadow） | 避免重复调用 | 0.5 天 | ⏳ 待评估 |
| **P1** | H1: compressionVariant 加所有参数 | 修复缓存键不全 | 0.5 天 | ✅ 已修 |
| **P1** | H2: 语义缓存也加 variant | 修复语义缓存串味 | 0.5 天 | ✅ 已修 |
| **P1** | H3: selectProviders 区分"零匹配"和"全过滤" | 错误信息可定位 | 0.3 天 | ✅ 已修 |
| **P1** | H4: Brain 工具白名单 + 最小变更原则 | 防止单次决策批量改配置 | 0.5 天 | ✅ 已修 |
| **P1** | H5: 配额用量内存累加 + 原子写 | 解决写盘抖动/损坏 | 1 天 | ✅ 已修 |
| **P1** | H6: 流式入口也触发 autoWake | 修复长空闲后第一个流式失败 | 0.2 天 | ✅ 已修 |
| **P2** | M1: 健康检测恢复 Key 加乐观锁 CAS | 防止误恢复坏 Key | 0.3 天 | ✅ 已修 |
| **P2** | M2: shadow runner 改用真实 max_tokens | 让一致性指标可用 | 0.5 天 | ✅ 已修 |
| **P2** | M3: promptCacheAffinity 失败时清除+LRU | 防止雪崩 | 0.2 天 | ✅ 已修 |
| **P1** | M6: 同渠道多 Key 报错时换 Key 重试（穷尽模式） | 不浪费 Key | 0.4 天 | ✅ 已修 |
| **P2** | M4: remote:migrate 导出含 API Key 加审计/限流 | 防止导出被滥用 | 0.3 天 | ✅ 已修 |
| **P3** | M5: tracer.write 失败降级 + IPC 状态端点 | 防止日志丢失导致状态黑盒 | 0.3 天 | ✅ 已修 |
| **P3** | L1-L3 | 增强 UI 透明度 | 各 0.2 天 | ⏳ 待修 |

---

## 总结

本报告揭示 18 个功能间交互漏洞，相比单点安全审计（17 个），这些漏洞的特点是：

- **触发更隐蔽**：往往是「正常路径 + 特定配置组合」触发，单元测试难以覆盖
- **后果更隐晦**：行为偏差而非崩溃，监控/告警难以及时发现
- **修复成本更低**：大部分是局部代码改动

最值得优先处理的三件事：
1. **C1 缓存串味**（跨用户/跨会话响应错乱）
2. **C2 Brain 静默修改配置**（可被 prompt 注入）
3. **C3 流式 token 计量失真**（配额/成本永久低估）

整体而言，项目的「功能模块独立性」做得不错，但「跨模块数据流」缺乏统一约束——缓存键/trace/quota 这些共享状态被多个模块读写，状态机不完整、缺乏事务保证。建议下一轮迭代把"数据契约"梳理一下（明确每个字段由谁写入、谁读取、谁验证），并对关键路径（路由/缓存/配额/trace）加端到端集成测试。

