// v2.2.6：app.js 内联样式白字 → 深色（浅色主题）
const fs = require('fs');

const file = 'renderer/app.js';
let src = fs.readFileSync(file, 'utf8');
const before = src;

// 1. color: rgba(255,255,255,0.X) → 深色对应透明度
const MAP = {
  '0.95': '0.95', '0.9': '0.92', '0.88': '0.9', '0.86': '0.88', '0.85': '0.88',
  '0.8': '0.85', '0.75': '0.8', '0.72': '0.78', '0.7': '0.75', '0.65': '0.7',
  '0.6': '0.65', '0.55': '0.6', '0.5': '0.55', '0.45': '0.5', '0.4': '0.5',
  '0.3': '0.45'
};
src = src.replace(/color:\s*rgba\(255,\s*255,\s*255,\s*0\.(\d+)\)/g, (m, d) => {
  const repl = MAP['0.' + d];
  if (!repl) return m;
  return m.replace(/255,\s*255,\s*255,\s*0\.(\d+)\)$/, '31, 41, 55, ' + repl + ')');
});

// 2. 内联 color: var(--white) → var(--text-main)
src = src.split('color: var(--white);').join('color: var(--text-main);');

fs.writeFileSync(file, src, 'utf8');
console.log('inline white -> dark done. 剩余白色内联:', (src.match(/color:\s*rgba\(255,\s*255,\s*255/g) || []).length, '处');
